#if UNITY_EDITOR
using System;
using System.IO;
using BurgerEmpire.Unity;
using UnityEditor;
using UnityEngine;

namespace BurgerEmpire.Editor
{
    // Local diagnostic files allow reproducible checks without depending on Editor.log.
    [InitializeOnLoad]
    public static class BurgerEmpireDiagnostics
    {
        static double nextWrite;
        static BurgerEmpireDiagnostics()
        {
            EditorApplication.update+=Update;
            Application.logMessageReceived+=Log;
        }
        static void Update()
        {
            if(!EditorApplication.isPlaying || EditorApplication.timeSinceStartup<nextWrite)return;
            nextWrite=EditorApplication.timeSinceStartup+2;
            var game=UnityEngine.Object.FindFirstObjectByType<BurgerEmpireGame>();
            if(game==null||game.Sim==null)return;
            try {File.WriteAllText(Path.GetFullPath("BurgerEmpireLiveState.json"),JsonUtility.ToJson(game.Sim.View(),true));}
            catch(IOException) { }
        }
        static void Log(string message,string stack,LogType type)
        {
            if(type!=LogType.Error && type!=LogType.Exception && type!=LogType.Assert)return;
            try {File.AppendAllText(Path.GetFullPath("BurgerEmpireErrors.log"),DateTime.Now.ToString("O")+" "+message+"\n"+stack+"\n");}
            catch(IOException) { }
        }
    }
}
#endif
