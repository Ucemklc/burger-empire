#if UNITY_EDITOR
using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.Build;
using UnityEngine;

namespace BurgerEmpire.Editor
{
    [InitializeOnLoad]
    public static class BurgerEmpireStoreArt
    {
        public const string Folder="Assets/BurgerEmpire/Branding";
        public const string Output="BurgerEmpireStoreArt-0.30";
        const string Report="BurgerEmpireStoreArtChecks.txt";
        static BurgerEmpireStoreArt(){EditorApplication.update+=Update;}
        static void Update()
        {
            if(EditorApplication.isCompiling||EditorApplication.isUpdating||EditorApplication.isPlayingOrWillChangePlaymode||!File.Exists("BurgerEmpireStoreArtChecks.request"))return;
            File.Delete("BurgerEmpireStoreArtChecks.request");File.WriteAllText(Report,"");
            try{Prepare();File.AppendAllText(Report,"Completed. Platform art exported and icons assigned; no APK or store upload.\n");}
            catch(Exception e){File.AppendAllText(Report,"FAIL: "+e+"\n");}
        }
        static void Check(bool good,string text)
        {File.AppendAllText(Report,(good?"PASS: ":"FAIL: ")+text+"\n");if(!good)throw new Exception(text);}
        static Texture2D Read(string path)
        {var t=new Texture2D(2,2,TextureFormat.RGBA32,false);if(!t.LoadImage(File.ReadAllBytes(path)))throw new IOException(path);return t;}
        static void Write(Texture2D t,string path){File.WriteAllBytes(path,t.EncodeToPNG());}
        static readonly Color Back=new Color32(28,76,46,255);
        static Texture2D RenderIcon(Texture2D source,int size,float scale,bool background)
        {
            var output=new Texture2D(size,size,TextureFormat.RGBA32,false);var pixels=new Color[size*size];
            for(int y=0;y<size;y++)for(int x=0;x<size;x++) {
                float u=((x+.5f)/size-.5f)/scale+.5f,v=((y+.5f)/size-.5f)/scale+.5f;
                Color c=u<0||u>1||v<0||v>1?Color.clear:source.GetPixelBilinear(u,v);
                if(background){float a=c.a;c=Color.Lerp(Back,c,a);c.a=1;}
                pixels[y*size+x]=c;
            }
            output.SetPixels(pixels);output.Apply();return output;
        }
        static Texture2D Import(string path)
        {
            AssetDatabase.ImportAsset(path,ImportAssetOptions.ForceSynchronousImport);
            var importer=(TextureImporter)AssetImporter.GetAtPath(path);importer.textureType=TextureImporterType.Default;
            importer.mipmapEnabled=false;importer.alphaIsTransparency=true;importer.textureCompression=TextureImporterCompression.Uncompressed;
            importer.maxTextureSize=2048;importer.isReadable=false;importer.SaveAndReimport();
            return AssetDatabase.LoadAssetAtPath<Texture2D>(path);
        }
        public static void Prepare()
        {
            Directory.CreateDirectory(Output);
            byte[] save=File.ReadAllBytes("BurgerEmpireSave.json");
            string package=PlayerSettings.GetApplicationIdentifier(NamedBuildTarget.Android);bool signing=PlayerSettings.Android.useCustomKeystore;
            var source=Read(Folder+"/CrownedBurger-0.29.png");
            var colors=source.GetPixels();
            Check(source.width==source.height&&colors.Any(c=>c.a==0)&&colors.Any(c=>c.a>.99f),"Generated foreground is square and has genuine alpha transparency");
            float radius=0;
            for(int y=0;y<source.height;y++)for(int x=0;x<source.width;x++)if(colors[y*source.width+x].a>.01f)
                radius=Mathf.Max(radius,new Vector2((x+.5f)/source.width-.5f,(y+.5f)/source.height-.5f).magnitude);
            float adaptiveScale=Mathf.Min(1,.295f/radius);
            var foreground=RenderIcon(source,432,adaptiveScale,false);Write(foreground,Folder+"/Icon-Foreground-0.29.png");
            var background=new Texture2D(432,432,TextureFormat.RGBA32,false);background.SetPixels(Enumerable.Repeat(Back,432*432).ToArray());background.Apply();Write(background,Folder+"/Icon-Background-0.29.png");
            var legacy=RenderIcon(source,512,1,true);Write(legacy,Folder+"/Icon-Store-0.29.png");Write(legacy,Output+"/Icon-512.png");
            Check(legacy.width==512&&legacy.height==512&&legacy.GetPixels().All(c=>c.a==1)&&new FileInfo(Output+"/Icon-512.png").Length<1024*1024,"Store icon is 512x512 RGBA PNG, opaque, and under 1 MiB");
            Check(foreground.GetPixels().Where((c,i)=>new Vector2((i%432+.5f)/432-.5f,(i/432+.5f)/432-.5f).magnitude>.3055f).All(c=>c.a<.01f),"Adaptive emblem fits the central safe circle, including its crown");
            var fg=Import(Folder+"/Icon-Foreground-0.29.png");var bg=Import(Folder+"/Icon-Background-0.29.png");var full=Import(Folder+"/Icon-Store-0.29.png");
            PlayerSettings.SetIcons(NamedBuildTarget.Unknown,new[]{full},IconKind.Any);
            int slots=0,layered=0;
            foreach(var kind in PlayerSettings.GetSupportedIconKinds(NamedBuildTarget.Android)) {
                var icons=PlayerSettings.GetPlatformIcons(NamedBuildTarget.Android,kind);
                foreach(var icon in icons) {
                    if(icon.minLayerCount>=2){icon.SetTexture(bg,0);icon.SetTexture(fg,1);layered++;}
                    else icon.SetTexture(full,0);
                    slots++;
                }
                PlayerSettings.SetPlatformIcons(NamedBuildTarget.Android,kind,icons);
            }
            AssetDatabase.SaveAssets();
            Check(slots>0&&layered>0,"Assigned all "+slots+" Android icon slots, including "+layered+" adaptive slots");
            bool complete=true;
            foreach(var kind in PlayerSettings.GetSupportedIconKinds(NamedBuildTarget.Android))foreach(var icon in PlayerSettings.GetPlatformIcons(NamedBuildTarget.Android,kind))
                for(int layer=0;layer<icon.minLayerCount;layer++)complete&=icon.GetTexture(layer)!=null;
            Check(complete,"Every required Android icon layer reads back with an assigned texture");
            // Mechanical export to the store's exact dimensions; source illustration is unchanged.
            var bannerSource=Read(Folder+"/FeatureGraphic-Source-0.29.png");var banner=new Texture2D(1024,500,TextureFormat.RGB24,false);
            for(int y=0;y<500;y++)for(int x=0;x<1024;x++)banner.SetPixel(x,y,bannerSource.GetPixelBilinear((x+.5f)/1024,(y+.5f)/500));
            banner.Apply();Write(banner,Output+"/Feature-1024x500.png");
            Check(banner.width==1024&&banner.height==500&&banner.format==TextureFormat.RGB24,"Feature graphic exports as exact 1024x500 RGB PNG without alpha");
            // Preview launcher masks using the same two assigned layers, without changing source art.
            var preview=RenderIcon(source,432,adaptiveScale,true);
            foreach(string shape in new[]{"circle","square"}) {
                var masked=new Texture2D(432,432,TextureFormat.RGBA32,false);
                for(int y=0;y<432;y++)for(int x=0;x<432;x++) {
                    float u=((x+.5f)/432-.5f)*3,v=((y+.5f)/432-.5f)*3;
                    bool outside=shape=="circle"?u*u+v*v>1:Mathf.Max(Mathf.Abs(u),Mathf.Abs(v))>1;
                    masked.SetPixel(x,y,outside?Color.clear:preview.GetPixel(x,y));
                }
                masked.Apply();Write(masked,Output+"/Adaptive-"+shape+"-preview.png");UnityEngine.Object.DestroyImmediate(masked);
            }
            Check(save.SequenceEqual(File.ReadAllBytes("BurgerEmpireSave.json"))&&package==PlayerSettings.GetApplicationIdentifier(NamedBuildTarget.Android)&&signing==PlayerSettings.Android.useCustomKeystore,"Art setup preserves real progress, package identity and signing choice");
            foreach(var t in new[]{source,foreground,background,legacy,bannerSource,banner,preview})UnityEngine.Object.DestroyImmediate(t);
        }
    }
}
#endif
