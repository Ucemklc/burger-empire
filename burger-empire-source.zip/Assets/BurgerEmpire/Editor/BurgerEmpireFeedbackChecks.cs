#if UNITY_EDITOR && ENABLE_INPUT_SYSTEM
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using BurgerEmpire.Core;
using BurgerEmpire.Unity;
using UnityEditor;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.LowLevel;
using UnityEngine.UI;
using Progress=BurgerEmpire.Core.Progress;

namespace BurgerEmpire.Editor
{
    [InitializeOnLoad]
    public static class BurgerEmpireFeedbackChecks
    {
        const string Pending="BurgerEmpire.FeedbackChecks",Report="BurgerEmpireFeedbackChecks.txt";
        static IEnumerator<float> steps;
        static double next;
        static int nextFrame;
        static BurgerEmpireGame game;
        static Simulation original;
        static string disk;
        static bool originalSound,hadSoundPreference;
        static int lastEvent;
        static Touchscreen touch;
        static InputSettings.BackgroundBehavior background;
        static InputSettings.EditorInputBehaviorInPlayMode routing;
        static BurgerEmpireFeedbackChecks(){EditorApplication.update+=Update;}
        static void Update()
        {
            if(EditorApplication.isCompiling||EditorApplication.isUpdating)return;
            if(File.Exists("BurgerEmpireFeedbackChecks.request")) {
                try {File.Delete("BurgerEmpireFeedbackChecks.request");} catch(IOException){return;}
                File.WriteAllText(Report,"");SessionState.SetBool(Pending,true);nextFrame=0;
                if(!EditorApplication.isPlaying){BurgerEmpireSetup.Play();return;}
            }
            if(!EditorApplication.isPlaying||!SessionState.GetBool(Pending,false)||EditorApplication.timeSinceStartup<next||Time.frameCount<nextFrame)return;
            try {
                if(steps==null) {
                    game=UnityEngine.Object.FindFirstObjectByType<BurgerEmpireGame>();if(!game||game.Sim==null)return;
                    original=game.Sim;originalSound=game.SoundEnabled;hadSoundPreference=PlayerPrefs.HasKey("BurgerEmpire.Sound");disk=File.ReadAllText("BurgerEmpireSave.json");game.ValidationActive=true;
                    lastEvent=(int)typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).GetValue(game);
                    background=InputSystem.settings.backgroundBehavior;InputSystem.settings.backgroundBehavior=InputSettings.BackgroundBehavior.IgnoreFocus;
                    routing=InputSystem.settings.editorInputBehaviorInPlayMode;InputSystem.settings.editorInputBehaviorInPlayMode=InputSettings.EditorInputBehaviorInPlayMode.AllDeviceInputAlwaysGoesToGameView;
                    touch=InputSystem.AddDevice<Touchscreen>();steps=Run();
                }
                if(steps.MoveNext()){next=EditorApplication.timeSinceStartup+steps.Current;nextFrame=Time.frameCount+3;}else Finish();
            } catch(Exception e){File.AppendAllText(Report,"FAIL: "+e+"\n");Finish();}
        }
        static void SetSimulation(Simulation value)
        {
            typeof(BurgerEmpireGame).GetProperty("Sim").SetValue(game,value);
            typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game,0);
            typeof(RestaurantHud).GetField("toastTime",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game.Hud,0f);
        }
        static void Finish()
        {
            if(touch!=null){InputSystem.RemoveDevice(touch);touch=null;}InputSystem.settings.backgroundBehavior=background;InputSystem.settings.editorInputBehaviorInPlayMode=routing;
            if(game&&original!=null) {
                if(game.LayoutEditor.Active)game.Hud.FinishLayout(false);
                Audio.SetVolumes(game.MusicVolume,game.EffectsVolume);game.SetSound(originalSound);if(!hadSoundPreference){PlayerPrefs.DeleteKey("BurgerEmpire.Sound");PlayerPrefs.Save();}
                SetSimulation(original);original.Paused=true;game.ValidationActive=false;game.Save();game.Hud.OpenPanel("Menü");
                typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game,lastEvent);
            }
            steps=null;original=null;nextFrame=0;SessionState.SetBool(Pending,false);
        }
        static Progress Fixture()
        {
            var p=JsonUtility.FromJson<Progress>(JsonUtility.ToJson(original.P));
            p.coins=3000;p.xp=700;p.grill=2;p.fryer=1;p.blender=0;p.doubleBurger=0;p.cheese=1;p.mission=5;p.tutorialDone=true;
            p.shakeSold=p.doubleSold=0;return p;
        }
        static void Check(bool good,string message)
        {File.AppendAllText(Report,(good?"PASS: ":"FAIL: ")+message+"\n");if(!good)throw new Exception(message);}
        static Button Find(string name){return UnityEngine.Object.FindObjectsByType<Button>(FindObjectsSortMode.None).First(b=>b.name==name&&b.gameObject.activeInHierarchy);}
        static Vector2 Center(RectTransform rt){return RectTransformUtility.WorldToScreenPoint(null,rt.TransformPoint(rt.rect.center));}
        static void Touch(Vector2 p,UnityEngine.InputSystem.TouchPhase phase)
        {InputSystem.QueueStateEvent(touch,new TouchState{touchId=1,position=p,phase=phase});}
        static bool Until(Func<bool> condition,int limit=1000)
        {
            game.Sim.Paused=false;
            for(int i=0;i<limit&&!condition();i++){if(game.Sim.Actors[0].job=="")game.Sim.Command("next");game.Sim.Tick(.1f);}
            game.Sim.Paused=true;return condition();
        }

        const System.Reflection.BindingFlags Private=System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic;
        static RestaurantAudio Audio=>(RestaurantAudio)typeof(BurgerEmpireGame).GetField("restaurantAudio",Private).GetValue(game);
        static Text ToastText=>(Text)typeof(RestaurantHud).GetField("toast",Private).GetValue(game.Hud);
        static FoodIconGraphic ToastIcon=>(FoodIconGraphic)typeof(RestaurantHud).GetField("toastIcon",Private).GetValue(game.Hud);
        static AudioSource Source(string name)=>game.transform.Find(name).GetComponent<AudioSource>();
        static IEnumerator<float> Run()
        {
            BurgerEmpireMobileChecks.SetSize(2340,1080);yield return .6f;
            if(game.LayoutEditor.Active)game.Hud.FinishLayout(false);
            if(game.Hud.BlocksWorldInput)game.Hud.ClosePanel();
            SetSimulation(new Simulation(new Progress{tutorialDone=true,coins=3000,xp=900}));game.SetSound(true);Audio.SetVolumes(.55f,1);yield return .2f;
            var clips=(Dictionary<string,AudioClip>)typeof(RestaurantAudio).GetField("clips",Private).GetValue(Audio);
            Check(clips.Count==11&&clips.All(p=>p.Value.channels==1&&p.Value.frequency==22050&&p.Value.loadState==AudioDataLoadState.Loaded),"Eleven mono clips load with supported PCM data");
            Check(game.GetComponentsInChildren<AudioSource>().Length==4&&game.GetComponentsInChildren<AudioSource>().All(s=>!s.playOnAwake&&s.spatialBlend==0),"Four reusable audio sources include the music voice; none autoplays");
            foreach(var kind in new[]{"order","ready","happy","coin","clean","upgrade","bad","vip"}) {
                Audio.Reset();int before=Audio.PlayedCues;Check(Audio.Play(kind),kind+": distinct cue accepted");yield return .04f;
                Check(Audio.LastCue==kind&&Source("Restaurant effects").clip==clips[kind]&&Audio.PlayedCues==before+1,kind+": assigned correct clip to effect voice");
            }
            Audio.Reset();Check(Audio.Play("coin")&&!Audio.Play("coin")&&!Audio.Play("order"),"Immediate repeated and lower-priority cues cannot stack");
            Check(Audio.Play("bad")&&Audio.LastCue=="bad","Warning replaces a minor cue immediately");
            Audio.Reset();game.Sim.Events.Clear();typeof(BurgerEmpireGame).GetField("lastEvent",Private).SetValue(game,0);
            game.Sim.Events.Add(new BurgerEmpire.Core.Event{id=201,kind="upgrade",text="Yeni mutfak hazır!"});
            game.Sim.Events.Add(new BurgerEmpire.Core.Event{id=202,kind="clean",text="Temiz masa"});yield return .18f;
            Check(Audio.LastCue=="upgrade"&&ToastText.text=="Yeni mutfak hazır!"&&ToastIcon.Kind=="crown","Frame coalescing presents upgrade instead of a newer routine message");
            int consumed=Audio.PlayedCues;yield return .25f;
            Check(Audio.PlayedCues==consumed&&(int)typeof(BurgerEmpireGame).GetField("lastEvent",Private).GetValue(game)==202,"All events in the batch are consumed once");
            game.Hud.Toast("Rutinde temizlik","clean");Check(ToastText.text=="Yeni mutfak hazır!","Important toast remains readable through immediate routine activity");
            game.Hud.Toast("Elle seçilen işlem bilgisi");Check(ToastText.text=="Elle seçilen işlem bilgisi","Explicit player response is never hidden by a previous upgrade toast");
            game.Sim.Paused=false;
            game.Sim.Customers.Add(new Customer{id=700,phase="waiting",order="cooking",station="grill",table=0,x=2.3f,z=5.95f,patience=1000,maxPatience=1000,cookTime=1000});
            game.Sim.Customers.Add(new Customer{id=701,phase="waiting",order="cooking",station="blender",table=1,x=6,z=5.95f,patience=1000,maxPatience=1000,cookTime=1000});yield return .2f;
            Check(Source("Grill ambience").isPlaying&&Source("Blender ambience").isPlaying,"Active burger and drink production start both quiet kitchen loops");
            game.Command("pause");yield return .1f;
            Check(!Source("Grill ambience").isPlaying&&!Source("Blender ambience").isPlaying,"Pausing silences both kitchen loops");
            game.Sim.Paused=false;yield return .1f;game.Hud.OpenPanel("Menü");
            Check(!Source("Grill ambience").isPlaying&&!Source("Blender ambience").isPlaying,"Opening a management panel immediately silences the kitchen");
            game.Hud.ClosePanel();yield return .1f;
            Check(Source("Grill ambience").isPlaying&&Source("Blender ambience").isPlaying,"Returning to an active shift restores only its working stations");
            var toggle=UnityEngine.Object.FindObjectsByType<Button>(FindObjectsSortMode.None).First(b=>b.gameObject.activeInHierarchy&&b.GetComponentInChildren<Text>()?.text=="SES");
            var point=Center(toggle.GetComponent<RectTransform>());Touch(point,UnityEngine.InputSystem.TouchPhase.Began);yield return .1f;Touch(point,UnityEngine.InputSystem.TouchPhase.Ended);yield return .15f;
            Check(!game.SoundEnabled&&PlayerPrefs.GetInt("BurgerEmpire.Sound")==0&&game.GetComponentsInChildren<AudioSource>().All(s=>!s.isPlaying),"Real touch mutes every source and persists the existing sound preference");
            consumed=Audio.PlayedCues;game.Hud.Toast("Sipariş hazır!","ready");Audio.Play("ready");yield return .15f;
            Check(Audio.PlayedCues==consumed&&ToastText.text=="Sipariş hazır!"&&ToastIcon.Kind=="check","Muted play retains the visual message and icon without playing a cue");
            game.Sim.Paused=true;
            toggle=UnityEngine.Object.FindObjectsByType<Button>(FindObjectsSortMode.None).First(b=>b.gameObject.activeInHierarchy&&b.GetComponentInChildren<Text>()?.text=="SESSİZ");
            point=Center(toggle.GetComponent<RectTransform>());Touch(point,UnityEngine.InputSystem.TouchPhase.Began);yield return .1f;Touch(point,UnityEngine.InputSystem.TouchPhase.Ended);yield return .12f;
            Check(game.SoundEnabled&&PlayerPrefs.GetInt("BurgerEmpire.Sound")==1&&!Source("Grill ambience").isPlaying&&!Source("Blender ambience").isPlaying,"Touch reenables sound while paused without starting kitchen ambience");
            game.Sim.Paused=false;yield return .1f;game.Sim.Customers[0].order="ready";yield return .1f;
            Check(!Source("Grill ambience").isPlaying&&Source("Blender ambience").isPlaying,"Finishing grill production stops only that station's loop");
            game.Suspend();Check(game.Sim.Paused&&game.GetComponentsInChildren<AudioSource>().All(s=>!s.isPlaying),"Backgrounding stops effect and loop sources immediately");
            SetSimulation(new Simulation(new Progress{tutorialDone=true,londonOpen=true,london=new RestaurantProgress{tutorialDone=true},blender=1}));yield return .1f;
            Audio.Play("vip");game.Sim.SwitchBranch(1,out _);yield return .1f;
            Check(game.Sim.P.activeBranch==1&&game.GetComponentsInChildren<AudioSource>().All(s=>!s.isPlaying),"Changing city clears the previous branch's sounds");
            foreach(string kind in new[]{"ready","coin","bad","upgrade"}) {
                typeof(RestaurantHud).GetField("toastTime",Private).SetValue(game.Hud,0f);game.Hud.Toast(kind=="ready"?"Tavuk Burger Menü hazır!":kind=="coin"?"+62 coin · 12 bahşiş":kind=="bad"?"Bekleme çok uzundu…":"Yeni tarif açıldı!",kind);yield return .05f;
                Check(ToastIcon.Kind==FeedbackSignals.Icon(kind)&&!ToastIcon.raycastTarget&&ToastIcon.GetComponent<RectTransform>().rect.width==20,kind+": compact nonblocking feedback icon");
            }
            typeof(RestaurantHud).GetField("toastTime",Private).SetValue(game.Hud,0f);game.Hud.Toast("Sipariş hazır!","ready");
            CheckToastBounds();ScreenCapture.CaptureScreenshot("BurgerEmpire-0.20-Feedback.png");yield return .2f;
            BurgerEmpireMobileChecks.SetSize(1080,2340);yield return .5f;CheckToastBounds();
            Check(ToastIcon.Kind=="check","Rotation preserves feedback meaning");ScreenCapture.CaptureScreenshot("BurgerEmpire-0.20-Feedback-Portrait.png");yield return .2f;
            BurgerEmpireMobileChecks.SetSize(2340,1080);yield return .4f;
            ExportPreview(clips);
            game.Save();Check(File.ReadAllText("BurgerEmpireSave.json")==disk,"Audio, touch and feedback tests never overwrite the player's progress");
            File.AppendAllText(Report,"Completed. PCM, Unity audio-source state, touch mute, pause, background and branch behavior verified. Physical phone speakers not tested.\n");
        }
        static void CheckToastBounds()
        {
            var card=(Image)typeof(RestaurantHud).GetField("toastBackground",Private).GetValue(game.Hud);var points=new Vector3[4];card.rectTransform.GetWorldCorners(points);
            Check(card.rectTransform.rect.height==42&&!card.raycastTarget&&Screen.safeArea.Contains(points[0])&&Screen.safeArea.Contains(points[2]),"Feedback keeps its existing 42-pixel strip inside the safe screen area");
            Check(ToastText.preferredHeight<=ToastText.rectTransform.rect.height+2,"Feedback text fits without covering action buttons");
        }
        static void ExportPreview(Dictionary<string,AudioClip> clips)
        {
            var samples=new List<float>();
            foreach(var kind in new[]{"order","ready","happy","coin","clean","upgrade","bad","vip"}){var data=new float[clips[kind].samples];clips[kind].GetData(data,0);samples.AddRange(data.Select(v=>v*.4f));samples.AddRange(new float[11025]);}
            using(var writer=new BinaryWriter(File.Create("BurgerEmpire-0.20-Sound-Preview.wav"))) {
                writer.Write(System.Text.Encoding.ASCII.GetBytes("RIFF"));writer.Write(36+samples.Count*2);writer.Write(System.Text.Encoding.ASCII.GetBytes("WAVEfmt "));writer.Write(16);writer.Write((short)1);writer.Write((short)1);writer.Write(22050);writer.Write(44100);writer.Write((short)2);writer.Write((short)16);writer.Write(System.Text.Encoding.ASCII.GetBytes("data"));writer.Write(samples.Count*2);
                foreach(var sample in samples)writer.Write((short)(sample*32767));
            }
        }
        static void CheckBounds(string label)
        {
            var safe=Screen.safeArea;var corners=new Vector3[4];
            foreach(var button in UnityEngine.Object.FindObjectsByType<Button>(FindObjectsSortMode.None).Where(b=>b.gameObject.activeInHierarchy)) {
                var rt=button.GetComponent<RectTransform>();rt.GetWorldCorners(corners);
                // Only visible controls; clipped scrolling cards are intentionally outside the viewport.
                if(corners[2].y<safe.yMin||corners[0].y>safe.yMax)continue;
                Check(rt.rect.height>=48&&corners[0].x>=safe.xMin-1&&corners[2].x<=safe.xMax+1,label+": "+button.name+" touch size and horizontal bounds");
            }
        }
    }
}
#endif
