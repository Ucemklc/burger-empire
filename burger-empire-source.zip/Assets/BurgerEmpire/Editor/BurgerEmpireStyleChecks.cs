#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using BurgerEmpire.Core;
using BurgerEmpire.Unity;
using UnityEditor;
using UnityEngine;
using Progress=BurgerEmpire.Core.Progress;

namespace BurgerEmpire.Editor
{
    [InitializeOnLoad]
    public static class BurgerEmpireStyleChecks
    {
        const string Pending="BurgerEmpire.StyleChecks",Report="BurgerEmpireStyleChecks.txt";
        const BindingFlags Private=BindingFlags.Instance|BindingFlags.NonPublic;
        static IEnumerator<float> steps;
        static double next;
        static int nextFrame,lastEvent;
        static BurgerEmpireGame game;
        static Simulation original;
        static string disk;
        static BurgerEmpireStyleChecks(){EditorApplication.update+=Update;}
        static void Update()
        {
            if(EditorApplication.isCompiling||EditorApplication.isUpdating)return;
            if(File.Exists("BurgerEmpireStyleChecks.request")) {
                try{File.Delete("BurgerEmpireStyleChecks.request");}catch(IOException){return;}
                File.WriteAllText(Report,"");SessionState.SetBool(Pending,true);nextFrame=0;
                if(!EditorApplication.isPlaying){BurgerEmpireSetup.Play();return;}
            }
            if(!EditorApplication.isPlaying||!SessionState.GetBool(Pending,false)||EditorApplication.timeSinceStartup<next||Time.frameCount<nextFrame)return;
            try {
                if(steps==null) {
                    game=UnityEngine.Object.FindFirstObjectByType<BurgerEmpireGame>();if(!game||game.Sim==null)return;
                    original=game.Sim;disk=File.ReadAllText("BurgerEmpireSave.json");game.ValidationActive=true;
                    lastEvent=(int)typeof(BurgerEmpireGame).GetField("lastEvent",Private).GetValue(game);steps=Run();
                }
                if(steps.MoveNext()){next=EditorApplication.timeSinceStartup+steps.Current;nextFrame=Time.frameCount+3;}else Finish();
            }catch(Exception e){File.AppendAllText(Report,"FAIL: "+e+"\n");Finish();}
        }
        static void SetSimulation(Simulation sim)
        {
            typeof(BurgerEmpireGame).GetProperty("Sim").SetValue(game,sim);
            typeof(BurgerEmpireGame).GetField("lastEvent",Private).SetValue(game,0);
            typeof(RestaurantHud).GetField("toastTime",Private).SetValue(game.Hud,0f);
        }
        static void Finish()
        {
            if(game&&original!=null){SetSimulation(original);original.Paused=true;game.ValidationActive=false;game.Save();typeof(BurgerEmpireGame).GetField("lastEvent",Private).SetValue(game,lastEvent);}
            original=null;steps=null;nextFrame=0;SessionState.SetBool(Pending,false);
        }
        static void Check(bool passed,string label)
        {File.AppendAllText(Report,(passed?"PASS: ":"FAIL: ")+label+"\n");if(!passed)throw new Exception(label);}
        static IEnumerator<float> Run()
        {
            BurgerEmpireMobileChecks.SetSize(2340,1080);yield return .4f;
            if(game.LayoutEditor.Active)game.Hud.FinishLayout(false);
            if(game.Hud.BlocksWorldInput)game.Hud.ClosePanel();
            var sim=new Simulation(new Progress{tutorialDone=true,served=40,coins=2500,xp=2000,tables=4,grill=3,cashier=2,cook=2,waiter=2,cleaner=2,manager=1,blender=2,driveThru=2,delivery=2,decor=1});SetSimulation(sim);yield return .3f;
            var world=GameObject.Find("Restaurant Environment").transform;
            var mesh=StyleGeometry.SoftBox;
            Check(mesh.vertexCount==96&&mesh.triangles.Length/3==108,"Furniture shares a bounded 96-vertex rounded mesh");
            Check(Vector3.Distance(mesh.bounds.size,Vector3.one)<.0001f&&mesh.vertices.All(v=>Mathf.Abs(v.x)<=.501f&&Mathf.Abs(v.y)<=.501f&&Mathf.Abs(v.z)<=.501f),"Rounded furniture stays inside the original cube bounds");
            bool outward=true;var v=mesh.vertices;var t=mesh.triangles;
            for(int i=0;i<t.Length;i+=3)outward&=Vector3.Dot(Vector3.Cross(v[t[i+1]]-v[t[i]],v[t[i+2]]-v[t[i]]),(v[t[i]]+v[t[i+1]]+v[t[i+2]])/3)>0;
            Check(outward,"Bevel faces point outward without inverted triangles");
            Check(world.Find("Table_0/Oak top").GetComponent<MeshFilter>().sharedMesh==mesh&&world.Find("Table_3/Oak top").GetComponent<MeshFilter>().sharedMesh==mesh,"Existing saved scene tables receive the same shared mesh");
            var finishes=world.Find("Restaurant finishes");Check(finishes&&finishes.Find("Kitchen backsplash").childCount==48,"Saved scene receives ceramic kitchen backsplash");
            Check(finishes.GetComponentsInChildren<Collider>(true).Length==0,"Surface decorations add no floor obstacles or touch colliders");
            int count=world.GetComponentsInChildren<Transform>(true).Length;RestaurantFinishes.Apply(world);
            Check(world.GetComponentsInChildren<Transform>(true).Length==count,"Applying finishes twice cannot duplicate furniture details");
            Check(Enumerable.Range(0,4).All(i=>world.Find("Table_"+i+"/Furniture finish")),"All purchased and future tables have upholstery and table settings");
            Check(UnityEngine.Object.FindObjectsByType<Light>(FindObjectsSortMode.None).Count(l=>l.type==LightType.Directional)==1,"Visual update reuses one directional light");
            var stage=new GameObject("Style gallery").transform;
            try {
                var worker=RestaurantArt.BuildPerson("waiter",0,stage);worker.UpdatePosition(50,0,2,false,false,"",Vector3.back);
                Check(!worker.root.Find("Cap").gameObject.activeSelf&&worker.root.Find("Bow tie")&&worker.root.Find("Swept hair"),"Waiter uses swept hair, white shirt and red bow tie");
                var manager=RestaurantArt.BuildPerson("manager",0,stage);manager.UpdatePosition(52,0,2,false);
                Check(manager.root.Find("Open glasses").childCount==9&&!manager.root.Find("Glasses").gameObject.activeSelf,"Manager glasses show the eyes through an open frame");
                var cashier=RestaurantArt.BuildPerson("cashier",0,stage);Check(cashier.root.Find("Staff ponytail")&&cashier.root.Find("Crown emblem"),"Cashier has tied hair and a crown apron emblem");
                var guest=RestaurantArt.BuildPerson("customer",1,stage);guest.UpdatePosition(54,0,2,false,true,"waiting");
                var happy=guest.root.Find("Eyebrow").localRotation;guest.UpdatePosition(54,0,2.1f,false,true,"impatient");
                Check(!guest.root.Find("Smile teeth").gameObject.activeSelf&&Quaternion.Angle(happy,guest.root.Find("Eyebrow").localRotation)>20,"Low patience changes brows and mouth as well as the pose");
                guest.UpdatePosition(54,0,2.2f,false,true,"waiting");Check(guest.root.Find("Smile teeth").gameObject.activeSelf,"Facial expression recovers after impatient state");
                guest.details.Pose(4.6f-.57f+.08f,"waiting");float shut=guest.root.Find("Eye").localScale.y;
                guest.details.Pose(4.6f-.57f+.30f,"waiting");Check(guest.root.Find("Eye").localScale.y>shut*5,"Blink closes and reopens the eyes using simulation time");
                guest.UpdatePosition(54,0,2.4f,false,true,"eating");var scales=guest.root.GetComponentsInChildren<Transform>().Select(x=>x.localScale).ToArray();guest.UpdatePosition(54,0,2.4f,false,true,"eating");
                Check(scales.SequenceEqual(guest.root.GetComponentsInChildren<Transform>().Select(x=>x.localScale)),"Paused faces and eyes remain exactly frozen");
                Check(worker.food.Find("Red cup").GetComponent<MeshFilter>().sharedMesh==StyleGeometry.Cup,"Drinks reuse the tapered cup mesh");
                foreach(Transform child in stage)child.gameObject.SetActive(false);
                CaptureGallery(stage,false);CaptureGallery(stage,true);
            } finally {UnityEngine.Object.Destroy(stage.gameObject);}
            for(int i=0;i<1400;i++){sim.Paused=false;sim.Tick(.1f);sim.Paused=true;if(i%100==0)yield return .01f;}
            Check(sim.P.served>42&&sim.P.cleaned>0,"Restyled scene continues normal service and cleanup");yield return .3f;
            typeof(RestaurantHud).GetField("toastTime",Private).SetValue(game.Hud,0f);yield return .1f;
            ScreenCapture.CaptureScreenshot("BurgerEmpire-0.18-Restaurant.png");yield return .3f;
            sim.Paused=true;game.Hud.BeginLayout();yield return .2f;
            Check(world.Find("Restaurant finishes").gameObject.activeInHierarchy&&!game.transform.Find("Living Restaurant").gameObject.activeInHierarchy,"Furniture styling remains visible during layout editing");
            game.Hud.FinishLayout(false);sim.Paused=true;
            BurgerEmpireMobileChecks.SetSize(1080,2340);yield return .4f;ScreenCapture.CaptureScreenshot("BurgerEmpire-0.18-Portrait.png");yield return .3f;
            BurgerEmpireMobileChecks.SetSize(2340,1080);yield return .3f;
            Check(File.ReadAllText("BurgerEmpireSave.json")==disk,"Style scenarios never overwrite the latest player save");
            File.AppendAllText(Report,"Completed. Procedural art, facial expressions and scene continuity verified; physical Android performance not measured.\n");
        }
        static void CaptureGallery(Transform stage,bool guests)
        {
            var gallery=RestaurantArt.Group("Gallery",stage,Vector3.zero);
            var roles=guests?new[]{"customer","customer","customer","customer","customer","customer"}:new[]{"player","cashier","cook","waiter","cleaner","manager"};
            var labels=guests?new[]{"MİSAFİR","MİSAFİR","AİLE","OFİS","SOSYAL","VIP"}:new[]{"KURUCU","KASİYER","AŞÇI","GARSON","TEMİZLİK","MÜDÜR"};
            for(int i=0;i<6;i++) {
                var person=RestaurantArt.BuildPerson(roles[i],guests?(i==5?VipCatalog.Kind:i):0,gallery);
                person.UpdatePosition(56.5f-i*1.3f,15,2, !guests&&i==3,false,!guests&&i==2?"cook":!guests&&i==4?"clean":"",Vector3.forward);
                RestaurantArt.Text("Label",labels[i],gallery,new Vector3(56.5f-i*1.3f,.06f,15.7f),.13f,RestaurantArt.Brown);
            }
            var camera=new GameObject("Gallery camera").AddComponent<Camera>();camera.orthographic=true;camera.orthographicSize=1.50f;
            camera.transform.position=new Vector3(53.25f,2.3f,24);camera.transform.LookAt(new Vector3(53.25f,1.08f,15));camera.clearFlags=CameraClearFlags.SolidColor;camera.backgroundColor=RestaurantArt.Cream;
            var target=new RenderTexture(1800,660,24);camera.targetTexture=target;var previous=RenderTexture.active;Texture2D picture=null;
            try {camera.Render();RenderTexture.active=target;picture=new Texture2D(1800,660,TextureFormat.RGB24,false);picture.ReadPixels(new Rect(0,0,1800,660),0,0);picture.Apply();File.WriteAllBytes(guests?"BurgerEmpire-0.18-Guests.png":"BurgerEmpire-0.18-Staff.png",picture.EncodeToPNG());}
            finally{RenderTexture.active=previous;camera.targetTexture=null;target.Release();UnityEngine.Object.Destroy(target);UnityEngine.Object.Destroy(camera.gameObject);if(picture)UnityEngine.Object.Destroy(picture);gallery.gameObject.SetActive(false);}
        }
    }
}
#endif
