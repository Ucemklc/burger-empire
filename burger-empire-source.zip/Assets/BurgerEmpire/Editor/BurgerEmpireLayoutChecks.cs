#if UNITY_EDITOR && ENABLE_INPUT_SYSTEM
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using BurgerEmpire.Core;
using Progress = BurgerEmpire.Core.Progress;
using BurgerEmpire.Unity;
using UnityEditor;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.LowLevel;
using UnityEngine.UI;

namespace BurgerEmpire.Editor
{
    [InitializeOnLoad]
    public static class BurgerEmpireLayoutChecks
    {
        const string Pending="BurgerEmpire.LayoutChecks",Report="BurgerEmpireLayoutChecks.txt";
        static IEnumerator<float> steps;
        static double next;
        static int nextFrame;
        static Touchscreen touch;
        static Mouse mouse;
        static BurgerEmpireGame game;
        static Simulation original;
        static string originalSavePath,originalDisk;
        static int lastEvent;
        static readonly System.Reflection.BindingFlags Private=System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic;
        static InputSettings.BackgroundBehavior background;
        static InputSettings.EditorInputBehaviorInPlayMode routing;
        static BurgerEmpireLayoutChecks(){EditorApplication.update+=Update;}
        static void Update()
        {
            if(EditorApplication.isCompiling||EditorApplication.isUpdating)return;
            if(File.Exists("BurgerEmpireLayoutChecks.request")) {
                try {File.Delete("BurgerEmpireLayoutChecks.request");} catch(IOException){return;}
                File.WriteAllText(Report,"");SessionState.SetBool(Pending,true);nextFrame=0;
                if(!EditorApplication.isPlaying){BurgerEmpireSetup.Play();return;}
            }
            if(!EditorApplication.isPlaying||!SessionState.GetBool(Pending,false)||EditorApplication.timeSinceStartup<next||Time.frameCount<nextFrame)return;
            try {
                if(steps==null) {
                    game=UnityEngine.Object.FindFirstObjectByType<BurgerEmpireGame>();if(!game||!game.Hud)return;
                    original=game.Sim;
                    originalSavePath=(string)typeof(BurgerEmpireGame).GetField("savePath",Private).GetValue(game);
                    originalDisk=File.ReadAllText(originalSavePath);
                    lastEvent=(int)typeof(BurgerEmpireGame).GetField("lastEvent",Private).GetValue(game);
                    if(game.LayoutEditor.Active)game.Hud.FinishLayout(false);
                    typeof(BurgerEmpireGame).GetField("savePath",Private).SetValue(game,Path.GetFullPath("BurgerEmpireLayoutValidationSave.json"));
                    typeof(BurgerEmpireGame).GetProperty("Sim").SetValue(game,new Simulation(new Progress{coins=2000,xp=900,tables=3,tutorialDone=true}));
                    typeof(BurgerEmpireGame).GetField("lastEvent",Private).SetValue(game,0);
                    game.Save();
                    background=InputSystem.settings.backgroundBehavior;InputSystem.settings.backgroundBehavior=InputSettings.BackgroundBehavior.IgnoreFocus;
                    // Route the synthetic touchscreen to the game even when another editor window has focus.
                    routing=InputSystem.settings.editorInputBehaviorInPlayMode;InputSystem.settings.editorInputBehaviorInPlayMode=InputSettings.EditorInputBehaviorInPlayMode.AllDeviceInputAlwaysGoesToGameView;
                    touch=InputSystem.AddDevice<Touchscreen>();mouse=InputSystem.AddDevice<Mouse>();steps=Run();
                }
                if(steps.MoveNext()){next=EditorApplication.timeSinceStartup+steps.Current;nextFrame=Time.frameCount+3;}else Finish();
            } catch(Exception e){File.AppendAllText(Report,"FAIL: "+e+"\n");Finish();}
        }
        static void Finish()
        {
            if(touch!=null){InputSystem.RemoveDevice(touch);touch=null;}
            if(mouse!=null){InputSystem.RemoveDevice(mouse);mouse=null;}
            InputSystem.settings.backgroundBehavior=background;InputSystem.settings.editorInputBehaviorInPlayMode=routing;
            if(game&&original!=null) {
                if(game.LayoutEditor.Active)game.Hud.FinishLayout(false);
                bool preserved=File.ReadAllText(originalSavePath)==originalDisk;
                typeof(BurgerEmpireGame).GetField("savePath",Private).SetValue(game,originalSavePath);
                typeof(BurgerEmpireGame).GetProperty("Sim").SetValue(game,original);original.Paused=true;
                typeof(BurgerEmpireGame).GetField("lastEvent",Private).SetValue(game,lastEvent);
                game.Save();game.Hud.OpenPanel("Restoran");
                File.AppendAllText(Report,(preserved?"PASS: ":"FAIL: ")+"Layout validation uses separate save and preserves player progress\n");
            }
            steps=null;original=null;nextFrame=0;SessionState.SetBool(Pending,false);
        }
        static void Check(bool passed,string name)
        {
            File.AppendAllText(Report,(passed?"PASS: ":"FAIL: ")+name+"\n");if(!passed)throw new Exception(name);
        }
        static void Touch(Vector2 p,UnityEngine.InputSystem.TouchPhase phase)
        { InputSystem.QueueStateEvent(touch,new TouchState{touchId=1,position=p,phase=phase}); }
        static void MouseAt(Vector2 p,bool pressed)
        {InputSystem.QueueStateEvent(mouse,new MouseState{position=p}.WithButton(MouseButton.Left,pressed));}
        static Vector2 World(float x,float z,float y=.25f){return game.GameCamera.WorldToScreenPoint(new Vector3(x,y,z));}
        static Button Button(string name){return UnityEngine.Object.FindObjectsByType<Button>(FindObjectsSortMode.None).First(b=>b.name==name&&b.gameObject.activeInHierarchy);}
        static Vector2 Center(string name){var rt=Button(name).GetComponent<RectTransform>();return RectTransformUtility.WorldToScreenPoint(null,rt.TransformPoint(rt.rect.center));}
        static void Bounds(string label)
        {
            var safe=Screen.safeArea;var corners=new Vector3[4];
            foreach(var b in UnityEngine.Object.FindObjectsByType<Button>(FindObjectsSortMode.None).Where(b=>b.gameObject.activeInHierarchy)) {
                var rt=b.GetComponent<RectTransform>();rt.GetWorldCorners(corners);
                Check(corners[0].x>=safe.xMin-1&&corners[0].y>=safe.yMin-1&&corners[2].x<=safe.xMax+1&&corners[2].y<=safe.yMax+1,label+": "+b.name+" within safe area");
                Check(rt.rect.height>=48,label+": "+b.name+" touch target >=48");
            }
            Check(game.GameCamera.rect.width>0&&game.GameCamera.rect.height>0,label+": positive viewport");
        }
        static IEnumerator<float> Run()
        {
            BurgerEmpireMobileChecks.SetSize(2340,1080);yield return 1;
            if(game.Hud.BlocksWorldInput)game.Hud.ClosePanel();game.Sim.Paused=true;
            game.Sim.ApplyLayout(RestaurantLayout.Default(),out _);
            game.Sim.Paused=false;game.Hud.OpenPanel("Restoran");yield return .2f;
            var list=UnityEngine.Object.FindFirstObjectByType<ScrollRect>();
            var layoutButton=Button("RESTORANI DÜZENLE").GetComponent<RectTransform>();
            list.StopMovement();list.content.anchoredPosition=new Vector2(0,Mathf.Max(0,-layoutButton.anchoredPosition.y-10));yield return .2f;
            var button=Center("RESTORANI DÜZENLE");
            Check(list.viewport.rect.Contains(list.viewport.InverseTransformPoint(button)),"Layout entry button is visible inside scrolled restaurant panel");
            Touch(button,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;
            Touch(button,UnityEngine.InputSystem.TouchPhase.Ended);yield return .3f;
            Check(game.LayoutEditor.Active&&game.Sim.Paused,"Restaurant button enters layout mode through touch input");
            Bounds("2340x1080");
            float time=game.Sim.Time;yield return .4f;
            Check(game.Sim.Time==time,"Layout mode freezes arrivals, meals and patience");
            var e=game.LayoutEditor;string committed=JsonUtility.ToJson(game.Sim.P.layout);int coins=game.Sim.P.coins;
            var p=World(2.3f,5.1f,1.15f);var delta=World(1.8f,5.1f,1.15f)-p;
            Check(!game.PointerOnUI(p),"Table drag starts inside unobstructed world viewport");
            Touch(p,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;
            Touch(p+delta,UnityEngine.InputSystem.TouchPhase.Moved);yield return .15f;
            Check(e.Dragging&&e.Valid,"Touch drag previews a valid table position");
            Touch(p+delta,UnityEngine.InputSystem.TouchPhase.Ended);yield return .2f;
            Check(Mathf.Abs(e.Draft.tables[0].x-1.75f)<.01f&&Mathf.Abs(e.Draft.tables[0].z-5)<.01f,"Touch release snaps and places the selected table");
            var table=GameObject.Find("Restaurant Environment").transform.Find("Table_0");
            Check(Mathf.Abs(table.localPosition.x-1.75f)<.01f,"3D table follows the draft without applying simulation changes");
            Check(JsonUtility.ToJson(game.Sim.P.layout)==committed,"Draft movement leaves committed layout untouched");
            p=World(1.75f,5,1.15f);delta=World(6,5,1.15f)-p;
            Touch(p,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;
            Touch(p+delta,UnityEngine.InputSystem.TouchPhase.Moved);yield return .15f;
            Check(!e.Valid,"Overlapping table preview is rejected");
            Touch(p+delta,UnityEngine.InputSystem.TouchPhase.Ended);yield return .15f;
            Check(e.Draft.tables[0].x==1.75f&&e.Valid,"Rejected drop restores last valid placement");
            p=World(.55f,9.45f,.9f);delta=World(.8f,9.2f,.9f)-p;
            Touch(p,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;
            Touch(p+delta,UnityEngine.InputSystem.TouchPhase.Moved);yield return .12f;
            Touch(p+delta,UnityEngine.InputSystem.TouchPhase.Ended);yield return .2f;
            Check(e.Selected==4&&e.Draft.plants[0].x==.75f&&e.Draft.plants[0].z==9.25f,"Free welcome plant can be selected and moved by touch");
            foreach(string name in new[]{"Zemin stili","Duvar stili","Mobilya stili"}) {
                p=Center(name);Touch(p,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;
                Touch(p,UnityEngine.InputSystem.TouchPhase.Ended);yield return .15f;
            }
            Check(e.Draft.floor==1&&e.Draft.wall==1&&e.Draft.furniture==1,"Touch style buttons update all three preview categories");
            Check(e.Selected==4&&!e.Dragging,"Style taps do not accidentally move furniture");
            game.Save();var disk=JsonUtility.FromJson<Progress>(File.ReadAllText("BurgerEmpireLayoutValidationSave.json"));
            Check(JsonUtility.ToJson(disk.layout)==committed,"Autosave writes committed layout, never unfinished preview");
            ScreenCapture.CaptureScreenshot(Path.GetFullPath("BurgerEmpire-0.4-Layout.png"));yield return .3f;
            p=Center("KAYDET");Touch(p,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;
            Touch(p,UnityEngine.InputSystem.TouchPhase.Ended);yield return .05f;
            Check(!e.Active&&!game.Sim.Paused,"Save closes editor and restores previous running state");
            game.Sim.Paused=true;yield return .1f;
            disk=JsonUtility.FromJson<Progress>(File.ReadAllText("BurgerEmpireLayoutValidationSave.json"));
            Check(disk.layout.floor==1&&disk.layout.tables[0].x==1.75f&&disk.layout.plants[0].x==.75f&&disk.coins==coins,"Saved JSON contains furniture, plant, styles and unchanged wallet");
            var reload=new Simulation(disk);
            Check(reload.Tables[0].x==1.75f&&reload.P.layout.wall==1,"Unity JSON restores moved table and styles in a fresh simulation");
            game.Hud.BeginLayout();yield return .2f;
            e.CycleStyle(0);game.Hud.Back();yield return .2f;
            Check(!e.Active&&game.Sim.Paused&&game.Sim.P.layout.floor==1,"Back cancels the draft and preserves prior paused state");
            game.Hud.BeginLayout();yield return .2f;
            e.Reset();yield return .1f;
            Check(e.Draft.tables[0].x==2.3f&&game.Sim.P.layout.tables[0].x==1.75f,"First-layout button is a reversible preview");
            game.Hud.FinishLayout(false);game.Hud.BeginLayout();yield return .3f;
            p=World(1.75f,5,1.15f);delta=World(2,5,1.15f)-p;
            MouseAt(p,true);yield return .12f;MouseAt(p+delta,true);yield return .12f;MouseAt(p+delta,false);yield return .2f;
            Check(e.Draft.tables[0].x==2,"Mouse drag shares the same placement behavior");
            p=World(2,5,1.15f);delta=World(2.25f,5,1.15f)-p;
            Touch(p,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;
            Touch(p+delta,UnityEngine.InputSystem.TouchPhase.Moved);yield return .12f;
            Touch(p+delta,UnityEngine.InputSystem.TouchPhase.Canceled);yield return .15f;
            Check(e.Draft.tables[0].x==2&&!e.Dragging,"Canceled touch rolls back only the active drag");
            game.Suspend();game.Hud.FinishLayout(false);yield return .15f;
            Check(game.Sim.Paused,"Backgrounding layout editor prevents accidental resume");
            game.Hud.BeginLayout();yield return .2f;
            BurgerEmpireMobileChecks.SetSize(1280,720);yield return .6f;Bounds("1280x720");
            BurgerEmpireMobileChecks.SetSize(1080,2340);yield return .6f;Bounds("1080x2340 portrait");
            Check(e.Active&&e.Draft.tables[0].x==1.75f,"Resizing rebuilds controls without losing the draft");
            ScreenCapture.CaptureScreenshot(Path.GetFullPath("BurgerEmpire-0.4-Layout-Portrait.png"));yield return .3f;
            BurgerEmpireMobileChecks.SetSize(2340,1080);yield return .6f;
            File.AppendAllText(Report,"Completed. Synthetic Unity touch and mouse tested; no physical Android device used.\n");
        }
    }
}
#endif
