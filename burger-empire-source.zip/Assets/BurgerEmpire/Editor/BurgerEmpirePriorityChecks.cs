#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using BurgerEmpire.Core;
using BurgerEmpire.Unity;
using UnityEditor;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.LowLevel;
using UnityEngine.UI;
using Progress=BurgerEmpire.Core.Progress;

namespace BurgerEmpire.Editor
{
    [InitializeOnLoad]
    public static class BurgerEmpirePriorityChecks
    {
        const string Pending="BurgerEmpire.PriorityChecks",Report="BurgerEmpirePriorityChecks.txt";
        const BindingFlags Private=BindingFlags.Instance|BindingFlags.NonPublic;
        static IEnumerator<float> steps;
        static double next;
        static int nextFrame,lastEvent;
        static BurgerEmpireGame game;
        static Simulation original;
        static string disk,originalPath;
        static Touchscreen touch;
        static InputSettings.BackgroundBehavior background;
        static InputSettings.EditorInputBehaviorInPlayMode routing;
        static BurgerEmpirePriorityChecks(){EditorApplication.update+=Update;}
        static void Update()
        {
            if(EditorApplication.isCompiling||EditorApplication.isUpdating)return;
            if(File.Exists("BurgerEmpirePriorityChecks.request")) {
                try{File.Delete("BurgerEmpirePriorityChecks.request");}catch(IOException){return;}
                File.WriteAllText(Report,"");SessionState.SetBool(Pending,true);nextFrame=0;
                if(!EditorApplication.isPlaying){BurgerEmpireSetup.Play();return;}
            }
            if(!EditorApplication.isPlaying||!SessionState.GetBool(Pending,false)||EditorApplication.timeSinceStartup<next||Time.frameCount<nextFrame)return;
            try {
                if(steps==null) {
                    game=UnityEngine.Object.FindFirstObjectByType<BurgerEmpireGame>();if(!game||game.Sim==null)return;
                    original=game.Sim;disk=File.ReadAllText("BurgerEmpireSave.json");
                    originalPath=(string)typeof(BurgerEmpireGame).GetField("savePath",Private).GetValue(game);
                    typeof(BurgerEmpireGame).GetField("savePath",Private).SetValue(game,Path.GetFullPath("BurgerEmpirePriorityValidationSave.json"));
                    lastEvent=(int)typeof(BurgerEmpireGame).GetField("lastEvent",Private).GetValue(game);
                    background=InputSystem.settings.backgroundBehavior;InputSystem.settings.backgroundBehavior=InputSettings.BackgroundBehavior.IgnoreFocus;
                    routing=InputSystem.settings.editorInputBehaviorInPlayMode;InputSystem.settings.editorInputBehaviorInPlayMode=InputSettings.EditorInputBehaviorInPlayMode.AllDeviceInputAlwaysGoesToGameView;
                    touch=InputSystem.AddDevice<Touchscreen>();steps=Run();
                }
                if(steps.MoveNext()){next=EditorApplication.timeSinceStartup+steps.Current;nextFrame=Time.frameCount+3;}else Finish();
            }catch(Exception e){File.AppendAllText(Report,"FAIL: "+e+"\n");Finish();}
        }
        static void Finish()
        {
            if(touch!=null){InputSystem.RemoveDevice(touch);touch=null;}
            InputSystem.settings.backgroundBehavior=background;InputSystem.settings.editorInputBehaviorInPlayMode=routing;
            if(game&&original!=null) {
                if(game.Hud.BlocksWorldInput)game.Hud.ClosePanel();
                typeof(BurgerEmpireGame).GetField("savePath",Private).SetValue(game,originalPath);
                SetSimulation(original);original.Paused=true;game.Save();
                typeof(BurgerEmpireGame).GetField("lastEvent",Private).SetValue(game,lastEvent);
            }
            steps=null;original=null;nextFrame=0;SessionState.SetBool(Pending,false);
        }
        static void SetSimulation(Simulation sim)
        {
            typeof(BurgerEmpireGame).GetProperty("Sim").SetValue(game,sim);
            typeof(BurgerEmpireGame).GetField("lastEvent",Private).SetValue(game,0);
            typeof(RestaurantHud).GetField("toastTime",Private).SetValue(game.Hud,0f);
        }
        static void Check(bool passed,string label)
        {File.AppendAllText(Report,(passed?"PASS: ":"FAIL: ")+label+"\n");if(!passed)throw new Exception(label);}
        static Button Find(string name)=>UnityEngine.Object.FindObjectsByType<Button>(FindObjectsSortMode.None).First(b=>b.name==name&&b.gameObject.activeInHierarchy);
        static ScrollRect List=>UnityEngine.Object.FindFirstObjectByType<ScrollRect>();
        static Vector2 Center(string name)=>RectTransformUtility.WorldToScreenPoint(null,Find(name).transform.TransformPoint(Find(name).GetComponent<RectTransform>().rect.center));
        static void Reveal(string name)
        {
            var list=List;var target=Find(name).GetComponent<RectTransform>();list.StopMovement();
            var relative=list.content.InverseTransformPoint(target.TransformPoint(target.rect.center));
            list.content.anchoredPosition=new Vector2(0,Mathf.Clamp(-relative.y-90,0,list.content.rect.height-list.viewport.rect.height));
            Canvas.ForceUpdateCanvases();
        }
        static void Touch(Vector2 point,UnityEngine.InputSystem.TouchPhase phase)
        {InputSystem.QueueStateEvent(touch,new TouchState{touchId=1,position=point,phase=phase});}
        static void Bounds(string size)
        {
            var points=new Vector3[4];List.viewport.GetWorldCorners(points);var safe=Screen.safeArea;
            Check(points[0].x>=safe.xMin&&points[2].x<=safe.xMax&&points[0].y>=safe.yMin&&points[2].y<=safe.yMax,size+": panel stays inside the safe display area");
            Check(List.content.rect.height>List.viewport.rect.height,size+": all policies can be reached by scrolling");
            Check(List.content.GetComponentsInChildren<Button>().All(b=>b.GetComponent<RectTransform>().rect.height>=48),size+": policy touch targets are at least 48 logical pixels");
            var overflow=List.content.GetComponentsInChildren<Text>().Where(t=>t.preferredHeight>t.rectTransform.rect.height+2).Select(t=>t.text);
            Check(!overflow.Any(),size+": policy descriptions fit: "+string.Join(" | ",overflow));
            Check(Find("×").GetComponent<RectTransform>().rect.height>=48,size+": close button stays reachable");
        }
        static Simulation Fixture(int mode,bool ready)
        {
            var sim=new Simulation(new Progress{version=11,tutorialDone=true,coins=2600,xp=3000,served=40,tables=4,grill=3,blender=1,servicePriority=mode,londonOpen=true,london=new RestaurantProgress{tutorialDone=true}});
            for(int i=0;i<3;i++) {
                var table=sim.Tables[i];table.customer=101+i;
                sim.Customers.Add(new Customer{id=101+i,table=i,name=i==1?"VIP":"Deniz",meal="Klasik Menü",phase="waiting",order=ready?"ready":"ordered",kind=i==1?6:0,patience=i==2?35:80,maxPatience=100,x=table.x,z=table.z+.85f,price=32});
            }
            return sim;
        }
        static IEnumerator<float> Run()
        {
            BurgerEmpireMobileChecks.SetSize(2340,1080);yield return .5f;
            if(game.LayoutEditor.Active)game.Hud.FinishLayout(false);
            if(game.Hud.BlocksWorldInput)game.Hud.ClosePanel();
            var sim=Fixture(0,false);SetSimulation(sim);sim.Paused=false;game.Hud.OpenPanel("Personel");yield return .3f;
            Check(sim.Paused&&Find("Open service priority").interactable,"Personnel screen pauses the shift and exposes priority settings");
            var target=Center("Open service priority");Touch(target,UnityEngine.InputSystem.TouchPhase.Began);yield return .1f;Touch(target,UnityEngine.InputSystem.TouchPhase.Ended);yield return .25f;
            Check(Find("Choose priority 0")&&!Find("Choose priority 0").interactable&&Find("Choose priority 1").interactable,"Actual touch opens priorities with arrival order selected");
            Bounds("2340x1080");
            Check(sim.UpcomingPreparation.id==101,"Default preparation preview agrees with arrival order");
            Reveal("Choose priority 1");yield return .1f;
            target=Center("Choose priority 1");Touch(target,UnityEngine.InputSystem.TouchPhase.Began);yield return .1f;Touch(target,UnityEngine.InputSystem.TouchPhase.Ended);yield return .25f;
            Check(sim.P.servicePriority==1&&!Find("Choose priority 1").interactable&&Find("Choose priority 0").interactable,"Actual touch selects patience and moves the selected indicator");
            var saved=JsonUtility.FromJson<Progress>(File.ReadAllText("BurgerEmpirePriorityValidationSave.json"));
            Check(saved.version==BurgerEmpire.Core.Progress.CurrentVersion&&saved.servicePriority==1&&saved.istanbul.servicePriority==1,"Selecting a priority immediately saves current schema and the active branch setting");
            Check(saved.coins==2600&&saved.xp==3000&&saved.served==40,"Selection has no currency, XP or completed-customer cost");
            Check(sim.UpcomingPreparation.id==103,"Preview now picks the shorter-patience guest without reserving work");
            Reveal("Choose priority 2");yield return .1f;
            target=Center("Choose priority 2");Touch(target,UnityEngine.InputSystem.TouchPhase.Began);yield return .1f;Touch(target,UnityEngine.InputSystem.TouchPhase.Ended);yield return .25f;
            Check(sim.P.servicePriority==2&&sim.UpcomingPreparation.id==102,"Actual touch selects VIP and immediately changes the eligible preparation preview");
            ScreenCapture.CaptureScreenshot("BurgerEmpire-0.16-Priority.png");yield return .4f;
            target=Center("×");Touch(target,UnityEngine.InputSystem.TouchPhase.Began);yield return .1f;Touch(target,UnityEngine.InputSystem.TouchPhase.Ended);yield return .2f;
            Check(!game.Hud.BlocksWorldInput&&!sim.Paused,"Closing nested priority settings resumes a previously running shift");sim.Paused=true;

            sim.Paused=false;game.Command("cook");sim.Paused=true;
            Check(sim.Actors[0].job=="cook"&&sim.Actors[0].customer==102,"Game command actually assigns the selected VIP preparation");
            int assigned=sim.Actors[0].customer;string route=JsonUtility.ToJson(sim.Actors[0]);
            game.Hud.OpenPanel("Servis önceliği");game.ChooseServicePriority(1);yield return .2f;
            Check(sim.Actors[0].customer==assigned&&JsonUtility.ToJson(sim.Actors[0])==route,"Policy change preserves in-flight job, route, stage and reservation");
            game.Hud.ClosePanel();sim.Paused=true;

            game.VisitBranch(1);yield return .2f;
            Check(game.Sim.P.activeBranch==1&&game.Sim.P.servicePriority==0,"London retains its default policy when Istanbul was changed");
            game.Hud.OpenPanel("Servis önceliği");game.ChooseServicePriority(2);game.Save();yield return .2f;
            saved=JsonUtility.FromJson<Progress>(File.ReadAllText("BurgerEmpirePriorityValidationSave.json"));
            var restored=new Simulation(saved);
            Check(restored.P.activeBranch==1&&restored.P.servicePriority==2&&restored.BranchProgress(0).servicePriority==1,"Unity JSON reload preserves distinct Istanbul and London choices");
            game.VisitBranch(0);yield return .2f;
            Check(game.Sim.P.servicePriority==1&&game.Sim.Actors[0].customer==assigned,"Returning to Istanbul restores its policy and unfinished job");

            if(game.Hud.BlocksWorldInput)game.Hud.ClosePanel();
            sim=Fixture(2,true);sim.Customers[2].patience=12;SetSimulation(sim);
            sim.Paused=false;game.Command("serve");sim.Paused=true;
            Check(sim.Actors[0].customer==103,"Actual game service picks the critical non-VIP ahead of a nonurgent VIP");
            game.Hud.OpenPanel("Servis önceliği");yield return .2f;
            Check(!Find("Choose priority 2").interactable,"Priority screen reflects the current branch after a scenario change");
            BurgerEmpireMobileChecks.SetSize(1280,720);yield return .5f;Bounds("1280x720");
            BurgerEmpireMobileChecks.SetSize(1080,2340);yield return .5f;Bounds("1080x2340");
            Reveal("Choose priority 0");yield return .1f;
            target=Center("Choose priority 0");Touch(target,UnityEngine.InputSystem.TouchPhase.Began);yield return .1f;Touch(target,UnityEngine.InputSystem.TouchPhase.Ended);yield return .25f;
            Check(sim.P.servicePriority==0&&!Find("Choose priority 0").interactable,"Portrait touch can return to arrival order");
            ScreenCapture.CaptureScreenshot("BurgerEmpire-0.16-Priority-Portrait.png");yield return .4f;
            Reveal("Priority back");yield return .1f;
            target=Center("Priority back");Touch(target,UnityEngine.InputSystem.TouchPhase.Began);yield return .1f;Touch(target,UnityEngine.InputSystem.TouchPhase.Ended);yield return .2f;
            Check(Find("Open service priority")&&sim.Paused,"Back returns to personnel without resuming the shift");
            game.Hud.Back();yield return .2f;
            Check(!game.Hud.BlocksWorldInput&&sim.Paused,"Back from personnel keeps an originally paused shift paused");
            BurgerEmpireMobileChecks.SetSize(2340,1080);yield return .5f;
            Check(File.ReadAllText("BurgerEmpireSave.json")==disk,"Priority UI and disk tests never overwrite the real player save");
            File.AppendAllText(Report,"Completed. Policies, actual Input System touch, mobile layouts and isolated Unity disk save verified; physical Android not tested.\n");
        }
    }
}
#endif
