#if UNITY_EDITOR && ENABLE_INPUT_SYSTEM
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using BurgerEmpire.Core;
using BurgerEmpire.Unity;
using UnityEditor;
using UnityEngine;
using UnityEngine.UI;
using Progress=BurgerEmpire.Core.Progress;

namespace BurgerEmpire.Editor
{
    // Actual game renders at a store-compatible resolution. No overlays or invented game art.
    [InitializeOnLoad]
    public static class BurgerEmpireStoreCaptureChecks
    {
        const string Report="BurgerEmpireStoreCaptureChecks.txt",Pending="BurgerEmpire.StoreCapture";
        const BindingFlags Private=BindingFlags.Instance|BindingFlags.NonPublic;
        static BurgerEmpireGame game;
        static Simulation original;
        static string disk,language,prefLanguage;
        static bool hadLanguage;
        static int lastEvent;
        static IEnumerator<float> steps;
        static double next;
        static int nextFrame;
        static BurgerEmpireStoreCaptureChecks(){EditorApplication.update+=Update;}
        static void Update()
        {
            if(EditorApplication.isCompiling||EditorApplication.isUpdating)return;
            if(File.Exists("BurgerEmpireStoreCaptureChecks.request")) {
                File.Delete("BurgerEmpireStoreCaptureChecks.request");File.WriteAllText(Report,"");SessionState.SetBool(Pending,true);
                if(!EditorApplication.isPlaying){BurgerEmpireSetup.Play();return;}
            }
            if(!EditorApplication.isPlaying||!SessionState.GetBool(Pending,false)||EditorApplication.timeSinceStartup<next||Time.frameCount<nextFrame)return;
            try {
                if(steps==null) {
                    game=UnityEngine.Object.FindFirstObjectByType<BurgerEmpireGame>();if(!game||game.Sim==null||!game.Hud)return;
                    original=game.Sim;disk=File.ReadAllText("BurgerEmpireSave.json");language=Localization.Language;
                    hadLanguage=PlayerPrefs.HasKey("BurgerEmpire.Language");prefLanguage=PlayerPrefs.GetString("BurgerEmpire.Language");
                    lastEvent=(int)typeof(BurgerEmpireGame).GetField("lastEvent",Private).GetValue(game);
                    game.ValidationActive=true;steps=Run();
                }
                if(steps.MoveNext()){next=EditorApplication.timeSinceStartup+steps.Current;nextFrame=Time.frameCount+3;}
                else Finish();
            }catch(Exception e){File.AppendAllText(Report,"FAIL: "+e+"\n");Finish();}
        }
        static void Check(bool good,string message)
        {File.AppendAllText(Report,(good?"PASS: ":"FAIL: ")+message+"\n");if(!good)throw new Exception(message);}
        static void SetSimulation(Simulation s)
        {
            typeof(BurgerEmpireGame).GetProperty("Sim").SetValue(game,s);
            typeof(BurgerEmpireGame).GetField("lastEvent",Private).SetValue(game,s.Events.Count>0?s.Events.Last().id:0);
            typeof(RestaurantHud).GetField("toastTime",Private).SetValue(game.Hud,0f);
        }
        static Progress Restaurant(bool channels)
        {
            return new Progress{tutorialDone=true,coins=2400,xp=1200,served=60,cooked=75,mission=5,tables=4,grill=2,fryer=2,blender=1,cheese=1,doubleBurger=1,chickenBurger=1,bbqBurger=1,chocolateShake=1,cashier=2,cook=2,waiter=2,cleaner=2,manager=1,decor=1,driveThru=channels?1:0,delivery=channels?1:0};
        }
        static Simulation Stage(bool channels)
        {
            var s=new Simulation(Restaurant(channels),39);s.Paused=false;
            for(int i=0;i<2500;i++) {
                s.Tick(.1f);
                if(s.Time>45&&s.Customers.Count(c=>!c.drive&&!c.delivery)>=4&&(!channels||s.DriveQueue>0&&s.DeliveryQueue>0))break;
            }
            s.Paused=true;return s;
        }
        static IEnumerator<float> Run()
        {
            Directory.CreateDirectory(BurgerEmpireStoreArt.Output);
            BurgerEmpireMobileChecks.SetSize(1920,1080);yield return .5f;
            Check(Screen.width==1920&&Screen.height==1080,"Game View uses native 1920x1080, not a crop of a wider validation image");
            foreach(string lang in new[]{"tr","en"}) {
                game.SetLanguage(lang);if(game.Hud.BlocksWorldInput)game.Hud.ClosePanel();
                var shift=Stage(false);SetSimulation(shift);yield return .3f;
                game.CameraControls.ZoomStep(1.22f);shift.Paused=false;yield return .4f;
                Check(shift.Customers.Any(c=>!c.drive&&!c.delivery)&&!game.Hud.BlocksWorldInput,lang+": restaurant capture contains actual simulated customers and staff");
                CheckLabels(lang);Capture(lang+"-01-Restaurant");yield return .3f;ValidateCapture(lang+"-01-Restaurant");shift.Paused=true;
                game.Hud.OpenPanel("Personel");yield return .3f;CheckLabels(lang);Capture(lang+"-02-Team");yield return .3f;ValidateCapture(lang+"-02-Team");
                game.Hud.ClosePanel();SetSimulation(Stage(true));yield return .3f;
                game.Sim.Paused=false;yield return .3f;
                Check(game.Sim.P.driveThru>0&&game.Sim.P.delivery>0,lang+": expansion capture uses actual unlocked drive-thru and delivery presentation");
                CheckLabels(lang);Capture(lang+"-03-Service");yield return .3f;ValidateCapture(lang+"-03-Service");game.Sim.Paused=true;
            }
            Check(File.ReadAllText("BurgerEmpireSave.json")==disk,"All six captures leave the player's actual save byte-for-byte unchanged");
            Check(game.RewardTest.Coins==0&&!game.RewardTest.Flow.Busy,"No editor ad test reward or screen appears in the capture session");
            BurgerEmpireMobileChecks.SetSize(2340,1080);yield return .3f;
            File.AppendAllText(Report,"Completed. Six actual Unity game captures from isolated demo progress; not physical Android screenshots.\n");
        }
        static void Capture(string name)
        {
            ScreenCapture.CaptureScreenshot(Path.Combine(BurgerEmpireStoreArt.Output,name+".png"));
        }
        static void ValidateCapture(string name)
        {
            string path=Path.Combine(BurgerEmpireStoreArt.Output,name+".png");
            var source=new Texture2D(2,2);Check(source.LoadImage(File.ReadAllBytes(path))&&source.width==1920&&source.height==1080,name+": completed capture is 1920x1080");
            Check(source.GetPixels().All(c=>c.a==1),name+": actual rendered pixels are opaque");
            var rgb=new Texture2D(source.width,source.height,TextureFormat.RGB24,false);rgb.SetPixels(source.GetPixels());rgb.Apply();
            File.WriteAllBytes(path,rgb.EncodeToPNG());UnityEngine.Object.DestroyImmediate(source);UnityEngine.Object.DestroyImmediate(rgb);
        }
        static void CheckLabels(string lang)
        {
            var labels=UnityEngine.Object.FindObjectsByType<Text>(FindObjectsSortMode.None).Where(t=>t.gameObject.activeInHierarchy).ToArray();
            Check(labels.All(t=>t.preferredHeight<=t.rectTransform.rect.height+2),lang+": visible text fits its allocated height");
            if(lang=="en")Check(labels.All(t=>t.text=="Türkçe"||!System.Text.RegularExpressions.Regex.IsMatch(t.text,"[çğıöşüÇĞİÖŞÜ]")),"English capture has no untranslated Turkish text");
        }
        static void Finish()
        {
            if(game&&original!=null) {
                if(game.LayoutEditor.Active)game.Hud.FinishLayout(false);
                SetSimulation(original);original.Paused=true;
                game.SetLanguage(language);if(hadLanguage)PlayerPrefs.SetString("BurgerEmpire.Language",prefLanguage);else PlayerPrefs.DeleteKey("BurgerEmpire.Language");PlayerPrefs.Save();
                game.ValidationActive=false;game.Hud.OpenMainMenu();
                typeof(BurgerEmpireGame).GetField("lastEvent",Private).SetValue(game,lastEvent);
            }
            original=null;steps=null;nextFrame=0;SessionState.SetBool(Pending,false);
        }
    }
}
#endif
