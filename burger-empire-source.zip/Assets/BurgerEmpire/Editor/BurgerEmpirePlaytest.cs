#if UNITY_EDITOR
using System;
using System.IO;
using BurgerEmpire.Unity;
using UnityEditor;
using UnityEngine;

namespace BurgerEmpire.Editor
{
    [InitializeOnLoad]
    public static class BurgerEmpirePlaytest
    {
        static string LatestKey=>"BurgerEmpire.Playtest.Latest."+EditorPlaytestSession.Root;
        public static string Latest=>EditorPrefs.GetString(LatestKey,"");
        static BurgerEmpirePlaytest(){EditorApplication.playModeStateChanged+=Changed;}
        static void Changed(PlayModeStateChange state)
        {
            if(state==PlayModeStateChange.ExitingPlayMode&&EditorPlaytestSession.Active) {
                var game=UnityEngine.Object.FindFirstObjectByType<BurgerEmpireGame>();
                if(game&&game.Sim!=null){game.Save();WriteObservation(game);}
            }
            if(state==PlayModeStateChange.EnteredEditMode)EditorPlaytestSession.Clear();
        }
        [MenuItem("Burger Empire/Oyuncu denemesi/1 - Yeni oyuncu oturumu")]
        public static void New()
        {
            if(EditorApplication.isPlayingOrWillChangePlaymode)return;
            string id=EditorPlaytestSession.NewProfile();EditorPrefs.SetString(LatestKey,id);
            File.WriteAllText(Path.Combine(Path.GetDirectoryName(EditorPlaytestSession.ProfilePath(id)),"README.txt"),
                "Burger Empire "+AndroidReleasePlan.Version+" — yerel Unity oyuncu denemesi\n"+
                "Bu profil ana oyuncu kaydından ve ses/dil tercihlerinden ayrıdır.\n"+
                "Play durdurulunca normal kayda dönülür. Oturum silinmez; deneme menüsünden devam edilebilir.\n"+
                "Bu klasör yereldir; sonuçlar gönderilmez. Otomatik ölçümler insan geri bildirimi değildir.\n");
            Launch();
        }
        [MenuItem("Burger Empire/Oyuncu denemesi/1 - Yeni oyuncu oturumu",true)]
        static bool CanNew()=>!EditorApplication.isPlayingOrWillChangePlaymode;
        [MenuItem("Burger Empire/Oyuncu denemesi/2 - Son denemeye devam et")]
        public static void Resume()
        {
            if(!CanResume())return;
            EditorPlaytestSession.Select(Latest);Launch();
        }
        [MenuItem("Burger Empire/Oyuncu denemesi/2 - Son denemeye devam et",true)]
        static bool CanResume()
        {
            if(!CanNew()||Latest=="")return false;
            try{return File.Exists(EditorPlaytestSession.ProfilePath(Latest));}catch(InvalidOperationException){return false;}
        }
        static void Launch()
        {
            try {
                BurgerEmpireSetup.Play();
                if(!EditorApplication.isPlayingOrWillChangePlaymode)EditorPlaytestSession.Clear();
            }catch{EditorPlaytestSession.Clear();throw;}
        }
        [MenuItem("Burger Empire/Oyuncu denemesi/3 - Denemeyi bitir")]
        public static void Stop(){if(EditorPlaytestSession.Active)EditorApplication.isPlaying=false;}
        [MenuItem("Burger Empire/Oyuncu denemesi/3 - Denemeyi bitir",true)]
        static bool CanStop()=>EditorApplication.isPlaying&&EditorPlaytestSession.Active;
        [Serializable] sealed class Observation
        {
            public string source="Unity editor observation; not human feedback",version=AndroidReleasePlan.Version;
            public bool tutorialCompleted;
            public int payments,lost,coins;
            public double sessionActiveSeconds;
            public long sessionPayments,sessionLost,sessionEarned;
        }
        public static void WriteObservation(BurgerEmpireGame game)
        {
            if(!EditorPlaytestSession.Active)return;
            var note=new Observation{tutorialCompleted=game.Sim.P.tutorialDone,payments=game.Sim.P.served,lost=game.Sim.P.lost,coins=game.Sim.P.coins,
                sessionActiveSeconds=game.Session.ActiveSeconds,sessionPayments=game.Session.Served,sessionLost=game.Session.Lost,sessionEarned=game.Session.Earned};
            string folder=Path.GetDirectoryName(EditorPlaytestSession.ProfilePath(EditorPlaytestSession.Id));
            File.WriteAllText(Path.Combine(folder,"Session-"+Guid.NewGuid().ToString("N")+".json"),JsonUtility.ToJson(note,true));
        }
    }
}
#endif
