#if UNITY_EDITOR && ENABLE_INPUT_SYSTEM
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using BurgerEmpire.Core;
using BurgerEmpire.Unity;
using UnityEditor;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.LowLevel;
using UnityEngine.UI;
using Progress=BurgerEmpire.Core.Progress;

namespace BurgerEmpire.Editor
{
    [InitializeOnLoad]
    public static class BurgerEmpireAchievementChecks
    {
        const string Pending="BurgerEmpire.AchievementChecks",Report="BurgerEmpireAchievementChecks.txt";
        static IEnumerator<float> steps;
        static double next;
        static int nextFrame;
        static BurgerEmpireGame game;
        static Simulation original;
        static string disk;
        static string originalSavePath;
        static int lastEvent;
        static Touchscreen touch;
        static InputSettings.BackgroundBehavior background;
        static BurgerEmpireAchievementChecks(){EditorApplication.update+=Update;}
        static void Update()
        {
            if(EditorApplication.isCompiling||EditorApplication.isUpdating)return;
            if(File.Exists("BurgerEmpireAchievementChecks.request")) {
                try {File.Delete("BurgerEmpireAchievementChecks.request");} catch(IOException){return;}
                File.WriteAllText(Report,"");SessionState.SetBool(Pending,true);
                nextFrame=0;
                if(!EditorApplication.isPlaying){BurgerEmpireSetup.Play();return;}
            }
            if(!EditorApplication.isPlaying||!SessionState.GetBool(Pending,false)||EditorApplication.timeSinceStartup<next||Time.frameCount<nextFrame)return;
            try {
                if(steps==null) {
                    game=UnityEngine.Object.FindFirstObjectByType<BurgerEmpireGame>();if(!game||game.Sim==null)return;
                    original=game.Sim;disk=File.ReadAllText("BurgerEmpireSave.json");
                    originalSavePath=(string)typeof(BurgerEmpireGame).GetField("savePath",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).GetValue(game);
                    typeof(BurgerEmpireGame).GetField("savePath",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game,Path.GetFullPath("BurgerEmpireAchievementValidationSave.json"));
                    lastEvent=(int)typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).GetValue(game);
                    background=InputSystem.settings.backgroundBehavior;InputSystem.settings.backgroundBehavior=InputSettings.BackgroundBehavior.IgnoreFocus;
                    touch=InputSystem.AddDevice<Touchscreen>();steps=Run();
                }
                // Process each touch in the game loop even when editor callbacks run faster.
                if(steps.MoveNext()){next=EditorApplication.timeSinceStartup+steps.Current;nextFrame=Time.frameCount+3;}else Finish();
            } catch(Exception e){File.AppendAllText(Report,"FAIL: "+e+"\n");Finish();}
        }
        static void SetSimulation(Simulation value)
        {
            typeof(BurgerEmpireGame).GetProperty("Sim").SetValue(game,value);
            typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game,0);
            typeof(RestaurantHud).GetField("toastTime",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game.Hud,0f);
        }
        static void Finish()
        {
            if(touch!=null){InputSystem.RemoveDevice(touch);touch=null;}InputSystem.settings.backgroundBehavior=background;
            if(game&&original!=null) {
                if(game.LayoutEditor.Active)game.Hud.FinishLayout(false);
                typeof(BurgerEmpireGame).GetField("savePath",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game,originalSavePath);
                SetSimulation(original);original.Paused=true;game.Save();game.Hud.OpenPanel("Başarımlar");
                typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game,lastEvent);
            }
            steps=null;original=null;nextFrame=0;SessionState.SetBool(Pending,false);
        }
        static Progress Fixture()
        {
            return new Progress{coins=2000,xp=900,tables=2,grill=2,cook=1,tutorialDone=true};
        }
        static void Check(bool good,string message)
        {File.AppendAllText(Report,(good?"PASS: ":"FAIL: ")+message+"\n");if(!good)throw new Exception(message);}
        static Button Find(string name){return UnityEngine.Object.FindObjectsByType<Button>(FindObjectsSortMode.None).First(b=>b.name==name&&b.gameObject.activeInHierarchy);}
        static Vector2 Center(RectTransform rt){return RectTransformUtility.WorldToScreenPoint(null,rt.TransformPoint(rt.rect.center));}
        static void Touch(Vector2 p,UnityEngine.InputSystem.TouchPhase phase)
        {InputSystem.QueueStateEvent(touch,new TouchState{touchId=1,position=p,phase=phase});}
        static void TraceTouch(Vector2 point,string stage)
        {
            var system=UnityEngine.EventSystems.EventSystem.current;
            var hits=new List<UnityEngine.EventSystems.RaycastResult>();
            system.RaycastAll(new UnityEngine.EventSystems.PointerEventData(system){position=point},hits);
            File.AppendAllText(Report,"INFO: "+stage+" frame="+Time.frameCount+" target="+point+" touch="+touch.primaryTouch.position.ReadValue()+" phase="+touch.primaryTouch.phase.ReadValue()+" hits="+string.Join(",",hits.Select(h=>h.gameObject.name+"#"+h.gameObject.GetInstanceID()))+"\n");
        }
        static bool Until(Func<bool> condition,int limit=1000)
        {
            game.Sim.Paused=false;
            for(int i=0;i<limit&&!condition();i++){if(game.Sim.Actors[0].job=="")game.Sim.Command("next");game.Sim.Tick(.1f);}
            game.Sim.Paused=true;return condition();
        }
        static bool WaitOnly(Func<bool> condition,int limit=2000)
        {
            game.Sim.Paused=false;
            for(int i=0;i<limit&&!condition();i++)game.Sim.Tick(.1f);
            game.Sim.Paused=true;return condition();
        }

        static string Texts=>string.Join("\n",UnityEngine.Object.FindObjectsByType<Text>(FindObjectsSortMode.None).Where(t=>t.gameObject.activeInHierarchy).Select(t=>t.text));
        static ScrollRect List=>UnityEngine.Object.FindFirstObjectByType<ScrollRect>();
        static void Reveal(string id)
        {
            var card=GameObject.Find("Achievement "+id).GetComponent<RectTransform>();
            List.StopMovement();List.content.anchoredPosition=new Vector2(0,-card.anchoredPosition.y);
        }
        static void Bounds(string size)
        {
            var list=List;var points=new Vector3[4];list.viewport.GetWorldCorners(points);var safe=Screen.safeArea;
            Check(points[0].x>=safe.xMin&&points[2].x<=safe.xMax&&points[0].y>=safe.yMin&&points[2].y<=safe.yMax,size+": achievement list viewport stays in safe area");
            Check(list.content.rect.height>list.viewport.rect.height,size+": achievement list can scroll");
            var claimButtons=list.content.GetComponentsInChildren<Button>();
            Check(claimButtons.All(b=>b.GetComponent<RectTransform>().rect.height>=48),size+": every achievement action has a large touch target");
            Check(list.content.GetComponentsInChildren<Text>().All(t=>t.preferredHeight<=t.rectTransform.rect.height+2),size+": all achievement text fits its allocated height");
            Check(Find("×").GetComponent<RectTransform>().rect.height>=48,size+": close button remains reachable");
            var fills=list.content.GetComponentsInChildren<RectTransform>().Where(t=>t.name=="Achievement progress");
            Check(fills.Count()==12&&fills.All(f=>f.rect.width>=0&&f.rect.width<=list.content.rect.width-28+1),size+": twelve progress bars stay within card width");
        }
        static IEnumerator<float> Run()
        {
            BurgerEmpireMobileChecks.SetSize(2340,1080);yield return .7f;
            if(game.LayoutEditor.Active)game.Hud.FinishLayout(false);
            if(game.Hud.BlocksWorldInput)game.Hud.ClosePanel();
            SetSimulation(new Simulation(new Progress()));game.Hud.OpenPanel("Görevler");yield return .3f;
            var target=Center(Find("Open achievements").GetComponent<RectTransform>());
            Check(List.viewport.rect.Contains(List.viewport.InverseTransformPoint(target)),"Permanent achievements entry appears at top of daily missions");
            Touch(target,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;Touch(target,UnityEngine.InputSystem.TouchPhase.Ended);yield return .25f;
            Check(GameObject.Find("Achievement summary")&&game.Hud.BlocksWorldInput&&game.Sim.Paused,"Touch opens achievements screen and pauses restaurant");
            Check(Texts.Contains("0 / 12 ÖDÜL ALINDI")&&List.content.GetComponentsInChildren<Button>().Count(b=>b.name.StartsWith("Claim achievement "))==12,"Fresh game displays twelve permanent goals and empty collection count");
            Check(!Find("Claim achievement firstBurger").interactable&&!Find("Claim achievement branches").interactable,"Fresh game disables locked reward buttons");
            float time=game.Sim.Time;yield return .3f;Check(game.Sim.Time==time,"Reading achievements freezes live restaurant time");
            var legacy=new Progress{version=8,coins=111,xp=900,served=30,classicSold=45,cheeseSold=20,doubleSold=35,cleaned=50,earned=10000,cashier=1,cook=1,waiter=1,cleaner=1,grill=2,cheese=1,blender=1,doubleBurger=1,tutorialDone=true};
            SetSimulation(new Simulation(JsonUtility.FromJson<Progress>(JsonUtility.ToJson(legacy))));game.Hud.RefreshPanel();yield return .25f;
            Check(game.Sim.P.version==BurgerEmpire.Core.Progress.CurrentVersion&&game.Sim.P.coins==111&&game.Sim.P.xp==900&&game.Sim.ReadyAchievements==6,"Unity JSON migration unlocks six earned goals without awarding coins or XP");
            Check(Find("Claim achievement hundredBurgers").interactable&&!Find("Claim achievement burgerMaster").interactable,"Completed and incomplete milestones show different button states");
            var sw=Center(List.viewport);Touch(sw,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;
            Touch(sw+Vector2.up*220,UnityEngine.InputSystem.TouchPhase.Moved);yield return .12f;
            Touch(sw+Vector2.up*440,UnityEngine.InputSystem.TouchPhase.Moved);yield return .12f;
            Touch(sw+Vector2.up*440,UnityEngine.InputSystem.TouchPhase.Ended);yield return .2f;
            Check(List.content.anchoredPosition.y>80,"Finger swipe scrolls long achievement list");
            Check(game.CameraControls.Zoom==1&&game.Sim.Actors[0].job=="","Achievement scrolling never zooms camera or moves player");
            Reveal("firstBurger");yield return .2f;target=Center(Find("Claim achievement firstBurger").GetComponent<RectTransform>());
            Check(List.viewport.rect.Contains(List.viewport.InverseTransformPoint(target)),"First reward button is inside scrolled viewport");
            Touch(target,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;Touch(target,UnityEngine.InputSystem.TouchPhase.Ended);yield return .25f;
            Check(game.Sim.P.coins==151&&game.Sim.P.xp==925&&game.Sim.P.achievementsClaimed.SequenceEqual(new[]{"firstBurger"}),"Actual reward tap grants forty coins and twenty-five XP once");
            Check(!Find("Claim achievement firstBurger").interactable&&Texts.Contains("1 / 12 ÖDÜL ALINDI"),"Claimed achievement disables its button and updates collection count");
            var saved=JsonUtility.FromJson<Progress>(File.ReadAllText("BurgerEmpireAchievementValidationSave.json"));
            Check(saved.coins==151&&saved.achievementsClaimed.Contains("firstBurger"),"Reward tap immediately saves the actual claimed flag and wallet to isolated validation file");
            int wallet=game.Sim.P.coins;game.Command("achieve","firstBurger");game.Command("achieve","burgerMaster");
            Check(game.Sim.P.coins==wallet,"Repeated and locked achievement commands cannot pay");
            SetSimulation(new Simulation(saved));game.Hud.RefreshPanel();yield return .2f;
            Check(!Find("Claim achievement firstBurger").interactable&&game.Sim.P.coins==151,"Unity reload keeps collected reward unavailable");
            var rich=new Progress{coins=4000,xp=1500,served=40,classicSold=110,cheeseSold=30,doubleSold=5,shakeSold=25,cleaned=55,earned=14000,cashier=1,cook=1,waiter=1,cleaner=1,grill=2,cheese=1,blender=1,doubleBurger=1,driveThru=2,delivery=2,driveServed=30,deliveryServed=28,reviewTotal=184,reviewCount=40,tutorialDone=true};
            SetSimulation(new Simulation(rich));game.Hud.RefreshPanel();yield return .2f;
            game.Command("achieve","hundredBurgers");wallet=game.Sim.P.coins;game.Sim.OpenLondon(out _);game.Hud.RefreshPanel();yield return .25f;
            Check(game.Sim.P.coins==wallet-1200&&game.Sim.P.achievementsClaimed.Contains("hundredBurgers")&&!Find("Claim achievement hundredBurgers").interactable,"Opening London preserves shared collected state and only charges branch price");
            Check(Find("Claim achievement branches").interactable&&game.Sim.Achievements().First(a=>a.definition.id=="hundredBurgers").current==145,"London opening unlocks two-city goal without duplicating Istanbul sales");
            Reveal("branches");yield return .2f;target=Center(Find("Claim achievement branches").GetComponent<RectTransform>());wallet=game.Sim.P.coins;
            Touch(target,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;Touch(target,UnityEngine.InputSystem.TouchPhase.Ended);yield return .25f;
            Check(game.Sim.P.coins==wallet+200&&game.Sim.P.achievementsClaimed.Contains("branches"),"Two-city reward can be collected with real touch after switching branches");
            game.Sim.SwitchBranch(0,out _);game.Hud.RefreshPanel();yield return .2f;wallet=game.Sim.P.coins;game.Command("achieve","branches");
            Check(game.Sim.P.coins==wallet&&!Find("Claim achievement branches").interactable,"Returning home cannot repeat global branch reward");
            var claims=string.Join(",",game.Sim.P.achievementsClaimed);game.Sim.RefreshDay("2099-02-01");game.Hud.RefreshPanel();yield return .2f;
            Check(string.Join(",",game.Sim.P.achievementsClaimed)==claims&&game.Sim.ReadyAchievements>0,"Changing day preserves earned and unclaimed permanent goals");
            game.Sim.P.reviewTotal=120;game.Hud.RefreshPanel();yield return .2f;
            Check(Find("Claim achievement rating").interactable,"Reputation reward remains available after rating drops");
            game.Hud.OpenPanel("Görevler");yield return .2f;
            Check(Find("Open achievements").GetComponentInChildren<Text>().text.Contains("ÖDÜL HAZIR"),"Daily missions page advertises available achievement rewards");
            target=Center(Find("Open achievements").GetComponent<RectTransform>());Touch(target,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;Touch(target,UnityEngine.InputSystem.TouchPhase.Ended);yield return .2f;
            Bounds("2340x1080");Reveal("firstBurger");yield return .25f;
            typeof(RestaurantHud).GetField("toastTime",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game.Hud,0f);
            ScreenCapture.CaptureScreenshot(Path.GetFullPath("BurgerEmpire-0.12-Achievements.png"));yield return .3f;
            BurgerEmpireMobileChecks.SetSize(1280,720);yield return .6f;Bounds("1280x720");
            BurgerEmpireMobileChecks.SetSize(1080,2340);yield return .6f;Bounds("1080x2340");
            List.StopMovement();List.verticalNormalizedPosition=1;yield return .2f;
            ScreenCapture.CaptureScreenshot(Path.GetFullPath("BurgerEmpire-0.12-Portrait.png"));yield return .3f;
            target=Center(Find("Achievements back").GetComponent<RectTransform>());TraceTouch(target,"Before back");
            Touch(target,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;TraceTouch(target,"Back pressed");
            Touch(target,UnityEngine.InputSystem.TouchPhase.Ended);yield return .25f;TraceTouch(target,"Back released");
            Check(Find("Open achievements")&&game.Hud.BlocksWorldInput,"Back button returns to daily missions without unpausing shift");
            game.Hud.ClosePanel();game.Sim.Paused=false;game.Hud.OpenPanel("Başarımlar");yield return .15f;
            target=Center(Find("×").GetComponent<RectTransform>());Touch(target,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;Touch(target,UnityEngine.InputSystem.TouchPhase.Ended);yield return .2f;
            Check(!game.Hud.BlocksWorldInput&&!game.Sim.Paused,"Touch close resumes previously running restaurant");game.Sim.Paused=true;
            BurgerEmpireMobileChecks.SetSize(2340,1080);yield return .5f;
            Check(File.ReadAllText("BurgerEmpireSave.json")==disk,"All achievement fixture purchases and rewards preserve actual player save");
            File.AppendAllText(Report,"Completed. Unity touch, isolated disk save and JSON reload tested; physical Android not tested.\n");
        }
    }
}
#endif
