#if UNITY_EDITOR
using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.Build;
using UnityEngine;

namespace BurgerEmpire.Editor
{
    [InitializeOnLoad]
    public sealed class BurgerEmpireRelease : EditorWindow
    {
        const string Request="BurgerEmpireReleaseAudit.request",Prepare="BurgerEmpireReleasePrepare.request";
        Vector2 positionInReport;
        string report="";
        static double next;
        static BurgerEmpireRelease(){EditorApplication.update+=Requests;}
        static void Requests()
        {
            if(EditorApplication.isCompiling||EditorApplication.isUpdating||EditorApplication.isPlayingOrWillChangePlaymode||EditorApplication.timeSinceStartup<next)return;
            next=EditorApplication.timeSinceStartup+1;
            bool prepare=File.Exists(Prepare),audit=File.Exists(Request);
            if(!prepare&&!audit)return;
            try {
                if(prepare){File.Delete(Prepare);ApplyVersion();}
                if(audit)File.Delete(Request);
                WriteReport();
            } catch(Exception e){File.WriteAllText("BurgerEmpireReleaseFailure.txt",e.ToString());}
        }
        // Explicit preparation changes only the two version fields; reporting never calls this.
        public static void ApplyVersion()
        {
            AndroidReleasePlan.ValidateVersion(PlayerSettings.bundleVersion,PlayerSettings.Android.bundleVersionCode);
            PlayerSettings.bundleVersion=AndroidReleasePlan.Version;
            PlayerSettings.Android.bundleVersionCode=AndroidReleasePlan.VersionCode;
            AssetDatabase.SaveAssets();
        }
        public static ReleaseSnapshot Capture()
        {
            bool icon=PlayerSettings.GetIcons(NamedBuildTarget.Android,IconKind.Any).Any(t=>t!=null)||PlayerSettings.GetIcons(NamedBuildTarget.Unknown,IconKind.Any).Any(t=>t!=null);
            foreach(var kind in PlayerSettings.GetSupportedIconKinds(NamedBuildTarget.Android))
                icon|=PlayerSettings.GetPlatformIcons(NamedBuildTarget.Android,kind).Any(slot=>slot.GetTextures().Any(t=>t!=null));
            return new ReleaseSnapshot{
                version=PlayerSettings.bundleVersion,code=PlayerSettings.Android.bundleVersionCode,
                package=PlayerSettings.GetApplicationIdentifier(NamedBuildTarget.Android),
                minApi=(int)PlayerSettings.Android.minSdkVersion,targetApi=(int)PlayerSettings.Android.targetSdkVersion,
                arm64=PlayerSettings.Android.targetArchitectures==AndroidArchitecture.ARM64,
                il2cpp=PlayerSettings.GetScriptingBackend(NamedBuildTarget.Android)==ScriptingImplementation.IL2CPP,
                androidModule=BuildPipeline.IsBuildTargetSupported(BuildTargetGroup.Android,BuildTarget.Android),
                sceneExists=File.Exists(AndroidReleasePlan.Scene),
                enabledScenes=EditorBuildSettings.scenes.Where(s=>s.enabled).Select(s=>s.path).ToArray(),
                landscape=PlayerSettings.defaultInterfaceOrientation==UIOrientation.AutoRotation&&PlayerSettings.allowedAutorotateToLandscapeLeft&&PlayerSettings.allowedAutorotateToLandscapeRight&&!PlayerSettings.allowedAutorotateToPortrait&&!PlayerSettings.allowedAutorotateToPortraitUpsideDown,
                customSigning=PlayerSettings.Android.useCustomKeystore,hasIcon=icon,bundle=EditorUserBuildSettings.buildAppBundle
            };
        }
        public static string WriteReport()
        {
            var snapshot=Capture();var result=AndroidReleasePlan.Evaluate(snapshot);
            string text=result.Text();
            File.WriteAllText("BurgerEmpireReleaseReport.txt",text);
            File.WriteAllText("BurgerEmpireReleaseReport.json",JsonUtility.ToJson(result,true));
            File.WriteAllText("BurgerEmpireReleaseSnapshot.json",JsonUtility.ToJson(snapshot,true));
            return text;
        }
        [MenuItem("Burger Empire/Android/Yayın hazırlık raporu (derlemez)")]
        public static void OpenReport()
        {
            var window=GetWindow<BurgerEmpireRelease>();window.titleContent=new GUIContent("Yayın hazırlığı");window.minSize=new Vector2(540,360);window.report=WriteReport();window.Show();
        }
        void OnGUI()
        {
            if(GUILayout.Button("Raporu yenile ve kaydet"))report=WriteReport();
            positionInReport=EditorGUILayout.BeginScrollView(positionInReport);
            float textHeight=EditorStyles.wordWrappedLabel.CalcHeight(new GUIContent(report),Mathf.Max(250,position.width-25));
            EditorGUILayout.SelectableLabel(report,EditorStyles.wordWrappedLabel,GUILayout.Height(textHeight+20));
            EditorGUILayout.EndScrollView();
        }
    }
}
#endif
