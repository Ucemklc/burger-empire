#if UNITY_EDITOR && ENABLE_INPUT_SYSTEM
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using BurgerEmpire.Core;
using BurgerEmpire.Unity;
using UnityEditor;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.LowLevel;
using UnityEngine.UI;
using Progress=BurgerEmpire.Core.Progress;

namespace BurgerEmpire.Editor
{
    [InitializeOnLoad]
    public static class BurgerEmpireDeliveryChecks
    {
        const string Pending="BurgerEmpire.DeliveryChecks",Report="BurgerEmpireDeliveryChecks.txt";
        static IEnumerator<float> steps;
        static double next;
        static int nextFrame;
        static BurgerEmpireGame game;
        static Simulation original;
        static string disk;
        static int lastEvent;
        static Touchscreen touch;
        static InputSettings.BackgroundBehavior background;
        static InputSettings.EditorInputBehaviorInPlayMode routing;
        static BurgerEmpireDeliveryChecks(){EditorApplication.update+=Update;}
        static void Update()
        {
            if(EditorApplication.isCompiling||EditorApplication.isUpdating)return;
            if(File.Exists("BurgerEmpireDeliveryChecks.request")) {
                try {File.Delete("BurgerEmpireDeliveryChecks.request");} catch(IOException){return;}
                File.WriteAllText(Report,"");SessionState.SetBool(Pending,true);
                nextFrame=0;
                if(!EditorApplication.isPlaying){BurgerEmpireSetup.Play();return;}
            }
            if(!EditorApplication.isPlaying||!SessionState.GetBool(Pending,false)||EditorApplication.timeSinceStartup<next||Time.frameCount<nextFrame)return;
            try {
                if(steps==null) {
                    game=UnityEngine.Object.FindFirstObjectByType<BurgerEmpireGame>();if(!game||game.Sim==null)return;
                    original=game.Sim;disk=File.ReadAllText("BurgerEmpireSave.json");game.ValidationActive=true;
                    lastEvent=(int)typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).GetValue(game);
                    background=InputSystem.settings.backgroundBehavior;InputSystem.settings.backgroundBehavior=InputSettings.BackgroundBehavior.IgnoreFocus;
                    // Route the synthetic touchscreen to the game even when another editor window has focus.
                    routing=InputSystem.settings.editorInputBehaviorInPlayMode;InputSystem.settings.editorInputBehaviorInPlayMode=InputSettings.EditorInputBehaviorInPlayMode.AllDeviceInputAlwaysGoesToGameView;
                    touch=InputSystem.AddDevice<Touchscreen>();steps=Run();
                }
                // Process each touch in the game loop even when editor callbacks run faster.
                if(steps.MoveNext()){next=EditorApplication.timeSinceStartup+steps.Current;nextFrame=Time.frameCount+3;}else Finish();
            } catch(Exception e){File.AppendAllText(Report,"FAIL: "+e+"\n");Finish();}
        }
        static void SetSimulation(Simulation value)
        {
            typeof(BurgerEmpireGame).GetProperty("Sim").SetValue(game,value);
            typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game,0);
            typeof(RestaurantHud).GetField("toastTime",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game.Hud,0f);
        }
        static void Finish()
        {
            if(touch!=null){InputSystem.RemoveDevice(touch);touch=null;}InputSystem.settings.backgroundBehavior=background;InputSystem.settings.editorInputBehaviorInPlayMode=routing;
            if(game&&original!=null) {
                if(game.LayoutEditor.Active)game.Hud.FinishLayout(false);
                SetSimulation(original);original.Paused=true;game.ValidationActive=false;game.Save();game.Hud.OpenPanel("Kurye teslimatı");
                typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game,lastEvent);
            }
            steps=null;original=null;nextFrame=0;SessionState.SetBool(Pending,false);
        }
        static Progress Fixture()
        {
            return new Progress{coins=2000,xp=900,tables=2,grill=2,cook=1,tutorialDone=true};
        }
        static void Check(bool good,string message)
        {File.AppendAllText(Report,(good?"PASS: ":"FAIL: ")+message+"\n");if(!good)throw new Exception(message);}
        static Button Find(string name){return UnityEngine.Object.FindObjectsByType<Button>(FindObjectsSortMode.None).First(b=>b.name==name&&b.gameObject.activeInHierarchy);}
        static Vector2 Center(RectTransform rt){return RectTransformUtility.WorldToScreenPoint(null,rt.TransformPoint(rt.rect.center));}
        static void Touch(Vector2 p,UnityEngine.InputSystem.TouchPhase phase)
        {InputSystem.QueueStateEvent(touch,new TouchState{touchId=1,position=p,phase=phase});}
        static bool Until(Func<bool> condition,int limit=1000)
        {
            game.Sim.Paused=false;
            for(int i=0;i<limit&&!condition();i++){if(game.Sim.Actors[0].job=="")game.Sim.Command("next");game.Sim.Tick(.1f);}
            game.Sim.Paused=true;return condition();
        }
        static bool WaitOnly(Func<bool> condition,int limit=2000)
        {
            game.Sim.Paused=false;
            for(int i=0;i<limit&&!condition();i++)game.Sim.Tick(.1f);
            game.Sim.Paused=true;return condition();
        }
        static IEnumerator<float> Run()
        {
            BurgerEmpireMobileChecks.SetSize(2340,1080);yield return .7f;
            if(game.LayoutEditor.Active)game.Hud.FinishLayout(false);
            if(game.Hud.BlocksWorldInput)game.Hud.ClosePanel();
            SetSimulation(new Simulation(Fixture()));game.Hud.OpenPanel("Restoran");yield return .3f;
            var target=Center(Find("KURYE TESLİMATI").GetComponent<RectTransform>());
            Touch(target,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;
            Touch(target,UnityEngine.InputSystem.TouchPhase.Ended);yield return .25f;
            Check(Find("Buy delivery").interactable,"Restaurant touch button opens eligible courier offer");
            var list=UnityEngine.Object.FindFirstObjectByType<ScrollRect>();var swipe=Center(list.viewport);
            Touch(swipe,UnityEngine.InputSystem.TouchPhase.Began);yield return .1f;
            Touch(swipe+Vector2.up*230,UnityEngine.InputSystem.TouchPhase.Moved);yield return .15f;
            Touch(swipe+Vector2.up*550,UnityEngine.InputSystem.TouchPhase.Moved);yield return .15f;
            Touch(swipe+Vector2.up*550,UnityEngine.InputSystem.TouchPhase.Ended);yield return .2f;
            Check(list.content.anchoredPosition.y>60,"Touch swipe scrolls courier panel to purchase and prices");
            list.content.anchoredPosition=new Vector2(0,170);yield return .2f;
            target=Center(Find("Buy delivery").GetComponent<RectTransform>());
            Check(list.viewport.rect.Contains(list.viewport.InverseTransformPoint(target)),"Courier opening button is visible inside phone viewport");
            Touch(target,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;
            Touch(target,UnityEngine.InputSystem.TouchPhase.Ended);yield return .3f;
            Check(game.Sim.P.delivery==1&&game.Sim.P.coins==1250,"Touch opens local delivery business for 750 coins");
            var world=GameObject.Find("Restaurant Environment").transform;
            Check(world.Find("Delivery station").gameObject.activeSelf&&world.Find("Delivery station/Packaging counter"),"Purchased packaging counter appears in restaurant");
            Check(!world.Find("Delivery station/Courier bay 2").gameObject.activeSelf,"First delivery level has two waiting bays");
            Check(GameObject.Find("Delivery stats")&&UnityEngine.Object.FindObjectsByType<Text>(FindObjectsSortMode.None).Any(t=>t.text.Contains("Klasik Menü · 37 coin")),"Courier panel shows statistics and rounded local menu prices");
            game.Hud.ClosePanel();foreach(var table in game.Sim.Tables)table.dirty=true;
            Check(WaitOnly(()=>game.Sim.Customers.Any(c=>c.delivery&&c.phase=="queue")),"Real courier spawns and reaches its waiting bay");yield return .3f;
            var courier=game.Sim.Customers.First(c=>c.delivery);
            Check(world.Find("Delivery couriers/Courier "+courier.id+"/Delivery backpack").gameObject.activeInHierarchy,"Courier is rendered with insulated delivery backpack");
            Check(game.GameCamera.pixelRect.Contains(game.GameCamera.WorldToScreenPoint(new Vector3(courier.x,1,courier.z))),"Courier waiting bay fits landscape restaurant viewport");
            Check(UnityEngine.Object.FindObjectsByType<FoodIconGraphic>(FindObjectsSortMode.None).Any(i=>i.Kind=="bag"&&i.gameObject.activeInHierarchy),"Order bubble identifies courier with a takeaway-bag illustration");
            game.Sim.Paused=false;yield return .2f;
            Check(Find("Sipariş al").interactable,"Courier can order when every table is dirty");
            target=Center(Find("Sipariş al").GetComponent<RectTransform>());
            Touch(target,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;
            Touch(target,UnityEngine.InputSystem.TouchPhase.Ended);yield return .2f;
            Check(WaitOnly(()=>courier.order=="ordered"||courier.order=="cooking"),"Touch order sends player to delivery counter and accepts order");
            Check(courier.table==-1&&game.Sim.Tables.All(t=>t.customer==0),"Courier never occupies a dining table");
            Check(WaitOnly(()=>courier.order=="ready"),"Hired cook automatically prepares courier recipe using shared grill");
            game.Sim.Paused=false;yield return .2f;target=Center(Find("Servis et").GetComponent<RectTransform>());
            Touch(target,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;
            Touch(target,UnityEngine.InputSystem.TouchPhase.Ended);yield return .2f;
            Check(WaitOnly(()=>game.Sim.Actors[0].job=="serve"&&game.Sim.Actors[0].stage==1),"Touch serve picks up food for courier packaging");yield return .2f;
            Check(game.transform.Find("Living Restaurant/player/Takeaway bag").gameObject.activeInHierarchy,"Player carries takeaway bag for courier handoff");
            Check(WaitOnly(()=>courier.order=="packing"),"Player reaches packaging counter before taking payment");yield return .3f;
            Check(world.Find("Delivery station/Packaging counter/Packing parcel").gameObject.activeInHierarchy&&game.Sim.P.deliveryServed==0,"Parcel appears while packing; delivery has not been paid early");
            var orderBubbles=(Dictionary<int,RectTransform>)typeof(RestaurantHud).GetField("customerBubbles",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).GetValue(game.Hud);
            Check(orderBubbles[courier.id].GetComponentsInChildren<FoodIconGraphic>().Any(i=>i.Kind=="spinner"&&i.gameObject.activeInHierarchy),"Courier bubble shows a spinner during timed packaging");
            typeof(RestaurantHud).GetField("toastTime",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game.Hud,0f);yield return .1f;
            ScreenCapture.CaptureScreenshot(Path.GetFullPath("BurgerEmpire-0.8-Delivery.png"));yield return .3f;
            Check(WaitOnly(()=>game.Sim.P.deliveryServed==1),"Packaging ends with automatic courier payment and exit");
            Check(game.Sim.P.coins==1250+game.Sim.P.deliveryEarned&&game.Sim.P.classicSold==1&&game.Sim.P.dailyServed==1,"Courier sale reconciles wallet, product count and daily progress");
            Check(game.Sim.Tables.All(t=>t.dirty)&&game.Sim.P.cleaned==0,"Courier service leaves dining tables unchanged");
            game.Hud.OpenPanel("Kurye teslimatı");yield return .2f;
            list=UnityEngine.Object.FindFirstObjectByType<ScrollRect>();list.content.anchoredPosition=new Vector2(0,400);yield return .2f;
            target=Center(Find("Buy delivery").GetComponent<RectTransform>());
            Check(list.viewport.rect.Contains(list.viewport.InverseTransformPoint(target)),"Courier upgrade button is visible inside viewport");
            int beforeUpgrade=game.Sim.P.coins;
            Touch(target,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;
            Touch(target,UnityEngine.InputSystem.TouchPhase.Ended);yield return .25f;
            Check(game.Sim.P.delivery==2&&game.Sim.P.coins==beforeUpgrade-500&&world.Find("Delivery station/Courier bay 2").gameObject.activeSelf,"Touch upgrade adds third bay and faster packaging for 500 coins");
            Check(!Find("Buy delivery").interactable,"Maximum courier upgrade cannot charge again");
            list=UnityEngine.Object.FindFirstObjectByType<ScrollRect>();list.verticalNormalizedPosition=1;yield return .2f;
            ScreenCapture.CaptureScreenshot(Path.GetFullPath("BurgerEmpire-0.8-DeliveryPanel.png"));yield return .3f;
            game.Sim.PrepareSave();var loaded=new Simulation(JsonUtility.FromJson<Progress>(JsonUtility.ToJson(game.Sim.P)));
            Check(loaded.P.version==BurgerEmpire.Core.Progress.CurrentVersion&&loaded.P.delivery==2&&loaded.P.deliveryServed==1&&loaded.P.deliveryEarned==game.Sim.P.deliveryEarned&&loaded.DeliveryQueue==0,"Unity serialization preserves courier progress and resets only transient orders");
            game.Hud.ClosePanel();game.Sim.Paused=true;game.Hud.BeginLayout();yield return .2f;
            Check(!world.Find("Delivery couriers").gameObject.activeInHierarchy&&world.Find("Delivery station").gameObject.activeSelf,"Layout mode hides couriers while keeping fixed packaging station");
            game.Hud.FinishLayout(false);game.Sim.Paused=true;
            var branchFixture=Fixture();branchFixture.coins=4000;branchFixture.served=30;branchFixture.delivery=2;branchFixture.driveThru=2;
            var branchSim=new Simulation(branchFixture);SetSimulation(branchSim);game.Hud.OpenPanel("Şubeler");yield return .2f;
            Check(WaitOnly(()=>branchSim.Customers.Any(c=>c.delivery&&c.phase=="queue")),"Branch travel scenario includes a real waiting courier");
            var waiting=branchSim.Customers.First(c=>c.delivery);float patience=waiting.patience;
            game.OpenLondon();yield return .3f;
            Check(game.Sim.P.activeBranch==1&&!world.Find("Delivery station").gameObject.activeSelf&&!world.Find("Delivery couriers").gameObject.activeSelf,"New branch hides other city's packaging station and couriers");
            game.VisitBranch(0);yield return .3f;
            Check(world.Find("Delivery station").gameObject.activeSelf&&branchSim.Customers.Contains(waiting)&&waiting.patience==patience,"Returning restores station and frozen courier order");
            game.Hud.ClosePanel();game.Sim.Paused=true;
            BurgerEmpireMobileChecks.SetSize(1280,720);yield return .5f;CheckBounds("1280x720");
            game.Hud.Toast("Paket teslim kontrolü");
            BurgerEmpireMobileChecks.SetSize(1080,2340);yield return .5f;CheckBounds("1080x2340");
            Check(UnityEngine.Object.FindObjectsByType<Text>(FindObjectsSortMode.None).Any(t=>t.text=="Paket teslim kontrolü"),"Changing phone dimensions preserves active toast text");
            typeof(RestaurantHud).GetField("toastTime",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game.Hud,0f);yield return .1f;
            Check(game.GameCamera.pixelRect.Contains(game.GameCamera.WorldToScreenPoint(new Vector3(Simulation.DeliveryBayX,1,Simulation.DeliveryBayZ(2)))),"Courier far bay fits portrait viewport with drive channel also active");
            Check(game.GameCamera.pixelRect.Contains(game.GameCamera.WorldToScreenPoint(new Vector3(Simulation.DriveWindowX,1,Simulation.DriveLaneZ))),"Drive pickup remains visible with courier channel in portrait");
            ScreenCapture.CaptureScreenshot(Path.GetFullPath("BurgerEmpire-0.8-Delivery-Portrait.png"));yield return .3f;
            game.Hud.OpenPanel("Kurye teslimatı");yield return .2f;
            ScreenCapture.CaptureScreenshot(Path.GetFullPath("BurgerEmpire-0.8-DeliveryPanel-Portrait.png"));yield return .3f;
            var locked=Fixture();locked.xp=0;SetSimulation(new Simulation(locked));game.Hud.OpenPanel("Kurye teslimatı");yield return .2f;
            Check(!Find("Buy delivery").interactable&&UnityEngine.Object.FindObjectsByType<Text>(FindObjectsSortMode.None).Any(t=>t.text=="Seviye 7 gerekiyor."),"Locked phone offer explains required level and prevents spending");
            BurgerEmpireMobileChecks.SetSize(2340,1080);yield return .5f;
            game.Save();Check(File.ReadAllText("BurgerEmpireSave.json")==disk,"Courier validation does not overwrite actual player progress");
            File.AppendAllText(Report,"Completed. Unity Input System touch verified. Physical Android device not tested.\n");
        }

        static void CheckBounds(string label)
        {
            var safe=Screen.safeArea;var corners=new Vector3[4];
            foreach(var button in UnityEngine.Object.FindObjectsByType<Button>(FindObjectsSortMode.None).Where(b=>b.gameObject.activeInHierarchy)) {
                var rt=button.GetComponent<RectTransform>();rt.GetWorldCorners(corners);
                // Only visible controls; clipped scrolling cards are intentionally outside the viewport.
                if(corners[2].y<safe.yMin||corners[0].y>safe.yMax)continue;
                Check(rt.rect.height>=48&&corners[0].x>=safe.xMin-1&&corners[2].x<=safe.xMax+1,label+": "+button.name+" touch size and horizontal bounds");
            }
        }
    }
}
#endif
