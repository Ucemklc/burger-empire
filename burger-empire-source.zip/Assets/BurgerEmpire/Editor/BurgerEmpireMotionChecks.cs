#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using BurgerEmpire.Core;
using BurgerEmpire.Unity;
using UnityEditor;
using UnityEngine;
using Progress=BurgerEmpire.Core.Progress;

namespace BurgerEmpire.Editor
{
    [InitializeOnLoad]
    public static class BurgerEmpireMotionChecks
    {
        const string Pending="BurgerEmpire.MotionChecks",Report="BurgerEmpireMotionChecks.txt";
        const BindingFlags Private=BindingFlags.Instance|BindingFlags.NonPublic;
        static IEnumerator<float> steps;
        static double next;
        static int nextFrame,lastEvent;
        static BurgerEmpireGame game;
        static Simulation original;
        static string disk;
        static BurgerEmpireMotionChecks(){EditorApplication.update+=Update;}
        static void Update()
        {
            if(EditorApplication.isCompiling||EditorApplication.isUpdating)return;
            if(File.Exists("BurgerEmpireMotionChecks.request")) {
                try{File.Delete("BurgerEmpireMotionChecks.request");}catch(IOException){return;}
                File.WriteAllText(Report,"");SessionState.SetBool(Pending,true);nextFrame=0;
                if(!EditorApplication.isPlaying){BurgerEmpireSetup.Play();return;}
            }
            if(!EditorApplication.isPlaying||!SessionState.GetBool(Pending,false)||EditorApplication.timeSinceStartup<next||Time.frameCount<nextFrame)return;
            try {
                if(steps==null) {
                    game=UnityEngine.Object.FindFirstObjectByType<BurgerEmpireGame>();if(!game||game.Sim==null)return;
                    original=game.Sim;disk=File.ReadAllText("BurgerEmpireSave.json");game.ValidationActive=true;
                    lastEvent=(int)typeof(BurgerEmpireGame).GetField("lastEvent",Private).GetValue(game);steps=Run();
                }
                if(steps.MoveNext()){next=EditorApplication.timeSinceStartup+steps.Current;nextFrame=Time.frameCount+3;}else Finish();
            }catch(Exception e){File.AppendAllText(Report,"FAIL: "+e+"\n");Finish();}
        }
        static void SetSimulation(Simulation sim)
        {
            typeof(BurgerEmpireGame).GetProperty("Sim").SetValue(game,sim);
            typeof(BurgerEmpireGame).GetField("lastEvent",Private).SetValue(game,0);
            typeof(RestaurantHud).GetField("toastTime",Private).SetValue(game.Hud,0f);
        }
        static void Finish()
        {
            if(game&&original!=null){SetSimulation(original);original.Paused=true;game.ValidationActive=false;game.Save();typeof(BurgerEmpireGame).GetField("lastEvent",Private).SetValue(game,lastEvent);}
            original=null;steps=null;nextFrame=0;SessionState.SetBool(Pending,false);
        }
        static void Check(bool passed,string label)
        {File.AppendAllText(Report,(passed?"PASS: ":"FAIL: ")+label+"\n");if(!passed)throw new Exception(label);}
        static IEnumerator<float> Run()
        {
            BurgerEmpireMobileChecks.SetSize(2340,1080);yield return .4f;
            if(game.LayoutEditor.Active)game.Hud.FinishLayout(false);
            if(game.Hud.BlocksWorldInput)game.Hud.ClosePanel();
            var stage=new GameObject("Motion verification stage").transform;
            try {
                var p=RestaurantArt.BuildPerson("waiter",0,stage);
                p.UpdatePosition(50,0,1,false,false,"",Vector3.forward);
                var initial=p.root.rotation;
                p.UpdatePosition(50.05f,0,1.02f,false);
                Check(p.motion.State=="walk"&&p.motion.Stride>0&&p.motion.Stride<.3f,"Walking eases in instead of instantly switching to full stride");
                Check(Quaternion.Angle(initial,p.root.rotation)>1&&Quaternion.Angle(initial,p.root.rotation)<10,"Direction changes are limited to 480 degrees per simulation second");
                for(int i=2;i<=30;i++)p.UpdatePosition(50+i*.05f,0,1+i*.02f,false);
                Check(p.motion.Stride>.99f&&Quaternion.Angle(p.root.rotation,Quaternion.LookRotation(Vector3.right))<.1f,"Continuous walking reaches full stride and turns toward its path");
                Check(Mathf.Abs(p.leftLeg.localPosition.y-p.rightLeg.localPosition.y)>.003f,"Opposite feet lift during the walking cycle");
                float stride=p.motion.Stride;p.UpdatePosition(51.5f,0,1.62f,false,false,"waiting");
                Check(p.motion.State=="waiting"&&p.motion.Stride>0&&p.motion.Stride<stride,"Stopping eases out into a waiting pose");
                for(int i=1;i<=30;i++)p.UpdatePosition(51.5f,0,1.62f+i*.02f,false,false,"waiting");
                Check(p.motion.Stride<.001f,"Waiting settles the legs without sliding across the floor");
                var joints=p.root.GetComponentsInChildren<Transform>().Select(t=>t.localRotation).ToArray();var pos=p.root.position;
                p.UpdatePosition(51.5f,0,2.22f,false,false,"waiting");
                Check(p.root.position==pos&&p.root.GetComponentsInChildren<Transform>().Select(t=>t.localRotation).SequenceEqual(joints),"Pausing freezes the blended pose exactly");
                p.motion.Reset();p.UpdatePosition(55,0,5,false,false,"waiting");
                Check(p.motion.Stride==0&&p.motion.State=="waiting"&&Mathf.Abs(p.root.position.x-55)<.001f,"Pooled character reuse resets gait without false movement");
                p.UpdatePosition(55,0,5.1f,true,false,"waiting");
                Check(p.food.gameObject.activeSelf&&!p.rightArm.Find("Spatula").gameObject.activeSelf,"Yielding waiter keeps its tray and suppresses work tools");
                p.UpdatePosition(55,0,5.2f,false,true,"impatient");
                Check(p.motion.State=="impatient"&&Quaternion.Angle(p.leftLeg.localRotation,Quaternion.Euler(-78,0,0))<.1f,"Impatient seated guest keeps the seated leg pose");
                var thirty=RestaurantArt.BuildPerson("player",0,stage);var sixty=RestaurantArt.BuildPerson("player",0,stage);
                thirty.UpdatePosition(56,0,0,false);sixty.UpdatePosition(56,2,0,false);
                for(int i=1;i<=30;i++)thirty.UpdatePosition(56+i/30f,0,i/30f,false);
                for(int i=1;i<=60;i++)sixty.UpdatePosition(56+i/60f,2,i/60f,false);
                Check(Quaternion.Angle(thirty.leftLeg.localRotation,sixty.leftLeg.localRotation)<.1f&&Mathf.Abs(thirty.motion.Stride-sixty.motion.Stride)<.001f,"Distance-based gait stays consistent at 30 and 60 updates per second");
            }finally{UnityEngine.Object.Destroy(stage.gameObject);}
            var sim=new Simulation(new Progress{tutorialDone=true,served=40,cashier=3,cook=3,waiter=3,cleaner=3,manager=1,tables=4,grill=3,fryer=3,blender=2,cheese=1,doubleBurger=1,driveThru=2,delivery=2,decor=1},53);
            SetSimulation(sim);yield return .2f;
            bool separation=true,matched=true,waitingPose=false;int detours=0;float minimum=99;
            for(int frame=0;frame<3000;frame++) {
                sim.Paused=false;sim.Tick(.1f);sim.Paused=true;
                var points=sim.Actors.Select(a=>new Vector2(a.x,a.z)).Concat(sim.Customers.Where(c=>!c.drive).Select(c=>new Vector2(c.x,c.z))).ToArray();
                for(int a=0;a<points.Length;a++)for(int b=a+1;b<points.Length;b++)minimum=Mathf.Min(minimum,Vector2.Distance(points[a],points[b]));
                separation&=minimum>=Simulation.PersonalSpace-.003f;detours+=sim.Actors.Count(a=>a.crowd.detour.Count>0);
                if(frame%30==0) {
                    yield return .01f;
                    var living=game.transform.Find("Living Restaurant");
                    foreach(var a in sim.Actors){var visual=living.Find(a.role);matched&=Vector2.Distance(new Vector2(visual.position.x,visual.position.z),new Vector2(a.x,a.z))<.001f;}
                    var visuals=(Dictionary<string,RestaurantArt.Person>)typeof(BurgerEmpireGame).GetField("actors",Private).GetValue(game);
                    waitingPose|=sim.Actors.Any(a=>a.crowd.waiting&&visuals[a.role].motion.State=="waiting");
                }
            }
            Check(separation,"Five-minute rendered shift keeps pedestrian centers separated; minimum "+minimum);
            Check(matched,"All visible workers match authoritative collision-checked positions");
            Check(waitingPose&&detours>0,"Real crowd encounters activate waiting animation and safe detours");
            Check(sim.P.served>55&&sim.P.cleaned>10&&sim.P.driveServed>0&&sim.P.deliveryServed>0,"Rendered crowd shift keeps dining, vehicle, courier and cleaning work active");
            yield return .2f;
            ScreenCapture.CaptureScreenshot(Path.GetFullPath("BurgerEmpire-0.17-Crowd.png"));yield return .3f;
            Check(File.ReadAllText("BurgerEmpireSave.json")==disk,"Motion fixtures do not overwrite the latest player save");
            File.AppendAllText(Report,"Completed. Unity animation and crowd movement verified; physical Android performance not measured.\n");
        }
    }
}
#endif
