#if UNITY_EDITOR && ENABLE_INPUT_SYSTEM
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using BurgerEmpire.Core;
using BurgerEmpire.Unity;
using UnityEditor;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.LowLevel;
using UnityEngine.UI;
using Progress=BurgerEmpire.Core.Progress;

namespace BurgerEmpire.Editor
{
    [InitializeOnLoad]
    public static class BurgerEmpireMusicChecks
    {
        const string Pending="BurgerEmpire.MusicChecks",Report="BurgerEmpireMusicChecks.txt";
        static IEnumerator<float> steps;
        static double next;
        static int nextFrame;
        static BurgerEmpireGame game;
        static Simulation original;
        static string disk;
        static float originalMusic,originalEffects;
        static bool originalSound,hadMusic,hadEffects,hadSound;
        static int lastEvent;
        static Touchscreen touch;
        static InputSettings.BackgroundBehavior background;
        static InputSettings.EditorInputBehaviorInPlayMode routing;
        static BurgerEmpireMusicChecks(){EditorApplication.update+=Update;}
        static void Update()
        {
            if(EditorApplication.isCompiling||EditorApplication.isUpdating)return;
            if(File.Exists("BurgerEmpireMusicChecks.request")) {
                try {File.Delete("BurgerEmpireMusicChecks.request");} catch(IOException){return;}
                File.WriteAllText(Report,"");SessionState.SetBool(Pending,true);nextFrame=0;
                if(!EditorApplication.isPlaying){BurgerEmpireSetup.Play();return;}
            }
            if(!EditorApplication.isPlaying||!SessionState.GetBool(Pending,false)||EditorApplication.timeSinceStartup<next||Time.frameCount<nextFrame)return;
            try {
                if(steps==null) {
                    game=UnityEngine.Object.FindFirstObjectByType<BurgerEmpireGame>();if(!game||game.Sim==null)return;
                    originalMusic=game.MusicVolume;originalEffects=game.EffectsVolume;originalSound=game.SoundEnabled;
                    hadMusic=PlayerPrefs.HasKey("BurgerEmpire.MusicVolume");hadEffects=PlayerPrefs.HasKey("BurgerEmpire.EffectsVolume");hadSound=PlayerPrefs.HasKey("BurgerEmpire.Sound");
                    original=game.Sim;disk=File.ReadAllText("BurgerEmpireSave.json");game.ValidationActive=true;
                    lastEvent=(int)typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).GetValue(game);
                    background=InputSystem.settings.backgroundBehavior;InputSystem.settings.backgroundBehavior=InputSettings.BackgroundBehavior.IgnoreFocus;
                    routing=InputSystem.settings.editorInputBehaviorInPlayMode;InputSystem.settings.editorInputBehaviorInPlayMode=InputSettings.EditorInputBehaviorInPlayMode.AllDeviceInputAlwaysGoesToGameView;
                    touch=InputSystem.AddDevice<Touchscreen>();steps=Run();
                }
                if(steps.MoveNext()){next=EditorApplication.timeSinceStartup+steps.Current;nextFrame=Time.frameCount+3;}else Finish();
            } catch(Exception e){File.AppendAllText(Report,"FAIL: "+e+"\n");Finish();}
        }
        static void SetSimulation(Simulation value)
        {
            typeof(BurgerEmpireGame).GetProperty("Sim").SetValue(game,value);
            typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game,0);
            typeof(RestaurantHud).GetField("toastTime",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game.Hud,0f);
        }
        static void Finish()
        {
            if(touch!=null){InputSystem.RemoveDevice(touch);touch=null;}InputSystem.settings.backgroundBehavior=background;InputSystem.settings.editorInputBehaviorInPlayMode=routing;
            if(game&&original!=null) {
                if(game.LayoutEditor.Active)game.Hud.FinishLayout(false);
                game.SetAudioLevels(originalMusic,originalEffects);game.SetSound(originalSound);
                if(!hadMusic)PlayerPrefs.DeleteKey("BurgerEmpire.MusicVolume");if(!hadEffects)PlayerPrefs.DeleteKey("BurgerEmpire.EffectsVolume");if(!hadSound)PlayerPrefs.DeleteKey("BurgerEmpire.Sound");PlayerPrefs.Save();
                SetSimulation(original);original.Paused=true;game.ValidationActive=false;game.Save();game.Hud.OpenPanel("Ses Ayarları");
                typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game,lastEvent);
            }
            steps=null;original=null;nextFrame=0;SessionState.SetBool(Pending,false);
        }
        static Progress Fixture()
        {
            var p=JsonUtility.FromJson<Progress>(JsonUtility.ToJson(original.P));
            p.coins=3000;p.xp=700;p.grill=2;p.fryer=1;p.blender=0;p.doubleBurger=0;p.cheese=1;p.mission=5;p.tutorialDone=true;
            p.shakeSold=p.doubleSold=0;p.activeBranch=0;p.chickenBurger=p.bbqBurger=p.chocolateShake=0;return p;
        }
        static void Check(bool good,string message)
        {File.AppendAllText(Report,(good?"PASS: ":"FAIL: ")+message+"\n");if(!good)throw new Exception(message);}
        static Button Find(string name){return UnityEngine.Object.FindObjectsByType<Button>(FindObjectsSortMode.None).First(b=>b.name==name&&b.gameObject.activeInHierarchy);}
        static Vector2 Center(RectTransform rt){return RectTransformUtility.WorldToScreenPoint(null,rt.TransformPoint(rt.rect.center));}
        static void Touch(Vector2 p,UnityEngine.InputSystem.TouchPhase phase)
        {InputSystem.QueueStateEvent(touch,new TouchState{touchId=1,position=p,phase=phase});}
        static bool Until(Func<bool> condition,int limit=1000)
        {
            game.Sim.Paused=false;
            for(int i=0;i<limit&&!condition();i++){if(game.Sim.Actors[0].job=="")game.Sim.Command("next");game.Sim.Tick(.1f);}
            game.Sim.Paused=true;return condition();
        }


        static string Tab=>(string)typeof(RestaurantHud).GetField("tab",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).GetValue(game.Hud);
        static bool HasText(string value)=>UnityEngine.Object.FindObjectsByType<Text>(FindObjectsSortMode.None).Any(t=>t.gameObject.activeInHierarchy&&t.text.Contains(value));
        static IEnumerator<float> Tap(string name)
        {
            var button=Find(name);var list=button.GetComponentInParent<ScrollRect>();
            if(list) {
                var rt=button.GetComponent<RectTransform>();
                float offset=-list.content.InverseTransformPoint(rt.TransformPoint(rt.rect.center)).y-list.viewport.rect.height*.5f;
                list.content.anchoredPosition=new Vector2(0,Mathf.Clamp(offset,0,list.content.rect.height-list.viewport.rect.height));
                list.StopMovement();Canvas.ForceUpdateCanvases();yield return .15f;
            }
            var point=Center(Find(name).GetComponent<RectTransform>());
            Touch(point,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;
            Touch(point,UnityEngine.InputSystem.TouchPhase.Ended);yield return .2f;
        }

        const System.Reflection.BindingFlags Private=System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic;
        static RestaurantAudio Audio=>(RestaurantAudio)typeof(BurgerEmpireGame).GetField("restaurantAudio",Private).GetValue(game);
        static AudioSource Source(string name)=>game.transform.Find(name).GetComponent<AudioSource>();
        static IEnumerator<float> Run()
        {
            BurgerEmpireMobileChecks.SetSize(2340,1080);yield return .6f;
            if(game.LayoutEditor.Active)game.Hud.FinishLayout(false);
            if(game.Hud.BlocksWorldInput)game.Hud.ClosePanel();
            SetSimulation(new Simulation(new Progress{tutorialDone=true,coins=1000,xp=900}));game.SetAudioLevels(.55f,1);game.SetSound(true);yield return .2f;
            var music=Source("Restaurant music");
            Check(game.GetComponentsInChildren<AudioSource>().Length==4&&music.loop&&!music.playOnAwake&&music.spatialBlend==0,"Exactly one reusable 2D music voice joins three existing sound voices");
            Check(music.clip.samples==(int)(MusicDesign.Duration*MusicDesign.SampleRate)&&music.clip.channels==1&&music.clip.frequency==22050,"Original eight-bar PCM loop loads in Unity");
            Check(!music.isPlaying,"Paused restaurant starts without background music");
            game.Sim.Paused=false;yield return .4f;
            Check(music.isPlaying&&Mathf.Abs(music.volume-.088f)<.001f,"Active shift starts quiet music at default 55 percent");
            game.Hud.OpenPanel("Restoran");yield return .2f;
            int sample=music.timeSamples;yield return .3f;
            Check(!music.isPlaying&&music.timeSamples==sample,"Management panel holds music playback position");
            foreach(var wait in Enumerate(Tap("Open audio settings")))yield return wait;
            Check(Tab=="Ses Ayarları"&&game.Sim.Paused,"Real touch opens sound settings while shift stays paused");
            foreach(var wait in Enumerate(Tap("Audio down music")))yield return wait;
            Check(Mathf.Abs(game.MusicVolume-.45f)<.001f&&game.EffectsVolume==1&&HasText("%45"),"Music minus changes only music by ten percentage points");
            foreach(var wait in Enumerate(Tap("Audio down effects")))yield return wait;
            Check(Mathf.Abs(game.EffectsVolume-.9f)<.001f&&Mathf.Abs(game.MusicVolume-.45f)<.001f,"Effects minus leaves music unchanged");
            foreach(var wait in Enumerate(Tap("Audio up music")))yield return wait;
            Check(Mathf.Abs(PlayerPrefs.GetFloat("BurgerEmpire.MusicVolume")-.55f)<.001f&&Mathf.Abs(PlayerPrefs.GetFloat("BurgerEmpire.EffectsVolume")-.9f)<.001f,"Both independent choices are persisted under separate preference keys");
            Check(Mathf.Abs(Source("Restaurant effects").volume-.18f)<.001f&&Mathf.Abs(Source("Grill ambience").volume-.0675f)<.001f,"Effect level scales effect and kitchen sources together");
            CheckBounds("2340x1080");CheckText();
            ScreenCapture.CaptureScreenshot("BurgerEmpire-0.22-Audio.png");yield return .3f;
            game.Hud.ClosePanel();yield return .15f;
            Check(!game.Sim.Paused&&music.isPlaying&&music.timeSamples>=sample&&music.timeSamples<sample+22050,"Leaving management resumes the previous musical position");
            game.Sim.Customers.Add(new Customer{id=820,phase="waiting",order="cooking",station="grill",table=0,patience=1000,maxPatience=1000,cookTime=1000});yield return .1f;
            game.SetAudioLevels(0,1);yield return .15f;
            Check(!music.isPlaying&&Source("Grill ambience").isPlaying&&Audio.Play("coin"),"Zero music leaves cooking and effect cues enabled");
            game.SetAudioLevels(.6f,0);yield return .15f;
            Check(music.isPlaying&&!Source("Grill ambience").isPlaying&&!Source("Restaurant effects").isPlaying&&!Audio.Play("coin"),"Zero effects silences kitchen and cues while music continues");
            game.Hud.Toast("Sipariş hazır!","ready");yield return .15f;Check(HasText("Sipariş hazır!"),"Visual notifications remain available with effects off");
            game.Hud.OpenPanel("Ses Ayarları");yield return .15f;
            Check(!Find("Audio down effects").interactable,"Zero-level minus button is disabled");
            game.SetAudioLevels(1,1);yield return .15f;
            Check(!Find("Audio up music").interactable&&!Find("Audio up effects").interactable,"Maximum-level plus buttons are disabled");
            foreach(var wait in Enumerate(Tap("Audio master")))yield return wait;
            Check(!game.SoundEnabled&&game.GetComponentsInChildren<AudioSource>().All(s=>!s.isPlaying)&&game.MusicVolume==1&&game.EffectsVolume==1,"Master mute stops all voices without discarding chosen levels");
            foreach(var wait in Enumerate(Tap("Audio master")))yield return wait;
            Check(game.SoundEnabled&&!music.isPlaying&&HasText("SES"),"Unmuting updates header and waits for active shift before music");
            BurgerEmpireMobileChecks.SetSize(1080,2340);yield return .5f;CheckBounds("1080x2340");CheckText();
            Check(Tab=="Ses Ayarları"&&game.MusicVolume==1&&game.EffectsVolume==1,"Rotation preserves the settings page and selected levels");
            ScreenCapture.CaptureScreenshot("BurgerEmpire-0.22-Audio-Portrait.png");yield return .3f;
            foreach(var wait in Enumerate(Tap("Audio down music")))yield return wait;
            Check(Mathf.Abs(game.MusicVolume-.9f)<.001f,"Portrait touch changes music level");
            game.Hud.ClosePanel();game.Sim.Paused=false;yield return .1f;game.Suspend();yield return .1f;
            Check(game.Sim.Paused&&game.GetComponentsInChildren<AudioSource>().All(s=>!s.isPlaying),"Backgrounding silences music and all other sources");
            game.Sim.Paused=false;yield return .15f;Check(music.isPlaying,"Explicitly resuming after background restores music");
            game.Sim.Paused=true;yield return .1f;
            SetSimulation(new Simulation(new Progress{tutorialDone=true,londonOpen=true,london=new RestaurantProgress{tutorialDone=true}}));game.Sim.SwitchBranch(1,out _);yield return .15f;
            Check(!music.isPlaying&&game.GetComponentsInChildren<AudioSource>().Length==4,"Switching branch does not duplicate or overlap music voices");
            game.Sim.Paused=false;yield return .1f;Check(music.isPlaying,"New branch uses the same music preferences");
            game.Sim.Paused=true;game.SetAudioLevels(float.NaN,float.PositiveInfinity);yield return .1f;
            Check(game.MusicVolume==.55f&&game.EffectsVolume==1,"Invalid volume values fall back to valid defaults");
            game.Hud.OpenPanel("Ses Ayarları");BurgerEmpireMobileChecks.SetSize(1280,720);yield return .5f;CheckBounds("1280x720");CheckText();
            ExportPreview(music.clip);
            BurgerEmpireMobileChecks.SetSize(2340,1080);yield return .4f;
            game.Save();Check(File.ReadAllText("BurgerEmpireSave.json")==disk,"Music tests never alter the actual restaurant save");
            File.AppendAllText(Report,"Completed. PCM, touch volume controls, loop pause/resume, mute, background and branch behavior verified. Physical phone speakers not tested.\n");
        }
        static void ExportPreview(AudioClip clip)
        {
            var data=new float[clip.samples];clip.GetData(data,0);
            using(var writer=new BinaryWriter(File.Create("BurgerEmpire-0.22-Music-Preview.wav"))) {
                writer.Write(System.Text.Encoding.ASCII.GetBytes("RIFF"));writer.Write(36+data.Length*2);writer.Write(System.Text.Encoding.ASCII.GetBytes("WAVEfmt "));writer.Write(16);writer.Write((short)1);writer.Write((short)1);writer.Write(22050);writer.Write(44100);writer.Write((short)2);writer.Write((short)16);writer.Write(System.Text.Encoding.ASCII.GetBytes("data"));writer.Write(data.Length*2);
                foreach(var value in data)writer.Write((short)(value*.8f*32767));
            }
        }
        static IEnumerable<float> Enumerate(IEnumerator<float> source){while(source.MoveNext())yield return source.Current;}
        static void CheckText()
        {
            var list=UnityEngine.Object.FindFirstObjectByType<ScrollRect>();
            var labels=list.content.GetComponentsInChildren<Text>().Where(t=>t.gameObject.activeInHierarchy).ToArray();
            Check(labels.All(t=>t.preferredHeight<=t.rectTransform.rect.height+1),"Audio settings text fits its allocated height at "+Screen.width+"x"+Screen.height);
        }
        static void CheckBounds(string label)
        {
            var safe=Screen.safeArea;var corners=new Vector3[4];
            foreach(var button in UnityEngine.Object.FindObjectsByType<Button>(FindObjectsSortMode.None).Where(b=>b.gameObject.activeInHierarchy)) {
                var rt=button.GetComponent<RectTransform>();rt.GetWorldCorners(corners);
                // Only visible controls; clipped scrolling cards are intentionally outside the viewport.
                if(corners[2].y<safe.yMin||corners[0].y>safe.yMax)continue;
                Check(rt.rect.height>=48&&corners[0].x>=safe.xMin-1&&corners[2].x<=safe.xMax+1,label+": "+button.name+" touch size and horizontal bounds");
            }
        }
    }
}
#endif

