#if UNITY_EDITOR
using System;
using System.IO;
using System.Reflection;
using BurgerEmpire.Core;
using BurgerEmpire.Unity;
using UnityEditor;
using UnityEngine;
using Progress=BurgerEmpire.Core.Progress;

namespace BurgerEmpire.Editor
{
    [InitializeOnLoad]
    public static class BurgerEmpirePlaytestChecks
    {
        const string Prefix="BurgerEmpire.PlaytestChecks.",Report="BurgerEmpirePlaytestChecks.txt";
        static int Phase {get=>SessionState.GetInt(Prefix+"phase",0);set=>SessionState.SetInt(Prefix+"phase",value);}
        static string Get(string key)=>SessionState.GetString(Prefix+key,"");
        static void Put(string key,string value)=>SessionState.SetString(Prefix+key,value);
        static BurgerEmpirePlaytestChecks(){EditorApplication.update+=Update;}
        static void Check(bool good,string description)
        {File.AppendAllText(Report,(good?"PASS: ":"FAIL: ")+description+"\n");if(!good)throw new Exception(description);}
        static string Preferences()=>PlayerPrefs.HasKey("BurgerEmpire.Language")+":"+PlayerPrefs.GetString("BurgerEmpire.Language")+"|"+
            PlayerPrefs.HasKey("BurgerEmpire.Sound")+":"+PlayerPrefs.GetInt("BurgerEmpire.Sound")+"|"+
            PlayerPrefs.HasKey("BurgerEmpire.MusicVolume")+":"+PlayerPrefs.GetFloat("BurgerEmpire.MusicVolume")+"|"+
            PlayerPrefs.HasKey("BurgerEmpire.EffectsVolume")+":"+PlayerPrefs.GetFloat("BurgerEmpire.EffectsVolume");
        static void Unchanged()
        {
            Check(File.ReadAllText("BurgerEmpireSave.json")==Get("disk"),"Real player save is byte-for-byte unchanged");
            Check(Preferences()==Get("preferences"),"Real language, sound and volume preferences remain unchanged");
        }
        static void Update()
        {
            if(EditorApplication.isCompiling||EditorApplication.isUpdating||EditorApplication.isPlayingOrWillChangePlaymode!=EditorApplication.isPlaying)return;
            try {
                if(File.Exists("BurgerEmpirePlaytestChecks.request")) {
                    if(EditorApplication.isPlaying){EditorApplication.isPlaying=false;return;}
                    File.Delete("BurgerEmpirePlaytestChecks.request");File.WriteAllText(Report,"");
                    Put("disk",File.ReadAllText("BurgerEmpireSave.json"));Put("preferences",Preferences());
                    Check(!EditorPlaytestSession.Active,"Ordinary editor has no test profile selected");
                    Check(EditorPlaytestSession.ResolveSavePath("normal.json")=="normal.json","Ordinary save path remains unchanged");
                    Check(EditorPlaytestSession.PreferenceKey("BurgerEmpire.Sound")=="BurgerEmpire.Sound","Ordinary preference keys remain unchanged");
                    bool rejected=false;try{EditorPlaytestSession.Select("../BurgerEmpireSave.json");}catch(InvalidOperationException){rejected=true;}
                    Check(rejected&&!EditorPlaytestSession.Active,"Invalid profile identifier is rejected without falling back or enabling test mode");
                    Put("id",EditorPlaytestSession.NewProfile());Phase=1;BurgerEmpireSetup.Play();return;
                }
                if(Phase==0)return;
                if(Phase==2&&!EditorApplication.isPlaying) {
                    Check(!EditorPlaytestSession.Active,"Stopping Play clears the test selector");Unchanged();
                    Check(File.Exists(EditorPlaytestSession.ProfilePath(Get("id"))),"Stopped test retains its own save for resume");
                    EditorPlaytestSession.Select(Get("id"));Phase=3;BurgerEmpireSetup.Play();return;
                }
                if(Phase==4&&!EditorApplication.isPlaying) {
                    Check(!EditorPlaytestSession.Active,"Second Stop also returns profile selection to normal");Unchanged();
                    Phase=5;BurgerEmpireSetup.Play();return;
                }
                if(!EditorApplication.isPlaying)return;
                var game=UnityEngine.Object.FindFirstObjectByType<BurgerEmpireGame>();if(!game||!game.Hud||game.Sim==null)return;
                if(Phase==1) {
                    Check(EditorPlaytestSession.Id==Get("id"),"Profile selection survives Enter Play domain reload");
                    var path=(string)typeof(BurgerEmpireGame).GetField("savePath",BindingFlags.Instance|BindingFlags.NonPublic).GetValue(game);
                    Check(path==EditorPlaytestSession.ProfilePath(Get("id")),"Game loads and autosaves through the selected isolated store");
                    Check(game.Sim.P.coins==120&&!game.Sim.P.tutorialDone&&game.Sim.P.served==0,"First-time test starts at the real default progression");
                    Check(game.Hud.BlocksWorldInput&&game.Sim.Paused,"First-time test waits at the normal home screen");
                    bool rejected=false;try{EditorPlaytestSession.NewProfile();}catch(InvalidOperationException){rejected=true;}
                    Check(rejected&&EditorPlaytestSession.Id==Get("id"),"Running profile cannot be replaced by another profile");
                    game.Hud.StartGame();
                    for(int i=0;i<4000&&!game.Sim.P.tutorialDone;i++){if(game.Sim.Actors[0].job=="")game.Sim.Command("next");game.Sim.Tick(.1f);}
                    game.Sim.Paused=true;
                    Check(game.Sim.P.tutorialDone&&game.Sim.P.served==1&&game.Sim.P.cleaned>0,"Fresh tutorial completes order, cooking, service, payment and cleaning");
                    game.SetLanguage("en");game.SetSound(false);game.SetAudioLevels(.23f,.41f);game.Save();
                    Put("saved",File.ReadAllText(path));
                    Check(JsonUtility.FromJson<Progress>(Get("saved")).tutorialDone,"Completed tutorial persists in the isolated save");Unchanged();
                    Phase=2;EditorApplication.isPlaying=false;return;
                }
                if(Phase==3) {
                    var saved=JsonUtility.FromJson<Progress>(Get("saved"));
                    Check(game.Sim.P.tutorialDone&&game.Sim.P.coins==saved.coins&&game.Sim.P.served==saved.served,"New Play reloads the test progress including earned money");
                    Check(Localization.Language=="en"&&!game.SoundEnabled&&Mathf.Abs(game.MusicVolume-.23f)<.001f&&Mathf.Abs(game.EffectsVolume-.41f)<.001f,"Test language, sound and volumes persist independently across Play sessions");
                    Check(game.Hud.BlocksWorldInput&&game.Sim.Paused,"Resumed test stays paused at home until the player continues");Unchanged();
                    Phase=4;EditorApplication.isPlaying=false;return;
                }
                if(Phase==5) {
                    var saved=JsonUtility.FromJson<Progress>(Get("disk"));
                    Check(!EditorPlaytestSession.Active&&game.Sim.P.coins==saved.coins&&game.Sim.P.xp==saved.xp&&game.Sim.P.activeBranch==saved.activeBranch,"Ordinary Play returns to the user's actual branch and progression");
                    Check(Localization.Language==PlayerPrefs.GetString("BurgerEmpire.Language","tr")&&game.SoundEnabled==(PlayerPrefs.GetInt("BurgerEmpire.Sound",1)!=0),"Ordinary Play restores actual user preferences");
                    game.Sim.Paused=true;Unchanged();Phase=0;
                    File.AppendAllText(Report,"Completed. Editor profile lifecycle and isolation verified. Automated walkthrough is not human playtest feedback. Physical Android not tested.\n");
                }
            }catch(Exception error){File.AppendAllText(Report,"FAIL: "+error+"\n");Phase=0;if(EditorApplication.isPlaying)EditorApplication.isPlaying=false;else EditorPlaytestSession.Clear();}
        }
    }
}
#endif
