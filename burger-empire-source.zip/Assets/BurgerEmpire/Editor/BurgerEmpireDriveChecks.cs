#if UNITY_EDITOR && ENABLE_INPUT_SYSTEM
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using BurgerEmpire.Core;
using BurgerEmpire.Unity;
using UnityEditor;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.LowLevel;
using UnityEngine.UI;
using Progress=BurgerEmpire.Core.Progress;

namespace BurgerEmpire.Editor
{
    [InitializeOnLoad]
    public static class BurgerEmpireDriveChecks
    {
        const string Pending="BurgerEmpire.DriveChecks",Report="BurgerEmpireDriveChecks.txt";
        static IEnumerator<float> steps;
        static double next;
        static int nextFrame;
        static BurgerEmpireGame game;
        static Simulation original;
        static string disk;
        static int lastEvent;
        static Touchscreen touch;
        static InputSettings.BackgroundBehavior background;
        static InputSettings.EditorInputBehaviorInPlayMode routing;
        static BurgerEmpireDriveChecks(){EditorApplication.update+=Update;}
        static void Update()
        {
            if(EditorApplication.isCompiling||EditorApplication.isUpdating)return;
            if(File.Exists("BurgerEmpireDriveChecks.request")) {
                try {File.Delete("BurgerEmpireDriveChecks.request");} catch(IOException){return;}
                File.WriteAllText(Report,"");SessionState.SetBool(Pending,true);nextFrame=0;
                if(!EditorApplication.isPlaying){BurgerEmpireSetup.Play();return;}
            }
            if(!EditorApplication.isPlaying||!SessionState.GetBool(Pending,false)||EditorApplication.timeSinceStartup<next||Time.frameCount<nextFrame)return;
            try {
                if(steps==null) {
                    game=UnityEngine.Object.FindFirstObjectByType<BurgerEmpireGame>();if(!game||game.Sim==null)return;
                    original=game.Sim;disk=File.ReadAllText("BurgerEmpireSave.json");game.ValidationActive=true;
                    lastEvent=(int)typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).GetValue(game);
                    background=InputSystem.settings.backgroundBehavior;InputSystem.settings.backgroundBehavior=InputSettings.BackgroundBehavior.IgnoreFocus;
                    // Route the synthetic touchscreen to the game even when another editor window has focus.
                    routing=InputSystem.settings.editorInputBehaviorInPlayMode;InputSystem.settings.editorInputBehaviorInPlayMode=InputSettings.EditorInputBehaviorInPlayMode.AllDeviceInputAlwaysGoesToGameView;
                    touch=InputSystem.AddDevice<Touchscreen>();steps=Run();
                }
                if(steps.MoveNext()){next=EditorApplication.timeSinceStartup+steps.Current;nextFrame=Time.frameCount+3;}else Finish();
            } catch(Exception e){File.AppendAllText(Report,"FAIL: "+e+"\n");Finish();}
        }
        static void SetSimulation(Simulation value)
        {
            typeof(BurgerEmpireGame).GetProperty("Sim").SetValue(game,value);
            typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game,0);
            typeof(RestaurantHud).GetField("toastTime",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game.Hud,0f);
        }
        static void Finish()
        {
            if(touch!=null){InputSystem.RemoveDevice(touch);touch=null;}InputSystem.settings.backgroundBehavior=background;InputSystem.settings.editorInputBehaviorInPlayMode=routing;
            if(game&&original!=null) {
                if(game.LayoutEditor.Active)game.Hud.FinishLayout(false);
                SetSimulation(original);original.Paused=true;game.ValidationActive=false;game.Save();game.Hud.OpenPanel("Arabaya servis");
                typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game,lastEvent);
            }
            steps=null;original=null;nextFrame=0;SessionState.SetBool(Pending,false);
        }
        static Progress Fixture()
        {
            return new Progress{coins=2000,xp=900,tables=2,grill=2,tutorialDone=true};
        }
        static void Check(bool good,string message)
        {File.AppendAllText(Report,(good?"PASS: ":"FAIL: ")+message+"\n");if(!good)throw new Exception(message);}
        static Button Find(string name){return UnityEngine.Object.FindObjectsByType<Button>(FindObjectsSortMode.None).First(b=>b.name==name&&b.gameObject.activeInHierarchy);}
        static Vector2 Center(RectTransform rt){return RectTransformUtility.WorldToScreenPoint(null,rt.TransformPoint(rt.rect.center));}
        static void Touch(Vector2 p,UnityEngine.InputSystem.TouchPhase phase)
        {InputSystem.QueueStateEvent(touch,new TouchState{touchId=1,position=p,phase=phase});}
        static bool Until(Func<bool> condition,int limit=1000)
        {
            game.Sim.Paused=false;
            for(int i=0;i<limit&&!condition();i++){if(game.Sim.Actors[0].job=="")game.Sim.Command("next");game.Sim.Tick(.1f);}
            game.Sim.Paused=true;return condition();
        }
        static bool WaitOnly(Func<bool> condition,int limit=2000)
        {
            game.Sim.Paused=false;
            for(int i=0;i<limit&&!condition();i++)game.Sim.Tick(.1f);
            game.Sim.Paused=true;return condition();
        }
        static IEnumerator<float> Run()
        {
            BurgerEmpireMobileChecks.SetSize(2340,1080);yield return .7f;
            if(game.LayoutEditor.Active)game.Hud.FinishLayout(false);
            if(game.Hud.BlocksWorldInput)game.Hud.ClosePanel();
            SetSimulation(new Simulation(Fixture()));game.Hud.OpenPanel("Restoran");yield return .3f;
            var target=Center(Find("ARABAYA SERVİS").GetComponent<RectTransform>());
            Touch(target,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;
            Touch(target,UnityEngine.InputSystem.TouchPhase.Ended);yield return .25f;
            Check(Find("Buy drive").interactable,"Restaurant button opens the eligible drive window offer");
            var list=UnityEngine.Object.FindFirstObjectByType<ScrollRect>();
            var swipe=Center(list.viewport);
            Touch(swipe,UnityEngine.InputSystem.TouchPhase.Began);yield return .1f;
            Touch(swipe+Vector2.up*230,UnityEngine.InputSystem.TouchPhase.Moved);yield return .15f;
            Touch(swipe+Vector2.up*550,UnityEngine.InputSystem.TouchPhase.Moved);yield return .15f;
            Touch(swipe+Vector2.up*550,UnityEngine.InputSystem.TouchPhase.Ended);yield return .2f;
            Check(list.content.anchoredPosition.y>60,"Touch scroll reveals drive purchase controls and prices");
            list.content.anchoredPosition=new Vector2(0,170);yield return .2f;
            target=Center(Find("Buy drive").GetComponent<RectTransform>());
            Check(list.viewport.rect.Contains(list.viewport.InverseTransformPoint(target)),"Opening button is visible inside scroll viewport");
            Touch(target,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;
            Touch(target,UnityEngine.InputSystem.TouchPhase.Ended);yield return .3f;
            Check(game.Sim.P.driveThru==1&&game.Sim.P.coins==1400,"Touch purchases local drive window for 600 coins");
            var world=GameObject.Find("Restaurant Environment").transform;
            Check(world.Find("DriveThru").gameObject.activeSelf&&world.Find("DriveThru/Pickup window"),"Purchased lane and pickup window appear in 3D restaurant");
            Check(world.Cast<Transform>().Where(t=>t.name=="Street tree"&&t.localPosition.x>Simulation.DriveWindowX).All(t=>Mathf.Abs(t.localPosition.z-Simulation.DriveLaneZ)>1.2f),"Street trees remain outside the vehicle exit lane");
            Check(!world.Find("DriveThru/Queue slot 3").gameObject.activeSelf,"First level shows three queue spaces");
            Check(GameObject.Find("Drive stats")&&UnityEngine.Object.FindObjectsByType<Text>(FindObjectsSortMode.None).Any(t=>t.text.Contains("Klasik Menü · 38 coin")),"Drive panel shows local statistics and rounded package price");
            Check(game.Sim.Actors.Count(a=>a.role=="drive")==1,"Buying the window includes one dedicated drive worker");
            // Keep this existing scenario focused on the player's touch controls.
            // The staffed window is exercised separately by OperationsChecks.
            game.Sim.Actors.RemoveAll(a=>a.role=="drive");
            game.Hud.ClosePanel();foreach(var table in game.Sim.Tables)table.dirty=true;
            Check(WaitOnly(()=>game.Sim.DriveFront!=null&&game.Sim.DriveFront.phase=="queue"&&Math.Abs(game.Sim.DriveFront.x-Simulation.DriveWindowX)<.02f),"Real spawned vehicle arrives at pickup window");yield return .3f;
            var car=game.Sim.DriveFront;
            Check(world.Find("Drive vehicles/Vehicle "+car.id).gameObject.activeInHierarchy,"Vehicle is rendered at its simulation position");
            var vehicleScreen=game.GameCamera.WorldToScreenPoint(new Vector3(car.x,.8f,car.z));
            Check(game.GameCamera.pixelRect.Contains(vehicleScreen),"Pickup car fits inside phone restaurant viewport");
            Check(UnityEngine.Object.FindObjectsByType<FoodIconGraphic>(FindObjectsSortMode.None).Any(i=>i.Kind=="car"&&i.gameObject.activeInHierarchy),"Driver bubble identifies vehicle order with a car illustration");
            game.Sim.Paused=false;yield return .2f;
            Check(Find("Sipariş al").interactable,"Order button can accept a vehicle while all tables are dirty");
            target=Center(Find("Sipariş al").GetComponent<RectTransform>());
            Touch(target,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;
            Touch(target,UnityEngine.InputSystem.TouchPhase.Ended);yield return .2f;
            Check(WaitOnly(()=>car.order=="ordered"),"Touch order sends player to window and takes driver's order");
            Check(car.table==-1&&game.Sim.Tables.All(t=>t.customer==0),"Drive order never seats driver at a salon table");
            game.Sim.Paused=false;yield return .2f;target=Center(Find("Hazırla").GetComponent<RectTransform>());
            Touch(target,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;
            Touch(target,UnityEngine.InputSystem.TouchPhase.Ended);yield return .2f;
            Check(WaitOnly(()=>car.order=="ready"),"Touch prepare cooks vehicle order through shared grill");
            game.Sim.Paused=false;yield return .2f;target=Center(Find("Servis et").GetComponent<RectTransform>());
            Touch(target,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;
            Touch(target,UnityEngine.InputSystem.TouchPhase.Ended);yield return .2f;
            Check(WaitOnly(()=>game.Sim.Actors[0].job=="serve"&&game.Sim.Actors[0].stage==1),"Touch serve picks up takeaway package");yield return .2f;
            Check(game.transform.Find("Living Restaurant/player/Takeaway bag").gameObject.activeInHierarchy&&!game.transform.Find("Living Restaurant/player/Carried tray").gameObject.activeSelf,"Player carries paper takeaway bag instead of dining tray");
            typeof(RestaurantHud).GetField("toastTime",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game.Hud,0f);yield return .1f;
            ScreenCapture.CaptureScreenshot(Path.GetFullPath("BurgerEmpire-0.7-DriveThru.png"));yield return .3f;
            Check(WaitOnly(()=>game.Sim.P.driveServed==1),"Package delivery automatically takes payment and sends car away");
            Check(game.Sim.P.coins==1400+game.Sim.P.driveEarned&&game.Sim.P.classicSold==1&&game.Sim.P.dailyServed==1,"Drive delivery credits wallet and shared product and daily counters exactly once");
            Check(game.Sim.Tables.All(t=>t.dirty)&&game.Sim.P.cleaned==0,"Drive service leaves all salon tables unchanged");
            game.Hud.OpenPanel("Arabaya servis");yield return .2f;
            list=UnityEngine.Object.FindFirstObjectByType<ScrollRect>();list.content.anchoredPosition=new Vector2(0,400);yield return .2f;
            target=Center(Find("Buy drive").GetComponent<RectTransform>());
            Check(list.viewport.rect.Contains(list.viewport.InverseTransformPoint(target)),"Upgrade button is visible for second purchase");
            int beforeUpgrade=game.Sim.P.coins;
            Touch(target,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;
            Touch(target,UnityEngine.InputSystem.TouchPhase.Ended);yield return .25f;
            Check(game.Sim.P.driveThru==2&&game.Sim.P.coins==beforeUpgrade-450&&world.Find("DriveThru/Queue slot 3").gameObject.activeSelf,"Touch upgrade adds fourth queue space for 450 coins");
            Check(!Find("Buy drive").interactable,"Maximum drive level cannot be purchased twice");
            list=UnityEngine.Object.FindFirstObjectByType<ScrollRect>();list.verticalNormalizedPosition=1;yield return .2f;
            ScreenCapture.CaptureScreenshot(Path.GetFullPath("BurgerEmpire-0.7-DrivePanel.png"));yield return .3f;
            game.Sim.PrepareSave();var loaded=new Simulation(JsonUtility.FromJson<Progress>(JsonUtility.ToJson(game.Sim.P)));
            Check(loaded.P.driveThru==2&&loaded.P.driveServed==1&&loaded.P.driveEarned==game.Sim.P.driveEarned&&loaded.DriveQueue==0,"Unity save round trip preserves drive progress and resets only transient traffic");
            game.Hud.ClosePanel();game.Sim.Paused=true;game.Hud.BeginLayout();yield return .2f;
            Check(!world.Find("Drive vehicles").gameObject.activeInHierarchy&&world.Find("DriveThru").gameObject.activeSelf,"Layout mode hides traffic while keeping fixed drive structure visible");
            game.Hud.FinishLayout(false);game.Sim.Paused=true;
            var branchFixture=Fixture();branchFixture.coins=3000;branchFixture.served=30;branchFixture.driveThru=2;
            var branchSim=new Simulation(branchFixture);SetSimulation(branchSim);game.Hud.OpenPanel("Şubeler");yield return .2f;
            Check(WaitOnly(()=>branchSim.DriveFront!=null),"Travel scenario has a waiting vehicle");var parked=branchSim.DriveFront;float savedPatience=parked.patience;
            game.OpenLondon();yield return .3f;
            Check(game.Sim.P.activeBranch==1&&!world.Find("DriveThru").gameObject.activeSelf&&!world.Find("Drive vehicles").gameObject.activeSelf,"New branch hides other city's drive window and cars");
            game.VisitBranch(0);yield return .3f;
            Check(world.Find("DriveThru").gameObject.activeSelf&&branchSim.Customers.Contains(parked)&&parked.patience==savedPatience,"Returning restores drive ownership and frozen vehicle queue");
            game.Hud.ClosePanel();game.Sim.Paused=true;
            BurgerEmpireMobileChecks.SetSize(1280,720);yield return .5f;CheckBounds("1280x720");
            BurgerEmpireMobileChecks.SetSize(1080,2340);yield return .5f;CheckBounds("1080x2340");
            Check(game.GameCamera.pixelRect.Contains(game.GameCamera.WorldToScreenPoint(new Vector3(Simulation.DriveWindowX,1,Simulation.DriveLaneZ))),"Drive window location fits portrait restaurant viewport");
            game.Hud.OpenPanel("Arabaya servis");yield return .2f;
            ScreenCapture.CaptureScreenshot(Path.GetFullPath("BurgerEmpire-0.7-Drive-Portrait.png"));yield return .3f;
            var locked=Fixture();locked.xp=0;SetSimulation(new Simulation(locked));game.Hud.OpenPanel("Arabaya servis");yield return .2f;
            Check(!Find("Buy drive").interactable&&UnityEngine.Object.FindObjectsByType<Text>(FindObjectsSortMode.None).Any(t=>t.text=="Seviye 6 gerekiyor."),"Low-level phone UI explains drive lock and prevents spending");
            BurgerEmpireMobileChecks.SetSize(2340,1080);yield return .5f;
            game.Save();Check(File.ReadAllText("BurgerEmpireSave.json")==disk,"Drive tests never overwrite player's actual save");
            File.AppendAllText(Report,"Completed. Unity Input System touch verified. Physical Android device not tested.\n");
        }
        static void CheckBounds(string label)
        {
            var safe=Screen.safeArea;var corners=new Vector3[4];
            foreach(var button in UnityEngine.Object.FindObjectsByType<Button>(FindObjectsSortMode.None).Where(b=>b.gameObject.activeInHierarchy)) {
                var rt=button.GetComponent<RectTransform>();rt.GetWorldCorners(corners);
                // Only visible controls; clipped scrolling cards are intentionally outside the viewport.
                if(corners[2].y<safe.yMin||corners[0].y>safe.yMax)continue;
                Check(rt.rect.height>=48&&corners[0].x>=safe.xMin-1&&corners[2].x<=safe.xMax+1,label+": "+button.name+" touch size and horizontal bounds");
            }
        }
    }
}
#endif
