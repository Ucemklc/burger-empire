#if UNITY_EDITOR && ENABLE_INPUT_SYSTEM
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using BurgerEmpire.Core;
using BurgerEmpire.Unity;
using UnityEditor;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.LowLevel;
using UnityEngine.UI;
using Progress=BurgerEmpire.Core.Progress;

namespace BurgerEmpire.Editor
{
    [InitializeOnLoad]
    public static class BurgerEmpireRecipeChecks
    {
        const string Pending="BurgerEmpire.RecipeChecks",Report="BurgerEmpireRecipeChecks.txt";
        static IEnumerator<float> steps;
        static double next;
        static int nextFrame;
        static BurgerEmpireGame game;
        static Simulation original;
        static string disk;
        static int lastEvent;
        static Touchscreen touch;
        static InputSettings.BackgroundBehavior background;
        static InputSettings.EditorInputBehaviorInPlayMode routing;
        static BurgerEmpireRecipeChecks(){EditorApplication.update+=Update;}
        static void Update()
        {
            if(EditorApplication.isCompiling||EditorApplication.isUpdating)return;
            if(File.Exists("BurgerEmpireRecipeChecks.request")) {
                try {File.Delete("BurgerEmpireRecipeChecks.request");} catch(IOException){return;}
                File.WriteAllText(Report,"");SessionState.SetBool(Pending,true);nextFrame=0;
                if(!EditorApplication.isPlaying){BurgerEmpireSetup.Play();return;}
            }
            if(!EditorApplication.isPlaying||!SessionState.GetBool(Pending,false)||EditorApplication.timeSinceStartup<next||Time.frameCount<nextFrame)return;
            try {
                if(steps==null) {
                    game=UnityEngine.Object.FindFirstObjectByType<BurgerEmpireGame>();if(!game||game.Sim==null)return;
                    original=game.Sim;disk=File.ReadAllText("BurgerEmpireSave.json");game.ValidationActive=true;
                    lastEvent=(int)typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).GetValue(game);
                    background=InputSystem.settings.backgroundBehavior;InputSystem.settings.backgroundBehavior=InputSettings.BackgroundBehavior.IgnoreFocus;
                    routing=InputSystem.settings.editorInputBehaviorInPlayMode;InputSystem.settings.editorInputBehaviorInPlayMode=InputSettings.EditorInputBehaviorInPlayMode.AllDeviceInputAlwaysGoesToGameView;
                    touch=InputSystem.AddDevice<Touchscreen>();steps=Run();
                }
                if(steps.MoveNext()){next=EditorApplication.timeSinceStartup+steps.Current;nextFrame=Time.frameCount+3;}else Finish();
            } catch(Exception e){File.AppendAllText(Report,"FAIL: "+e+"\n");Finish();}
        }
        static void SetSimulation(Simulation value)
        {
            typeof(BurgerEmpireGame).GetProperty("Sim").SetValue(game,value);
            typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game,0);
            typeof(RestaurantHud).GetField("toastTime",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game.Hud,0f);
        }
        static void Finish()
        {
            if(touch!=null){InputSystem.RemoveDevice(touch);touch=null;}InputSystem.settings.backgroundBehavior=background;InputSystem.settings.editorInputBehaviorInPlayMode=routing;
            if(game&&original!=null) {
                if(game.LayoutEditor.Active)game.Hud.FinishLayout(false);
                SetSimulation(original);original.Paused=true;game.ValidationActive=false;game.Save();game.Hud.OpenPanel("Menü");
                typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game,lastEvent);
            }
            steps=null;original=null;nextFrame=0;SessionState.SetBool(Pending,false);
        }
        static Progress Fixture()
        {
            var p=JsonUtility.FromJson<Progress>(JsonUtility.ToJson(original.P));
            p.coins=3000;p.xp=700;p.grill=2;p.fryer=1;p.blender=0;p.doubleBurger=0;p.cheese=1;p.mission=5;p.tutorialDone=true;
            p.shakeSold=p.doubleSold=0;p.activeBranch=0;p.chickenBurger=p.bbqBurger=p.chocolateShake=0;return p;
        }
        static void Check(bool good,string message)
        {File.AppendAllText(Report,(good?"PASS: ":"FAIL: ")+message+"\n");if(!good)throw new Exception(message);}
        static Button Find(string name){return UnityEngine.Object.FindObjectsByType<Button>(FindObjectsSortMode.None).First(b=>b.name==name&&b.gameObject.activeInHierarchy);}
        static Vector2 Center(RectTransform rt){return RectTransformUtility.WorldToScreenPoint(null,rt.TransformPoint(rt.rect.center));}
        static void Touch(Vector2 p,UnityEngine.InputSystem.TouchPhase phase)
        {InputSystem.QueueStateEvent(touch,new TouchState{touchId=1,position=p,phase=phase});}
        static bool Until(Func<bool> condition,int limit=1000)
        {
            game.Sim.Paused=false;
            for(int i=0;i<limit&&!condition();i++){if(game.Sim.Actors[0].job=="")game.Sim.Command("next");game.Sim.Tick(.1f);}
            game.Sim.Paused=true;return condition();
        }

        static IEnumerator<float> Run()
        {
            BurgerEmpireMobileChecks.SetSize(2340,1080);yield return .6f;
            if(game.LayoutEditor.Active)game.Hud.FinishLayout(false);
            if(game.Hud.BlocksWorldInput)game.Hud.ClosePanel();
            var p=Fixture();p.blender=1;p.doubleBurger=1;
            SetSimulation(new Simulation(p));game.Hud.OpenPanel("Menü");yield return .2f;
            Check(new[]{"chicken","bbq","chocolate"}.All(id=>GameObject.Find("Recipe "+id)),"Menu exposes all three new recipe cards");
            foreach(string id in new[]{"chicken","bbq","chocolate"}) {
                game.Hud.OpenPanel("Ürün:"+id);yield return .2f;
                var button=Find("Buy "+id);Check(button.interactable,id+": eligible recipe can be bought");
                var target=Center(button.GetComponent<RectTransform>());
                Touch(target,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;
                Touch(target,UnityEngine.InputSystem.TouchPhase.Ended);yield return .2f;
                Check(MenuCatalog.Get(id,game.Sim.P).available,id+": real Input System touch unlocks the recipe");
                int coins=game.Sim.P.coins;game.Command("buy",id);yield return .1f;
                Check(game.Sim.P.coins==coins&&!Find("Buy "+id).interactable,id+": completed purchase cannot charge twice");
            }
            Check(game.Sim.P.coins==2120,"Three recipe purchases charge exactly 880 coins");
            var loaded=new Simulation(JsonUtility.FromJson<Progress>(JsonUtility.ToJson(game.Sim.P)));
            Check(loaded.P.version==BurgerEmpire.Core.Progress.CurrentVersion&&loaded.P.chickenBurger==1&&loaded.P.bbqBurger==1&&loaded.P.chocolateShake==1,"Unity JSON restores all recipe unlocks in current schema");
            foreach(string id in new[]{"chicken","bbq","chocolate"}) {
                var low=Fixture();low.xp=0;SetSimulation(new Simulation(low));game.Hud.OpenPanel("Ürün:"+id);yield return .2f;
                Check(!Find("Buy "+id).interactable&&UnityEngine.Object.FindObjectsByType<Text>(FindObjectsSortMode.None).Any(t=>t.text.StartsWith("Seviye ")&&t.text.EndsWith("gerekiyor.")),id+": locked UI explains the required level");
            }
            SetSimulation(loaded);game.Hud.OpenPanel("Menü");yield return .2f;
            var list=UnityEngine.Object.FindFirstObjectByType<ScrollRect>();list.verticalNormalizedPosition=0;yield return .3f;
            CheckBounds("2340x1080");CheckText();
            ScreenCapture.CaptureScreenshot("BurgerEmpire-0.19-Menu.png");yield return .3f;
            BurgerEmpireMobileChecks.SetSize(1080,2340);yield return .5f;
            list=UnityEngine.Object.FindFirstObjectByType<ScrollRect>();list.verticalNormalizedPosition=0;yield return .2f;
            CheckBounds("1080x2340");CheckText();
            ScreenCapture.CaptureScreenshot("BurgerEmpire-0.19-Menu-Portrait.png");yield return .3f;
            BurgerEmpireMobileChecks.SetSize(1280,720);yield return .4f;CheckBounds("1280x720");CheckText();
            BurgerEmpireMobileChecks.SetSize(2340,1080);yield return .4f;
            game.Hud.ClosePanel();var world=GameObject.Find("Restaurant Environment").transform;
            foreach(string product in new[]{"chicken","bbq","chocolate","classic"}) {
                p=Fixture();p.blender=2;p.chickenBurger=p.bbqBurger=p.chocolateShake=1;
                var sim=new Simulation(p);var recipe=MenuCatalog.Get(product,p);
                var c=new Customer{id=500,kind=0,name="Tarif testi",phase="queue",product=product,station=recipe.station,meal=recipe.name,price=recipe.price,patience=1000,maxPatience=1000,x=9.1f,z=3.4f};
                sim.Customers.Add(c);SetSimulation(sim);
                Check(Until(()=>sim.Actors.Any(a=>a.job=="serve"&&a.stage==1&&a.customer==500)),product+": complete kitchen workflow reaches carrying the meal");yield return .2f;
                var actor=sim.Actors.First(a=>a.job=="serve"&&a.stage==1&&a.customer==500);
                string visual=product=="chicken"?"Chicken burger":product=="bbq"?"BBQ burger":product=="chocolate"?"Chocolate milkshake":"Burger";
                var tray=game.transform.Find("Living Restaurant/"+actor.role+"/Carried tray");
                Check(tray.Find(visual)&&tray.Find(visual).gameObject.activeInHierarchy,product+": server carries the matching 3D product");
                var bubbles=(Dictionary<int,RectTransform>)typeof(RestaurantHud).GetField("customerBubbles",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).GetValue(game.Hud);
                var bubble=bubbles[c.id];var icons=bubble.GetComponentsInChildren<FoodIconGraphic>();
                Check(icons.Any(i=>i.Kind==OrderSignals.Items(product)[0]&&i.DrawnVertices>0),product+": compact order icon has visible geometry");
                Check(bubble.rect.width==(product=="chocolate"?34:64)&&bubble.rect.height==29,product+": order bubble keeps the small PlateUp-like dimensions");
                Check(Until(()=>c.phase=="eating"),product+": customer receives the prepared product");yield return .2f;
                var meal=world.Find("Table_"+c.table+"/Meal");
                Check(meal.Find(visual).gameObject.activeInHierarchy,product+": table shows the correct meal");
                Check(new[]{"Chicken burger","BBQ burger","Chocolate milkshake","Strawberry milkshake","Double burger","Burger"}.Where(n=>n!=visual).All(n=>!meal.Find(n)||!meal.Find(n).gameObject.activeSelf),product+": switching products hides previous variants");
                Check(!bubbles[c.id].gameObject.activeSelf,product+": order bubble hides after service");
                Check(Until(()=>MenuCatalog.Sales(sim.P,product)>0),product+": payment records a product sale");
                var restored=new Simulation(JsonUtility.FromJson<Progress>(JsonUtility.ToJson(sim.P)));
                Check(MenuCatalog.Sales(restored.P,product)>0&&restored.P.reviews.Any(r=>r.product==product&&r.completed),product+": Unity save/reload retains sale and review identity");
            }
            CaptureMeals();yield return .2f;
            game.Save();Check(File.ReadAllText("BurgerEmpireSave.json")==disk,"Synthetic recipe purchases and meals never overwrite the player's latest save");
            File.AppendAllText(Report,"Completed. Three recipes verified through Unity touch, rendering, service, payment and JSON reload; physical Android not tested.\n");
        }
        static void CheckText()
        {
            var list=UnityEngine.Object.FindFirstObjectByType<ScrollRect>();
            var overflow=list.content.GetComponentsInChildren<Text>().Where(t=>t.preferredHeight>t.rectTransform.rect.height+2).Select(t=>t.text);
            Check(!overflow.Any(),"Recipe names, prices and descriptions fit the mobile cards: "+string.Join(" | ",overflow));
        }
        static void CaptureMeals()
        {
            var stage=RestaurantArt.Group("Recipe gallery",null,Vector3.zero);
            var menu=(MenuPresentation)typeof(BurgerEmpireGame).GetField("menuPresentation",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).GetValue(game);
            string[] products={"chicken","bbq","chocolate"},labels={"TAVUK BURGER MENÜ","BARBEKÜ MENÜ","ÇİKOLATALI MILKSHAKE"};
            for(int i=0;i<3;i++) {
                var person=RestaurantArt.BuildPerson("waiter",0,stage);
                foreach(Transform child in person.root)child.gameObject.SetActive(child==person.food);
                person.root.position=new Vector3(57-i*3.2f,0,15);person.root.rotation=Quaternion.identity;
                person.food.localPosition=Vector3.zero;person.food.localRotation=Quaternion.identity;person.food.localScale=Vector3.one*2;
                menu.Carry(person,products[i]);person.food.gameObject.SetActive(true);
                RestaurantArt.Text("Label",labels[i],stage,new Vector3(57-i*3.2f,-.45f,15.7f),.19f,RestaurantArt.Brown);
            }
            var camera=new GameObject("Recipe gallery camera").AddComponent<Camera>();camera.orthographic=true;camera.orthographicSize=1.95f;
            camera.transform.position=new Vector3(53.8f,4.0f,24);camera.transform.LookAt(new Vector3(53.8f,.15f,15));camera.clearFlags=CameraClearFlags.SolidColor;camera.backgroundColor=RestaurantArt.Cream;
            var target=new RenderTexture(1800,660,24);camera.targetTexture=target;var previous=RenderTexture.active;Texture2D picture=null;
            try {camera.Render();RenderTexture.active=target;picture=new Texture2D(1800,660,TextureFormat.RGB24,false);picture.ReadPixels(new Rect(0,0,1800,660),0,0);picture.Apply();File.WriteAllBytes("BurgerEmpire-0.19-Recipes.png",picture.EncodeToPNG());}
            finally{RenderTexture.active=previous;camera.targetTexture=null;target.Release();UnityEngine.Object.Destroy(target);UnityEngine.Object.Destroy(camera.gameObject);if(picture)UnityEngine.Object.Destroy(picture);UnityEngine.Object.Destroy(stage.gameObject);}
        }
        static void CheckBounds(string label)
        {
            var safe=Screen.safeArea;var corners=new Vector3[4];
            foreach(var button in UnityEngine.Object.FindObjectsByType<Button>(FindObjectsSortMode.None).Where(b=>b.gameObject.activeInHierarchy)) {
                var rt=button.GetComponent<RectTransform>();rt.GetWorldCorners(corners);
                // Only visible controls; clipped scrolling cards are intentionally outside the viewport.
                if(corners[2].y<safe.yMin||corners[0].y>safe.yMax)continue;
                Check(rt.rect.height>=48&&corners[0].x>=safe.xMin-1&&corners[2].x<=safe.xMax+1,label+": "+button.name+" touch size and horizontal bounds");
            }
        }
    }
}
#endif
