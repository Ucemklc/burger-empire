#if UNITY_EDITOR
using System;
using System.IO;
using System.Linq;
using BurgerEmpire.Unity;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

namespace BurgerEmpire.Editor
{
    [InitializeOnLoad]
    public static class BurgerEmpireSetup
    {
        const string Root="Assets/BurgerEmpire";
        static BurgerEmpireSetup() { EditorApplication.delayCall+=InstallRequested; }
        static void InstallRequested()
        {
            string marker=Root+"/Setup.request";
            if(!File.Exists(marker))return;
            if(EditorApplication.isCompiling || EditorApplication.isUpdating) { EditorApplication.delayCall+=InstallRequested;return; }
            if(EditorApplication.isPlayingOrWillChangePlaymode)return;
            try {
                Build();
                AssetDatabase.ImportAsset(marker);
                string destination=AssetDatabase.GenerateUniqueAssetPath(Root+"/Setup.completed");
                string error=AssetDatabase.MoveAsset(marker,destination);
                if(!string.IsNullOrEmpty(error))throw new IOException(error);
            }
            catch(Exception e){Debug.LogException(e);File.WriteAllText(Root+"/Setup.error.txt",e.ToString());}
        }
        [MenuItem("Burger Empire/01 - Restoran sahnesini oluştur ve aç")]
        public static void Build()
        {
            if(EditorApplication.isPlayingOrWillChangePlaymode) { Debug.LogWarning("Önce Play modunu durdur.");return; }
            Directory.CreateDirectory(Root+"/Scenes");Directory.CreateDirectory(Root+"/Generated/Materials");
            var current=EditorSceneManager.GetActiveScene();
            if(current.isDirty) {
                string backup=Root+"/Scenes/PreviousScene_"+DateTime.Now.ToString("yyyyMMdd_HHmmss")+".unity";
                if(!EditorSceneManager.SaveScene(current,backup,true))throw new IOException("Önceki sahnenin yedeği kaydedilemedi.");
            }
            var scene=EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);
            var world=RestaurantArt.BuildWorld();
            foreach(Renderer renderer in world.GetComponentsInChildren<Renderer>(true)) {
                Material m=renderer.sharedMaterial;
                if(m==null||!m.name.StartsWith("BE_")||AssetDatabase.Contains(m))continue;
                string path=Root+"/Generated/Materials/"+m.name+".mat";
                var saved=AssetDatabase.LoadAssetAtPath<Material>(path);
                if(saved!=null)renderer.sharedMaterial=saved;else AssetDatabase.CreateAsset(m,path);
            }
            var cameraObject=new GameObject("Main Camera");cameraObject.tag="MainCamera";
            var camera=cameraObject.AddComponent<Camera>();cameraObject.AddComponent<AudioListener>();
            BurgerEmpireGame.ConfigureCamera(camera);BurgerEmpireGame.CreateLighting();
            new GameObject("Burger Empire Game").AddComponent<BurgerEmpireGame>();
            string scenePath=Root+"/Scenes/BurgerEmpire.unity";
            EditorSceneManager.SaveScene(scene,scenePath);
            var scenes=EditorBuildSettings.scenes.Where(s=>s.path!=scenePath).ToList();scenes.Insert(0,new EditorBuildSettingsScene(scenePath,true));EditorBuildSettings.scenes=scenes.ToArray();
            AssetDatabase.SaveAssets();AssetDatabase.Refresh();
            Selection.activeGameObject=world.gameObject;
            if(SceneView.lastActiveSceneView!=null) {
                SceneView.lastActiveSceneView.LookAt(new Vector3(5,0,5),camera.transform.rotation,13);
            }
            Debug.Log("BURGER_EMPIRE_SETUP_OK: "+scenePath);
            File.WriteAllText(Path.GetFullPath("BurgerEmpireSetupReport.txt"),"PASS: Unity editor compiled Burger Empire scripts and built the restaurant scene.\nUnity "+Application.unityVersion+"\n"+DateTime.Now.ToString("O"));
        }
        [MenuItem("Burger Empire/02 - Oyunu başlat")]
        public static void Play()
        {
            if(!EditorApplication.isPlaying) {
                string target=Root+"/Scenes/BurgerEmpire.unity";
                if(EditorSceneManager.GetActiveScene().path!=target){
                    if(!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo())return;
                    EditorSceneManager.OpenScene(target);
                }
                EditorApplication.ExecuteMenuItem("Window/General/Game");EditorApplication.isPlaying=true;
            }
        }
        [MenuItem("Burger Empire/03 - Oyun görüntüsünü kaydet")]
        public static void Screenshot()
        {
            if(!EditorApplication.isPlaying){Debug.LogWarning("Görüntü için önce oyunu başlat.");return;}
            ScreenCapture.CaptureScreenshot(Path.GetFullPath("BurgerEmpirePreview.png"),1);
        }
    }
}
#endif
