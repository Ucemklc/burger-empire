#if UNITY_EDITOR && ENABLE_INPUT_SYSTEM
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using BurgerEmpire.Core;
using BurgerEmpire.Unity;
using UnityEditor;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.LowLevel;
using UnityEngine.UI;
using Progress=BurgerEmpire.Core.Progress;

namespace BurgerEmpire.Editor
{
    [InitializeOnLoad]
    public static class BurgerEmpireBranchChecks
    {
        const string Pending="BurgerEmpire.BranchChecks",Report="BurgerEmpireBranchChecks.txt";
        static IEnumerator<float> steps;
        static double next;
        static BurgerEmpireGame game;
        static Simulation original;
        static string disk;
        static int lastEvent;
        static Touchscreen touch;
        static InputSettings.BackgroundBehavior background;
        static BurgerEmpireBranchChecks(){EditorApplication.update+=Update;}
        static void Update()
        {
            if(EditorApplication.isCompiling||EditorApplication.isUpdating)return;
            if(File.Exists("BurgerEmpireBranchChecks.request")) {
                try {File.Delete("BurgerEmpireBranchChecks.request");} catch(IOException){return;}
                File.WriteAllText(Report,"");SessionState.SetBool(Pending,true);
                if(!EditorApplication.isPlaying){BurgerEmpireSetup.Play();return;}
            }
            if(!EditorApplication.isPlaying||!SessionState.GetBool(Pending,false)||EditorApplication.timeSinceStartup<next)return;
            try {
                if(steps==null) {
                    game=UnityEngine.Object.FindFirstObjectByType<BurgerEmpireGame>();if(!game||game.Sim==null)return;
                    original=game.Sim;disk=File.ReadAllText("BurgerEmpireSave.json");game.ValidationActive=true;
                    lastEvent=(int)typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).GetValue(game);
                    background=InputSystem.settings.backgroundBehavior;InputSystem.settings.backgroundBehavior=InputSettings.BackgroundBehavior.IgnoreFocus;
                    touch=InputSystem.AddDevice<Touchscreen>();steps=Run();
                }
                if(steps.MoveNext())next=EditorApplication.timeSinceStartup+steps.Current;else Finish();
            } catch(Exception e){File.AppendAllText(Report,"FAIL: "+e+"\n");Finish();}
        }
        static void SetSimulation(Simulation value)
        {
            typeof(BurgerEmpireGame).GetProperty("Sim").SetValue(game,value);
            typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game,0);
            typeof(RestaurantHud).GetField("toastTime",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game.Hud,0f);
        }
        static void Finish()
        {
            if(touch!=null){InputSystem.RemoveDevice(touch);touch=null;}InputSystem.settings.backgroundBehavior=background;
            if(game&&original!=null) {
                if(game.LayoutEditor.Active)game.Hud.FinishLayout(false);
                SetSimulation(original);original.Paused=true;game.ValidationActive=false;game.Save();game.Hud.OpenPanel("Şubeler");
                typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game,lastEvent);
            }
            steps=null;original=null;SessionState.SetBool(Pending,false);
        }
        static Progress Fixture()
        {
            var layout=RestaurantLayout.Default();layout.floor=1;
            return new Progress{coins=4000,xp=900,tables=4,grill=2,fryer=2,blender=2,doubleBurger=1,cheese=1,
                served=30,cashier=1,cook=1,waiter=1,cleaner=1,tutorialDone=true,layout=layout};
        }
        static void Check(bool good,string message)
        {File.AppendAllText(Report,(good?"PASS: ":"FAIL: ")+message+"\n");if(!good)throw new Exception(message);}
        static Button Find(string name){return UnityEngine.Object.FindObjectsByType<Button>(FindObjectsSortMode.None).First(b=>b.name==name&&b.gameObject.activeInHierarchy);}
        static Vector2 Center(RectTransform rt){return RectTransformUtility.WorldToScreenPoint(null,rt.TransformPoint(rt.rect.center));}
        static void Touch(Vector2 p,UnityEngine.InputSystem.TouchPhase phase)
        {InputSystem.QueueStateEvent(touch,new TouchState{touchId=1,position=p,phase=phase});}
        static bool Until(Func<bool> condition,int limit=1000)
        {
            game.Sim.Paused=false;
            for(int i=0;i<limit&&!condition();i++){if(game.Sim.Actors[0].job=="")game.Sim.Command("next");game.Sim.Tick(.1f);}
            game.Sim.Paused=true;return condition();
        }
        static IEnumerator<float> Run()
        {
            BurgerEmpireMobileChecks.SetSize(2340,1080);yield return .6f;
            if(game.LayoutEditor.Active)game.Hud.FinishLayout(false);
            if(game.Hud.BlocksWorldInput)game.Hud.ClosePanel();
            SetSimulation(new Simulation(Fixture()));
            Check(Until(()=>game.Sim.Customers.Any(c=>c.phase=="payment"&&game.Sim.Actors.Any(a=>a.job=="collect"&&a.customer==c.id))),"Actual Istanbul shift reaches a reserved payment before branch switch");
            var pending=game.Sim.Customers.First(c=>c.phase=="payment"&&game.Sim.Actors.Any(a=>a.job=="collect"&&a.customer==c.id));
            float patience=pending.patience,shiftTime=game.Sim.Time;int wallet=game.Sim.P.coins;
            game.Hud.OpenPanel("Restoran");yield return .25f;
            var target=Center(Find("ŞUBELER · DÜNYAYA AÇIL").GetComponent<RectTransform>());
            Touch(target,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;
            Touch(target,UnityEngine.InputSystem.TouchPhase.Ended);yield return .25f;
            Check(GameObject.Find("Branch route")&&GameObject.Find("Branch 0")&&GameObject.Find("Branch 1"),"Touch opens both city cards from Restaurant panel");
            var list=UnityEngine.Object.FindFirstObjectByType<ScrollRect>();
            Check(list.content.rect.height>list.viewport.rect.height,"City list can scroll on landscape phone screen");
            var swipe=Center(list.viewport);
            Touch(swipe,UnityEngine.InputSystem.TouchPhase.Began);yield return .1f;
            Touch(swipe+Vector2.up*350,UnityEngine.InputSystem.TouchPhase.Moved);yield return .15f;
            Touch(swipe+Vector2.up*550,UnityEngine.InputSystem.TouchPhase.Moved);yield return .15f;
            Touch(swipe+Vector2.up*550,UnityEngine.InputSystem.TouchPhase.Ended);yield return .2f;
            Check(list.content.anchoredPosition.y>100,"Touch swipe reveals London opening card");
            list.verticalNormalizedPosition=0;yield return .2f;
            Check(Find("Open London").interactable,"Eligible London opening button is enabled");
            target=Center(Find("Open London").GetComponent<RectTransform>());
            Check(list.viewport.rect.Contains(list.viewport.InverseTransformPoint(target)),"Opening button is inside scroll viewport before touch");
            Touch(target,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;
            Touch(target,UnityEngine.InputSystem.TouchPhase.Ended);yield return .3f;
            Check(game.Sim.P.activeBranch==1&&game.Sim.P.londonOpen&&game.Sim.P.coins==wallet-1200,"Touch opens London and charges exactly once");
            Check(game.Sim.Paused&&game.Hud.BlocksWorldInput,"Opening and visiting keep shift paused under modal");
            var world=GameObject.Find("Restaurant Environment").transform;
            Check(world.Find("London telephone box").gameObject.activeSelf&&world.Find("City marker/City name").GetComponent<TextMesh>().text=="LONDRA","London telephone box and city sign are visible");
            Check(world.GetComponentsInChildren<TextMesh>().Any(t=>t.name=="Menu price"&&t.text.Contains("35 COIN")),"Visible illustrated kitchen price board agrees with London menu pricing");
            Check(!world.Find("Table_2").gameObject.activeSelf&&!world.Find("Table_3").gameObject.activeSelf,"Istanbul's additional tables are hidden in new London branch");
            Check(!world.Find("Grill_1").gameObject.activeSelf&&!world.Find("Milkshake station").gameObject.activeSelf,"London does not inherit another city's kitchen visuals");
            Check(!game.transform.Find("Living Restaurant/cook").gameObject.activeSelf&&!game.transform.Find("Living Restaurant/waiter").gameObject.activeSelf,"Unhired London employees are hidden");
            Check(game.Sim.Customers.Count==0&&game.Sim.Actors.Count==1,"London begins with only the founder and empty queue");
            Check(GameObject.Find("Branch 1").GetComponentsInChildren<Text>().Any(t=>t.text.Contains("BURADASIN")),"City card identifies active London branch");
            list=UnityEngine.Object.FindFirstObjectByType<ScrollRect>();list.verticalNormalizedPosition=0;yield return .2f;
            ScreenCapture.CaptureScreenshot(Path.GetFullPath("BurgerEmpire-0.6-Branches.png"));yield return .3f;
            game.Hud.ClosePanel();game.Sim.Paused=true;yield return .2f;
            Check(UnityEngine.Object.FindObjectsByType<Text>(FindObjectsSortMode.None).Any(t=>t.text.Contains("LONDRA")&&t.text.Contains("DURAKLATILDI")),"Gameplay status clearly identifies current city");
            typeof(RestaurantHud).GetField("toastTime",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game.Hud,0f);yield return .1f;
            ScreenCapture.CaptureScreenshot(Path.GetFullPath("BurgerEmpire-0.6-London.png"));yield return .3f;
            game.Hud.OpenPanel("Menü");yield return .2f;
            Check(GameObject.Find("Recipe classic").GetComponentsInChildren<Text>().Any(t=>t.text.Contains("35 coin")),"London menu shows city-specific selling price");
            game.Hud.ClosePanel();game.Sim.Paused=true;game.Hud.BeginLayout();yield return .2f;
            int beforeWall=game.Sim.P.layout.wall;game.LayoutEditor.CycleStyle(1);
            game.VisitBranch(0);
            Check(game.Sim.P.activeBranch==1&&game.LayoutEditor.Active,"Branch switching cannot escape an unfinished layout draft");
            game.Hud.FinishLayout(true);game.Sim.Paused=true;yield return .2f;
            Check(game.Sim.P.layout.wall==(beforeWall+1)%3,"London layout customization commits to its own branch");
            game.Command("buy","blender");game.Sim.PrepareSave();
            var unityJson=JsonUtility.ToJson(game.Sim.P);var loaded=new Simulation(JsonUtility.FromJson<Progress>(unityJson));
            Check(loaded.P.activeBranch==1&&loaded.P.blender==1&&loaded.P.layout.wall==2&&loaded.P.istanbul.tables==4&&loaded.P.istanbul.cook==1,"Unity JsonUtility saves inherited local fields and both branch snapshots");
            loaded.SwitchBranch(0,out _);
            Check(loaded.P.tables==4&&loaded.P.blender==2&&loaded.P.layout.floor==1&&loaded.P.coins==game.Sim.P.coins,"Reloaded Unity save restores other city and shared wallet");
            game.Hud.OpenPanel("Şubeler");yield return .2f;
            list=UnityEngine.Object.FindFirstObjectByType<ScrollRect>();list.verticalNormalizedPosition=1;yield return .2f;
            target=Center(Find("Visit branch 0").GetComponent<RectTransform>());
            Touch(target,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;
            Touch(target,UnityEngine.InputSystem.TouchPhase.Ended);yield return .3f;
            Check(game.Sim.P.activeBranch==0&&game.Sim.Customers.Contains(pending)&&pending.patience==patience&&game.Sim.Time==shiftTime,"Touch return preserves existing customer's patience, payment and shift clock");
            Check(world.Find("Table_3").gameObject.activeSelf&&world.Find("Grill_1").gameObject.activeSelf&&world.Find("Milkshake station").gameObject.activeSelf,"Returning restores purchased Istanbul tables and equipment");
            Check(game.transform.Find("Living Restaurant/cook").gameObject.activeSelf&&game.transform.Find("Living Restaurant/waiter").gameObject.activeSelf&&!world.Find("London telephone box").gameObject.activeSelf,"Returning restores local crew and removes London-only landmark");
            int served=game.Sim.P.served;game.Hud.ClosePanel();
            Check(Until(()=>game.Sim.P.served>served),"Payment interrupted by travel completes once after return");
            game.Hud.OpenPanel("Şubeler");yield return .2f;
            list=UnityEngine.Object.FindFirstObjectByType<ScrollRect>();list.verticalNormalizedPosition=0;yield return .2f;
            target=Center(Find("Visit branch 1").GetComponent<RectTransform>());
            Touch(target,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;
            Touch(target,UnityEngine.InputSystem.TouchPhase.Ended);yield return .3f;
            Check(game.Sim.P.activeBranch==1&&game.Sim.P.blender==1&&game.Sim.P.layout.wall==2,"Touch revisits existing London with its purchased mixer and customized wall");
            game.Hud.Back();yield return .2f;
            Check(!game.Hud.BlocksWorldInput&&game.Sim.Paused,"Android back semantics close travel panel and preserve prior pause state");
            game.Hud.OpenPanel("Şubeler");yield return .2f;
            BurgerEmpireMobileChecks.SetSize(1280,720);yield return .5f;CheckBounds("1280x720");
            BurgerEmpireMobileChecks.SetSize(1080,2340);yield return .5f;CheckBounds("1080x2340");
            ScreenCapture.CaptureScreenshot(Path.GetFullPath("BurgerEmpire-0.6-Branches-Portrait.png"));yield return .3f;
            var low=Fixture();low.coins=123;low.served=24;SetSimulation(new Simulation(low));game.Hud.OpenPanel("Şubeler");yield return .2f;
            Check(!Find("Open London").interactable&&GameObject.Find("Branch 1").GetComponentsInChildren<Text>().Any(t=>t.text.Contains("24/30")),"Locked branch shows real progress and prevents premature spending");
            BurgerEmpireMobileChecks.SetSize(2340,1080);yield return .5f;
            game.Save();Check(File.ReadAllText("BurgerEmpireSave.json")==disk,"All branch scenarios leave the user's disk progress untouched");
            File.AppendAllText(Report,"Completed. Unity Input System touch verified. Physical Android device not tested.\n");
        }
        static void CheckBounds(string label)
        {
            var safe=Screen.safeArea;var corners=new Vector3[4];
            foreach(var button in UnityEngine.Object.FindObjectsByType<Button>(FindObjectsSortMode.None).Where(b=>b.gameObject.activeInHierarchy)) {
                var rt=button.GetComponent<RectTransform>();rt.GetWorldCorners(corners);
                // Only visible controls; clipped scrolling cards are intentionally outside the viewport.
                if(corners[2].y<safe.yMin||corners[0].y>safe.yMax)continue;
                Check(rt.rect.height>=48&&corners[0].x>=safe.xMin-1&&corners[2].x<=safe.xMax+1,label+": "+button.name+" touch size and horizontal bounds");
            }
        }
    }
}
#endif
