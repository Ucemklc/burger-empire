#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using BurgerEmpire.Core;
using BurgerEmpire.Unity;
using UnityEditor;
using UnityEngine;
using Progress=BurgerEmpire.Core.Progress;

namespace BurgerEmpire.Editor
{
    [InitializeOnLoad]
    public static class BurgerEmpireNavigationChecks
    {
        const string Pending="BurgerEmpire.NavigationChecks",Report="BurgerEmpireNavigationChecks.txt";
        const BindingFlags Private=BindingFlags.Instance|BindingFlags.NonPublic;
        static IEnumerator<float> steps;
        static double next;
        static int nextFrame,lastEvent;
        static BurgerEmpireGame game;
        static Simulation original;
        static string disk;
        struct Blocker { public string name;public Bounds bounds; }
        static BurgerEmpireNavigationChecks(){EditorApplication.update+=Update;}
        static void Update()
        {
            if(EditorApplication.isCompiling||EditorApplication.isUpdating)return;
            if(File.Exists("BurgerEmpireNavigationChecks.request")) {
                try{File.Delete("BurgerEmpireNavigationChecks.request");}catch(IOException){return;}
                File.WriteAllText(Report,"");SessionState.SetBool(Pending,true);nextFrame=0;
                if(!EditorApplication.isPlaying){BurgerEmpireSetup.Play();return;}
            }
            if(!EditorApplication.isPlaying||!SessionState.GetBool(Pending,false)||EditorApplication.timeSinceStartup<next||Time.frameCount<nextFrame)return;
            try {
                if(steps==null) {
                    game=UnityEngine.Object.FindFirstObjectByType<BurgerEmpireGame>();if(!game||game.Sim==null)return;
                    original=game.Sim;disk=File.ReadAllText("BurgerEmpireSave.json");game.ValidationActive=true;
                    lastEvent=(int)typeof(BurgerEmpireGame).GetField("lastEvent",Private).GetValue(game);steps=Run();
                }
                if(steps.MoveNext()){next=EditorApplication.timeSinceStartup+steps.Current;nextFrame=Time.frameCount+3;}else Finish();
            }catch(Exception e){File.AppendAllText(Report,"FAIL: "+e+"\n");Finish();}
        }
        static void SetSimulation(Simulation sim)
        {
            typeof(BurgerEmpireGame).GetProperty("Sim").SetValue(game,sim);
            typeof(BurgerEmpireGame).GetField("lastEvent",Private).SetValue(game,0);
            typeof(RestaurantHud).GetField("toastTime",Private).SetValue(game.Hud,0f);
        }
        static void Finish()
        {
            if(game&&original!=null){SetSimulation(original);original.Paused=true;game.ValidationActive=false;game.Save();typeof(BurgerEmpireGame).GetField("lastEvent",Private).SetValue(game,lastEvent);}
            original=null;steps=null;nextFrame=0;SessionState.SetBool(Pending,false);
        }
        static void Check(bool passed,string label)
        {File.AppendAllText(Report,(passed?"PASS: ":"FAIL: ")+label+"\n");if(!passed)throw new Exception(label);}
        static Transform Model(Transform world,NavigationSolid solid)
        {
            var office=world.Find("Staff work zones/Manager Office");
            switch(solid.name) {
                case "Door frame lower":return office.Cast<Transform>().First(t=>t.name=="Door frame"&&t.localPosition.z<WorkZones.DoorZ);
                case "Door frame upper":return office.Cast<Transform>().First(t=>t.name=="Door frame"&&t.localPosition.z>WorkZones.DoorZ);
                case "Desk oak top":return office.Find("Manager Desk/Desk oak top");
                case "Kitchen plant":return world.Cast<Transform>().First(t=>t.name=="Plant"&&t.localPosition.z<3).Find("Terracotta");
                case "Cleaning cart":return world.Find("Staff work zones/Cleaning Station");
                case "Waste bin":return world.Find("Staff work zones/Restaurant waste bin/Waste bin");
                case "Drive worktop":return world.Find("DriveThru/Pickup window/Worktop");
                case "Packaging worktop":return world.Find("Delivery station/Packaging counter/Worktop");
                case "Milkshake worktop":return world.Find("Milkshake station/Milkshake worktop");
                default:return office.Find(solid.name)??world.Find(solid.name);
            }
        }
        static bool Hits(Bounds bounds,Point a,Point b)
        {
            // Renderer bounds are independent of the navigation graph's obstacle list.
            var start=new Vector3(a.x,bounds.center.y,a.z);var end=new Vector3(b.x,bounds.center.y,b.z);
            if(bounds.Contains(start)||bounds.Contains(end))return true;
            var delta=end-start;float distance=delta.magnitude;
            return distance>.000001f&&bounds.IntersectRay(new Ray(start,delta/distance),out var entry)&&entry<distance;
        }
        static IEnumerator<float> Run()
        {
            BurgerEmpireMobileChecks.SetSize(2340,1080);yield return .5f;
            if(game.LayoutEditor.Active)game.Hud.FinishLayout(false);
            if(game.Hud.BlocksWorldInput)game.Hud.ClosePanel();
            var sim=new Simulation(new Progress{tutorialDone=true,served=40,xp=3000,coins=2000,cashier=3,cook=3,waiter=3,cleaner=3,manager=1,tables=4,grill=3,fryer=3,blender=2,cheese=1,doubleBurger=1,decor=1,driveThru=2,delivery=2});
            SetSimulation(sim);yield return .4f;
            var world=GameObject.Find("Restaurant Environment").transform;var blockers=new List<Blocker>();
            foreach(var solid in NavigationGeometry.Solids.Where(s=>s.name!="Open door clearance")) {
                var model=Model(world,solid);Check(model&&model.gameObject.activeInHierarchy,solid.name+": actual solid model is present");
                var renderers=model.GetComponentsInChildren<Renderer>();var bounds=renderers[0].bounds;
                foreach(var renderer in renderers.Skip(1))bounds.Encapsulate(renderer.bounds);
                Check(bounds.min.x>=solid.x-solid.width/2-.015f&&bounds.max.x<=solid.x+solid.width/2+.015f&&bounds.min.z>=solid.z-solid.depth/2-.015f&&bounds.max.z<=solid.z+solid.depth/2+.015f,solid.name+": navigation footprint encloses the visible model");
                bounds.Expand(new Vector3((solid.clearance-.02f)*2,0,(solid.clearance-.02f)*2));blockers.Add(new Blocker{name=solid.name,bounds=bounds});
            }
            var operations=(RestaurantOperations)typeof(BurgerEmpireGame).GetField("operations",Private).GetValue(game);
            var door=world.Find("Staff work zones/Manager Office/Push office door");
            var counts=sim.Actors.ToDictionary(a=>a.role,a=>0);int guests=0,doorPasses=0;
            string collision="";bool clear=true,doorClear=true;
            for(int frame=0;frame<6000;frame++) {
                if(frame>=695&&frame<=705){sim.Tables[0].dirty=true;sim.Tables[1].dirty=true;}
                var before=sim.Actors.ToDictionary(a=>a.role,a=>new Point(a.x,a.z));
                var beforeGuests=sim.Customers.Where(c=>!c.drive).ToDictionary(c=>c.id,c=>new Point(c.x,c.z));
                sim.Paused=false;if(sim.Actors[0].job=="")sim.Command("next");sim.Tick(.05f);sim.Paused=true;
                operations.Sync(sim);
                foreach(var actor in sim.Actors) {
                    var a=before[actor.role];var b=new Point(actor.x,actor.z);
                    if(WorkZones.Distance(a,b)<.000001f)continue;counts[actor.role]++;
                    foreach(var blocker in blockers)if(Hits(blocker.bounds,a,b)){clear=false;collision=actor.role+" / "+blocker.name;}
                    var localA=door.InverseTransformPoint(new Vector3(a.x,1,a.z));var localB=door.InverseTransformPoint(new Vector3(b.x,1,b.z));
                    if(Hits(new Bounds(new Vector3(0,0,.65f),new Vector3(.76f,4,1.96f)),new Point(localA.x,localA.z),new Point(localB.x,localB.z)))doorClear=false;
                    if(a.x*b.x<0)doorPasses++;
                }
                foreach(var guest in sim.Customers.Where(c=>!c.drive))if(beforeGuests.TryGetValue(guest.id,out var a)) {
                    var b=new Point(guest.x,guest.z);if(WorkZones.Distance(a,b)<.000001f)continue;guests++;
                    foreach(var blocker in blockers)if(Hits(blocker.bounds,a,b)){clear=false;collision="customer "+guest.id+" / "+blocker.name;}
                }
                if(frame%100==0)yield return .01f;
            }
            Check(clear,"Five-minute shift: no moving employee or pedestrian intersects actual scene solids: "+collision);
            Check(doorClear&&doorPasses>=2,"Manager enters and leaves office without intersecting the moving door leaf");
            foreach(var pair in counts)Check(pair.Value>10,pair.Key+": movement tested against actual walls and counters ("+pair.Value+" segments)");
            Check(guests>500,"Customers and couriers tested against actual scene solids ("+guests+" segments)");
            Check(sim.P.driveServed>0&&sim.P.deliveryServed>0&&sim.P.served>sim.P.driveServed+sim.P.deliveryServed&&sim.P.cleaned>0,"Salon, drive, courier, payments and cleaning continue with collision-safe routes");
            yield return .25f;
            var people=GameObject.Find("Living Restaurant").transform;
            Check(sim.Actors.All(a=>Vector2.Distance(new Vector2(people.Find(a.role).position.x,people.Find(a.role).position.z),new Vector2(a.x,a.z))<.001f),"Visible worker positions match the checked simulation positions");
            ScreenCapture.CaptureScreenshot(Path.GetFullPath("BurgerEmpire-0.15.2-Navigation.png"));yield return .3f;
            Check(File.ReadAllText("BurgerEmpireSave.json")==disk,"Navigation fixtures never overwrite the current player save");
            File.AppendAllText(Report,"Completed. Actual Unity renderer footprints, door leaf, all staff roles and pedestrians verified; physical Android not tested.\n");
        }
    }
}
#endif
