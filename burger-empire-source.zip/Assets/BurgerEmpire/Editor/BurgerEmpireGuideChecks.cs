#if UNITY_EDITOR && ENABLE_INPUT_SYSTEM
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using BurgerEmpire.Core;
using BurgerEmpire.Unity;
using UnityEditor;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.LowLevel;
using UnityEngine.UI;
using Progress=BurgerEmpire.Core.Progress;

namespace BurgerEmpire.Editor
{
    [InitializeOnLoad]
    public static class BurgerEmpireGuideChecks
    {
        const string Pending="BurgerEmpire.GuideChecks",Report="BurgerEmpireGuideChecks.txt";
        static IEnumerator<float> steps;
        static double next;
        static int nextFrame;
        static BurgerEmpireGame game;
        static Simulation original;
        static string disk;
        static int lastEvent;
        static Touchscreen touch;
        static InputSettings.BackgroundBehavior background;
        static InputSettings.EditorInputBehaviorInPlayMode routing;
        static BurgerEmpireGuideChecks(){EditorApplication.update+=Update;}
        static void Update()
        {
            if(EditorApplication.isCompiling||EditorApplication.isUpdating)return;
            if(File.Exists("BurgerEmpireGuideChecks.request")) {
                try {File.Delete("BurgerEmpireGuideChecks.request");} catch(IOException){return;}
                File.WriteAllText(Report,"");SessionState.SetBool(Pending,true);nextFrame=0;
                if(!EditorApplication.isPlaying){BurgerEmpireSetup.Play();return;}
            }
            if(!EditorApplication.isPlaying||!SessionState.GetBool(Pending,false)||EditorApplication.timeSinceStartup<next||Time.frameCount<nextFrame)return;
            try {
                if(steps==null) {
                    game=UnityEngine.Object.FindFirstObjectByType<BurgerEmpireGame>();if(!game||game.Sim==null)return;
                    original=game.Sim;disk=File.ReadAllText("BurgerEmpireSave.json");game.ValidationActive=true;
                    lastEvent=(int)typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).GetValue(game);
                    background=InputSystem.settings.backgroundBehavior;InputSystem.settings.backgroundBehavior=InputSettings.BackgroundBehavior.IgnoreFocus;
                    routing=InputSystem.settings.editorInputBehaviorInPlayMode;InputSystem.settings.editorInputBehaviorInPlayMode=InputSettings.EditorInputBehaviorInPlayMode.AllDeviceInputAlwaysGoesToGameView;
                    touch=InputSystem.AddDevice<Touchscreen>();steps=Run();
                }
                if(steps.MoveNext()){next=EditorApplication.timeSinceStartup+steps.Current;nextFrame=Time.frameCount+3;}else Finish();
            } catch(Exception e){File.AppendAllText(Report,"FAIL: "+e+"\n");Finish();}
        }
        static void SetSimulation(Simulation value)
        {
            typeof(BurgerEmpireGame).GetProperty("Sim").SetValue(game,value);
            typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game,0);
            typeof(RestaurantHud).GetField("toastTime",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game.Hud,0f);
        }
        static void Finish()
        {
            if(touch!=null){InputSystem.RemoveDevice(touch);touch=null;}InputSystem.settings.backgroundBehavior=background;InputSystem.settings.editorInputBehaviorInPlayMode=routing;
            if(game&&original!=null) {
                if(game.LayoutEditor.Active)game.Hud.FinishLayout(false);
                SetSimulation(original);original.Paused=true;game.ValidationActive=false;game.Save();game.Hud.OpenPanel("Gelişim Rehberi");
                typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game,lastEvent);
            }
            steps=null;original=null;nextFrame=0;SessionState.SetBool(Pending,false);
        }
        static Progress Fixture()
        {
            var p=JsonUtility.FromJson<Progress>(JsonUtility.ToJson(original.P));
            p.coins=3000;p.xp=700;p.grill=2;p.fryer=1;p.blender=0;p.doubleBurger=0;p.cheese=1;p.mission=5;p.tutorialDone=true;
            p.shakeSold=p.doubleSold=0;p.activeBranch=0;p.chickenBurger=p.bbqBurger=p.chocolateShake=0;return p;
        }
        static void Check(bool good,string message)
        {File.AppendAllText(Report,(good?"PASS: ":"FAIL: ")+message+"\n");if(!good)throw new Exception(message);}
        static Button Find(string name){return UnityEngine.Object.FindObjectsByType<Button>(FindObjectsSortMode.None).First(b=>b.name==name&&b.gameObject.activeInHierarchy);}
        static Vector2 Center(RectTransform rt){return RectTransformUtility.WorldToScreenPoint(null,rt.TransformPoint(rt.rect.center));}
        static void Touch(Vector2 p,UnityEngine.InputSystem.TouchPhase phase)
        {InputSystem.QueueStateEvent(touch,new TouchState{touchId=1,position=p,phase=phase});}
        static bool Until(Func<bool> condition,int limit=1000)
        {
            game.Sim.Paused=false;
            for(int i=0;i<limit&&!condition();i++){if(game.Sim.Actors[0].job=="")game.Sim.Command("next");game.Sim.Tick(.1f);}
            game.Sim.Paused=true;return condition();
        }


        static string Tab=>(string)typeof(RestaurantHud).GetField("tab",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).GetValue(game.Hud);
        static bool HasText(string value)=>UnityEngine.Object.FindObjectsByType<Text>(FindObjectsSortMode.None).Any(t=>t.gameObject.activeInHierarchy&&t.text.Contains(value));
        static IEnumerator<float> Tap(string name)
        {
            var button=Find(name);var list=button.GetComponentInParent<ScrollRect>();
            if(list) {
                var rt=button.GetComponent<RectTransform>();
                float offset=-list.content.InverseTransformPoint(rt.TransformPoint(rt.rect.center)).y-list.viewport.rect.height*.5f;
                list.content.anchoredPosition=new Vector2(0,Mathf.Clamp(offset,0,list.content.rect.height-list.viewport.rect.height));
                list.StopMovement();Canvas.ForceUpdateCanvases();yield return .15f;
            }
            var point=Center(Find(name).GetComponent<RectTransform>());
            Touch(point,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;
            Touch(point,UnityEngine.InputSystem.TouchPhase.Ended);yield return .2f;
        }
        static IEnumerator<float> Run()
        {
            BurgerEmpireMobileChecks.SetSize(2340,1080);yield return .6f;
            if(game.LayoutEditor.Active)game.Hud.FinishLayout(false);
            if(game.Hud.BlocksWorldInput)game.Hud.ClosePanel();
            SetSimulation(new Simulation(new Progress()));game.Sim.Paused=false;
            game.Hud.OpenPanel("Restoran");yield return .2f;
            foreach(var wait in Enumerate(Tap("Open growth guide")))yield return wait;
            Check(Tab=="Gelişim Rehberi"&&game.Sim.Paused,"Restaurant touch opens guide and pauses the running shift");
            Check(HasText("SIRADAKİ · İlk vardiyanı tamamla")&&HasText("55 coin eksik"),"Fresh guide explains first shift and first hire shortage");
            Check(game.Sim.P.coins==120&&game.Sim.P.cashier==0,"Browsing guide does not spend money or hire staff");
            foreach(var wait in Enumerate(Tap("Guide action shift")))yield return wait;
            Check(!game.Hud.BlocksWorldInput&&!game.Sim.Paused,"Return to shift restores running state");
            game.Sim.Paused=true;game.Hud.OpenPanel("Görevler");yield return .2f;
            foreach(var wait in Enumerate(Tap("Open growth guide")))yield return wait;
            Check(Tab=="Gelişim Rehberi","Tasks touch also opens the same guide");
            game.Hud.ClosePanel();Check(game.Sim.Paused,"Closing guide preserves an already paused shift");

            SetSimulation(new Simulation(new Progress{tutorialDone=true,coins=500,xp=900}));
            game.Hud.OpenPanel("Gelişim Rehberi");yield return .2f;
            foreach(var wait in Enumerate(Tap("Guide action crew")))yield return wait;
            Check(Tab=="Geliştirme:cashier"&&Find("Buy cashier").interactable&&game.Sim.P.coins==500,"Crew action shows the real offer without buying it");
            foreach(var wait in Enumerate(Tap("Buy cashier")))yield return wait;
            Check(game.Sim.P.cashier==1&&game.Sim.P.coins==325,"Explicit touch hires cashier with one 175-coin payment");
            foreach(var wait in Enumerate(Tap("Back to growth guide")))yield return wait;
            Check(Tab=="Gelişim Rehberi"&&GrowthGuide.Steps(game.Sim).Single(s=>s.id=="crew").target=="Geliştirme:cook","Back to guide recalculates the next hire");

            var low=new Progress{tutorialDone=true,coins=12,cheese=1,cashier=1,cook=1,waiter=1,cleaner=1};
            SetSimulation(new Simulation(low));game.Hud.OpenPanel("Gelişim Rehberi");yield return .2f;
            Check(HasText("Seviye 3 gerekiyor.")&&HasText("238 coin eksik"),"Guide displays level and exact money shortage together");
            foreach(var wait in Enumerate(Tap("Guide action menu")))yield return wait;
            Check(Tab=="Geliştirme:blender"&&!Find("Buy blender").interactable,"Locked guide destination prevents an ineligible purchase");
            game.Hud.OpenPanel("Gelişim Rehberi");yield return .2f;
            CheckBounds("2340x1080");CheckText();
            ScreenCapture.CaptureScreenshot(Path.GetFullPath("BurgerEmpire-0.21-Guide.png"));yield return .3f;
            var list=UnityEngine.Object.FindFirstObjectByType<ScrollRect>();var swipe=Center(list.viewport);
            Touch(swipe,UnityEngine.InputSystem.TouchPhase.Began);yield return .1f;
            Touch(swipe+Vector2.up*220,UnityEngine.InputSystem.TouchPhase.Moved);yield return .15f;
            Touch(swipe+Vector2.up*500,UnityEngine.InputSystem.TouchPhase.Moved);yield return .15f;
            Touch(swipe+Vector2.up*500,UnityEngine.InputSystem.TouchPhase.Ended);yield return .2f;
            Check(list.content.anchoredPosition.y>60,"Real touch swipe scrolls through the guide");
            BurgerEmpireMobileChecks.SetSize(1080,2340);yield return .5f;
            Check(Tab=="Gelişim Rehberi"&&game.Sim.Paused,"Rotation retains guide and pause state");
            CheckBounds("1080x2340");CheckText();
            ScreenCapture.CaptureScreenshot(Path.GetFullPath("BurgerEmpire-0.21-Guide-Portrait.png"));yield return .3f;
            foreach(var wait in Enumerate(Tap("Guide action london")))yield return wait;
            Check(Tab=="Şubeler"&&!game.Sim.P.londonOpen,"Portrait expansion action opens branches without spending money");

            var reward=new Progress{tutorialDone=true,served=1,coins=120};
            SetSimulation(new Simulation(reward));game.Hud.OpenPanel("Gelişim Rehberi");yield return .2f;
            Check(HasText("Alınmayı bekleyen ödüllerin var."),"Ready mission reward is highlighted");
            foreach(var wait in Enumerate(Tap("Guide rewards")))yield return wait;
            Check(Tab=="Görevler"&&game.Sim.P.mission==0&&game.Sim.P.coins==120,"Reward link shows tasks without silently claiming a reward");
            var branches=new Progress{tutorialDone=true,londonOpen=true,london=new RestaurantProgress{tutorialDone=true},cashier=1,cook=1,waiter=1,cleaner=1};
            SetSimulation(new Simulation(branches));game.Sim.SwitchBranch(1,out _);game.Hud.OpenPanel("Gelişim Rehberi");yield return .2f;
            Check(HasText("Londra ·")&&HasText("SIRADAKİ · Ekibini kur")&&HasText("TAMAM · Londra şubesini aç"),"London guide uses its own staff and the shared expansion milestone");
            foreach(var wait in Enumerate(Tap("Guide action crew")))yield return wait;
            Check(Tab=="Geliştirme:cashier"&&!Find("Buy cashier").interactable,"London offer uses shared wallet and its own missing cashier");

            var complete=new Progress{tutorialDone=true,londonOpen=true,london=new RestaurantProgress{tutorialDone=true},cashier=1,cook=1,waiter=1,cleaner=1,cheese=1,blender=1,doubleBurger=1,chickenBurger=1,bbqBurger=1,chocolateShake=1,driveThru=1,delivery=1};
            SetSimulation(new Simulation(complete));game.Hud.OpenPanel("Gelişim Rehberi");yield return .2f;
            Check(HasText("7/7 rehber adımı")&&HasText("Bu rehberin bütün adımları tamam!")&&!HasText("SIRADAKİ ·"),"Completed guide offers continued play without inventing more unlocks");
            CheckText();BurgerEmpireMobileChecks.SetSize(1280,720);yield return .5f;CheckBounds("1280x720");CheckText();
            BurgerEmpireMobileChecks.SetSize(2340,1080);yield return .5f;
            game.Save();Check(File.ReadAllText("BurgerEmpireSave.json")==disk,"All guide scenarios leave the real player save unchanged");
            File.AppendAllText(Report,"Completed. Unity Input System touch verified. Physical Android device not tested.\n");
        }
        static IEnumerable<float> Enumerate(IEnumerator<float> source){while(source.MoveNext())yield return source.Current;}
        static void CheckText()
        {
            var list=UnityEngine.Object.FindFirstObjectByType<ScrollRect>();
            var labels=list.content.GetComponentsInChildren<Text>().Where(t=>t.gameObject.activeInHierarchy).ToArray();
            Check(labels.All(t=>t.preferredHeight<=t.rectTransform.rect.height+1),"Guide text fits its allocated height at "+Screen.width+"x"+Screen.height);
        }
        static void CheckBounds(string label)
        {
            var safe=Screen.safeArea;var corners=new Vector3[4];
            foreach(var button in UnityEngine.Object.FindObjectsByType<Button>(FindObjectsSortMode.None).Where(b=>b.gameObject.activeInHierarchy)) {
                var rt=button.GetComponent<RectTransform>();rt.GetWorldCorners(corners);
                // Only visible controls; clipped scrolling cards are intentionally outside the viewport.
                if(corners[2].y<safe.yMin||corners[0].y>safe.yMax)continue;
                Check(rt.rect.height>=48&&corners[0].x>=safe.xMin-1&&corners[2].x<=safe.xMax+1,label+": "+button.name+" touch size and horizontal bounds");
            }
        }
    }
}
#endif

