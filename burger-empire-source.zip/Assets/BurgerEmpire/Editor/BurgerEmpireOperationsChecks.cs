#if UNITY_EDITOR && ENABLE_INPUT_SYSTEM
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using BurgerEmpire.Core;
using BurgerEmpire.Unity;
using UnityEditor;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.LowLevel;
using UnityEngine.UI;
using Progress=BurgerEmpire.Core.Progress;

namespace BurgerEmpire.Editor
{
    [InitializeOnLoad]
    public static class BurgerEmpireOperationsChecks
    {
        const string Pending="BurgerEmpire.OperationsChecks",Report="BurgerEmpireOperationsChecks.txt";
        static IEnumerator<float> steps;
        static double next;
        static int nextFrame,lastEvent;
        static BurgerEmpireGame game;
        static Simulation original;
        static string disk,originalPath;
        static Touchscreen touch;
        static InputSettings.BackgroundBehavior background;
        static InputSettings.EditorInputBehaviorInPlayMode routing;
        const BindingFlags Private=BindingFlags.Instance|BindingFlags.NonPublic;
        static BurgerEmpireOperationsChecks(){EditorApplication.update+=Update;}
        static void Update()
        {
            if(EditorApplication.isCompiling||EditorApplication.isUpdating)return;
            if(File.Exists("BurgerEmpireOperationsChecks.request")) {
                try{File.Delete("BurgerEmpireOperationsChecks.request");}catch(IOException){return;}
                File.WriteAllText(Report,"");SessionState.SetBool(Pending,true);nextFrame=0;
                if(!EditorApplication.isPlaying){BurgerEmpireSetup.Play();return;}
            }
            if(!EditorApplication.isPlaying||!SessionState.GetBool(Pending,false)||EditorApplication.timeSinceStartup<next||Time.frameCount<nextFrame)return;
            try {
                if(steps==null) {
                    game=UnityEngine.Object.FindFirstObjectByType<BurgerEmpireGame>();if(!game||game.Sim==null)return;
                    original=game.Sim;disk=File.ReadAllText("BurgerEmpireSave.json");
                    originalPath=(string)typeof(BurgerEmpireGame).GetField("savePath",Private).GetValue(game);
                    typeof(BurgerEmpireGame).GetField("savePath",Private).SetValue(game,Path.GetFullPath("BurgerEmpireOperationsValidationSave.json"));
                    lastEvent=(int)typeof(BurgerEmpireGame).GetField("lastEvent",Private).GetValue(game);
                    background=InputSystem.settings.backgroundBehavior;InputSystem.settings.backgroundBehavior=InputSettings.BackgroundBehavior.IgnoreFocus;
                    // Route the synthetic touchscreen to the game even when another editor window has focus.
                    routing=InputSystem.settings.editorInputBehaviorInPlayMode;InputSystem.settings.editorInputBehaviorInPlayMode=InputSettings.EditorInputBehaviorInPlayMode.AllDeviceInputAlwaysGoesToGameView;
                    touch=InputSystem.AddDevice<Touchscreen>();steps=Run();
                }
                if(steps.MoveNext()){next=EditorApplication.timeSinceStartup+steps.Current;nextFrame=Time.frameCount+3;}else Finish();
            }catch(Exception e){File.AppendAllText(Report,"FAIL: "+e+"\n");Finish();}
        }
        static void Finish()
        {
            if(touch!=null){InputSystem.RemoveDevice(touch);touch=null;}InputSystem.settings.backgroundBehavior=background;InputSystem.settings.editorInputBehaviorInPlayMode=routing;
            if(game&&original!=null) {
                typeof(BurgerEmpireGame).GetField("savePath",Private).SetValue(game,originalPath);
                SetSimulation(original);original.Paused=true;game.Save();
                typeof(BurgerEmpireGame).GetField("lastEvent",Private).SetValue(game,lastEvent);
            }
            steps=null;original=null;nextFrame=0;SessionState.SetBool(Pending,false);
        }
        static void SetSimulation(Simulation sim)
        {
            typeof(BurgerEmpireGame).GetProperty("Sim").SetValue(game,sim);
            typeof(BurgerEmpireGame).GetField("lastEvent",Private).SetValue(game,0);
            typeof(RestaurantHud).GetField("toastTime",Private).SetValue(game.Hud,0f);
        }
        static void Check(bool passed,string label){File.AppendAllText(Report,(passed?"PASS: ":"FAIL: ")+label+"\n");if(!passed)throw new Exception(label);}
        static void Touch(Vector2 point,UnityEngine.InputSystem.TouchPhase phase)
        {InputSystem.QueueStateEvent(touch,new TouchState{touchId=1,position=point,phase=phase});}
        static void Advance(float seconds){game.Sim.Paused=false;for(int i=0;i<(int)(seconds*20);i++)game.Sim.Tick(.05f);game.Sim.Paused=true;}
        static Dictionary<int,RectTransform> Bubbles=>(Dictionary<int,RectTransform>)typeof(RestaurantHud).GetField("customerBubbles",Private).GetValue(game.Hud);
        static FoodIconGraphic[] Icons(int id)=>Bubbles[id].GetComponentsInChildren<FoodIconGraphic>();
        static Transform Zones=>GameObject.Find("Restaurant Environment").transform.Find("Staff work zones");
        static Progress Crew()=>new Progress{tutorialDone=true,xp=1800,coins=2500,cashier=1,cook=2,waiter=1,cleaner=1,manager=1,driveThru=2,delivery=2,grill=3,fryer=2,blender=1,cheese=1,doubleBurger=1,tables=4,decor=1};
        static void BubbleBounds(string size)
        {
            var camera=game.GameCamera.pixelRect;var points=new Vector3[4];
            foreach(var pair in Bubbles.Where(p=>p.Value.gameObject.activeInHierarchy)) {
                pair.Value.GetWorldCorners(points);
                Check(points[0].x>=camera.xMin-1&&points[2].x<=camera.xMax+1&&points[0].y>=camera.yMin-1&&points[2].y<=camera.yMax+1,size+": order "+pair.Key+" stays in the restaurant viewport");
            }
            Check(Bubbles.Values.All(b=>b.GetComponentsInChildren<Text>(true).Length==0),size+": customer bubbles contain no tiny product or status text");
            Check(Bubbles.Values.SelectMany(b=>b.GetComponentsInChildren<FoodIconGraphic>()).All(i=>i.canvasRenderer&&i.canvasRenderer.materialCount>0&&i.DrawnVertices>0),size+": every active icon has a renderer, material and populated geometry");
            var rectangles=Bubbles.Values.Where(b=>b.gameObject.activeInHierarchy).Select(b=>new Rect(b.anchoredPosition.x,-b.anchoredPosition.y,b.rect.width,b.rect.height)).ToArray();
            bool separate=true;for(int i=0;i<rectangles.Length;i++)for(int j=i+1;j<rectangles.Length;j++)separate&=!rectangles[i].Overlaps(rectangles[j]);
            Check(separate,size+": neighboring customer cards do not overlap");
            foreach(var icon in Icons(900).Where(i=>i.name.StartsWith("Food item"))) {
                icon.rectTransform.GetWorldCorners(points);Check(points[2].x-points[0].x>=20&&points[2].x-points[0].x<=40,size+": passive food illustration stays compact and visible (20-40 screen pixels)");
            }
            Check(Bubbles.Values.SelectMany(b=>b.GetComponentsInChildren<Graphic>(true)).All(g=>!g.raycastTarget),size+": order indicators never intercept restaurant touches");
            foreach(var p in new[]{new Vector3(-3.6f,.3f,.6f),new Vector3(-3.6f,.3f,4.6f),new Vector3(0,2.4f,WorkZones.DoorZ)})
                Check(camera.Contains(game.GameCamera.WorldToScreenPoint(p)),size+": manager office and door remain in view");
        }
        static IEnumerator<float> Run()
        {
            BurgerEmpireMobileChecks.SetSize(2340,1080);yield return .7f;
            if(game.LayoutEditor.Active)game.Hud.FinishLayout(false);
            if(game.Hud.BlocksWorldInput)game.Hud.ClosePanel();
            SetSimulation(new Simulation(Crew()));yield return .4f;
            var office=Zones.Find("Manager Office");
            Check(office&&office.Find("Manager Desk")&&office.Find("Manager Chair")&&office.Find("Filing cabinet")&&office.Find("Management board"),"Separate office contains desk, chair, filing cabinet and management board");
            Check(office.Find("Manager Desk/Computer monitor")&&office.Find("Manager Desk/Keyboard")&&office.Find("Manager Desk/Files"),"Manager desk has visible computer, keyboard and files");
            Check(office.Find("Office partition")&&office.Find("Office outer wall")&&office.Find("Push office door/Door leaf").GetComponent<BoxCollider>(),"Office is divided by walls and a solid hinged door");
            Check(Zones.Find("Cleaning Station/Mop pole")&&Zones.Find("Preparation Table/Assembly board")&&Zones.Find("Kitchen Pickup Point"),"Cleaner, chef and waiter have visible dedicated workstations");
            foreach(string role in new[]{"cashier","cook","waiter","cleaner","drive","manager"})
                Check(Zones.Find(role+" Idle Position")&&Zones.Find(role+" Interaction Position"),role+": scene exposes separate idle and interaction markers");
            var staff=GameObject.Find("Living Restaurant").transform;
            Check(staff.Find("drive/Drive headset")&&staff.Find("manager/Manager tie"),"Window attendant wears a headset and manager has an office uniform");
            Check(staff.Find("manager").position.x<0&&Math.Abs(staff.Find("manager").position.z-WorkZones.Idle("manager").z)<.1f,"Manager visual is seated at the desk, away from the dining crew");
            ScreenCapture.CaptureScreenshot(Path.GetFullPath("BurgerEmpire-0.15.1-WorkZones.png"));yield return .3f;

            SetSimulation(new Simulation(new Progress{tutorialDone=true}));yield return .3f;game.Sim.Paused=false;
            var target=(Vector2)game.GameCamera.WorldToScreenPoint(new Vector3(-1.65f,.25f,2.5f));
            Check(!game.PointerOnUI(target),"Office floor is a playable touch target");
            Touch(target,UnityEngine.InputSystem.TouchPhase.Began);yield return .15f;Touch(target,UnityEngine.InputSystem.TouchPhase.Ended);yield return .25f;
            Check(game.Sim.Actors[0].job=="move"&&game.Sim.Actors[0].path.Count>0,"Real touch inside office routes player through the door");
            for(int i=0;i<300&&game.Sim.OfficeDoorAngle<70;i++)game.Sim.Tick(.05f);
            game.Sim.Paused=true;yield return .2f;
            Check(game.Sim.OfficeDoorAngle>=65&&Math.Abs(office.Find("Push office door").localEulerAngles.y)>60,"Door visibly swings open as player reaches it");
            float angle=game.Sim.OfficeDoorAngle;yield return .25f;Check(game.Sim.OfficeDoorAngle==angle,"Paused restaurant freezes door animation");
            ScreenCapture.CaptureScreenshot(Path.GetFullPath("BurgerEmpire-0.15.1-OfficeDoor.png"));yield return .3f;
            Advance(8);yield return .2f;
            Check(game.Sim.Actors[0].x<0&&game.Sim.Actors[0].job==""&&game.Sim.OfficeDoorAngle==0,"Player reaches office and door closes after passage");
            game.Sim.Paused=false;target=game.GameCamera.WorldToScreenPoint(new Vector3(1.1f,.25f,WorkZones.DoorZ));
            Touch(target,UnityEngine.InputSystem.TouchPhase.Began);yield return .15f;Touch(target,UnityEngine.InputSystem.TouchPhase.Ended);yield return .2f;
            Advance(8);yield return .2f;Check(game.Sim.Actors[0].x>0&&game.Sim.Actors[0].job=="","Real touch outside office brings player back to restaurant");

            var fixture=new Simulation(Crew());
            fixture.Customers.Add(new Customer{id=900,phase="waiting",order="ordered",table=0,x=2.3f,z=5.95f,product="classic",station="grill",patience=100,maxPatience=100});
            fixture.Customers.Add(new Customer{id=901,kind=VipCatalog.Kind,phase="waiting",order="ready",table=1,x=6,z=5.95f,product="double",station="grill",patience=20,maxPatience=100});
            fixture.Customers.Add(new Customer{id=902,phase="queue",order="cooking",x=9.1f,z=4.25f,product="shake",station="blender",patience=40,maxPatience=100,cookTime=100});
            fixture.Tables[0].customer=900;fixture.Tables[1].customer=901;SetSimulation(fixture);yield return .35f;
            Check(Icons(900).Where(i=>i.name.StartsWith("Food item")).Select(i=>i.Kind).SequenceEqual(new[]{"burger","fries","cola"}),"Combo bubble displays burger, fries and cola side by side");
            Check(Icons(902).Count(i=>i.name.StartsWith("Food item"))==1&&Icons(902).Any(i=>i.Kind=="shake"),"Single milkshake order displays exactly one food illustration");
            Check(Icons(901).Any(i=>i.Kind=="double")&&Icons(901).Any(i=>i.Kind=="crown"),"VIP double burger uses its distinct food illustration and crown badge");
            Check(Icons(900).Any(i=>i.Kind=="clock")&&Icons(901).Any(i=>i.Kind=="check")&&Icons(902).Any(i=>i.Kind=="spinner"),"Waiting, ready and cooking states have different graphic signals");
            Check(Icons(900).Any(i=>i.Kind=="face"&&i.Mood==0)&&Icons(902).Any(i=>i.Kind=="face"&&i.Mood==1)&&Icons(901).Any(i=>i.Kind=="face"&&i.Mood==2),"Happy, waiting and angry faces follow actual patience");
            Check(Bubbles[901].Find("Patience").GetComponent<Image>().color==RestaurantArt.Red,"Urgent patience is also marked in red");
            BubbleBounds("2340x1080");
            ScreenCapture.CaptureScreenshot(Path.GetFullPath("BurgerEmpire-0.15.1-Orders.png"));yield return .3f;
            var c=fixture.Customers.First(v=>v.id==900);c.order="served";c.phase="eating";yield return .25f;
            Check(!Bubbles[900].gameObject.activeSelf,"Order bubble disappears immediately after serving the meal");
            c.phase="payment";yield return .2f;
            Check(Icons(900).Length==1&&Icons(900)[0].Kind=="coin","Payment uses a single coin signal instead of repeating the order");
            c.phase="waiting";c.order="ordered";yield return .2f;
            BurgerEmpireMobileChecks.SetSize(1280,720);yield return .6f;BubbleBounds("1280x720");
            BurgerEmpireMobileChecks.SetSize(1080,2340);yield return .6f;BubbleBounds("1080x2340");
            ScreenCapture.CaptureScreenshot(Path.GetFullPath("BurgerEmpire-0.15.1-Portrait.png"));yield return .3f;
            BurgerEmpireMobileChecks.SetSize(2340,1080);yield return .6f;
            SetSimulation(new Simulation(Crew()));Advance(90);yield return .3f;
            Check(game.Sim.P.driveServed>0&&game.Sim.P.served>game.Sim.P.driveServed,"Staffed Unity shift completes both drive and salon orders");
            Check(game.Sim.Actors.Where(a=>a.role=="cook").All(a=>a.z<2.5f),"Chef stays in kitchen during the live staffed shift");
            ScreenCapture.CaptureScreenshot(Path.GetFullPath("BurgerEmpire-0.15.1-Operation.png"));yield return .3f;
            game.Save();var saved=JsonUtility.FromJson<Progress>(File.ReadAllText("BurgerEmpireOperationsValidationSave.json"));
            Check(saved.coins==game.Sim.P.coins&&saved.driveServed==game.Sim.P.driveServed,"Operational income survives isolated Unity JSON save");
            Check(File.ReadAllText("BurgerEmpireSave.json")==disk,"All room and staff fixtures preserve the actual player's save");
            File.AppendAllText(Report,"Completed. Actual Unity touch, office navigation, door animation, work zones, icons and save verified; physical Android not tested.\n");
        }
    }
}
#endif
