#if UNITY_EDITOR && ENABLE_INPUT_SYSTEM
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using BurgerEmpire.Core;
using BurgerEmpire.Unity;
using UnityEditor;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.LowLevel;
using UnityEngine.UI;
using Progress=BurgerEmpire.Core.Progress;

namespace BurgerEmpire.Editor
{
    [InitializeOnLoad]
    public static class BurgerEmpireArtChecks
    {
        const string Pending="BurgerEmpire.ArtChecks",Report="BurgerEmpireArtChecks.txt";
        static IEnumerator<float> steps;
        static double next;
        static BurgerEmpireGame game;
        static Simulation original;
        static string disk;
        static int lastEvent;
        static Touchscreen touch;
        static InputSettings.BackgroundBehavior background;
        static BurgerEmpireArtChecks(){EditorApplication.update+=Update;}
        static void Update()
        {
            if(EditorApplication.isCompiling||EditorApplication.isUpdating)return;
            if(File.Exists("BurgerEmpireArtChecks.request")) {
                try {File.Delete("BurgerEmpireArtChecks.request");} catch(IOException){return;}
                File.WriteAllText(Report,"");SessionState.SetBool(Pending,true);
                if(!EditorApplication.isPlaying){BurgerEmpireSetup.Play();return;}
            }
            if(!EditorApplication.isPlaying||!SessionState.GetBool(Pending,false)||EditorApplication.timeSinceStartup<next)return;
            try {
                if(steps==null) {
                    game=UnityEngine.Object.FindFirstObjectByType<BurgerEmpireGame>();if(!game||game.Sim==null)return;
                    original=game.Sim;disk=File.ReadAllText("BurgerEmpireSave.json");game.ValidationActive=true;
                    lastEvent=(int)typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).GetValue(game);
                    background=InputSystem.settings.backgroundBehavior;InputSystem.settings.backgroundBehavior=InputSettings.BackgroundBehavior.IgnoreFocus;
                    touch=InputSystem.AddDevice<Touchscreen>();steps=Run();
                }
                if(steps.MoveNext())next=EditorApplication.timeSinceStartup+steps.Current;else Finish();
            } catch(Exception e){File.AppendAllText(Report,"FAIL: "+e+"\n");Finish();}
        }
        static void SetSimulation(Simulation value)
        {
            typeof(BurgerEmpireGame).GetProperty("Sim").SetValue(game,value);
            typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game,0);
            typeof(RestaurantHud).GetField("toastTime",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game.Hud,0f);
        }
        static void Finish()
        {
            if(touch!=null){InputSystem.RemoveDevice(touch);touch=null;}InputSystem.settings.backgroundBehavior=background;
            if(game&&original!=null) {
                if(game.LayoutEditor.Active)game.Hud.FinishLayout(false);
                SetSimulation(original);original.Paused=true;game.ValidationActive=false;game.Save();game.Hud.OpenPanel("Restoran");
                typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game,lastEvent);
            }
            steps=null;original=null;SessionState.SetBool(Pending,false);
        }
        static Progress Fixture()
        {
            return new Progress{coins=2000,xp=900,tables=2,grill=2,cook=1,tutorialDone=true};
        }
        static void Check(bool good,string message)
        {File.AppendAllText(Report,(good?"PASS: ":"FAIL: ")+message+"\n");if(!good)throw new Exception(message);}
        static Button Find(string name){return UnityEngine.Object.FindObjectsByType<Button>(FindObjectsSortMode.None).First(b=>b.name==name&&b.gameObject.activeInHierarchy);}
        static Vector2 Center(RectTransform rt){return RectTransformUtility.WorldToScreenPoint(null,rt.TransformPoint(rt.rect.center));}
        static void Touch(Vector2 p,UnityEngine.InputSystem.TouchPhase phase)
        {InputSystem.QueueStateEvent(touch,new TouchState{touchId=1,position=p,phase=phase});}
        static bool Until(Func<bool> condition,int limit=1000)
        {
            game.Sim.Paused=false;
            for(int i=0;i<limit&&!condition();i++){if(game.Sim.Actors[0].job=="")game.Sim.Command("next");game.Sim.Tick(.1f);}
            game.Sim.Paused=true;return condition();
        }
        static bool WaitOnly(Func<bool> condition,int limit=2000)
        {
            game.Sim.Paused=false;
            for(int i=0;i<limit&&!condition();i++)game.Sim.Tick(.1f);
            game.Sim.Paused=true;return condition();
        }
        static IEnumerator<float> Run()
        {
            BurgerEmpireMobileChecks.SetSize(2340,1080);yield return .7f;
            if(game.LayoutEditor.Active)game.Hud.FinishLayout(false);
            if(game.Hud.BlocksWorldInput)game.Hud.ClosePanel();
            var p=new Progress{coins=2200,xp=1400,tutorialDone=true,served=40,tables=4,grill=3,cashier=2,cook=2,waiter=2,cleaner=2,decor=1,cheese=1,blender=2,fryer=2,doubleBurger=1,driveThru=2,delivery=2};
            SetSimulation(new Simulation(p));yield return .3f;
            var world=GameObject.Find("Restaurant Environment").transform;
            Check(world.Find("Restaurant polish/Crowned brand/Brand artwork").GetComponent<SpriteRenderer>().sprite!=null,"Generated transparent brand artwork loads on restaurant sign");
            Check(Vector3.Dot(world.Find("Restaurant polish/Crowned brand/Brand artwork").forward,Vector3.back)>.99f,"World logo faces the same readable direction as restaurant lettering");
            var signTop=game.GameCamera.WorldToScreenPoint(new Vector3(5,4.7f,.1f));
            Check(game.GameCamera.pixelRect.Contains(signTop),"Raised brand sign fits completely below phone header");
            Check(GameObject.Find("Burger Empire brand").GetComponent<RawImage>().texture!=null,"Phone header loads new wordmark without blocking touch");
            Check(!GameObject.Find("Burger Empire brand").GetComponent<RawImage>().raycastTarget,"Decorative brand does not intercept touch input");
            Check(world.Find("Restaurant polish/Illustrated menu 0/Menu burger")&&world.Find("Restaurant polish/Illustrated menu 1/Menu drink"),"Raised menu panels show burger and drink models above the kitchen");
            Check(world.Find("Restaurant polish/Illustrated menu 0/Menu price").GetComponent<TextMesh>().text.Contains("32"),"Illustrated menu uses current Istanbul price");
            Check(UnityEngine.Object.FindObjectsByType<Light>(FindObjectsSortMode.None).Count(l=>l.type==LightType.Directional)==1,"Visual polish reuses scene sun without adding extra realtime lights");
            Check(world.Find("Table_0/Table sauces")&&world.Find("Table_3/Table sauces"),"Every table receives condiments without changing its saved placement");
            var stage=RestaurantArt.Group("Motion validation",null,new Vector3(50,0,0));
            try {
                var chef=RestaurantArt.BuildPerson("cook",0,stage);
                chef.UpdatePosition(50,0,1,false,false,"cook",Vector3.forward);
                Check(chef.rightArm.Find("Spatula").gameObject.activeSelf&&chef.motion.State=="cook","Cooking pose equips spatula");
                var arm=chef.rightArm.localRotation;chef.UpdatePosition(50,0,1.2f,false,false,"cook",Vector3.forward);
                Check(Quaternion.Angle(arm,chef.rightArm.localRotation)>2,"Stationary cooking pose moves the spatula arm over simulation time");
                arm=chef.rightArm.localRotation;var frozen=chef.root.position;var face=chef.root.rotation;
                chef.UpdatePosition(50,0,1.2f,false,false,"cook",Vector3.forward);
                Check(chef.rightArm.localRotation==arm&&chef.root.position==frozen&&chef.root.rotation==face,"Paused simulation freezes arms, idle breathing and facing exactly");
                chef.UpdatePosition(50.15f,0,1.3f,false,false,"cook");
                Check(chef.motion.State=="walk"&&!chef.rightArm.Find("Spatula").gameObject.activeSelf,"Walking suspends cooking tool and uses stride pose");
                chef.UpdatePosition(50.15f,0,1.4f,true);
                Check(chef.food.gameObject.activeSelf&&!chef.rightArm.Find("Spatula").gameObject.activeSelf,"Carrying tray suppresses work tools");
                chef.UpdatePosition(50.15f,0,1.6f,true,false,"packing",Vector3.forward);
                Check(!chef.food.gameObject.activeSelf&&chef.motion.State=="packing","Packing pose frees both hands over counter");
                var cleaner=RestaurantArt.BuildPerson("cleaner",1,stage);cleaner.UpdatePosition(51.2f,0,2,false,false,"clean",Vector3.forward);
                arm=cleaner.rightArm.localRotation;cleaner.UpdatePosition(51.2f,0,2.2f,false,false,"clean",Vector3.forward);
                Check(cleaner.rightArm.Find("Cleaning cloth").gameObject.activeSelf&&Quaternion.Angle(arm,cleaner.rightArm.localRotation)>2,"Cleaner wipes with visible cloth and moving arm");
                cleaner.UpdatePosition(51.2f,0,2.3f,false);
                Check(!cleaner.rightArm.Find("Cleaning cloth").gameObject.activeSelf,"Finishing cleaning hides cloth");
                var cashier=RestaurantArt.BuildPerson("cashier",2,stage);cashier.UpdatePosition(52.4f,0,2,false,false,"order",Vector3.forward);
                Check(cashier.leftArm.Find("Order pad").gameObject.activeSelf,"Order-taking pose shows notepad");
                var diner=RestaurantArt.BuildPerson("customer",0,stage);diner.UpdatePosition(53.6f,0,2,false,true,"eating");arm=diner.rightArm.localRotation;
                diner.UpdatePosition(53.6f,0,2.2f,false,true,"eating");
                Check(Quaternion.Angle(arm,diner.rightArm.localRotation)>2&&diner.motion.State=="eating","Seated diner lifts hand to eat");
                diner.UpdatePosition(53.6f,0,2.4f,false,true,"payment");
                Check(diner.motion.State=="payment"&&Quaternion.Angle(diner.rightArm.localRotation,Quaternion.identity)>80,"Diner visibly raises hand when payment is ready");
                var thirty=RestaurantArt.BuildPerson("player",0,stage);var sixty=RestaurantArt.BuildPerson("player",0,stage);
                thirty.UpdatePosition(55,0,0,false);sixty.UpdatePosition(55,1.5f,0,false);
                for(int i=1;i<=30;i++)thirty.UpdatePosition(55+i/30f,0,i/30f,false);
                for(int i=1;i<=60;i++)sixty.UpdatePosition(55+i/60f,1.5f,i/60f,false);
                Check(Quaternion.Angle(thirty.leftLeg.localRotation,sixty.leftLeg.localRotation)<.1f,"Walking stride follows distance consistently at 30 and 60 updates per second");
                CaptureCharacters(stage);
            } finally {UnityEngine.Object.Destroy(stage.gameObject);}
            Check(WaitOnly(()=>game.Sim.P.deliveryServed>=1&&game.Sim.P.driveServed>=1&&game.Sim.P.served>45,5000),"Restyled staff complete real salon, vehicle and courier orders together");yield return .3f;
            Check(WaitOnly(()=>game.Sim.Customers.Any(c=>c.station=="grill"&&c.order=="cooking")),"Real order enters grill cooking stage");yield return .3f;
            Check(world.Find("Grill_0/Grill heat").gameObject.activeInHierarchy,"Grill warmth appears during actual cooking");
            var living=game.transform.Find("Living Restaurant");var chefVisual=living.Find("cook");
            Check(chefVisual.Find("Right arm/Spatula")&&chefVisual.Find("Eye glint"),"Runtime staff use new face and animation rig");
            var joints=living.GetComponentsInChildren<Transform>().Select(t=>t.localRotation).ToArray();var time=game.Sim.Time;yield return .3f;
            Check(game.Sim.Time==time&&living.GetComponentsInChildren<Transform>().Select(t=>t.localRotation).SequenceEqual(joints),"Paused live restaurant leaves all character joints unchanged across rendered frames");
            typeof(RestaurantHud).GetField("toastTime",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game.Hud,0f);yield return .1f;
            ScreenCapture.CaptureScreenshot(Path.GetFullPath("BurgerEmpire-0.9-Restaurant.png"));yield return .3f;
            game.Hud.OpenPanel("Restoran");yield return .2f;
            var target=Center(Find("KURYE TESLİMATI").GetComponent<RectTransform>());
            Touch(target,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;Touch(target,UnityEngine.InputSystem.TouchPhase.Ended);yield return .25f;
            Check(Find("Buy delivery")!=null,"Decorative UI shadows preserve courier navigation touches");
            game.Hud.ClosePanel();game.Sim.Paused=true;game.Hud.BeginLayout();yield return .2f;
            Check(world.Find("Restaurant polish").gameObject.activeInHierarchy&&!living.gameObject.activeInHierarchy,"Layout preview preserves fixed decorative art and hides people");
            game.Hud.FinishLayout(false);game.Sim.Paused=true;
            Check(game.Sim.OpenLondon(out _),"London branch remains available with art upgrade");yield return .3f;
            Check(world.Find("Restaurant polish/Illustrated menu 0/Menu price").GetComponent<TextMesh>().text.Contains("35"),"Illustrated menu updates its price for London");
            game.Sim.SwitchBranch(0,out _);yield return .2f;
            BurgerEmpireMobileChecks.SetSize(1280,720);yield return .5f;CheckBounds("1280x720");
            BurgerEmpireMobileChecks.SetSize(1080,2340);yield return .5f;CheckBounds("1080x2340");
            var logoRect=GameObject.Find("Burger Empire brand").GetComponent<RectTransform>();
            Check(logoRect.rect.height<76&&!logoRect.GetComponent<RawImage>().raycastTarget,"New wordmark fits portrait header and remains non-interactive");
            typeof(RestaurantHud).GetField("toastTime",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game.Hud,0f);yield return .1f;
            ScreenCapture.CaptureScreenshot(Path.GetFullPath("BurgerEmpire-0.9-Portrait.png"));yield return .3f;
            BurgerEmpireMobileChecks.SetSize(2340,1080);yield return .5f;
            game.Save();Check(File.ReadAllText("BurgerEmpireSave.json")==disk,"Art validation does not overwrite player save");
            File.AppendAllText(Report,"Completed. In-editor visuals and touch tested; physical Android performance not measured.\n");
        }
        static void CaptureCharacters(Transform stage)
        {
            var gallery=RestaurantArt.Group("Character gallery",stage,Vector3.zero);
            foreach(Transform child in stage)if(child!=gallery)child.gameObject.SetActive(false);
            var roles=new[]{"player","cashier","cook","waiter","cleaner","manager"};
            var labels=new[]{"KURUCU","KASİYER","AŞÇI","GARSON","TEMİZLİK","MÜDÜR"};
            for(int i=0;i<roles.Length;i++) {
                var p=RestaurantArt.BuildPerson(roles[i],i,gallery);
                p.UpdatePosition(48+i*1.25f,8,3,i==3,false,i==1?"order":i==2?"cook":i==4?"clean":"",Vector3.forward);
                RestaurantArt.Text("Role label",labels[i],gallery,new Vector3(-2+i*1.25f,.05f,8.2f),.09f,RestaurantArt.Brown);
            }
            var cam=new GameObject("Gallery camera").AddComponent<Camera>();
            cam.orthographic=true;cam.orthographicSize=1.7f;cam.transform.position=new Vector3(51.15f,2.8f,18);cam.transform.LookAt(new Vector3(51.15f,1.0f,8));cam.clearFlags=CameraClearFlags.SolidColor;cam.backgroundColor=RestaurantArt.Cream;
            var target=new RenderTexture(1500,650,24);cam.targetTexture=target;
            var old=RenderTexture.active;Texture2D image=null;
            try {cam.Render();RenderTexture.active=target;image=new Texture2D(1500,650,TextureFormat.RGB24,false);image.ReadPixels(new Rect(0,0,1500,650),0,0);image.Apply();File.WriteAllBytes("BurgerEmpire-0.9-Characters.png",image.EncodeToPNG());}
            finally {RenderTexture.active=old;cam.targetTexture=null;target.Release();UnityEngine.Object.Destroy(target);UnityEngine.Object.Destroy(cam.gameObject);if(image)UnityEngine.Object.Destroy(image);}
        }

        static void CheckBounds(string label)
        {
            var safe=Screen.safeArea;var corners=new Vector3[4];
            foreach(var button in UnityEngine.Object.FindObjectsByType<Button>(FindObjectsSortMode.None).Where(b=>b.gameObject.activeInHierarchy)) {
                var rt=button.GetComponent<RectTransform>();rt.GetWorldCorners(corners);
                // Only visible controls; clipped scrolling cards are intentionally outside the viewport.
                if(corners[2].y<safe.yMin||corners[0].y>safe.yMax)continue;
                Check(rt.rect.height>=48&&corners[0].x>=safe.xMin-1&&corners[2].x<=safe.xMax+1,label+": "+button.name+" touch size and horizontal bounds");
            }
        }
    }
}
#endif
