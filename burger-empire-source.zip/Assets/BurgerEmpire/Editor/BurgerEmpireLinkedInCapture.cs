#if UNITY_EDITOR && ENABLE_INPUT_SYSTEM
using System;
using System.Collections;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using BurgerEmpire.Core;
using BurgerEmpire.Unity;
using UnityEditor;
using UnityEngine;
using Progress=BurgerEmpire.Core.Progress;

namespace BurgerEmpire.Editor
{
    [InitializeOnLoad]
    public static class BurgerEmpireLinkedInCapture
    {
        const string Request="BurgerEmpireLinkedInCapture.request",Report="BurgerEmpireLinkedInCapture.txt";
        const BindingFlags Private=BindingFlags.Instance|BindingFlags.NonPublic;
        [Serializable] sealed class Settings {public string output,encoder;}
        static Settings settings;
        static BurgerEmpireGame game;
        static Simulation original;
        static string language,preferenceKey,preference,mainSave,profileSave,profilePath;
        static bool active,hadPreference,runInBackground,validation;
        static int lastEvent,captureRate,frames;
        static float audioVolume;
        static Texture2D frame;
        static byte[] pixels;
        static System.Diagnostics.Process encoder;
        static readonly StringBuilder encoderLog=new StringBuilder();
        static IEnumerator steps;
        static BurgerEmpireLinkedInCapture()
        {
            EditorApplication.update+=Update;
            EditorApplication.playModeStateChanged+=s=>{if(s==PlayModeStateChange.ExitingPlayMode&&active){Log("Interrupted by leaving Play mode.");Finish();}};
        }
        static void Log(string value)=>File.AppendAllText(Report,value+"\n");
        static void Update()
        {
            if(active||EditorApplication.isCompiling||EditorApplication.isUpdating||!File.Exists(Request))return;
            if(!EditorApplication.isPlaying){BurgerEmpireSetup.Play();return;}
            game=UnityEngine.Object.FindFirstObjectByType<BurgerEmpireGame>();if(!game||!game.Hud)return;
            try {
                settings=JsonUtility.FromJson<Settings>(File.ReadAllText(Request));File.Delete(Request);File.WriteAllText(Report,"");
                if(!Path.IsPathRooted(settings.output)||!File.Exists(settings.encoder))throw new InvalidOperationException("Invalid capture paths.");
                Directory.CreateDirectory(settings.output);
                original=game.Sim;mainSave=File.ReadAllText("BurgerEmpireSave.json");
                profilePath=(string)typeof(BurgerEmpireGame).GetField("savePath",Private).GetValue(game);
                profileSave=File.Exists(profilePath)?File.ReadAllText(profilePath):null;
                language=Localization.Language;preferenceKey=EditorPlaytestSession.PreferenceKey("BurgerEmpire.Language");
                hadPreference=PlayerPrefs.HasKey(preferenceKey);preference=PlayerPrefs.GetString(preferenceKey);
                lastEvent=(int)typeof(BurgerEmpireGame).GetField("lastEvent",Private).GetValue(game);
                runInBackground=Application.runInBackground;captureRate=Time.captureFramerate;audioVolume=AudioListener.volume;validation=game.ValidationActive;
                active=true;game.ValidationActive=true;Application.runInBackground=true;Time.captureFramerate=30;AudioListener.volume=0;
                frames=0;steps=Record();game.StartCoroutine(SafeRun());
            }catch(Exception error){Log("FAIL: "+error);Finish();}
        }
        static IEnumerator SafeRun()
        {
            while(active) {
                object current=null;bool more=false;
                try{more=steps.MoveNext();if(more)current=steps.Current;}
                catch(Exception error){Log("FAIL: "+error);Finish();yield break;}
                if(!more){Finish();yield break;}
                yield return current;
            }
        }
        static void SetSimulation(Simulation value)
        {
            typeof(BurgerEmpireGame).GetProperty("Sim").SetValue(game,value);
            typeof(BurgerEmpireGame).GetField("lastEvent",Private).SetValue(game,value.Events.Count>0?value.Events.Last().id:0);
            typeof(RestaurantHud).GetField("toastTime",Private).SetValue(game.Hud,0f);
        }
        static Simulation Stage(bool channels,bool london=false)
        {
            var p=new Progress{tutorialDone=true,coins=4800,xp=1200,served=60,cooked=75,mission=5,tables=4,grill=3,fryer=2,blender=1,
                cheese=1,doubleBurger=1,chickenBurger=1,bbqBurger=1,chocolateShake=1,cashier=2,cook=2,waiter=2,cleaner=2,manager=1,decor=1,driveThru=channels?1:0,delivery=channels?1:0};
            if(london) {
                p.istanbul=p.Copy();p.londonOpen=true;p.activeBranch=1;
                p.layout=RestaurantLayout.Default();p.layout.floor=2;p.layout.wall=1;p.layout.furniture=1;
            }
            var s=new Simulation(p,39);
            s.Paused=false;
            for(int i=0;i<2200;i++) {
                if(s.Actors[0].job=="")s.Command("next");s.Tick(.1f);
                if(s.Time>45&&s.Customers.Count(c=>!c.drive&&!c.delivery)>=4&&(!channels||s.DriveQueue>0&&s.DeliveryQueue>0))break;
            }
            s.Paused=true;return s;
        }
        static IEnumerator Record()
        {
            BurgerEmpireMobileChecks.SetSize(1920,1080);game.SetLanguage("tr");game.Hud.StartGame();
            for(int i=0;i<6;i++)yield return new WaitForEndOfFrame();
            if(Screen.width!=1920||Screen.height!=1080)throw new Exception("Game View did not reach 1920x1080.");
            frame=new Texture2D(1920,1080,TextureFormat.RGB24,false);pixels=new byte[1920*1080*3];
            string video=Path.Combine(settings.output,"Gameplay-raw.mp4");
            var start=new System.Diagnostics.ProcessStartInfo(settings.encoder,
                "-y -hide_banner -loglevel warning -f rawvideo -pixel_format rgb24 -video_size 1920x1080 -framerate 30 -i pipe:0 -an -vf vflip -c:v libx264 -preset ultrafast -crf 17 -pix_fmt yuv420p -movflags +faststart \""+video+"\"")
                {UseShellExecute=false,CreateNoWindow=true,WindowStyle=System.Diagnostics.ProcessWindowStyle.Hidden,RedirectStandardInput=true,RedirectStandardError=true};
            encoderLog.Clear();encoder=new System.Diagnostics.Process{StartInfo=start};encoder.ErrorDataReceived+=(s,e)=>{if(e.Data!=null)lock(encoderLog)encoderLog.AppendLine(e.Data);};
            encoder.Start();encoder.BeginErrorReadLine();WriteMusic();
            string[] names={"Restoran","Personel","Menu","Servis","Londra","Vardiya","Final"};
            int[] lengths={360,150,150,300,150,150,120};
            for(int shot=0;shot<names.Length;shot++) {
                game.Sim.Paused=true;if(game.Hud.BlocksWorldInput)game.Hud.ClosePanel();
                if(shot==0||shot==3||shot==4||shot==5||shot==6)SetSimulation(Stage(shot==3,shot==4));
                game.Sim.Paused=true;
                for(int i=0;i<4;i++)yield return new WaitForEndOfFrame();
                game.CameraControls.Reset();game.CameraControls.ZoomStep(shot==3?1.10f:1.30f);
                if(shot==1)game.Hud.OpenPanel("Personel");
                else if(shot==2)game.Hud.OpenPanel("Menü");
                else if(shot==5)game.Hud.OpenPanel("Hedef Vardiya");
                else game.Sim.Paused=false;
                for(int i=0;i<3;i++)yield return new WaitForEndOfFrame();
                Log("SHOT "+names[shot]+" starts at frame "+frames);
                for(int n=0;n<lengths[shot];n++) {
                    if(!game.Hud.BlocksWorldInput&&game.Sim.Actors[0].job=="")game.Sim.Command("next");
                    yield return new WaitForEndOfFrame();
                    frame.ReadPixels(new Rect(0,0,1920,1080),0,0,false);frame.GetRawTextureData<byte>().CopyTo(pixels);
                    encoder.StandardInput.BaseStream.Write(pixels,0,pixels.Length);frames++;
                    if(n==60)File.WriteAllBytes(Path.Combine(settings.output,(shot+1).ToString("00")+"-"+names[shot]+".png"),frame.EncodeToPNG());
                    if(frames%120==0)Log("FRAME "+frames+" / 1380");
                }
            }
            encoder.StandardInput.Close();if(!encoder.WaitForExit(30000))throw new Exception("Encoder did not finish.");
            if(encoder.ExitCode!=0)throw new Exception("Encoder failed: "+encoderLog);
            encoder.Dispose();encoder=null;File.WriteAllText(Path.Combine(settings.output,"Encoder-log.txt"),encoderLog.ToString());
            if(File.ReadAllText("BurgerEmpireSave.json")!=mainSave)throw new Exception("Real save changed during capture.");
            if(profileSave!=null&&File.ReadAllText(profilePath)!=profileSave)throw new Exception("Selected playtest save changed during capture.");
            Log("PASS: 1380 rendered game frames recorded at 1920x1080, 30 fps (46 seconds).");
            Log("PASS: Normal and selected playtest saves unchanged; demonstration simulation only.");
            Log("Completed. Actual Unity gameplay with staged unlocked demo progression. No physical Android recording or publication.");
        }
        static void WriteMusic()
        {
            var samples=MusicDesign.Samples();int bytes=samples.Length*2;
            using(var w=new BinaryWriter(File.Create(Path.Combine(settings.output,"Original-game-music.wav")))) {
                w.Write(Encoding.ASCII.GetBytes("RIFF"));w.Write(36+bytes);w.Write(Encoding.ASCII.GetBytes("WAVEfmt "));w.Write(16);w.Write((short)1);w.Write((short)1);
                w.Write(MusicDesign.SampleRate);w.Write(MusicDesign.SampleRate*2);w.Write((short)2);w.Write((short)16);w.Write(Encoding.ASCII.GetBytes("data"));w.Write(bytes);
                foreach(float sample in samples)w.Write((short)(Mathf.Clamp(sample,-1,1)*32767));
            }
        }
        static void Finish()
        {
            if(!active)return;active=false;
            if(encoder!=null){try{encoder.StandardInput.Close();if(!encoder.WaitForExit(10000))encoder.Kill();}catch{}encoder.Dispose();encoder=null;}
            if(frame)UnityEngine.Object.Destroy(frame);frame=null;pixels=null;
            Time.captureFramerate=captureRate;Application.runInBackground=runInBackground;AudioListener.volume=audioVolume;
            if(game&&original!=null) {
                SetSimulation(original);original.Paused=true;game.SetLanguage(language);
                if(hadPreference)PlayerPrefs.SetString(preferenceKey,preference);else PlayerPrefs.DeleteKey(preferenceKey);PlayerPrefs.Save();
                game.ValidationActive=validation;game.Hud.OpenMainMenu();typeof(BurgerEmpireGame).GetField("lastEvent",Private).SetValue(game,lastEvent);
            }
            original=null;steps=null;
        }
    }
}
#endif
