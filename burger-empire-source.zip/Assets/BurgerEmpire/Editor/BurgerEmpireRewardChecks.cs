#if UNITY_EDITOR && ENABLE_INPUT_SYSTEM
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using BurgerEmpire.Core;
using BurgerEmpire.Unity;
using UnityEditor;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.LowLevel;
using UnityEngine.UI;
using Progress=BurgerEmpire.Core.Progress;

namespace BurgerEmpire.Editor
{
    [InitializeOnLoad]
    public static class BurgerEmpireRewardChecks
    {
        const string Pending="BurgerEmpire.RewardChecks",Report="BurgerEmpireRewardChecks.txt";
        static IEnumerator<float> steps;
        static double next;
        static int nextFrame;
        static BurgerEmpireGame game;
        static Simulation original;
        static string disk,originalLanguage;
        static bool hadLanguage;
        static string originalPath;
        static RewardedAdsTest originalReward;
        static ProgressStore originalStore;
        static SessionMeasurements originalSession;
        static int lastEvent;
        static Touchscreen touch;
        static InputSettings.BackgroundBehavior background;
        static InputSettings.EditorInputBehaviorInPlayMode routing;
        static BurgerEmpireRewardChecks(){EditorApplication.update+=Update;}
        static void Update()
        {
            if(EditorApplication.isCompiling||EditorApplication.isUpdating)return;
            if(File.Exists("BurgerEmpireRewardChecks.request")) {
                try {File.Delete("BurgerEmpireRewardChecks.request");} catch(IOException){return;}
                File.WriteAllText(Report,"");SessionState.SetBool(Pending,true);nextFrame=0;
                if(!EditorApplication.isPlaying){BurgerEmpireSetup.Play();return;}
            }
            if(!EditorApplication.isPlaying||!SessionState.GetBool(Pending,false)||EditorApplication.timeSinceStartup<next||Time.frameCount<nextFrame)return;
            try {
                if(steps==null) {
                    game=UnityEngine.Object.FindFirstObjectByType<BurgerEmpireGame>();if(!game||game.Sim==null)return;
                    originalLanguage=Localization.Language;hadLanguage=PlayerPrefs.HasKey("BurgerEmpire.Language");original=game.Sim;disk=File.ReadAllText("BurgerEmpireSave.json");game.ValidationActive=true;
                    originalPath=CurrentPath;originalStore=(ProgressStore)typeof(BurgerEmpireGame).GetField("progressStore",Private).GetValue(game);originalSession=game.Session;
                    originalReward=game.RewardTest;typeof(BurgerEmpireGame).GetProperty("RewardTest").SetValue(game,new RewardedAdsTest());
                    lastEvent=(int)typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).GetValue(game);
                    background=InputSystem.settings.backgroundBehavior;InputSystem.settings.backgroundBehavior=InputSettings.BackgroundBehavior.IgnoreFocus;
                    routing=InputSystem.settings.editorInputBehaviorInPlayMode;InputSystem.settings.editorInputBehaviorInPlayMode=InputSettings.EditorInputBehaviorInPlayMode.AllDeviceInputAlwaysGoesToGameView;
                    touch=InputSystem.AddDevice<Touchscreen>();steps=Run();
                }
                if(steps.MoveNext()){next=EditorApplication.timeSinceStartup+steps.Current;nextFrame=Time.frameCount+3;}else Finish();
            } catch(Exception e){File.AppendAllText(Report,"FAIL: "+e+"\n");Finish();}
        }
        static void SetSimulation(Simulation value)
        {
            typeof(BurgerEmpireGame).GetProperty("Sim").SetValue(game,value);
            typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game,0);
            typeof(RestaurantHud).GetField("toastTime",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game.Hud,0f);
        }
        static void Finish()
        {
            if(touch!=null){InputSystem.RemoveDevice(touch);touch=null;}InputSystem.settings.backgroundBehavior=background;InputSystem.settings.editorInputBehaviorInPlayMode=routing;
            if(game&&original!=null) {
                if(game.LayoutEditor.Active)game.Hud.FinishLayout(false);
                game.SetLanguage(originalLanguage);if(!hadLanguage){PlayerPrefs.DeleteKey("BurgerEmpire.Language");PlayerPrefs.Save();}
                typeof(BurgerEmpireGame).GetField("savePath",Private).SetValue(game,originalPath);
                typeof(BurgerEmpireGame).GetField("progressStore",Private).SetValue(game,originalStore);
                typeof(BurgerEmpireGame).GetProperty("Session").SetValue(game,originalSession);
                game.RewardTest.Dispose();typeof(BurgerEmpireGame).GetProperty("RewardTest").SetValue(game,originalReward);
                SetSimulation(original);original.Paused=true;game.ValidationActive=false;game.Save();game.Hud.OpenMainMenu();
                typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game,lastEvent);
            }
            steps=null;original=null;nextFrame=0;SessionState.SetBool(Pending,false);
        }
        static Progress Fixture()
        {
            var p=JsonUtility.FromJson<Progress>(JsonUtility.ToJson(original.P));
            p.coins=3000;p.xp=700;p.grill=2;p.fryer=1;p.blender=0;p.doubleBurger=0;p.cheese=1;p.mission=5;p.tutorialDone=true;
            p.shakeSold=p.doubleSold=0;p.activeBranch=0;p.chickenBurger=p.bbqBurger=p.chocolateShake=0;return p;
        }
        static void Check(bool good,string message)
        {File.AppendAllText(Report,(good?"PASS: ":"FAIL: ")+message+"\n");if(!good)throw new Exception(message);}
        static Button Find(string name){return UnityEngine.Object.FindObjectsByType<Button>(FindObjectsSortMode.None).First(b=>b.name==name&&b.gameObject.activeInHierarchy);}
        static Vector2 Center(RectTransform rt){return RectTransformUtility.WorldToScreenPoint(null,rt.TransformPoint(rt.rect.center));}
        static void Touch(Vector2 p,UnityEngine.InputSystem.TouchPhase phase)
        {InputSystem.QueueStateEvent(touch,new TouchState{touchId=1,position=p,phase=phase});}
        static bool Until(Func<bool> condition,int limit=1000)
        {
            game.Sim.Paused=false;
            for(int i=0;i<limit&&!condition();i++){if(game.Sim.Actors[0].job=="")game.Sim.Command("next");game.Sim.Tick(.1f);}
            game.Sim.Paused=true;return condition();
        }


        const System.Reflection.BindingFlags Private=System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic;
        static string CurrentPath=>(string)typeof(BurgerEmpireGame).GetField("savePath",Private).GetValue(game);
        static string Tab=>(string)typeof(RestaurantHud).GetField("tab",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).GetValue(game.Hud);
        static bool HasText(string value)=>UnityEngine.Object.FindObjectsByType<Text>(FindObjectsSortMode.None).Any(t=>t.gameObject.activeInHierarchy&&t.text.Contains(value));
        static IEnumerator<float> Tap(string name)
        {
            var button=Find(name);var list=button.GetComponentInParent<ScrollRect>();
            if(list) {
                var rt=button.GetComponent<RectTransform>();
                float offset=-list.content.InverseTransformPoint(rt.TransformPoint(rt.rect.center)).y-list.viewport.rect.height*.5f;
                list.content.anchoredPosition=new Vector2(0,Mathf.Clamp(offset,0,list.content.rect.height-list.viewport.rect.height));
                list.StopMovement();Canvas.ForceUpdateCanvases();yield return .15f;
            }
            var point=Center(Find(name).GetComponent<RectTransform>());
            Touch(point,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;
            Touch(point,UnityEngine.InputSystem.TouchPhase.Ended);yield return .2f;
        }


        static IEnumerator<float> Run()
        {
            SetSimulation(new Simulation(Fixture()));game.Sim.Paused=true;
            string before=JsonUtility.ToJson(game.Sim.P);var test=game.RewardTest;
            BurgerEmpireMobileChecks.SetSize(2340,1080);game.SetLanguage("tr");game.Hud.OpenMainMenu();yield return .4f;
            Check(test.Coins==0&&test.Flow.State==RewardedAdState.Ready,"Editor starts without an ad or a reward");
            foreach(var wait in Enumerate(Tap("Home settings")))yield return wait;
            foreach(var wait in Enumerate(Tap("Settings rewards")))yield return wait;
            Check(Tab=="Reklam Testi"&&game.Sim.Paused&&HasText("GERÇEK REKLAM DEĞİL"),"Touch opens the clearly labeled editor-only test and pauses the shift");
            Check(HasText("+100 deneme coin")&&test.Coins==0,"Reward amount is visible before opt-in, without changing the wallet");
            CheckPage("Turkish ready landscape");
            foreach(var wait in Enumerate(Tap("Reward start")))yield return wait;
            Check(test.Flow.Busy&&test.Coins==0&&!test.Flow.Begin(),"Opt-in opens manual viewing; a duplicate start is rejected");
            float frozen=game.Sim.Time;yield return .3f;
            Check(game.Sim.Time==frozen&&game.Hud.BlocksWorldInput,"Customers and world input stay paused during viewing");
            CheckPage("Turkish showing landscape");ScreenCapture.CaptureScreenshot("BurgerEmpire-0.27-Reward-Test.png");yield return .2f;
            foreach(var wait in Enumerate(Tap("Reward complete")))yield return wait;
            Check(test.Coins==100&&test.Flow.State==RewardedAdState.Rewarded&&HasText("+100 deneme coin eklendi"),"Real completion button awards exactly 100 test coins");
            test.Complete();test.Complete();yield return .15f;
            Check(test.Coins==100,"Duplicate completion cannot award the same viewing again");
            foreach(var wait in Enumerate(Tap("Reward start")))yield return wait;
            foreach(var wait in Enumerate(Tap("Reward cancel")))yield return wait;
            Check(test.Flow.State==RewardedAdState.AwaitingReward&&test.Coins==100,"Early close waits for a possible completion without giving coins");
            yield return 2.2f;
            Check(test.Flow.State==RewardedAdState.Canceled&&test.Coins==100&&HasText("Ödül verilmedi"),"No completion ends as canceled with the original test balance");
            foreach(var wait in Enumerate(Tap("Reward start")))yield return wait;
            foreach(var wait in Enumerate(Tap("Reward fail")))yield return wait;
            Check(test.Flow.State==RewardedAdState.Failed&&test.Coins==100&&Find("Reward start").interactable,"Failure grants nothing and offers explicit retry");
            foreach(var wait in Enumerate(Tap("Reward availability")))yield return wait;
            Check(test.Flow.State==RewardedAdState.Unavailable&&!Find("Reward start").interactable,"Unavailable test ad disables the viewing button");
            foreach(var wait in Enumerate(Tap("Reward availability")))yield return wait;
            Check(test.Flow.State==RewardedAdState.Ready&&Find("Reward start").interactable,"Availability recovery updates status and enables viewing");
            foreach(var wait in Enumerate(Tap("Reward start")))yield return wait;
            game.Hud.Back();yield return .2f;test.Complete();
            Check(!test.Flow.Busy&&test.Coins==100&&Tab!="Reklam Testi","Back exits the test and rejects later completion");
            game.Hud.OpenPanel("Reklam Testi");yield return .2f;
            foreach(var wait in Enumerate(Tap("Reward start")))yield return wait;
            game.Suspend();yield return .2f;test.Complete();
            Check(!test.Flow.Busy&&test.Coins==100&&game.Sim.Paused,"Backgrounding cancels an unfinished test, keeps pause and gives no reward");
            foreach(var wait in Enumerate(Tap("Reward start")))yield return wait;
            test.Flow.Tick(RewardedAdFlow.ShowTimeout);yield return .25f;
            Check(test.Flow.State==RewardedAdState.TimedOut&&test.Coins==100&&Find("Reward start").interactable,"Missing response times out and releases the test without a reward");
            BurgerEmpireMobileChecks.SetSize(1080,2340);game.SetLanguage("en");yield return .4f;
            CheckPage("English timed-out portrait");
            foreach(var wait in Enumerate(Tap("Reward start")))yield return wait;
            CheckPage("English showing portrait");
            float amount=test.Coins;BurgerEmpireMobileChecks.SetSize(2340,1080);yield return .4f;
            Check(test.Flow.State==RewardedAdState.Showing&&test.Coins==amount,"Rotation keeps the same viewing and does not grant coins");
            CheckPage("English showing landscape");
            foreach(var wait in Enumerate(Tap("Reward complete")))yield return wait;
            BurgerEmpireMobileChecks.SetSize(1080,2340);yield return .4f;
            Check(test.Coins==200&&HasText("Completed: +100 test coins added."),"A separate successful viewing earns another 100 in English");
            CheckPage("English completed portrait");ScreenCapture.CaptureScreenshot("BurgerEmpire-0.27-Reward-Portrait.png");yield return .2f;
            foreach(var wait in Enumerate(Tap("Reward availability")))yield return wait;
            CheckPage("English unavailable portrait");
            foreach(var wait in Enumerate(Tap("Reward availability")))yield return wait;
            game.SetLanguage("tr");yield return .2f;CheckPage("Turkish ready portrait");
            Check(JsonUtility.ToJson(game.Sim.P)==before&&File.ReadAllText(originalPath)==disk,"Every ad scenario leaves restaurant progress and actual player save unchanged");
            using(var restarted=new RewardedAdsTest())Check(restarted.Coins==0&&!restarted.Flow.Busy,"A new Play-session test wallet starts at zero and replays no award");
            BurgerEmpireMobileChecks.SetSize(2340,1080);yield return .3f;
            File.AppendAllText(Report,"Completed. Offline editor mock only; no advertising SDK, network traffic, persisted reward or physical Android ad tested.\n");
        }

        static void CheckPage(string context)
        {
            var labels=UnityEngine.Object.FindObjectsByType<Text>(FindObjectsSortMode.None).Where(t=>t.gameObject.activeInHierarchy).ToArray();
            if(Localization.Language=="en") {
                var untranslated=labels.Where(t=>t.text!="Türkçe"&&System.Text.RegularExpressions.Regex.IsMatch(t.text,"[çğıöşüÇĞİÖŞÜ]")).Select(t=>t.text).ToArray();
                Check(untranslated.Length==0,context+": no untranslated Turkish text: "+string.Join(" | ",untranslated));
            }
            var overflow=labels.Where(t=>t.preferredHeight>t.rectTransform.rect.height+2).Select(t=>t.text+" ("+t.preferredHeight+"/"+t.rectTransform.rect.height+")").ToArray();
            Check(overflow.Length==0,context+": text height fits: "+string.Join(" | ",overflow));
            var buttons=UnityEngine.Object.FindObjectsByType<Button>(FindObjectsSortMode.None).Where(b=>b.gameObject.activeInHierarchy).ToArray();
            Check(buttons.All(b=>b.GetComponent<RectTransform>().rect.height>=48),context+": touch controls have at least 48 logical pixels");
        }
        static IEnumerable<float> Enumerate(IEnumerator<float> source){while(source.MoveNext())yield return source.Current;}
        static void CheckText()
        {
            var list=UnityEngine.Object.FindFirstObjectByType<ScrollRect>();
            var labels=list.content.GetComponentsInChildren<Text>().Where(t=>t.gameObject.activeInHierarchy).ToArray();
            Check(labels.All(t=>t.preferredHeight<=t.rectTransform.rect.height+1),"Guide text fits its allocated height at "+Screen.width+"x"+Screen.height);
        }
        static void CheckBounds(string label)
        {
            var safe=Screen.safeArea;var corners=new Vector3[4];
            foreach(var button in UnityEngine.Object.FindObjectsByType<Button>(FindObjectsSortMode.None).Where(b=>b.gameObject.activeInHierarchy)) {
                var rt=button.GetComponent<RectTransform>();rt.GetWorldCorners(corners);
                // Only visible controls; clipped scrolling cards are intentionally outside the viewport.
                if(corners[2].y<safe.yMin||corners[0].y>safe.yMax)continue;
                Check(rt.rect.height>=48&&corners[0].x>=safe.xMin-1&&corners[2].x<=safe.xMax+1,label+": "+button.name+" touch size and horizontal bounds");
            }
        }
    }
}
#endif

