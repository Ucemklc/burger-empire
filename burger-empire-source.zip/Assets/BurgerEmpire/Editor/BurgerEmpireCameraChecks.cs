#if UNITY_EDITOR && ENABLE_INPUT_SYSTEM
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using BurgerEmpire.Core;
using BurgerEmpire.Unity;
using UnityEditor;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.LowLevel;
using UnityEngine.UI;
using Progress=BurgerEmpire.Core.Progress;

namespace BurgerEmpire.Editor
{
    [InitializeOnLoad]
    public static class BurgerEmpireCameraChecks
    {
        const string Pending="BurgerEmpire.CameraChecks",Report="BurgerEmpireCameraChecks.txt";
        static IEnumerator<float> steps;
        static double next;
        static int nextFrame;
        static BurgerEmpireGame game;
        static Simulation original;
        static string disk;
        static int lastEvent;
        static Touchscreen touch;
        static Mouse mouse;
        static InputSettings.BackgroundBehavior background;
        static InputSettings.EditorInputBehaviorInPlayMode routing;
        static BurgerEmpireCameraChecks(){EditorApplication.update+=Update;}
        static void Update()
        {
            if(EditorApplication.isCompiling||EditorApplication.isUpdating)return;
            if(File.Exists("BurgerEmpireCameraChecks.request")) {
                try {File.Delete("BurgerEmpireCameraChecks.request");} catch(IOException){return;}
                File.WriteAllText(Report,"");SessionState.SetBool(Pending,true);nextFrame=0;
                if(!EditorApplication.isPlaying){BurgerEmpireSetup.Play();return;}
            }
            if(!EditorApplication.isPlaying||!SessionState.GetBool(Pending,false)||EditorApplication.timeSinceStartup<next||Time.frameCount<nextFrame)return;
            try {
                if(steps==null) {
                    game=UnityEngine.Object.FindFirstObjectByType<BurgerEmpireGame>();if(!game||game.Sim==null)return;
                    original=game.Sim;disk=File.ReadAllText("BurgerEmpireSave.json");game.ValidationActive=true;
                    lastEvent=(int)typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).GetValue(game);
                    background=InputSystem.settings.backgroundBehavior;InputSystem.settings.backgroundBehavior=InputSettings.BackgroundBehavior.IgnoreFocus;
                    // Route the synthetic touchscreen to the game even when another editor window has focus.
                    routing=InputSystem.settings.editorInputBehaviorInPlayMode;InputSystem.settings.editorInputBehaviorInPlayMode=InputSettings.EditorInputBehaviorInPlayMode.AllDeviceInputAlwaysGoesToGameView;
                    touch=InputSystem.AddDevice<Touchscreen>();mouse=InputSystem.AddDevice<Mouse>();steps=Run();
                }
                if(steps.MoveNext()){next=EditorApplication.timeSinceStartup+steps.Current;nextFrame=Time.frameCount+3;}else Finish();
            } catch(Exception e){File.AppendAllText(Report,"FAIL: "+e+"\n");Finish();}
        }
        static void SetSimulation(Simulation value)
        {
            typeof(BurgerEmpireGame).GetProperty("Sim").SetValue(game,value);
            typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game,0);
            typeof(RestaurantHud).GetField("toastTime",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game.Hud,0f);
        }
        static void Finish()
        {
            if(mouse!=null){InputSystem.RemoveDevice(mouse);mouse=null;}
            if(touch!=null){InputSystem.RemoveDevice(touch);touch=null;}InputSystem.settings.backgroundBehavior=background;InputSystem.settings.editorInputBehaviorInPlayMode=routing;
            if(game&&original!=null) {
                if(game.LayoutEditor.Active)game.Hud.FinishLayout(false);
                SetSimulation(original);original.Paused=true;game.ValidationActive=false;game.Save();game.Hud.OpenPanel("Restoran");
                typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game,lastEvent);
            }
            steps=null;original=null;nextFrame=0;SessionState.SetBool(Pending,false);
        }
        static Progress Fixture()
        {
            return new Progress{coins=2000,xp=900,tables=2,grill=2,cook=1,tutorialDone=true};
        }
        static void Check(bool good,string message)
        {File.AppendAllText(Report,(good?"PASS: ":"FAIL: ")+message+"\n");if(!good)throw new Exception(message);}
        static Button Find(string name){return UnityEngine.Object.FindObjectsByType<Button>(FindObjectsSortMode.None).First(b=>b.name==name&&b.gameObject.activeInHierarchy);}
        static Vector2 Center(RectTransform rt){return RectTransformUtility.WorldToScreenPoint(null,rt.TransformPoint(rt.rect.center));}
        static void Touch(Vector2 p,UnityEngine.InputSystem.TouchPhase phase)
        {InputSystem.QueueStateEvent(touch,new TouchState{touchId=1,position=p,phase=phase});}
        static bool Until(Func<bool> condition,int limit=1000)
        {
            game.Sim.Paused=false;
            for(int i=0;i<limit&&!condition();i++){if(game.Sim.Actors[0].job=="")game.Sim.Command("next");game.Sim.Tick(.1f);}
            game.Sim.Paused=true;return condition();
        }
        static bool WaitOnly(Func<bool> condition,int limit=2000)
        {
            game.Sim.Paused=false;
            for(int i=0;i<limit&&!condition();i++)game.Sim.Tick(.1f);
            game.Sim.Paused=true;return condition();
        }

        static void Finger(int id,Vector2 p,UnityEngine.InputSystem.TouchPhase phase)
        {InputSystem.QueueStateEvent(touch,new TouchState{touchId=id,position=p,phase=phase});}
        static Vector3 Ground(Vector2 p)
        {var ray=game.GameCamera.ScreenPointToRay(p);new Plane(Vector3.up,new Vector3(0,.25f,0)).Raycast(ray,out var d);return ray.GetPoint(d);}
        static void Pair(Vector2 p,Vector2 q,UnityEngine.InputSystem.TouchPhase phase)
        {Finger(1,p,phase);Finger(2,q,phase);}
        static void MouseAt(Vector2 p,Vector2 wheel, bool right=false)
        {InputSystem.QueueStateEvent(mouse,new MouseState{position=p,scroll=wheel,buttons=(ushort)(right?2:0)});}
        static void Bounds(string size)
        {
            var safe=Screen.safeArea;var points=new Vector3[4];
            foreach(string name in new[]{"Camera zoom in","Camera zoom out","Camera reset"}) {
                var rt=Find(name).GetComponent<RectTransform>();rt.GetWorldCorners(points);
                Check(rt.rect.width>=48&&rt.rect.height>=48&&points[0].x>=safe.xMin&&points[2].x<=safe.xMax&&points[0].y>=safe.yMin&&points[2].y<=safe.yMax,size+": "+name+" is reachable and at least 48 logical pixels");
            }
        }
        static IEnumerator<float> Run()
        {
            var began=UnityEngine.InputSystem.TouchPhase.Began;var moved=UnityEngine.InputSystem.TouchPhase.Moved;var ended=UnityEngine.InputSystem.TouchPhase.Ended;
            BurgerEmpireMobileChecks.SetSize(2340,1080);yield return .7f;
            if(game.Hud.BlocksWorldInput)game.Hud.ClosePanel();
            SetSimulation(new Simulation(new Progress{coins=2000,xp=1400,served=40,tutorialDone=true}));game.Sim.Paused=true;yield return .3f;
            var c=game.CameraControls;var cam=game.GameCamera;
            Check(c.Zoom==1&&c.Pan==Vector3.zero,"Opening restaurant starts at full view");Bounds("2340x1080");
            Vector3 defaultPosition=cam.transform.position;float defaultSize=cam.orthographicSize;
            var button=Center(Find("Camera zoom in").GetComponent<RectTransform>());
            Touch(button,began);yield return .12f;Touch(button,ended);yield return .25f;
            Check(Mathf.Abs(c.Zoom-1.25f)<.001f&&cam.orthographicSize<defaultSize,"Actual touch on plus button zooms in");
            button=Center(Find("Camera zoom out").GetComponent<RectTransform>());
            Touch(button,began);yield return .12f;Touch(button,ended);yield return .25f;
            Check(c.Zoom==1,"Actual touch on minus button returns to minimum zoom");
            Check(!Find("Camera zoom out").interactable,"Minus button disables at minimum zoom");
            game.Sim.Paused=false;Vector2 center=cam.pixelRect.center;
            Vector2 p=center+Vector2.left*120,q=center+Vector2.right*120;
            Check(!game.PointerOnUI(p)&&!game.PointerOnUI(q),"Gesture fixture begins in unobstructed restaurant area");
            Pair(p,q,began);yield return .15f;
            var anchor=Ground(center);
            p=center+Vector2.left*216;q=center+Vector2.right*216;
            Pair(p,q,moved);yield return .15f;
            Check(Mathf.Abs(c.Zoom-1.8f)<.03f,"Two real touch contacts spread to 1.8x zoom");
            Check(Vector3.Distance(anchor,Ground(center))<.02f,"Pinch holds the ground under the midpoint steady");
            Vector2 delta=new Vector2(90,50);p+=delta;q+=delta;Pair(p,q,moved);yield return .15f;
            Check(c.Pan.magnitude>.15f&&Vector3.Distance(anchor,Ground(center+delta))<.03f,"Moving both fingers pans with the ground following their midpoint");
            Finger(1,p,ended);yield return .15f;Finger(2,q,ended);yield return .25f;
            Check(game.Sim.Actors[0].job==""&&game.Sim.Actors[0].path.Count==0,"Releasing pinch fingers separately never creates a walk command");
            game.Sim.Paused=true;float t=game.Sim.Time;yield return .2f;
            Check(c.Zoom>1.7f&&game.Sim.Time==t,"Camera framing persists across visual updates while shift is paused");
            button=Center(Find("Camera reset").GetComponent<RectTransform>());
            Touch(button,began);yield return .12f;Touch(button,ended);yield return .2f;
            Check(c.Zoom==1&&c.Pan==Vector3.zero&&Vector3.Distance(cam.transform.position,defaultPosition)<.001f,"MERKEZ touch restores the exact initial camera pose");
            p=center+Vector2.left*80;q=center+Vector2.right*80;Pair(p,q,began);yield return .12f;
            Pair(center+Vector2.left*800,center+Vector2.right*800,moved);yield return .12f;
            Check(c.Zoom==RestaurantCamera.MaxZoom&&!Find("Camera zoom in").interactable,"Large pinch clamps at 2.5x and disables plus");
            Pair(center+Vector2.left*20,center+Vector2.right*20,moved);yield return .12f;
            Check(c.Zoom==1,"Shrinking pinch clamps at full restaurant view");
            Pair(center+Vector2.left*20,center+Vector2.right*20,ended);yield return .2f;
            // A UI-origin contact must not become a camera gesture after leaving its button.
            var ui=Center(Find("Camera reset").GetComponent<RectTransform>());
            Finger(1,ui,began);Finger(2,center,began);yield return .12f;
            Pair(center+Vector2.left*300,center+Vector2.right*300,moved);yield return .15f;
            Check(c.Zoom==1,"A touch starting on UI cannot become a pinch");
            Pair(center+Vector2.left*300,center+Vector2.right*300,ended);yield return .2f;
            c.Reset();yield return .12f;
            p=center+Vector2.left*110;q=center+Vector2.right*110;Pair(p,q,began);yield return .12f;
            Finger(3,center+Vector2.up*80,began);yield return .12f;
            Pair(center+Vector2.left*220,center+Vector2.right*220,moved);yield return .12f;
            Check(c.Zoom==1,"Third finger suspends camera without a jump");
            Finger(3,center+Vector2.up*80,ended);yield return .12f;
            Check(c.Zoom==1,"Returning to two fingers rebases the gesture");
            Pair(center+Vector2.left*220,center+Vector2.right*220,ended);yield return .2f;
            p=center+Vector2.left*100;q=center+Vector2.right*100;Pair(p,q,began);yield return .12f;
            Pair(center+Vector2.left*160,center+Vector2.right*160,moved);yield return .12f;
            float before=c.Zoom;game.Suspend();yield return .1f;
            Pair(center+Vector2.left*220,center+Vector2.right*220,moved);yield return .12f;
            Check(c.Zoom==before&&game.Sim.Paused,"Backgrounding cancels held fingers and pauses shift");
            Pair(p,q,ended);yield return .2f;
            game.Hud.OpenPanel("Personel");yield return .12f;
            Pair(p,q,began);yield return .12f;Pair(center+Vector2.left*240,center+Vector2.right*240,moved);yield return .12f;
            Check(c.Zoom==before,"Management panel blocks camera gesture");
            game.Hud.ClosePanel();yield return .12f;
            Pair(center+Vector2.left*260,center+Vector2.right*260,moved);yield return .12f;
            Check(c.Zoom==before,"Closing a panel does not reactivate already-held fingers");
            Pair(p,q,ended);yield return .3f;
            c.Reset();yield return .12f;
            MouseAt(center,Vector2.up*120);yield return .15f;MouseAt(center,Vector2.zero);yield return .15f;
            Check(c.Zoom>1.1f,"Mouse wheel over restaurant zooms in");
            var pan=c.Pan;MouseAt(center,Vector2.zero,true);yield return .12f;
            MouseAt(center+new Vector2(100,40),Vector2.zero,true);yield return .12f;
            Check(Vector3.Distance(c.Pan,pan)>.1f,"Right mouse drag pans restaurant");
            MouseAt(center+new Vector2(9000,9000),Vector2.zero,true);yield return .12f;
            Check(Mathf.Abs(c.Pan.x)<=4&&Mathf.Abs(c.Pan.z)<=4,"Extreme dragging keeps camera within restaurant bounds");
            MouseAt(center,Vector2.zero);yield return .12f;
            before=c.Zoom;MouseAt(ui,Vector2.up*120);yield return .12f;MouseAt(ui,Vector2.zero);yield return .12f;
            Check(c.Zoom==before,"Mouse wheel over UI does not zoom restaurant");
            game.Hud.BeginLayout();yield return .25f;
            Check(c.Zoom==1&&c.Pan==Vector3.zero,"Entering furniture edit restores full layout framing");
            Check(!UnityEngine.Object.FindObjectsByType<Button>(FindObjectsSortMode.None).Any(b=>b.name=="Camera zoom in"&&b.gameObject.activeInHierarchy),"Camera buttons are hidden while editing furniture");
            center=cam.pixelRect.center;p=center+Vector2.left*100;q=center+Vector2.right*100;
            Pair(p,q,began);yield return .12f;Pair(p+Vector2.left*80,q+Vector2.right*80,moved);yield return .12f;
            Check(c.Zoom==1&&c.Pan==Vector3.zero,"Layout editor retains exclusive camera framing");
            Pair(p,q,ended);yield return .12f;game.Hud.FinishLayout(false);yield return .3f;
            c.ZoomStep(2);yield return .1f;
            Check(game.Sim.OpenLondon(out _),"Camera fixture opens London");yield return .3f;
            Check(c.Zoom==1&&c.Pan==Vector3.zero,"Changing city resets view to new restaurant");
            game.Sim.SwitchBranch(0,out _);yield return .2f;
            // A single tap after all gestures must still route the player to the touched floor.
            SetSimulation(new Simulation(Fixture()));game.Sim.Paused=false;yield return .2f;
            var floor=(Vector2)cam.WorldToScreenPoint(new Vector3(7,.25f,7));
            Check(cam.pixelRect.Contains(floor)&&!game.PointerOnUI(floor),"Walking fixture is inside visible floor");
            Touch(floor,began);yield return .12f;Touch(floor,ended);yield return .15f;
            Check(game.Sim.Actors[0].job=="move"&&game.Sim.Actors[0].path.Count>0,"Single tap walking still works after camera gestures");
            game.Sim.Paused=true;
            var rich=new Progress{coins=2200,xp=1400,served=40,tutorialDone=true,tables=4,grill=3,cashier=1,cook=1,waiter=1,cleaner=1,decor=1,driveThru=2,delivery=2};
            SetSimulation(new Simulation(rich));yield return .3f;
            Check(cam.orthographicSize>=7.9f,"Camera reset includes unlocked vehicle and courier areas");
            game.Sim.Paused=false;for(int i=0;i<400;i++)game.Sim.Tick(.1f);game.Sim.Paused=true;yield return .3f;
            ScreenCapture.CaptureScreenshot(Path.GetFullPath("BurgerEmpire-0.10-Overview.png"));yield return .3f;
            c.ZoomStep(1.8f);yield return .25f;
            ScreenCapture.CaptureScreenshot(Path.GetFullPath("BurgerEmpire-0.10-Closeup.png"));yield return .3f;
            BurgerEmpireMobileChecks.SetSize(1280,720);yield return .5f;Bounds("1280x720");
            Check(c.Zoom==1&&c.Pan==Vector3.zero,"Screen-size change resets camera to fit restaurant");
            c.ZoomStep(1.8f);BurgerEmpireMobileChecks.SetSize(1080,2340);yield return .5f;Bounds("1080x2340");
            Check(c.Zoom==1,"Portrait change resets zoom and preserves safe framing");
            c.ZoomStep(1.6f);yield return .3f;
            ScreenCapture.CaptureScreenshot(Path.GetFullPath("BurgerEmpire-0.10-Portrait.png"));yield return .3f;
            BurgerEmpireMobileChecks.SetSize(2340,1080);yield return .5f;
            game.Save();Check(File.ReadAllText("BurgerEmpireSave.json")==disk,"Camera validation does not overwrite player save");
            File.AppendAllText(Report,"Completed. Editor multitouch events, mouse and phone layouts tested; physical Android not tested.\n");
        }
    }
}
#endif
