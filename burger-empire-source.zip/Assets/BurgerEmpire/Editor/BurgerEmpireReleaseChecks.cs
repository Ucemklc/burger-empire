#if UNITY_EDITOR
using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace BurgerEmpire.Editor
{
    [InitializeOnLoad]
    public static class BurgerEmpireReleaseChecks
    {
        const string Request="BurgerEmpireReleaseChecks.request",Report="BurgerEmpireReleaseChecks.txt";
        static BurgerEmpireReleaseChecks(){EditorApplication.update+=Update;}
        static void Update()
        {
            if(EditorApplication.isCompiling||EditorApplication.isUpdating||EditorApplication.isPlayingOrWillChangePlaymode||!File.Exists(Request))return;
            File.Delete(Request);File.WriteAllText(Report,"");
            try {Run();File.AppendAllText(Report,"Completed. Read-only release report and version/path protection verified. No player build.\n");}
            catch(Exception e){File.AppendAllText(Report,"FAIL: "+e+"\n");}
        }
        static void Check(bool good,string label)
        {File.AppendAllText(Report,(good?"PASS: ":"FAIL: ")+label+"\n");if(!good)throw new Exception(label);}
        static bool Reject(Action work){try{work();return false;}catch(ArgumentException){return true;}catch(InvalidOperationException){return true;}}
        static string State(ReleaseReport r,string id)=>r.items.Single(i=>i.id==id).state;
        static void Run()
        {
            byte[] settings=File.ReadAllBytes("ProjectSettings/ProjectSettings.asset"),save=File.ReadAllBytes("BurgerEmpireSave.json");
            string[] existingArtifacts=Directory.GetFiles(".","*.apk",SearchOption.TopDirectoryOnly).Concat(Directory.GetFiles(".","*.aab",SearchOption.TopDirectoryOnly)).OrderBy(x=>x).ToArray();
            var snapshot=BurgerEmpireRelease.Capture();
            string report=BurgerEmpireRelease.WriteReport();var saved=JsonUtility.FromJson<ReleaseReport>(File.ReadAllText("BurgerEmpireReleaseReport.json"));
            Check(report==saved.Text()&&saved.items.Count==15,"Text and JSON reports describe the same 15 release observations");
            Check(snapshot.version==PlayerSettings.bundleVersion&&snapshot.code==PlayerSettings.Android.bundleVersionCode,"Snapshot reads actual Unity version values");
            Check(snapshot.version==AndroidReleasePlan.Version&&snapshot.code==AndroidReleasePlan.VersionCode,"Prepared project uses the single release version and code");
            Check(snapshot.minApi==26&&snapshot.targetApi>=36&&snapshot.arm64&&snapshot.il2cpp,"Current Android target is API 36 or newer with ARM64 and IL2CPP");
            Check(State(saved,"device")=="BEKLİYOR"&&State(saved,"ads")=="BEKLİYOR"&&State(saved,"balance")=="ATLANDI","Unperformed device/ad work and skipped balance are never labeled complete");
            Check(!report.Contains("AndroidKeystoreName")&&!report.Contains("Password")&&!report.Contains("keyaliasPass"),"Report does not dump signing names or credentials");
            var bad=JsonUtility.FromJson<ReleaseSnapshot>(JsonUtility.ToJson(snapshot));bad.version="0.2.0";bad.code=2;bad.targetApi=35;bad.arm64=false;bad.sceneExists=false;bad.androidModule=false;
            var badReport=AndroidReleasePlan.Evaluate(bad);
            Check(new[]{"version","api","runtime","scene","module"}.All(id=>State(badReport,id)=="EKSİK"),"Old version, low API, wrong architecture, missing scene and module are flagged");
            bad.enabledScenes=new[]{AndroidReleasePlan.Scene,"Assets/Scenes/SampleScene.unity"};bad.package=AndroidReleasePlan.DefaultPackage;bad.customSigning=false;bad.hasIcon=false;bad.bundle=false;
            badReport=AndroidReleasePlan.Evaluate(bad);
            Check(new[]{"scene-list","package","signing","icon","bundle"}.All(id=>State(badReport,id)=="BEKLİYOR"),"Prototype package, sample scene, absent signing/icon and APK choice remain visible");
            bad.enabledScenes=new[]{AndroidReleasePlan.Scene};bad.package="com.example.finalgame";bad.customSigning=true;bad.hasIcon=true;bad.bundle=true;
            badReport=AndroidReleasePlan.Evaluate(bad);
            Check(State(badReport,"scene-list")=="OK"&&new[]{"package","signing","icon","bundle"}.All(id=>State(badReport,id)=="İNCELE"),"Configured publish fields still require review instead of a false readiness guarantee");
            AndroidReleasePlan.ValidateVersion("0.2.0",2);AndroidReleasePlan.ValidateVersion(AndroidReleasePlan.Version,AndroidReleasePlan.VersionCode);
            Check(Reject(()=>AndroidReleasePlan.ValidateVersion("99.0.0",AndroidReleasePlan.VersionCode))&&Reject(()=>AndroidReleasePlan.ValidateVersion(AndroidReleasePlan.Version,AndroidReleasePlan.VersionCode+1))&&Reject(()=>AndroidReleasePlan.ValidateVersion("99.0.0",1)),"Older tool rejects either a newer version name or a newer version code");
            Check(AndroidReleasePlan.PackageOrDefault("com.example.finalgame")=="com.example.finalgame"&&AndroidReleasePlan.PackageOrDefault("")==AndroidReleasePlan.DefaultPackage,"Chosen package is preserved; default is only used for an empty identifier");
            string path=Path.GetFullPath("Builds/"+AndroidReleasePlan.ApkName);
            Check(AndroidReleasePlan.ValidateApkPath(path)==path,"Local APK path supports spaces in the current project path");
            Check(new[]{"","relative.apk",Path.GetFullPath("bad.aab"),Path.GetFullPath("bad.txt")}.All(p=>Reject(()=>AndroidReleasePlan.ValidateApkPath(p))),"Empty, relative, AAB and wrong extension paths cannot enter the local APK pipeline");
            Check(settings.SequenceEqual(File.ReadAllBytes("ProjectSettings/ProjectSettings.asset"))&&save.SequenceEqual(File.ReadAllBytes("BurgerEmpireSave.json")),"Reporting and all fixtures preserve project settings and the real save byte-for-byte");
            var after=Directory.GetFiles(".","*.apk",SearchOption.TopDirectoryOnly).Concat(Directory.GetFiles(".","*.aab",SearchOption.TopDirectoryOnly)).OrderBy(x=>x).ToArray();
            Check(existingArtifacts.SequenceEqual(after)&&!File.Exists("BurgerEmpireAndroid.request")&&SessionState.GetString("BurgerEmpire.AndroidBuild","")=="","Checks neither request nor schedule a player build");
        }
    }
}
#endif
