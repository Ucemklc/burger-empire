#if UNITY_EDITOR && ENABLE_INPUT_SYSTEM
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using BurgerEmpire.Core;
using BurgerEmpire.Unity;
using UnityEditor;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.LowLevel;
using UnityEngine.UI;
using Progress=BurgerEmpire.Core.Progress;

namespace BurgerEmpire.Editor
{
    [InitializeOnLoad]
    public static class BurgerEmpireLanguageChecks
    {
        const string Pending="BurgerEmpire.LanguageChecks",Report="BurgerEmpireLanguageChecks.txt";
        static IEnumerator<float> steps;
        static double next;
        static int nextFrame;
        static BurgerEmpireGame game;
        static Simulation original;
        static string disk,originalLanguage;
        static bool hadLanguage;
        static int lastEvent;
        static Touchscreen touch;
        static InputSettings.BackgroundBehavior background;
        static InputSettings.EditorInputBehaviorInPlayMode routing;
        static BurgerEmpireLanguageChecks(){EditorApplication.update+=Update;}
        static void Update()
        {
            if(EditorApplication.isCompiling||EditorApplication.isUpdating)return;
            if(File.Exists("BurgerEmpireLanguageChecks.request")) {
                try {File.Delete("BurgerEmpireLanguageChecks.request");} catch(IOException){return;}
                File.WriteAllText(Report,"");SessionState.SetBool(Pending,true);nextFrame=0;
                if(!EditorApplication.isPlaying){BurgerEmpireSetup.Play();return;}
            }
            if(!EditorApplication.isPlaying||!SessionState.GetBool(Pending,false)||EditorApplication.timeSinceStartup<next||Time.frameCount<nextFrame)return;
            try {
                if(steps==null) {
                    game=UnityEngine.Object.FindFirstObjectByType<BurgerEmpireGame>();if(!game||game.Sim==null)return;
                    originalLanguage=Localization.Language;hadLanguage=PlayerPrefs.HasKey("BurgerEmpire.Language");original=game.Sim;disk=File.ReadAllText("BurgerEmpireSave.json");game.ValidationActive=true;
                    lastEvent=(int)typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).GetValue(game);
                    background=InputSystem.settings.backgroundBehavior;InputSystem.settings.backgroundBehavior=InputSettings.BackgroundBehavior.IgnoreFocus;
                    routing=InputSystem.settings.editorInputBehaviorInPlayMode;InputSystem.settings.editorInputBehaviorInPlayMode=InputSettings.EditorInputBehaviorInPlayMode.AllDeviceInputAlwaysGoesToGameView;
                    touch=InputSystem.AddDevice<Touchscreen>();steps=Run();
                }
                if(steps.MoveNext()){next=EditorApplication.timeSinceStartup+steps.Current;nextFrame=Time.frameCount+3;}else Finish();
            } catch(Exception e){File.AppendAllText(Report,"FAIL: "+e+"\n");Finish();}
        }
        static void SetSimulation(Simulation value)
        {
            typeof(BurgerEmpireGame).GetProperty("Sim").SetValue(game,value);
            typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game,0);
            typeof(RestaurantHud).GetField("toastTime",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game.Hud,0f);
        }
        static void Finish()
        {
            if(touch!=null){InputSystem.RemoveDevice(touch);touch=null;}InputSystem.settings.backgroundBehavior=background;InputSystem.settings.editorInputBehaviorInPlayMode=routing;
            if(game&&original!=null) {
                if(game.LayoutEditor.Active)game.Hud.FinishLayout(false);
                game.SetLanguage(originalLanguage);if(!hadLanguage){PlayerPrefs.DeleteKey("BurgerEmpire.Language");PlayerPrefs.Save();}
                SetSimulation(original);original.Paused=true;game.ValidationActive=false;game.Save();game.Hud.OpenMainMenu();
                typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game,lastEvent);
            }
            steps=null;original=null;nextFrame=0;SessionState.SetBool(Pending,false);
        }
        static Progress Fixture()
        {
            var p=JsonUtility.FromJson<Progress>(JsonUtility.ToJson(original.P));
            p.coins=3000;p.xp=700;p.grill=2;p.fryer=1;p.blender=0;p.doubleBurger=0;p.cheese=1;p.mission=5;p.tutorialDone=true;
            p.shakeSold=p.doubleSold=0;p.activeBranch=0;p.chickenBurger=p.bbqBurger=p.chocolateShake=0;return p;
        }
        static void Check(bool good,string message)
        {File.AppendAllText(Report,(good?"PASS: ":"FAIL: ")+message+"\n");if(!good)throw new Exception(message);}
        static Button Find(string name){return UnityEngine.Object.FindObjectsByType<Button>(FindObjectsSortMode.None).First(b=>b.name==name&&b.gameObject.activeInHierarchy);}
        static Vector2 Center(RectTransform rt){return RectTransformUtility.WorldToScreenPoint(null,rt.TransformPoint(rt.rect.center));}
        static void Touch(Vector2 p,UnityEngine.InputSystem.TouchPhase phase)
        {InputSystem.QueueStateEvent(touch,new TouchState{touchId=1,position=p,phase=phase});}
        static bool Until(Func<bool> condition,int limit=1000)
        {
            game.Sim.Paused=false;
            for(int i=0;i<limit&&!condition();i++){if(game.Sim.Actors[0].job=="")game.Sim.Command("next");game.Sim.Tick(.1f);}
            game.Sim.Paused=true;return condition();
        }


        static string Tab=>(string)typeof(RestaurantHud).GetField("tab",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).GetValue(game.Hud);
        static bool HasText(string value)=>UnityEngine.Object.FindObjectsByType<Text>(FindObjectsSortMode.None).Any(t=>t.gameObject.activeInHierarchy&&t.text.Contains(value));
        static IEnumerator<float> Tap(string name)
        {
            var button=Find(name);var list=button.GetComponentInParent<ScrollRect>();
            if(list) {
                var rt=button.GetComponent<RectTransform>();
                float offset=-list.content.InverseTransformPoint(rt.TransformPoint(rt.rect.center)).y-list.viewport.rect.height*.5f;
                list.content.anchoredPosition=new Vector2(0,Mathf.Clamp(offset,0,list.content.rect.height-list.viewport.rect.height));
                list.StopMovement();Canvas.ForceUpdateCanvases();yield return .15f;
            }
            var point=Center(Find(name).GetComponent<RectTransform>());
            Touch(point,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;
            Touch(point,UnityEngine.InputSystem.TouchPhase.Ended);yield return .2f;
        }

        static IEnumerator<float> Run()
        {
            BurgerEmpireMobileChecks.SetSize(2340,1080);yield return .6f;
            if(game.LayoutEditor.Active)game.Hud.FinishLayout(false);
            if(game.Hud.BlocksWorldInput)game.Hud.ClosePanel();
            SetSimulation(new Simulation(new Progress()));game.SetLanguage("tr");game.Hud.OpenMainMenu();yield return .2f;
            Check(Tab=="Ana Menü"&&game.Sim.Paused&&Find("Home play").GetComponentInChildren<Text>().text=="OYUNA BAŞLA","Fresh main menu pauses the shift and offers Start playing");
            float time=game.Sim.Time;yield return .3f;game.Hud.Back();yield return .1f;
            Check(Tab=="Ana Menü"&&game.Sim.Paused&&game.Sim.Time==time,"Android back on home does not accidentally start the shift");
            foreach(var wait in Enumerate(Tap("Home settings")))yield return wait;
            foreach(var wait in Enumerate(Tap("Settings language")))yield return wait;
            Check(Tab=="Dil Seçimi"&&!Find("Language tr").interactable,"Settings exposes Turkish as the initial selected language");
            string before=JsonUtility.ToJson(game.Sim.P);
            foreach(var wait in Enumerate(Tap("Language en")))yield return wait;
            Check(Localization.Language=="en"&&PlayerPrefs.GetString("BurgerEmpire.Language")=="en"&&!Find("Language en").interactable,"Real touch selects and saves English");
            Check(HasText("Changing language keeps your progress.")&&JsonUtility.ToJson(game.Sim.P)==before&&game.Sim.Paused,"Language refresh translates current page without changing progression or pause");
            game.Hud.Back();yield return .15f;
            Check(Tab=="Ana Menü"&&Find("Home play").GetComponentInChildren<Text>().text=="START PLAYING","Back from home settings returns to translated main menu");
            CheckPage("English home landscape");ScreenCapture.CaptureScreenshot("BurgerEmpire-0.23-Home-English.png");yield return .3f;
            foreach(var wait in Enumerate(Tap("Home help")))yield return wait;
            Check(HasText("First burger. First step.")&&HasText("Tap the floor to walk."),"First-time instructions are translated before starting");
            game.Hud.Back();yield return .1f;
            foreach(var wait in Enumerate(Tap("Home play")))yield return wait;
            Check(!game.Hud.BlocksWorldInput&&!game.Sim.Paused&&HasText("Take order")&&HasText("FIRST SHIFT"),"English Start begins the tutorial with localized HUD");
            game.Sim.Paused=true;
            SetSimulation(new Simulation(new Progress{tutorialDone=true,coins=5000,xp=900,cheese=1,cashier=1,cook=1,waiter=1,cleaner=1,served=31,londonOpen=true,london=new RestaurantProgress{tutorialDone=true}}));
            game.Sim.Paused=false;game.Hud.OpenMainMenu();yield return .2f;
            Check(Find("Home play").GetComponentInChildren<Text>().text=="CONTINUE"&&game.Sim.P.coins==5000,"Existing progress offers Continue without resetting money or staff");
            foreach(var wait in Enumerate(Tap("Home play")))yield return wait;
            Check(!game.Sim.Paused&&game.Sim.P.cashier==1,"Continue resumes the existing staffed restaurant");
            game.Hud.OpenPanel("Restoran");yield return .15f;
            foreach(var wait in Enumerate(Tap("Open main menu")))yield return wait;
            Check(Tab=="Ana Menü"&&game.Sim.Paused,"Restaurant action returns safely to main menu");
            foreach(var wait in Enumerate(Tap("Home settings")))yield return wait;
            foreach(var wait in Enumerate(Tap("Settings audio")))yield return wait;
            Check(HasText("The restaurant rhythm")&&HasText("BACK TO SETTINGS"),"Home sound screen uses English and returns to Settings");
            game.Hud.Back();yield return .1f;
            BurgerEmpireMobileChecks.SetSize(1080,2340);yield return .5f;
            Check(Tab=="Ana Menü"&&game.Sim.Paused&&HasText("CONTINUE"),"Portrait rotation preserves home and selected language");
            CheckPage("English home portrait");ScreenCapture.CaptureScreenshot("BurgerEmpire-0.23-Home-Portrait.png");yield return .3f;
            foreach(var wait in Enumerate(Tap("Home play")))yield return wait;
            game.Sim.Paused=true;
            foreach(var tab in new[]{"Restoran","Ayarlar","Dil Seçimi","Ses Ayarları","Yardım","Geliştir","Personel","Menü","Görevler","Başarımlar","Gelişim Rehberi","Şubeler","Arabaya servis","Kurye teslimatı","Servis önceliği","Müşteri yorumları","Popülerlik","VIP misafirler","Müşteriler","Kayıt ve Oturum","Reklam Testi"}) {
                game.Hud.OpenPanel(tab);yield return .15f;CheckPage("English portrait: "+tab);
            }
            game.Hud.OpenPanel("Ürün:chicken");yield return .15f;
            int coins=game.Sim.P.coins;
            foreach(var wait in Enumerate(Tap("Buy chicken")))yield return wait;
            Check(game.Sim.P.chickenBurger==1&&game.Sim.P.coins==coins-220,"Translated purchase button keeps the original command and exact cost");
            game.Hud.OpenPanel("Menü");yield return .1f;
            Check(HasText("Chicken Burger Meal")&&HasText("Available"),"Recipe state refresh remains translated after purchase");
            game.Hud.ClosePanel();game.Sim.Paused=true;
            game.Hud.BeginLayout();yield return .3f;CheckPage("English layout");game.Hud.FinishLayout(false);yield return .15f;
            Check(UnityEngine.Object.FindObjectsByType<TextMesh>(FindObjectsSortMode.None).Where(t=>t.gameObject.activeInHierarchy).All(t=>!System.Text.RegularExpressions.Regex.IsMatch(t.text,"[çğıöşüÇĞİÖŞÜ]")),"Visible restaurant signs translate along with UI");
            game.Hud.OpenPanel("Dil Seçimi");yield return .1f;
            before=JsonUtility.ToJson(game.Sim.P);
            foreach(var wait in Enumerate(Tap("Language tr")))yield return wait;
            Check(Localization.Language=="tr"&&HasText("Dil değişikliği")&&JsonUtility.ToJson(game.Sim.P)==before,"Switching back restores Turkish without changing purchased content");
            game.Hud.OpenPanel("Menü");yield return .1f;Check(HasText("Tavuk Burger Menü"),"Turkish recipe names return after language switch");
            game.Hud.OpenMainMenu();yield return .1f;
            BurgerEmpireMobileChecks.SetSize(1280,720);yield return .5f;CheckPage("Turkish home 1280x720");
            game.SetLanguage("en");yield return .15f;CheckPage("English home 1280x720");
            game.Suspend();game.Hud.Back();yield return .1f;Check(game.Sim.Paused&&Tab=="Ana Menü","Background and Back preserve paused home state");
            game.SetLanguage("tr");BurgerEmpireMobileChecks.SetSize(2340,1080);yield return .5f;
            ScreenCapture.CaptureScreenshot("BurgerEmpire-0.23-Home-Turkish.png");yield return .3f;
            game.Save();Check(File.ReadAllText("BurgerEmpireSave.json")==disk,"All language and main-menu scenarios preserve the actual saved restaurant");
            File.AppendAllText(Report,"Completed. Main menu, bilingual UI, touch, branch-safe progression and portrait/landscape verified. Physical Android device not tested.\n");
        }
        static void CheckPage(string context)
        {
            var labels=UnityEngine.Object.FindObjectsByType<Text>(FindObjectsSortMode.None).Where(t=>t.gameObject.activeInHierarchy).ToArray();
            if(Localization.Language=="en") {
                var untranslated=labels.Where(t=>t.text!="Türkçe"&&System.Text.RegularExpressions.Regex.IsMatch(t.text,"[çğıöşüÇĞİÖŞÜ]")).Select(t=>t.text).ToArray();
                Check(untranslated.Length==0,context+": no untranslated Turkish text: "+string.Join(" | ",untranslated));
            }
            var overflow=labels.Where(t=>t.preferredHeight>t.rectTransform.rect.height+2).Select(t=>t.text+" ("+t.preferredHeight+"/"+t.rectTransform.rect.height+")").ToArray();
            Check(overflow.Length==0,context+": text height fits: "+string.Join(" | ",overflow));
            var buttons=UnityEngine.Object.FindObjectsByType<Button>(FindObjectsSortMode.None).Where(b=>b.gameObject.activeInHierarchy).ToArray();
            Check(buttons.All(b=>b.GetComponent<RectTransform>().rect.height>=48),context+": touch controls have at least 48 logical pixels");
        }
        static IEnumerable<float> Enumerate(IEnumerator<float> source){while(source.MoveNext())yield return source.Current;}
        static void CheckText()
        {
            var list=UnityEngine.Object.FindFirstObjectByType<ScrollRect>();
            var labels=list.content.GetComponentsInChildren<Text>().Where(t=>t.gameObject.activeInHierarchy).ToArray();
            Check(labels.All(t=>t.preferredHeight<=t.rectTransform.rect.height+1),"Guide text fits its allocated height at "+Screen.width+"x"+Screen.height);
        }
        static void CheckBounds(string label)
        {
            var safe=Screen.safeArea;var corners=new Vector3[4];
            foreach(var button in UnityEngine.Object.FindObjectsByType<Button>(FindObjectsSortMode.None).Where(b=>b.gameObject.activeInHierarchy)) {
                var rt=button.GetComponent<RectTransform>();rt.GetWorldCorners(corners);
                // Only visible controls; clipped scrolling cards are intentionally outside the viewport.
                if(corners[2].y<safe.yMin||corners[0].y>safe.yMax)continue;
                Check(rt.rect.height>=48&&corners[0].x>=safe.xMin-1&&corners[2].x<=safe.xMax+1,label+": "+button.name+" touch size and horizontal bounds");
            }
        }
    }
}
#endif

