#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace BurgerEmpire.Editor
{
    public static class AndroidReleasePlan
    {
        public const string Version="0.31.0";
        public const int VersionCode=31,MinApi=26,TargetApi=36;
        public const string DefaultPackage="com.burgerempire.prototype";
        public const string Scene="Assets/BurgerEmpire/Scenes/BurgerEmpire.unity";
        public static string ApkName=>"BurgerEmpire-"+Version+".apk";
        public static void ValidateVersion(string currentVersion,int currentCode)
        {
            if(currentCode>VersionCode||System.Version.TryParse(currentVersion,out var version)&&version>System.Version.Parse(Version))
                throw new InvalidOperationException("Proje daha yeni bir sürüme ait. AndroidReleasePlan sürümünü güncelle; eski araçla düşürme yapma.");
        }
        public static string PackageOrDefault(string value)=>string.IsNullOrWhiteSpace(value)?DefaultPackage:value;
        public static string ValidateApkPath(string path)
        {
            if(string.IsNullOrWhiteSpace(path)||!Path.IsPathRooted(path)||!string.Equals(Path.GetExtension(path),".apk",StringComparison.OrdinalIgnoreCase))
                throw new ArgumentException("Yerel test için tam bir .apk dosya yolu seç.");
            return Path.GetFullPath(path);
        }
        public static ReleaseReport Evaluate(ReleaseSnapshot s)
        {
            var r=new ReleaseReport{version=Version,versionCode=VersionCode};
            r.Add(s.version==Version&&s.code==VersionCode?"OK":"EKSİK","version","Proje sürümü: "+s.version+" ("+s.code+"); hedef: "+Version+" ("+VersionCode+").");
            r.Add(s.minApi==MinApi&&s.targetApi>=TargetApi?"OK":"EKSİK","api","Minimum API "+s.minApi+"; hedef API "+s.targetApi+". Plan: minimum 26, hedef en az 36.");
            r.Add(s.arm64&&s.il2cpp?"OK":"EKSİK","runtime","ARM64: "+s.arm64+"; IL2CPP: "+s.il2cpp+".");
            r.Add(s.androidModule?"OK":"EKSİK","module","Unity Android modülü: "+s.androidModule+". SDK/NDK ve yerel derleme ayrıca doğrulanmalı.");
            r.Add(s.sceneExists?"OK":"EKSİK","scene","Restoran sahnesi: "+s.sceneExists+".");
            r.Add(s.enabledScenes.Length==1&&s.enabledScenes[0]==Scene?"OK":"BEKLİYOR","scene-list","Etkin genel sahne listesi: "+string.Join(", ",s.enabledScenes)+". Özel APK aracı yalnız restoran sahnesini kullanır.");
            r.Add(s.landscape?"OK":"EKSİK","orientation","İki yatay yön açık, dikey yön kapalı: "+s.landscape+".");
            r.Add(s.package==DefaultPackage||string.IsNullOrWhiteSpace(s.package)?"BEKLİYOR":"İNCELE","package","Paket adı: "+s.package+". Yayın kimliği mağazaya ilk yüklemeden önce kesinleştirilmeli; mevcut kimlik otomatik değiştirilmez.");
            r.Add(s.customSigning?"İNCELE":"BEKLİYOR","signing",s.customSigning?"Özel imza seçili. Anahtarın geçerliliği bu raporda denenmedi.":"Özel yayın imzası seçilmemiş. Mevcut yerel test ayarı korunuyor.");
            r.Add(s.hasIcon?"İNCELE":"BEKLİYOR","icon",s.hasIcon?"Özel ikon dokusu var; tüm ikon katmanları ve mağaza görseli ayrıca incelenmeli.":"Atanmış özel uygulama ikonu bulunamadı; mağaza ve cihaz ikonu hazırlanmalı.");
            r.Add(s.bundle?"İNCELE":"BEKLİYOR","bundle",s.bundle?"App Bundle seçili; bu rapor AAB oluşturmaz veya doğrulamaz.":"Yerel APK ayarı açık. Mağaza için imzalı AAB hazırlığı bekliyor.");
            r.Add("BEKLİYOR","ads","0.27 reklam altyapısı editör testidir. Gerçek sağlayıcı, kalıcı ödül ve Android doğrulaması bekliyor.");
            r.Add("BEKLİYOR","device","Fiziksel telefon, güncelleme ile kayıt koruma ve 16 KB yerel kütüphane/çalıştırma testleri yapılmadı.");
            r.Add("BEKLİYOR","listing","Mağaza metinleri taslak. Yayıncı/iletişim, gizlilik adresi, Veri Güvenliği, hedef kitle ve görseller tamamlanmalı.");
            r.Add("ATLANDI","balance","Denge ve performans kullanıcı isteğiyle atlandı; tamamlanmış sayılmaz.");
            return r;
        }
    }
    [Serializable] public sealed class ReleaseSnapshot
    {
        public string version,package;
        public int code,minApi,targetApi;
        public bool arm64,il2cpp,androidModule,sceneExists,landscape,customSigning,hasIcon,bundle;
        public string[] enabledScenes=Array.Empty<string>();
    }
    [Serializable] public sealed class ReleaseItem {public string state,id,detail;}
    [Serializable] public sealed class ReleaseReport
    {
        public string version;
        public int versionCode;
        public List<ReleaseItem> items=new List<ReleaseItem>();
        public void Add(string state,string id,string detail){items.Add(new ReleaseItem{state=state,id=id,detail=detail});}
        public string Text()=>"BURGER EMPIRE · ANDROID YAYIN HAZIRLIĞI\nKaynak sürümü "+version+" ("+versionCode+")\n"+
            "Bu rapor ayarları okur. APK/AAB oluşturmaz, telefona aktarmaz, mağazaya yüklemez.\n\n"+
            string.Join("\n\n",items.Select(i=>"["+i.state+"] "+i.id+" · "+i.detail))+"\n\nSonuç: yayın hazır onayı verilmedi; bekleyenler yukarıda listelenir.\n";
    }
}
#endif
