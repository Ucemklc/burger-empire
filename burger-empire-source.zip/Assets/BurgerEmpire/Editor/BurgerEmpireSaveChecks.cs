#if UNITY_EDITOR && ENABLE_INPUT_SYSTEM
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using BurgerEmpire.Core;
using BurgerEmpire.Unity;
using UnityEditor;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.LowLevel;
using UnityEngine.UI;
using Progress=BurgerEmpire.Core.Progress;

namespace BurgerEmpire.Editor
{
    [InitializeOnLoad]
    public static class BurgerEmpireSaveChecks
    {
        const string Pending="BurgerEmpire.SaveChecks",Report="BurgerEmpireSaveChecks.txt";
        static IEnumerator<float> steps;
        static double next;
        static int nextFrame;
        static BurgerEmpireGame game;
        static Simulation original;
        static string disk,originalLanguage;
        static bool hadLanguage;
        static string originalPath,testDirectory;
        static ProgressStore originalStore;
        static SessionMeasurements originalSession;
        static int lastEvent;
        static Touchscreen touch;
        static InputSettings.BackgroundBehavior background;
        static InputSettings.EditorInputBehaviorInPlayMode routing;
        static BurgerEmpireSaveChecks(){EditorApplication.update+=Update;}
        static void Update()
        {
            if(EditorApplication.isCompiling||EditorApplication.isUpdating)return;
            if(File.Exists("BurgerEmpireSaveChecks.request")) {
                try {File.Delete("BurgerEmpireSaveChecks.request");} catch(IOException){return;}
                File.WriteAllText(Report,"");SessionState.SetBool(Pending,true);nextFrame=0;
                if(!EditorApplication.isPlaying){BurgerEmpireSetup.Play();return;}
            }
            if(!EditorApplication.isPlaying||!SessionState.GetBool(Pending,false)||EditorApplication.timeSinceStartup<next||Time.frameCount<nextFrame)return;
            try {
                if(steps==null) {
                    game=UnityEngine.Object.FindFirstObjectByType<BurgerEmpireGame>();if(!game||game.Sim==null)return;
                    originalLanguage=Localization.Language;hadLanguage=PlayerPrefs.HasKey("BurgerEmpire.Language");original=game.Sim;disk=File.ReadAllText("BurgerEmpireSave.json");game.ValidationActive=true;
                    originalPath=CurrentPath;originalStore=(ProgressStore)typeof(BurgerEmpireGame).GetField("progressStore",Private).GetValue(game);originalSession=game.Session;
                    testDirectory=Path.GetFullPath(Path.Combine("Temp","BurgerEmpireSaveChecks-"+Guid.NewGuid().ToString("N")));Directory.CreateDirectory(testDirectory);
                    lastEvent=(int)typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).GetValue(game);
                    background=InputSystem.settings.backgroundBehavior;InputSystem.settings.backgroundBehavior=InputSettings.BackgroundBehavior.IgnoreFocus;
                    routing=InputSystem.settings.editorInputBehaviorInPlayMode;InputSystem.settings.editorInputBehaviorInPlayMode=InputSettings.EditorInputBehaviorInPlayMode.AllDeviceInputAlwaysGoesToGameView;
                    touch=InputSystem.AddDevice<Touchscreen>();steps=Run();
                }
                if(steps.MoveNext()){next=EditorApplication.timeSinceStartup+steps.Current;nextFrame=Time.frameCount+3;}else Finish();
            } catch(Exception e){File.AppendAllText(Report,"FAIL: "+e+"\n");Finish();}
        }
        static void SetSimulation(Simulation value)
        {
            typeof(BurgerEmpireGame).GetProperty("Sim").SetValue(game,value);
            typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game,0);
            typeof(RestaurantHud).GetField("toastTime",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game.Hud,0f);
        }
        static void Finish()
        {
            if(touch!=null){InputSystem.RemoveDevice(touch);touch=null;}InputSystem.settings.backgroundBehavior=background;InputSystem.settings.editorInputBehaviorInPlayMode=routing;
            if(game&&original!=null) {
                if(game.LayoutEditor.Active)game.Hud.FinishLayout(false);
                game.SetLanguage(originalLanguage);if(!hadLanguage){PlayerPrefs.DeleteKey("BurgerEmpire.Language");PlayerPrefs.Save();}
                typeof(BurgerEmpireGame).GetField("savePath",Private).SetValue(game,originalPath);
                typeof(BurgerEmpireGame).GetField("progressStore",Private).SetValue(game,originalStore);
                typeof(BurgerEmpireGame).GetProperty("Session").SetValue(game,originalSession);
                SetSimulation(original);original.Paused=true;game.ValidationActive=false;game.Save();game.Hud.OpenMainMenu();
                typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game,lastEvent);
            }
            steps=null;original=null;nextFrame=0;SessionState.SetBool(Pending,false);
        }
        static Progress Fixture()
        {
            var p=JsonUtility.FromJson<Progress>(JsonUtility.ToJson(original.P));
            p.coins=3000;p.xp=700;p.grill=2;p.fryer=1;p.blender=0;p.doubleBurger=0;p.cheese=1;p.mission=5;p.tutorialDone=true;
            p.shakeSold=p.doubleSold=0;p.activeBranch=0;p.chickenBurger=p.bbqBurger=p.chocolateShake=0;return p;
        }
        static void Check(bool good,string message)
        {File.AppendAllText(Report,(good?"PASS: ":"FAIL: ")+message+"\n");if(!good)throw new Exception(message);}
        static Button Find(string name){return UnityEngine.Object.FindObjectsByType<Button>(FindObjectsSortMode.None).First(b=>b.name==name&&b.gameObject.activeInHierarchy);}
        static Vector2 Center(RectTransform rt){return RectTransformUtility.WorldToScreenPoint(null,rt.TransformPoint(rt.rect.center));}
        static void Touch(Vector2 p,UnityEngine.InputSystem.TouchPhase phase)
        {InputSystem.QueueStateEvent(touch,new TouchState{touchId=1,position=p,phase=phase});}
        static bool Until(Func<bool> condition,int limit=1000)
        {
            game.Sim.Paused=false;
            for(int i=0;i<limit&&!condition();i++){if(game.Sim.Actors[0].job=="")game.Sim.Command("next");game.Sim.Tick(.1f);}
            game.Sim.Paused=true;return condition();
        }


        static string Tab=>(string)typeof(RestaurantHud).GetField("tab",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).GetValue(game.Hud);
        static bool HasText(string value)=>UnityEngine.Object.FindObjectsByType<Text>(FindObjectsSortMode.None).Any(t=>t.gameObject.activeInHierarchy&&t.text.Contains(value));
        static IEnumerator<float> Tap(string name)
        {
            var button=Find(name);var list=button.GetComponentInParent<ScrollRect>();
            if(list) {
                var rt=button.GetComponent<RectTransform>();
                float offset=-list.content.InverseTransformPoint(rt.TransformPoint(rt.rect.center)).y-list.viewport.rect.height*.5f;
                list.content.anchoredPosition=new Vector2(0,Mathf.Clamp(offset,0,list.content.rect.height-list.viewport.rect.height));
                list.StopMovement();Canvas.ForceUpdateCanvases();yield return .15f;
            }
            var point=Center(Find(name).GetComponent<RectTransform>());
            Touch(point,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;
            Touch(point,UnityEngine.InputSystem.TouchPhase.Ended);yield return .2f;
        }


        static IEnumerator<float> Run()
        {
            BurgerEmpireMobileChecks.SetSize(2340,1080);yield return .4f;game.SetLanguage("tr");
            var p=new Simulation(new Progress{tutorialDone=true,coins=5555,xp=800,served=31,cooked=36,cashier=1,cook=1,waiter=1,cleaner=1}).P;
            string valid=JsonUtility.ToJson(p,true);
            UseSave("backup","{truncated",valid);Check(game.Sim.P.coins==5555&&game.SaveRecovery=="backup"&&!game.SaveBlocked,"Actual Unity loader restores a corrupt main file from its backup");
            game.Hud.OpenMainMenu();yield return .2f;Check(HasText("son sağlam yedekten")&&Find("Home play").interactable,"Recovery is visible on home without blocking recovered progress");
            foreach(var wait in Enumerate(Tap("Home save")))yield return wait;
            Check(Tab=="Kayıt ve Oturum"&&game.Sim.Paused,"Touch opens save status without running the shift");
            game.ValidationActive=false;foreach(var wait in Enumerate(Tap("Retry save")))yield return wait;game.ValidationActive=true;
            Check(JsonUtility.FromJson<Progress>(File.ReadAllText(CurrentPath)).coins==5555&&File.ReadAllText(CurrentPath+".bak")==valid,"Touch commits recovered progress and retains the valid backup");
            Check(Directory.GetFiles(Path.GetDirectoryName(CurrentPath),"*.recovery-*.json").Length==1,"Original corrupt file is archived for later inspection");
            UseSave("blocked","{broken","{also broken");game.Hud.OpenMainMenu();yield return .2f;
            Check(game.SaveBlocked&&!Find("Home play").interactable&&HasText("Kayıt ve yedekleri açılamadı"),"Unreadable generations disable Continue and clearly explain protection");
            game.Hud.StartGame();game.Command("pause");game.ValidationActive=false;game.Save();game.ValidationActive=true;
            Check(game.Sim.Paused&&File.ReadAllText(CurrentPath)=="{broken"&&File.ReadAllText(CurrentPath+".bak")=="{also broken","Play commands and autosave cannot replace a blocked save");
            BurgerEmpireMobileChecks.SetSize(1080,2340);yield return .4f;CheckPage("Turkish blocked-save portrait");
            ScreenCapture.CaptureScreenshot("BurgerEmpire-0.26-Protected-Save.png");yield return .2f;
            game.SetLanguage("en");yield return .2f;CheckPage("English blocked-save portrait");
            Check(HasText("The save and backups could not be opened"),"Blocked-save explanation is available in English");
            File.WriteAllText(CurrentPath,valid);
            foreach(var wait in Enumerate(Tap("Retry save")))yield return wait;
            Check(!game.SaveBlocked&&game.Sim.P.coins==5555&&game.Sim.Paused,"Retry loads a repaired file without silently starting the shift");
            game.SetLanguage("tr");UseSave("future",valid.Replace("\"version\": "+BurgerEmpire.Core.Progress.CurrentVersion,"\"version\": 999"),valid);
            game.Hud.OpenMainMenu();yield return .2f;Check(game.SaveBlocked&&game.SaveState=="future"&&!Find("Home play").interactable,"Newer save versions are protected even with an older usable backup");
            UseSave("pending",null,null,valid);Check(game.Sim.P.coins==5555&&game.SaveRecovery=="pending","Interrupted first save can be recovered from the temporary file");
            game.ValidationActive=false;game.Save();game.ValidationActive=true;Check(File.Exists(CurrentPath)&&JsonUtility.FromJson<Progress>(File.ReadAllText(CurrentPath)).coins==5555,"Recovered temporary save commits through the game save path");
            UseSave("write-failure",valid);var faults=new WriteFailureFiles();var failing=new ProgressStore(CurrentPath,JsonUtility.FromJson<Progress>,value=>JsonUtility.ToJson(value,true),faults);failing.Load();
            typeof(BurgerEmpireGame).GetField("progressStore",Private).SetValue(game,failing);game.Sim.P.coins+=37;
            game.ValidationActive=false;game.Save();game.ValidationActive=true;game.Hud.OpenPanel("Kayıt ve Oturum");yield return .2f;
            Check(game.SaveState=="write-error"&&game.Sim.P.coins==5592&&File.ReadAllText(CurrentPath)==valid&&HasText("boş alanı kontrol et"),"Write error retains in-memory earnings and last good disk save with a useful message");
            faults.Fail=false;game.ValidationActive=false;foreach(var wait in Enumerate(Tap("Retry save")))yield return wait;game.ValidationActive=true;
            Check(game.SaveState=="saved"&&JsonUtility.FromJson<Progress>(File.ReadAllText(CurrentPath)).coins==5592,"Retry saves current earnings instead of reloading older progress");
            game.Hud.ClosePanel();game.Sim.Paused=false;game.ValidationActive=false;double started=game.Session.ActiveSeconds;yield return .5f;game.Sim.Paused=true;game.ValidationActive=true;
            Check(game.Session.ActiveSeconds>started,"Actual running Unity frames add active session time");
            double frozen=game.Session.ActiveSeconds;game.ValidationActive=false;yield return .3f;game.ValidationActive=true;
            Check(game.Session.ActiveSeconds==frozen,"Paused Unity frames do not add session time");
            game.Hud.OpenPanel("Kayıt ve Oturum");yield return .2f;CheckPage("Turkish save and session portrait");
            ScreenCapture.CaptureScreenshot("BurgerEmpire-0.26-Save-Session.png");yield return .2f;
            game.SetLanguage("en");yield return .2f;CheckPage("English save and session portrait");
            Check(HasText("Session counters reset")&&HasText("not sent anywhere"),"Session lifetime and local-only measurement are explained");
            BurgerEmpireMobileChecks.SetSize(1280,720);yield return .4f;CheckPage("English save and session landscape");
            game.SetLanguage("tr");BurgerEmpireMobileChecks.SetSize(2340,1080);yield return .3f;
            Check(File.ReadAllText(originalPath)==disk,"All corruption and interruption scenarios leave the real player save byte-for-byte unchanged");
            File.AppendAllText(Report,"Completed. Real Unity JSON, recovery, protected loading, retry, local session measurement and mobile UI verified. Physical Android file operations not tested.\n");
        }
        const System.Reflection.BindingFlags Private=System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic;
        static string CurrentPath=>(string)typeof(BurgerEmpireGame).GetField("savePath",Private).GetValue(game);
        static void UseSave(string name,string main,string backup=null,string pending=null)
        {
            string folder=Path.Combine(testDirectory,name);Directory.CreateDirectory(folder);string path=Path.Combine(folder,"save.json");
            if(main!=null)File.WriteAllText(path,main);if(backup!=null)File.WriteAllText(path+".bak",backup);if(pending!=null)File.WriteAllText(path+".tmp",pending);
            typeof(BurgerEmpireGame).GetField("savePath",Private).SetValue(game,path);
            typeof(BurgerEmpireGame).GetMethod("LoadProgress",Private).Invoke(game,null);
            typeof(BurgerEmpireGame).GetField("lastEvent",Private).SetValue(game,0);
        }
        sealed class WriteFailureFiles:SaveFiles
        {
            public bool Fail=true;
            public override void Write(string path,string text){if(Fail)throw new IOException("Simulated disk full");base.Write(path,text);}
        }

        static void CheckPage(string context)
        {
            var labels=UnityEngine.Object.FindObjectsByType<Text>(FindObjectsSortMode.None).Where(t=>t.gameObject.activeInHierarchy).ToArray();
            if(Localization.Language=="en") {
                var untranslated=labels.Where(t=>t.text!="Türkçe"&&System.Text.RegularExpressions.Regex.IsMatch(t.text,"[çğıöşüÇĞİÖŞÜ]")).Select(t=>t.text).ToArray();
                Check(untranslated.Length==0,context+": no untranslated Turkish text: "+string.Join(" | ",untranslated));
            }
            var overflow=labels.Where(t=>t.preferredHeight>t.rectTransform.rect.height+2).Select(t=>t.text+" ("+t.preferredHeight+"/"+t.rectTransform.rect.height+")").ToArray();
            Check(overflow.Length==0,context+": text height fits: "+string.Join(" | ",overflow));
            var buttons=UnityEngine.Object.FindObjectsByType<Button>(FindObjectsSortMode.None).Where(b=>b.gameObject.activeInHierarchy).ToArray();
            Check(buttons.All(b=>b.GetComponent<RectTransform>().rect.height>=48),context+": touch controls have at least 48 logical pixels");
        }
        static IEnumerable<float> Enumerate(IEnumerator<float> source){while(source.MoveNext())yield return source.Current;}
        static void CheckText()
        {
            var list=UnityEngine.Object.FindFirstObjectByType<ScrollRect>();
            var labels=list.content.GetComponentsInChildren<Text>().Where(t=>t.gameObject.activeInHierarchy).ToArray();
            Check(labels.All(t=>t.preferredHeight<=t.rectTransform.rect.height+1),"Guide text fits its allocated height at "+Screen.width+"x"+Screen.height);
        }
        static void CheckBounds(string label)
        {
            var safe=Screen.safeArea;var corners=new Vector3[4];
            foreach(var button in UnityEngine.Object.FindObjectsByType<Button>(FindObjectsSortMode.None).Where(b=>b.gameObject.activeInHierarchy)) {
                var rt=button.GetComponent<RectTransform>();rt.GetWorldCorners(corners);
                // Only visible controls; clipped scrolling cards are intentionally outside the viewport.
                if(corners[2].y<safe.yMin||corners[0].y>safe.yMax)continue;
                Check(rt.rect.height>=48&&corners[0].x>=safe.xMin-1&&corners[2].x<=safe.xMax+1,label+": "+button.name+" touch size and horizontal bounds");
            }
        }
    }
}
#endif

