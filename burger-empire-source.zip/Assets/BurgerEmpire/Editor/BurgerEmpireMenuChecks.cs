#if UNITY_EDITOR && ENABLE_INPUT_SYSTEM
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using BurgerEmpire.Core;
using BurgerEmpire.Unity;
using UnityEditor;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.LowLevel;
using UnityEngine.UI;
using Progress=BurgerEmpire.Core.Progress;

namespace BurgerEmpire.Editor
{
    [InitializeOnLoad]
    public static class BurgerEmpireMenuChecks
    {
        const string Pending="BurgerEmpire.MenuChecks",Report="BurgerEmpireMenuChecks.txt";
        static IEnumerator<float> steps;
        static double next;
        static int nextFrame;
        static BurgerEmpireGame game;
        static Simulation original;
        static string disk;
        static int lastEvent;
        static Touchscreen touch;
        static InputSettings.BackgroundBehavior background;
        static InputSettings.EditorInputBehaviorInPlayMode routing;
        static BurgerEmpireMenuChecks(){EditorApplication.update+=Update;}
        static void Update()
        {
            if(EditorApplication.isCompiling||EditorApplication.isUpdating)return;
            if(File.Exists("BurgerEmpireMenuChecks.request")) {
                try {File.Delete("BurgerEmpireMenuChecks.request");} catch(IOException){return;}
                File.WriteAllText(Report,"");SessionState.SetBool(Pending,true);nextFrame=0;
                if(!EditorApplication.isPlaying){BurgerEmpireSetup.Play();return;}
            }
            if(!EditorApplication.isPlaying||!SessionState.GetBool(Pending,false)||EditorApplication.timeSinceStartup<next||Time.frameCount<nextFrame)return;
            try {
                if(steps==null) {
                    game=UnityEngine.Object.FindFirstObjectByType<BurgerEmpireGame>();if(!game||game.Sim==null)return;
                    original=game.Sim;disk=File.ReadAllText("BurgerEmpireSave.json");game.ValidationActive=true;
                    lastEvent=(int)typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).GetValue(game);
                    background=InputSystem.settings.backgroundBehavior;InputSystem.settings.backgroundBehavior=InputSettings.BackgroundBehavior.IgnoreFocus;
                    routing=InputSystem.settings.editorInputBehaviorInPlayMode;InputSystem.settings.editorInputBehaviorInPlayMode=InputSettings.EditorInputBehaviorInPlayMode.AllDeviceInputAlwaysGoesToGameView;
                    touch=InputSystem.AddDevice<Touchscreen>();steps=Run();
                }
                if(steps.MoveNext()){next=EditorApplication.timeSinceStartup+steps.Current;nextFrame=Time.frameCount+3;}else Finish();
            } catch(Exception e){File.AppendAllText(Report,"FAIL: "+e+"\n");Finish();}
        }
        static void SetSimulation(Simulation value)
        {
            typeof(BurgerEmpireGame).GetProperty("Sim").SetValue(game,value);
            typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game,0);
            typeof(RestaurantHud).GetField("toastTime",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game.Hud,0f);
        }
        static void Finish()
        {
            if(touch!=null){InputSystem.RemoveDevice(touch);touch=null;}InputSystem.settings.backgroundBehavior=background;InputSystem.settings.editorInputBehaviorInPlayMode=routing;
            if(game&&original!=null) {
                if(game.LayoutEditor.Active)game.Hud.FinishLayout(false);
                SetSimulation(original);original.Paused=true;game.ValidationActive=false;game.Save();game.Hud.OpenPanel("Menü");
                typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game,lastEvent);
            }
            steps=null;original=null;nextFrame=0;SessionState.SetBool(Pending,false);
        }
        static Progress Fixture()
        {
            var p=JsonUtility.FromJson<Progress>(JsonUtility.ToJson(original.P));
            p.coins=3000;p.xp=700;p.grill=2;p.fryer=1;p.blender=0;p.doubleBurger=0;p.cheese=1;p.mission=5;p.tutorialDone=true;
            p.shakeSold=p.doubleSold=0;return p;
        }
        static void Check(bool good,string message)
        {File.AppendAllText(Report,(good?"PASS: ":"FAIL: ")+message+"\n");if(!good)throw new Exception(message);}
        static Button Find(string name){return UnityEngine.Object.FindObjectsByType<Button>(FindObjectsSortMode.None).First(b=>b.name==name&&b.gameObject.activeInHierarchy);}
        static Vector2 Center(RectTransform rt){return RectTransformUtility.WorldToScreenPoint(null,rt.TransformPoint(rt.rect.center));}
        static void Touch(Vector2 p,UnityEngine.InputSystem.TouchPhase phase)
        {InputSystem.QueueStateEvent(touch,new TouchState{touchId=1,position=p,phase=phase});}
        static bool Until(Func<bool> condition,int limit=1000)
        {
            game.Sim.Paused=false;
            for(int i=0;i<limit&&!condition();i++){if(game.Sim.Actors[0].job=="")game.Sim.Command("next");game.Sim.Tick(.1f);}
            game.Sim.Paused=true;return condition();
        }
        static IEnumerator<float> Run()
        {
            BurgerEmpireMobileChecks.SetSize(2340,1080);yield return .7f;
            if(game.LayoutEditor.Active)game.Hud.FinishLayout(false);
            if(game.Hud.BlocksWorldInput)game.Hud.ClosePanel();
            SetSimulation(new Simulation(Fixture()));game.Hud.OpenPanel("Menü");yield return .2f;
            Check(GameObject.Find("Recipe shake")&&GameObject.Find("Recipe double"),"Menu contains locked milkshake and double burger cards");
            game.Hud.OpenPanel("Ürün:shake");yield return .2f;
            var target=Center(Find("Buy blender").GetComponent<RectTransform>());
            Check(Find("Buy blender").interactable,"Eligible machine purchase is enabled");
            Touch(target,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;
            Touch(target,UnityEngine.InputSystem.TouchPhase.Ended);yield return .25f;
            Check(game.Sim.P.blender==1&&game.Sim.P.coins==2750,"Touch purchases the blender with the correct coin cost");
            var world=GameObject.Find("Restaurant Environment").transform;
            Check(world.Find("Milkshake station").gameObject.activeInHierarchy,"Purchased milkshake station appears in the kitchen");
            Check(!world.Find("Milkshake station/Mixer 1").gameObject.activeSelf,"First machine level shows one mixer");
            game.Hud.OpenPanel("Görevler");yield return .2f;
            var reward=UnityEngine.Object.FindObjectsByType<Button>(FindObjectsSortMode.None).First(b=>b.name=="ÖDÜLÜ AL"&&b.interactable&&b.transform.parent.GetComponentsInChildren<Text>().Any(t=>t.text=="Milkshake makinesi al"));
            target=Center(reward.GetComponent<RectTransform>());Touch(target,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;
            Touch(target,UnityEngine.InputSystem.TouchPhase.Ended);yield return .2f;
            Check(game.Sim.P.mission==6&&game.Sim.P.coins==2900,"Touch claims the new machine quest reward once");
            game.Hud.OpenPanel("Ürün:double");yield return .2f;
            target=Center(Find("Buy double").GetComponent<RectTransform>());Touch(target,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;
            Touch(target,UnityEngine.InputSystem.TouchPhase.Ended);yield return .2f;
            Check(game.Sim.P.doubleBurger==1&&game.Sim.P.coins==2580,"Touch unlocks the double burger recipe");
            game.Sim.Command("buy","blender");game.Sim.Command("buy","fryer");yield return .2f;
            Check(world.Find("Milkshake station/Mixer 1").gameObject.activeSelf&&world.Find("Fryer upgrade label").GetComponent<TextMesh>().text.Contains("2"),"Upgraded mixer and fryer have visible level feedback");
            game.Hud.OpenPanel("Menü");yield return .2f;
            var list=UnityEngine.Object.FindFirstObjectByType<ScrollRect>();
            Check(list.content.rect.height>list.viewport.rect.height,"Expanded menu scrolls within the mobile panel");
            var swipe=Center(list.viewport);
            Touch(swipe,UnityEngine.InputSystem.TouchPhase.Began);yield return .1f;
            Touch(swipe+Vector2.up*360,UnityEngine.InputSystem.TouchPhase.Moved);yield return .15f;
            Touch(swipe+Vector2.up*600,UnityEngine.InputSystem.TouchPhase.Moved);yield return .15f;
            Touch(swipe+Vector2.up*600,UnityEngine.InputSystem.TouchPhase.Ended);yield return .2f;
            Check(list.content.anchoredPosition.y>100,"Touch swipe reveals additional menu products");
            list.verticalNormalizedPosition=0;yield return .2f;
            Check(GameObject.Find("Recipe shake").GetComponentsInChildren<Text>().Any(t=>t.text.Contains("Menüde açık")),"Milkshake card shows unlocked state and preparation time");
            ScreenCapture.CaptureScreenshot(Path.GetFullPath("BurgerEmpire-0.5-Menu.png"));yield return .3f;
            game.Save();Check(File.ReadAllText("BurgerEmpireSave.json")==disk,"Editor test purchases never overwrite the player's saved progress");
            game.Hud.ClosePanel();game.Sim.Paused=true;
            foreach(string product in new[]{"shake","double"}) {
                var p=Fixture();p.blender=2;p.fryer=2;p.doubleBurger=1;
                var sim=new Simulation(p);var recipe=MenuCatalog.Get(product,p);
                var customer=new Customer{id=500,kind=0,phase="queue",product=product,station=recipe.station,meal=recipe.name,price=recipe.price,patience=1000,maxPatience=1000,x=9.1f,z=3.4f};
                sim.Customers.Add(customer);SetSimulation(sim);
                Check(Until(()=>sim.Actors.Any(a=>a.job=="serve"&&a.stage==1&&a.customer==500)),product+": actual job loop reaches carrying the prepared product");yield return .2f;
                var carrier=sim.Actors.First(a=>a.job=="serve"&&a.stage==1&&a.customer==500);
                string visual=product=="shake"?"Strawberry milkshake":"Double burger";
                var carried=game.transform.Find("Living Restaurant/"+carrier.role+"/Carried tray/"+visual);
                Check(carried&&carried.gameObject.activeInHierarchy,product+": server carries the correct 3D product");
                var orderBubbles=(Dictionary<int,RectTransform>)typeof(RestaurantHud).GetField("customerBubbles",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).GetValue(game.Hud);
                Check(orderBubbles[customer.id].GetComponentsInChildren<FoodIconGraphic>().Any(i=>i.Kind==product&&i.gameObject.activeInHierarchy),product+": order bubble displays the correct food illustration before handoff");
                Check(Until(()=>customer.phase=="eating"),product+": served customer begins eating or drinking");yield return .2f;
                var meal=world.Find("Table_"+customer.table+"/Meal");
                Check(meal.Find(visual).gameObject.activeInHierarchy&&!meal.Find("Burger").gameObject.activeSelf,product+": table displays the correct product instead of a classic burger");
                Check(!orderBubbles[customer.id].gameObject.activeSelf,product+": order bubble disappears after serving");
                typeof(RestaurantHud).GetField("toastTime",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game.Hud,0f);yield return .1f;
                ScreenCapture.CaptureScreenshot(Path.GetFullPath("BurgerEmpire-0.5-"+product+".png"));yield return .3f;
                Check(Until(()=>MenuCatalog.Sales(sim.P,product)>0),product+": payment records the sale and credits the wallet");
            }
            var low=Fixture();low.xp=0;low.blender=0;low.doubleBurger=0;SetSimulation(new Simulation(low));
            game.Hud.OpenPanel("Ürün:shake");yield return .2f;
            Check(!Find("Buy blender").interactable&&UnityEngine.Object.FindObjectsByType<Text>(FindObjectsSortMode.None).Any(t=>t.text=="Seviye 3 gerekiyor."),"Low-level UI explains the machine lock and prevents purchasing");
            BurgerEmpireMobileChecks.SetSize(1280,720);yield return .5f;CheckBounds("1280x720");
            BurgerEmpireMobileChecks.SetSize(1080,2340);yield return .5f;CheckBounds("1080x2340");
            game.Hud.OpenPanel("Menü");yield return .2f;list=UnityEngine.Object.FindFirstObjectByType<ScrollRect>();list.verticalNormalizedPosition=0;yield return .2f;
            ScreenCapture.CaptureScreenshot(Path.GetFullPath("BurgerEmpire-0.5-Menu-Portrait.png"));yield return .3f;
            BurgerEmpireMobileChecks.SetSize(2340,1080);yield return .5f;
            Check(File.ReadAllText("BurgerEmpireSave.json")==disk,"All synthetic menu scenarios finish without altering the player's save");
            File.AppendAllText(Report,"Completed. Unity Input System touch verified. Physical Android device not tested.\n");
        }
        static void CheckBounds(string label)
        {
            var safe=Screen.safeArea;var corners=new Vector3[4];
            foreach(var button in UnityEngine.Object.FindObjectsByType<Button>(FindObjectsSortMode.None).Where(b=>b.gameObject.activeInHierarchy)) {
                var rt=button.GetComponent<RectTransform>();rt.GetWorldCorners(corners);
                // Only visible controls; clipped scrolling cards are intentionally outside the viewport.
                if(corners[2].y<safe.yMin||corners[0].y>safe.yMax)continue;
                Check(rt.rect.height>=48&&corners[0].x>=safe.xMin-1&&corners[2].x<=safe.xMax+1,label+": "+button.name+" touch size and horizontal bounds");
            }
        }
    }
}
#endif
