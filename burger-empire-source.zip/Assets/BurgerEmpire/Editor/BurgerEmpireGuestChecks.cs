#if UNITY_EDITOR && ENABLE_INPUT_SYSTEM
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using BurgerEmpire.Core;
using BurgerEmpire.Unity;
using UnityEditor;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.LowLevel;
using UnityEngine.UI;
using Progress=BurgerEmpire.Core.Progress;

namespace BurgerEmpire.Editor
{
    [InitializeOnLoad]
    public static class BurgerEmpireGuestChecks
    {
        const string Pending="BurgerEmpire.GuestChecks",Report="BurgerEmpireGuestChecks.txt";
        static IEnumerator<float> steps;
        static double next;
        static int nextFrame;
        static BurgerEmpireGame game;
        static Simulation original;
        static string disk,originalLanguage;
        static bool hadLanguage;
        static int lastEvent;
        static Touchscreen touch;
        static InputSettings.BackgroundBehavior background;
        static InputSettings.EditorInputBehaviorInPlayMode routing;
        static BurgerEmpireGuestChecks(){EditorApplication.update+=Update;}
        static void Update()
        {
            if(EditorApplication.isCompiling||EditorApplication.isUpdating)return;
            if(File.Exists("BurgerEmpireGuestChecks.request")) {
                try {File.Delete("BurgerEmpireGuestChecks.request");} catch(IOException){return;}
                File.WriteAllText(Report,"");SessionState.SetBool(Pending,true);nextFrame=0;
                if(!EditorApplication.isPlaying){BurgerEmpireSetup.Play();return;}
            }
            if(!EditorApplication.isPlaying||!SessionState.GetBool(Pending,false)||EditorApplication.timeSinceStartup<next||Time.frameCount<nextFrame)return;
            try {
                if(steps==null) {
                    game=UnityEngine.Object.FindFirstObjectByType<BurgerEmpireGame>();if(!game||game.Sim==null)return;
                    originalLanguage=Localization.Language;hadLanguage=PlayerPrefs.HasKey("BurgerEmpire.Language");original=game.Sim;disk=File.ReadAllText("BurgerEmpireSave.json");game.ValidationActive=true;
                    lastEvent=(int)typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).GetValue(game);
                    background=InputSystem.settings.backgroundBehavior;InputSystem.settings.backgroundBehavior=InputSettings.BackgroundBehavior.IgnoreFocus;
                    routing=InputSystem.settings.editorInputBehaviorInPlayMode;InputSystem.settings.editorInputBehaviorInPlayMode=InputSettings.EditorInputBehaviorInPlayMode.AllDeviceInputAlwaysGoesToGameView;
                    touch=InputSystem.AddDevice<Touchscreen>();steps=Run();
                }
                if(steps.MoveNext()){next=EditorApplication.timeSinceStartup+steps.Current;nextFrame=Time.frameCount+3;}else Finish();
            } catch(Exception e){File.AppendAllText(Report,"FAIL: "+e+"\n");Finish();}
        }
        static void SetSimulation(Simulation value)
        {
            typeof(BurgerEmpireGame).GetProperty("Sim").SetValue(game,value);
            typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game,0);
            typeof(RestaurantHud).GetField("toastTime",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game.Hud,0f);
        }
        static void Finish()
        {
            if(touch!=null){InputSystem.RemoveDevice(touch);touch=null;}InputSystem.settings.backgroundBehavior=background;InputSystem.settings.editorInputBehaviorInPlayMode=routing;
            if(game&&original!=null) {
                if(game.LayoutEditor.Active)game.Hud.FinishLayout(false);
                game.SetLanguage(originalLanguage);if(!hadLanguage){PlayerPrefs.DeleteKey("BurgerEmpire.Language");PlayerPrefs.Save();}
                SetSimulation(original);original.Paused=true;game.ValidationActive=false;game.Save();game.Hud.OpenMainMenu();
                typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game,lastEvent);
            }
            steps=null;original=null;nextFrame=0;SessionState.SetBool(Pending,false);
        }
        static Progress Fixture()
        {
            var p=JsonUtility.FromJson<Progress>(JsonUtility.ToJson(original.P));
            p.coins=3000;p.xp=700;p.grill=2;p.fryer=1;p.blender=0;p.doubleBurger=0;p.cheese=1;p.mission=5;p.tutorialDone=true;
            p.shakeSold=p.doubleSold=0;p.activeBranch=0;p.chickenBurger=p.bbqBurger=p.chocolateShake=0;return p;
        }
        static void Check(bool good,string message)
        {File.AppendAllText(Report,(good?"PASS: ":"FAIL: ")+message+"\n");if(!good)throw new Exception(message);}
        static Button Find(string name){return UnityEngine.Object.FindObjectsByType<Button>(FindObjectsSortMode.None).First(b=>b.name==name&&b.gameObject.activeInHierarchy);}
        static Vector2 Center(RectTransform rt){return RectTransformUtility.WorldToScreenPoint(null,rt.TransformPoint(rt.rect.center));}
        static void Touch(Vector2 p,UnityEngine.InputSystem.TouchPhase phase)
        {InputSystem.QueueStateEvent(touch,new TouchState{touchId=1,position=p,phase=phase});}
        static bool Until(Func<bool> condition,int limit=1000)
        {
            game.Sim.Paused=false;
            for(int i=0;i<limit&&!condition();i++){if(game.Sim.Actors[0].job=="")game.Sim.Command("next");game.Sim.Tick(.1f);}
            game.Sim.Paused=true;return condition();
        }


        static string Tab=>(string)typeof(RestaurantHud).GetField("tab",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).GetValue(game.Hud);
        static bool HasText(string value)=>UnityEngine.Object.FindObjectsByType<Text>(FindObjectsSortMode.None).Any(t=>t.gameObject.activeInHierarchy&&t.text.Contains(value));
        static IEnumerator<float> Tap(string name)
        {
            var button=Find(name);var list=button.GetComponentInParent<ScrollRect>();
            if(list) {
                var rt=button.GetComponent<RectTransform>();
                float offset=-list.content.InverseTransformPoint(rt.TransformPoint(rt.rect.center)).y-list.viewport.rect.height*.5f;
                list.content.anchoredPosition=new Vector2(0,Mathf.Clamp(offset,0,list.content.rect.height-list.viewport.rect.height));
                list.StopMovement();Canvas.ForceUpdateCanvases();yield return .15f;
            }
            var point=Center(Find(name).GetComponent<RectTransform>());
            Touch(point,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;
            Touch(point,UnityEngine.InputSystem.TouchPhase.Ended);yield return .2f;
        }


        static IEnumerator<float> Run()
        {
            BurgerEmpireMobileChecks.SetSize(2340,1080);yield return .5f;
            if(game.Hud.BlocksWorldInput)game.Hud.ClosePanel();game.SetLanguage("tr");
            SetSimulation(new Simulation(new Progress{version=13,tutorialDone=true,coins=3000,xp=1800,served=40,reviewTotal=190,reviewCount=41,reviews=new List<CustomerReview>{new CustomerReview{id=41,completed=true,name="Eski misafir",stars=4.6f,product="classic"}}}));
            game.Hud.OpenPanel("Müşteri yorumları");yield return .2f;
            Check(game.Sim.P.version==BurgerEmpire.Core.Progress.CurrentVersion&&HasText("Henüz ölçülmedi")&&HasText("Eski ziyaret · Kategori ölçümü yok"),"Migrated history keeps old stars and labels missing category measurements honestly");
            Check(game.Sim.P.reviewTotal==190&&game.Sim.P.coins==3000,"Opening category screen does not rewrite historical rating or wallet");
            SetSimulation(new Simulation(new Progress{tutorialDone=true,coins=3000,xp=1800,served=40,tables=4,grill=3,fryer=3,blender=2,cheese=1,doubleBurger=1,chickenBurger=1,bbqBurger=1,chocolateShake=1,cashier=3,cook=3,waiter=3,cleaner=3,manager=1,decor=1}));
            Check(Until(()=>game.Sim.P.reviews.Count>=12,12000),"A real staffed shift fills measured review history");
            game.Hud.OpenPanel("Müşteri yorumları");yield return .2f;
            Check(game.Sim.P.reviews.All(r=>r.measured)&&Enumerable.Range(0,5).All(i=>RatingSignals.Count(game.Sim.P.reviews,i)>0),"Actual completed visits populate all five categories");
            foreach(var wait in Enumerate(Tap("Show customer types")))yield return wait;
            Check(Tab=="Müşteriler"&&HasText("Öğrenci")&&HasText("Ofis çalışanı")&&HasText("VIP misafir"),"Real touch opens all six dining profiles and existing VIP profile");
            foreach(var wait in Enumerate(Tap("Guest reviews")))yield return wait;
            Check(Tab=="Müşteri yorumları"&&game.Sim.Paused,"Real touch returns to reviews without resuming shift");
            BurgerEmpireMobileChecks.SetSize(1080,2340);yield return .5f;CheckPage("Turkish measured review portrait");
            ScreenCapture.CaptureScreenshot("BurgerEmpire-0.25-Ratings.png");yield return .3f;
            game.SetLanguage("en");yield return .2f;CheckPage("English measured review portrait");
            Check(HasText("Food")&&HasText("Speed")&&HasText("Cleanliness")&&HasText("Price")&&HasText("Service"),"All category names translate with measured values");
            game.Hud.OpenPanel("Müşteriler");yield return .2f;CheckPage("English customer profiles portrait");
            ScreenCapture.CaptureScreenshot("BurgerEmpire-0.25-Customers-English.png");yield return .3f;
            game.SetLanguage("tr");game.Hud.ClosePanel();game.Sim.Paused=true;
            var family=new Customer{id=180001,kind=2,table=0,phase="eating",order="served",product="chicken",x=game.Sim.Tables[0].x,z=game.Sim.Tables[0].z+.85f,patience=100,maxPatience=100};
            game.Sim.Customers.Add(family);game.Sim.Tables[0].customer=family.id;yield return .2f;
            var meal=GameObject.Find("Restaurant Environment").transform.Find("Table_0/Meal");
            Check(meal.Find("Family serving chicken")&&meal.Find("Family serving chicken").gameObject.activeInHierarchy,"Family meal shows its second serving on the actual dining table");
            family.kind=0;yield return .2f;Check(!meal.Find("Family serving chicken").gameObject.activeSelf,"Reusing table for a regular diner hides extra family serving");
            family.kind=2;yield return .2f;
            var stage=new GameObject("Guest pose test").transform;
            try {
                var influencer=RestaurantArt.BuildPerson("customer",5,stage);influencer.UpdatePosition(50,0,1,false,true,"photo");
                var phone=influencer.rightArm.Find("Selfie phone");Check(phone&&phone.gameObject.activeInHierarchy,"Influencer photo pose equips a visible phone");
                var arm=influencer.rightArm.localRotation;influencer.UpdatePosition(50,0,1,false,true,"photo");
                Check(arm==influencer.rightArm.localRotation&&phone.gameObject.activeSelf,"Paused photo pose remains frozen");
                influencer.motion.Reset();influencer.UpdatePosition(50,0,1,false,false,"photo",Vector3.forward);
                CaptureGallery(stage,meal);
                influencer.UpdatePosition(50,0,1.2f,false,true,"impatient");Check(!phone.gameObject.activeSelf,"Impatient influencer puts phone away");
            }finally{UnityEngine.Object.Destroy(stage.gameObject);}
            game.Hud.OpenPanel("Müşteri yorumları");BurgerEmpireMobileChecks.SetSize(1280,720);yield return .4f;CheckPage("Turkish measured review landscape");
            BurgerEmpireMobileChecks.SetSize(2340,1080);yield return .4f;
            game.Save();Check(File.ReadAllText("BurgerEmpireSave.json")==disk,"Guest and category scenarios leave actual migrated save unchanged");
            File.AppendAllText(Report,"Completed. Customer profiles, measured categories, photos, family servings and mobile UI verified. Physical Android not tested.\n");
        }
        static void CaptureGallery(Transform stage,Transform meal)
        {
            var serving=UnityEngine.Object.Instantiate(meal.gameObject,stage).transform;
            serving.name="Family meal preview";serving.position=new Vector3(52,.75f,0);serving.rotation=Quaternion.identity;serving.localScale=Vector3.one*2;
            RestaurantArt.Text("Photo label","FOTOĞRAF",stage,new Vector3(50,.06f,.7f),.13f,RestaurantArt.Brown);
            RestaurantArt.Text("Meal label","AİLE MENÜSÜ",stage,new Vector3(52,.06f,.7f),.13f,RestaurantArt.Brown);
            var camera=new GameObject("Guest preview camera").AddComponent<Camera>();camera.orthographic=true;camera.orthographicSize=1.5f;
            camera.transform.position=new Vector3(51,3.5f,8);camera.transform.LookAt(new Vector3(51,1,0));camera.clearFlags=CameraClearFlags.SolidColor;camera.backgroundColor=RestaurantArt.Cream;
            var target=new RenderTexture(1200,700,24);camera.targetTexture=target;var previous=RenderTexture.active;Texture2D picture=null;
            try {camera.Render();RenderTexture.active=target;picture=new Texture2D(1200,700,TextureFormat.RGB24,false);picture.ReadPixels(new Rect(0,0,1200,700),0,0);picture.Apply();File.WriteAllBytes("BurgerEmpire-0.25-Guest-Details.png",picture.EncodeToPNG());}
            finally {RenderTexture.active=previous;camera.targetTexture=null;target.Release();UnityEngine.Object.Destroy(target);UnityEngine.Object.Destroy(camera.gameObject);if(picture)UnityEngine.Object.Destroy(picture);}
        }
        static void CheckPage(string context)
        {
            var labels=UnityEngine.Object.FindObjectsByType<Text>(FindObjectsSortMode.None).Where(t=>t.gameObject.activeInHierarchy).ToArray();
            if(Localization.Language=="en") {
                var untranslated=labels.Where(t=>t.text!="Türkçe"&&System.Text.RegularExpressions.Regex.IsMatch(t.text,"[çğıöşüÇĞİÖŞÜ]")).Select(t=>t.text).ToArray();
                Check(untranslated.Length==0,context+": no untranslated Turkish text: "+string.Join(" | ",untranslated));
            }
            var overflow=labels.Where(t=>t.preferredHeight>t.rectTransform.rect.height+2).Select(t=>t.text+" ("+t.preferredHeight+"/"+t.rectTransform.rect.height+")").ToArray();
            Check(overflow.Length==0,context+": text height fits: "+string.Join(" | ",overflow));
            var buttons=UnityEngine.Object.FindObjectsByType<Button>(FindObjectsSortMode.None).Where(b=>b.gameObject.activeInHierarchy).ToArray();
            Check(buttons.All(b=>b.GetComponent<RectTransform>().rect.height>=48),context+": touch controls have at least 48 logical pixels");
        }
        static IEnumerable<float> Enumerate(IEnumerator<float> source){while(source.MoveNext())yield return source.Current;}
        static void CheckText()
        {
            var list=UnityEngine.Object.FindFirstObjectByType<ScrollRect>();
            var labels=list.content.GetComponentsInChildren<Text>().Where(t=>t.gameObject.activeInHierarchy).ToArray();
            Check(labels.All(t=>t.preferredHeight<=t.rectTransform.rect.height+1),"Guide text fits its allocated height at "+Screen.width+"x"+Screen.height);
        }
        static void CheckBounds(string label)
        {
            var safe=Screen.safeArea;var corners=new Vector3[4];
            foreach(var button in UnityEngine.Object.FindObjectsByType<Button>(FindObjectsSortMode.None).Where(b=>b.gameObject.activeInHierarchy)) {
                var rt=button.GetComponent<RectTransform>();rt.GetWorldCorners(corners);
                // Only visible controls; clipped scrolling cards are intentionally outside the viewport.
                if(corners[2].y<safe.yMin||corners[0].y>safe.yMax)continue;
                Check(rt.rect.height>=48&&corners[0].x>=safe.xMin-1&&corners[2].x<=safe.xMax+1,label+": "+button.name+" touch size and horizontal bounds");
            }
        }
    }
}
#endif

