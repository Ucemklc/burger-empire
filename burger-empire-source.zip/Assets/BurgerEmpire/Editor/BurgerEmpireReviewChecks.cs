#if UNITY_EDITOR && ENABLE_INPUT_SYSTEM
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using BurgerEmpire.Core;
using BurgerEmpire.Unity;
using UnityEditor;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.LowLevel;
using UnityEngine.UI;
using Progress=BurgerEmpire.Core.Progress;

namespace BurgerEmpire.Editor
{
    [InitializeOnLoad]
    public static class BurgerEmpireReviewChecks
    {
        const string Pending="BurgerEmpire.ReviewChecks",Report="BurgerEmpireReviewChecks.txt";
        static IEnumerator<float> steps;
        static double next;
        static int nextFrame;
        static BurgerEmpireGame game;
        static Simulation original;
        static string disk;
        static int lastEvent;
        static Touchscreen touch;
        static InputSettings.BackgroundBehavior background;
        static InputSettings.EditorInputBehaviorInPlayMode routing;
        static BurgerEmpireReviewChecks(){EditorApplication.update+=Update;}
        static void Update()
        {
            if(EditorApplication.isCompiling||EditorApplication.isUpdating)return;
            if(File.Exists("BurgerEmpireReviewChecks.request")) {
                try {File.Delete("BurgerEmpireReviewChecks.request");} catch(IOException){return;}
                File.WriteAllText(Report,"");SessionState.SetBool(Pending,true);
                nextFrame=0;
                if(!EditorApplication.isPlaying){BurgerEmpireSetup.Play();return;}
            }
            if(!EditorApplication.isPlaying||!SessionState.GetBool(Pending,false)||EditorApplication.timeSinceStartup<next||Time.frameCount<nextFrame)return;
            try {
                if(steps==null) {
                    game=UnityEngine.Object.FindFirstObjectByType<BurgerEmpireGame>();if(!game||game.Sim==null)return;
                    original=game.Sim;disk=File.ReadAllText("BurgerEmpireSave.json");game.ValidationActive=true;
                    lastEvent=(int)typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).GetValue(game);
                    background=InputSystem.settings.backgroundBehavior;InputSystem.settings.backgroundBehavior=InputSettings.BackgroundBehavior.IgnoreFocus;
                    // Route the synthetic touchscreen to the game even when another editor window has focus.
                    routing=InputSystem.settings.editorInputBehaviorInPlayMode;InputSystem.settings.editorInputBehaviorInPlayMode=InputSettings.EditorInputBehaviorInPlayMode.AllDeviceInputAlwaysGoesToGameView;
                    touch=InputSystem.AddDevice<Touchscreen>();steps=Run();
                }
                // Editor callbacks may outrun the game loop when the window is unfocused.
                // Let input and EventSystem process each gesture step before queuing the next.
                if(steps.MoveNext()){next=EditorApplication.timeSinceStartup+steps.Current;nextFrame=Time.frameCount+3;}else Finish();
            } catch(Exception e){File.AppendAllText(Report,"FAIL: "+e+"\n");Finish();}
        }
        static void SetSimulation(Simulation value)
        {
            typeof(BurgerEmpireGame).GetProperty("Sim").SetValue(game,value);
            typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game,0);
            typeof(RestaurantHud).GetField("toastTime",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game.Hud,0f);
        }
        static void Finish()
        {
            if(touch!=null){InputSystem.RemoveDevice(touch);touch=null;}InputSystem.settings.backgroundBehavior=background;InputSystem.settings.editorInputBehaviorInPlayMode=routing;
            if(game&&original!=null) {
                if(game.LayoutEditor.Active)game.Hud.FinishLayout(false);
                SetSimulation(original);original.Paused=true;game.ValidationActive=false;game.Save();game.Hud.OpenPanel("Restoran");
                typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game,lastEvent);
            }
            steps=null;original=null;nextFrame=0;SessionState.SetBool(Pending,false);
        }
        static Progress Fixture()
        {
            return new Progress{coins=2000,xp=900,tables=2,grill=2,cook=1,tutorialDone=true};
        }
        static void Check(bool good,string message)
        {File.AppendAllText(Report,(good?"PASS: ":"FAIL: ")+message+"\n");if(!good)throw new Exception(message);}
        static Button Find(string name){return UnityEngine.Object.FindObjectsByType<Button>(FindObjectsSortMode.None).First(b=>b.name==name&&b.gameObject.activeInHierarchy);}
        static Vector2 Center(RectTransform rt){return RectTransformUtility.WorldToScreenPoint(null,rt.TransformPoint(rt.rect.center));}
        static void Touch(Vector2 p,UnityEngine.InputSystem.TouchPhase phase)
        {InputSystem.QueueStateEvent(touch,new TouchState{touchId=1,position=p,phase=phase});}
        static bool Until(Func<bool> condition,int limit=1000)
        {
            game.Sim.Paused=false;
            for(int i=0;i<limit&&!condition();i++){if(game.Sim.Actors[0].job=="")game.Sim.Command("next");game.Sim.Tick(.1f);}
            game.Sim.Paused=true;return condition();
        }
        static bool WaitOnly(Func<bool> condition,int limit=2000)
        {
            game.Sim.Paused=false;
            for(int i=0;i<limit&&!condition();i++)game.Sim.Tick(.1f);
            game.Sim.Paused=true;return condition();
        }

        static void Top(){var scroll=UnityEngine.Object.FindFirstObjectByType<ScrollRect>();scroll.StopMovement();scroll.verticalNormalizedPosition=1;}
        static string Texts=>string.Join("\n",UnityEngine.Object.FindObjectsByType<Text>(FindObjectsSortMode.None).Where(t=>t.gameObject.activeInHierarchy).Select(t=>t.text));
        static int CardCount()=>UnityEngine.Object.FindObjectsByType<RectTransform>(FindObjectsSortMode.None).Count(r=>r.name.StartsWith("Review ")&&r.name!="Review summary"&&r.name!="Review accent"&&r.gameObject.activeInHierarchy);
        static void Bounds(string size)
        {
            var list=UnityEngine.Object.FindFirstObjectByType<ScrollRect>();var corners=new Vector3[4];
            var shield=GameObject.Find("Modal shield").GetComponent<RectTransform>();shield.GetWorldCorners(corners);
            Check(corners[0].x<=1&&corners[0].y<=1&&corners[2].x>=Screen.width-1&&corners[2].y>=Screen.height-1,size+": review modal shields complete display");
            list.viewport.GetWorldCorners(corners);var safe=Screen.safeArea;
            Check(corners[0].x>=safe.xMin&&corners[2].x<=safe.xMax&&corners[0].y>=safe.yMin&&corners[2].y<=safe.yMax,size+": review viewport stays inside safe area");
            Check(Find("×").GetComponent<RectTransform>().rect.height>=48,size+": close control remains reachable and large enough");
            Check(list.content.rect.height>list.viewport.rect.height,size+": long review history scrolls");
            foreach(var text in list.content.GetComponentsInChildren<Text>()) {
                var rect=text.GetComponent<RectTransform>();
                Check(text.preferredHeight<=rect.rect.height+2,size+": text fits allocated height: "+text.text.Replace("\n"," ").Substring(0,Math.Min(30,text.text.Length)));
            }
        }
        static IEnumerator<float> Run()
        {
            BurgerEmpireMobileChecks.SetSize(2340,1080);yield return .7f;
            if(game.Hud.BlocksWorldInput)game.Hud.ClosePanel();
            var old=new Progress{version=7,coins=287,xp=812,served=22,reviewTotal=99,reviewCount=24,tutorialDone=true};
            SetSimulation(new Simulation(JsonUtility.FromJson<Progress>(JsonUtility.ToJson(old))));game.Hud.OpenPanel("Restoran");yield return .25f;
            var list=UnityEngine.Object.FindFirstObjectByType<ScrollRect>();list.content.anchoredPosition=new Vector2(0,-Find("MÜŞTERİ YORUMLARI").GetComponent<RectTransform>().anchoredPosition.y-list.viewport.rect.height/2);yield return .2f;
            var target=Center(Find("MÜŞTERİ YORUMLARI").GetComponent<RectTransform>());
            Check(list.viewport.rect.Contains(list.viewport.InverseTransformPoint(target)),"Review entry is visible inside scrolled restaurant panel");
            Touch(target,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;Touch(target,UnityEngine.InputSystem.TouchPhase.Ended);yield return .25f;
            Check(GameObject.Find("Review summary")&&game.Hud.BlocksWorldInput&&game.Sim.Paused,"Actual touch opens review screen and pauses restaurant");
            Check(Texts.Contains("İlk yorumunu bekliyorsun")&&game.Sim.P.reviews.Count==0,"Legacy save shows empty review history without fabricated comments");
            Check(game.Sim.P.version==BurgerEmpire.Core.Progress.CurrentVersion&&game.Sim.P.coins==287&&game.Sim.P.reviewTotal==99&&game.Sim.P.reviewCount==24,"Unity JSON migration preserves wallet and historic restaurant rating");
            Check(!Find("ÖDÜLÜ AL").interactable,"Daily review reward is disabled before positive reviews exist");
            float time=game.Sim.Time;yield return .25f;Check(game.Sim.Time==time,"Reading reviews freezes customer patience and simulation time");
            var fixture=new Progress{coins=2500,xp=1500,served=35,tutorialDone=true,cashier=3,cook=3,waiter=3,cleaner=3,manager=1,tables=4,grill=3,fryer=3,blender=2,cheese=1,doubleBurger=1,decor=1,driveThru=2,delivery=2};
            game.Hud.ClosePanel();SetSimulation(new Simulation(fixture));yield return .2f;
            Check(WaitOnly(()=>game.Sim.P.reviews.Count==12&&game.Sim.P.dailyReviews==5,12000),"A real staffed restaurant fills twelve reviews and earns five positive visits");
            game.Hud.OpenPanel("Müşteri yorumları");yield return .3f;
            Check(CardCount()==12&&game.Sim.P.reviews.Select(r=>r.id).Distinct().Count()==12,"Review screen renders twelve distinct actual visits");
            Check(Texts.Contains("Salon")&&Texts.Contains("Arabaya servis")&&Texts.Contains("Kurye"),"Review cards distinguish all three service channels");
            Check(Texts.Contains("Kalan sabır %")&&Texts.Contains("Temizlik %")&&Texts.Contains("coin ödeme"),"Cards show observed patience, cleanliness and paid coin amount");
            var cards=list=UnityEngine.Object.FindFirstObjectByType<ScrollRect>();
            var ordered=cards.content.Cast<Transform>().Where(t=>t.name.StartsWith("Review ")&&t.name!="Review summary").ToArray();
            Check(ordered.First().name=="Review "+game.Sim.P.reviews.Last().id,"Newest review is displayed first");
            var sw=Center(cards.viewport);Touch(sw,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;
            Touch(sw+Vector2.up*250,UnityEngine.InputSystem.TouchPhase.Moved);yield return .12f;
            Touch(sw+Vector2.up*450,UnityEngine.InputSystem.TouchPhase.Moved);yield return .12f;
            Touch(sw+Vector2.up*450,UnityEngine.InputSystem.TouchPhase.Ended);yield return .25f;
            Check(cards.content.anchoredPosition.y>80,"Real finger swipe scrolls review history");
            Check(game.CameraControls.Zoom==1&&game.Sim.Actors[0].job=="","Scrolling review cards never zooms camera or walks player");
            Top();yield return .2f;target=Center(Find("ÖDÜLÜ AL").GetComponent<RectTransform>());
            Check(cards.viewport.rect.Contains(cards.viewport.InverseTransformPoint(target)),"Positive-review reward button is visible in top panel");
            int wallet=game.Sim.P.coins,xp=game.Sim.P.xp;
            Touch(target,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;Touch(target,UnityEngine.InputSystem.TouchPhase.Ended);yield return .25f;
            Check(game.Sim.P.coins==wallet+100&&game.Sim.P.xp==xp+25&&game.Sim.P.dailyReviewClaimed,"Touch claim grants 100 coins and 25 XP exactly once (coin delta "+(game.Sim.P.coins-wallet)+", XP delta "+(game.Sim.P.xp-xp)+", claimed "+game.Sim.P.dailyReviewClaimed+")");
            Check(!Find("ALINDI").interactable,"Claimed daily reward displays ALINDI and disables repeat claim");
            string history=JsonUtility.ToJson(game.Sim.P);var loaded=new Simulation(JsonUtility.FromJson<Progress>(history));
            Check(loaded.P.reviews.Count==12&&JsonUtility.ToJson(loaded.P.reviews[11])==JsonUtility.ToJson(game.Sim.P.reviews[11]),"Unity JSON reload preserves complete latest review details");
            Check(loaded.P.dailyReviewClaimed&&loaded.P.dailyReviews==5,"Unity reload retains daily count and claimed flag");
            Check(game.Sim.OpenLondon(out _),"Review fixture opens London branch");game.Hud.RefreshPanel();yield return .25f;
            Check(Texts.Contains("Londra · Müşteri yorumları")&&Texts.Contains("İlk yorumunu bekliyorsun")&&game.Sim.P.reviews.Count==0,"London displays its own empty feed without copying Istanbul reviews");
            Check(!Find("ALINDI").interactable,"Changing branch cannot claim shared daily review reward again");
            game.Sim.SwitchBranch(0,out _);game.Hud.RefreshPanel();yield return .25f;
            Check(CardCount()==12&&Texts.Contains("İstanbul · Müşteri yorumları"),"Switching back restores Istanbul review cards");
            Top();Bounds("2340x1080");
            cards=UnityEngine.Object.FindFirstObjectByType<ScrollRect>();cards.content.anchoredPosition=new Vector2(0,400);cards.StopMovement();yield return .25f;
            ScreenCapture.CaptureScreenshot(Path.GetFullPath("BurgerEmpire-0.11-Reviews.png"));yield return .3f;
            BurgerEmpireMobileChecks.SetSize(1280,720);yield return .6f;Bounds("1280x720");
            BurgerEmpireMobileChecks.SetSize(1080,2340);yield return .6f;Bounds("1080x2340");
            cards=UnityEngine.Object.FindFirstObjectByType<ScrollRect>();cards.content.anchoredPosition=new Vector2(0,365);cards.StopMovement();yield return .25f;
            ScreenCapture.CaptureScreenshot(Path.GetFullPath("BurgerEmpire-0.11-Portrait.png"));yield return .3f;
            game.Hud.ClosePanel();SetSimulation(new Simulation(new Progress{tutorialDone=true}));
            Check(WaitOnly(()=>game.Sim.P.lost>=2,7000),"Unserved real customers eventually leave and record negative reviews");
            game.Hud.OpenPanel("Müşteri yorumları");yield return .3f;
            Check(game.Sim.P.reviews.All(r=>!r.completed&&r.stars==2)&&game.Sim.P.dailyReviews==0,"Unpaid departures are two-star reviews and never advance positive objective");
            Check(Texts.Contains("Beklemeyi azalt")&&Texts.Contains("Sipariş tamamlanmadı"),"Negative reviews explain the problem and show an actionable staffing suggestion");
            target=Center(Find("×").GetComponent<RectTransform>());Touch(target,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;Touch(target,UnityEngine.InputSystem.TouchPhase.Ended);yield return .25f;
            Check(!game.Hud.BlocksWorldInput&&game.Sim.Paused,"Touch close restores prior paused state without resuming an abandoned shift");
            BurgerEmpireMobileChecks.SetSize(2340,1080);yield return .5f;
            game.Save();Check(File.ReadAllText("BurgerEmpireSave.json")==disk,"Review fixtures never overwrite real player progress");
            File.AppendAllText(Report,"Completed. Actual Unity touch and JSON serialization tested; physical Android not tested.\n");
        }
    }
}
#endif
