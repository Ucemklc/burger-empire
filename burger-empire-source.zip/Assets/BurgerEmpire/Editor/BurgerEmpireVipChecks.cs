#if UNITY_EDITOR && ENABLE_INPUT_SYSTEM
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using BurgerEmpire.Core;
using BurgerEmpire.Unity;
using UnityEditor;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.LowLevel;
using UnityEngine.UI;
using Progress=BurgerEmpire.Core.Progress;

namespace BurgerEmpire.Editor
{
    [InitializeOnLoad]
    public static class BurgerEmpireVipChecks
    {
        const string Pending="BurgerEmpire.VipChecks",Report="BurgerEmpireVipChecks.txt";
        static IEnumerator<float> steps;
        static double next;
        static int nextFrame;
        static BurgerEmpireGame game;
        static Simulation original;
        static string disk;
        static string originalSavePath;
        static int lastEvent;
        static Touchscreen touch;
        static InputSettings.BackgroundBehavior background;
        static InputSettings.EditorInputBehaviorInPlayMode routing;
        static BurgerEmpireVipChecks(){EditorApplication.update+=Update;}
        static void Update()
        {
            if(EditorApplication.isCompiling||EditorApplication.isUpdating)return;
            if(File.Exists("BurgerEmpireVipChecks.request")) {
                try {File.Delete("BurgerEmpireVipChecks.request");} catch(IOException){return;}
                File.WriteAllText(Report,"");SessionState.SetBool(Pending,true);nextFrame=0;
                if(!EditorApplication.isPlaying){BurgerEmpireSetup.Play();return;}
            }
            if(!EditorApplication.isPlaying||!SessionState.GetBool(Pending,false)||EditorApplication.timeSinceStartup<next||Time.frameCount<nextFrame)return;
            try {
                if(steps==null) {
                    game=UnityEngine.Object.FindFirstObjectByType<BurgerEmpireGame>();if(!game||game.Sim==null)return;
                    original=game.Sim;disk=File.ReadAllText("BurgerEmpireSave.json");
                    originalSavePath=(string)typeof(BurgerEmpireGame).GetField("savePath",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).GetValue(game);
                    typeof(BurgerEmpireGame).GetField("savePath",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game,Path.GetFullPath("BurgerEmpireVipValidationSave.json"));
                    lastEvent=(int)typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).GetValue(game);
                    background=InputSystem.settings.backgroundBehavior;InputSystem.settings.backgroundBehavior=InputSettings.BackgroundBehavior.IgnoreFocus;
                    // Route the synthetic touchscreen to the game even when another editor window has focus.
                    routing=InputSystem.settings.editorInputBehaviorInPlayMode;InputSystem.settings.editorInputBehaviorInPlayMode=InputSettings.EditorInputBehaviorInPlayMode.AllDeviceInputAlwaysGoesToGameView;
                    touch=InputSystem.AddDevice<Touchscreen>();steps=Run();
                }
                if(steps.MoveNext()){next=EditorApplication.timeSinceStartup+steps.Current;nextFrame=Time.frameCount+3;}else Finish();
            } catch(Exception e){File.AppendAllText(Report,"FAIL: "+e+"\n");Finish();}
        }
        static void SetSimulation(Simulation value)
        {
            typeof(BurgerEmpireGame).GetProperty("Sim").SetValue(game,value);
            typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game,0);
            typeof(RestaurantHud).GetField("toastTime",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game.Hud,0f);
        }
        static void Finish()
        {
            if(touch!=null){InputSystem.RemoveDevice(touch);touch=null;}InputSystem.settings.backgroundBehavior=background;InputSystem.settings.editorInputBehaviorInPlayMode=routing;
            if(game&&original!=null) {
                if(game.LayoutEditor.Active)game.Hud.FinishLayout(false);
                typeof(BurgerEmpireGame).GetField("savePath",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game,originalSavePath);
                SetSimulation(original);original.Paused=true;game.Save();game.Hud.OpenPanel("VIP misafirler");
                typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game,lastEvent);
            }
            steps=null;original=null;nextFrame=0;SessionState.SetBool(Pending,false);
        }
        static Progress Fixture()
        {
            return new Progress{coins=2000,xp=900,tables=2,grill=2,cook=1,tutorialDone=true};
        }
        static void Check(bool good,string message)
        {File.AppendAllText(Report,(good?"PASS: ":"FAIL: ")+message+"\n");if(!good)throw new Exception(message);}
        static Button Find(string name){return UnityEngine.Object.FindObjectsByType<Button>(FindObjectsSortMode.None).First(b=>b.name==name&&b.gameObject.activeInHierarchy);}
        static Vector2 Center(RectTransform rt){return RectTransformUtility.WorldToScreenPoint(null,rt.TransformPoint(rt.rect.center));}
        static void Touch(Vector2 p,UnityEngine.InputSystem.TouchPhase phase)
        {InputSystem.QueueStateEvent(touch,new TouchState{touchId=1,position=p,phase=phase});}
        static bool Until(Func<bool> condition,int limit=1000)
        {
            game.Sim.Paused=false;
            for(int i=0;i<limit&&!condition();i++){if(game.Sim.Actors[0].job=="")game.Sim.Command("next");game.Sim.Tick(.1f);}
            game.Sim.Paused=true;return condition();
        }
        static bool WaitOnly(Func<bool> condition,int limit=2000)
        {
            game.Sim.Paused=false;
            for(int i=0;i<limit&&!condition();i++)game.Sim.Tick(.1f);
            game.Sim.Paused=true;return condition();
        }



        static string Texts=>string.Join("\n",UnityEngine.Object.FindObjectsByType<Text>(FindObjectsSortMode.None).Where(t=>t.gameObject.activeInHierarchy).Select(t=>t.text));
        static ScrollRect List=>UnityEngine.Object.FindFirstObjectByType<ScrollRect>();
        static void Reveal(string name)
        {var target=Find(name).GetComponent<RectTransform>();List.StopMovement();List.content.anchoredPosition=new Vector2(0,Mathf.Max(0,-target.anchoredPosition.y-10));}
        static void Top(){List.StopMovement();List.verticalNormalizedPosition=1;}
        static Customer NaturalVip()
        {
            game.Sim.Paused=false;
            for(int i=0;i<20000;i++) {
                var c=game.Sim.Customers.FirstOrDefault(VipCatalog.IsVip);
                if(c!=null){game.Sim.Paused=true;return c;}
                game.Sim.Customers.Clear();game.Sim.Tick(.25f);
            }
            throw new Exception("Eligible VIP did not arrive");
        }
        static void Bounds(string size)
        {
            var list=List;var points=new Vector3[4];list.viewport.GetWorldCorners(points);var safe=Screen.safeArea;
            Check(points[0].x>=safe.xMin&&points[2].x<=safe.xMax&&points[0].y>=safe.yMin&&points[2].y<=safe.yMax,size+": VIP panel fits safe display area");
            Check(list.content.rect.height>list.viewport.rect.height,size+": VIP details remain scrollable");
            Check(list.content.GetComponentsInChildren<Button>().All(b=>b.GetComponent<RectTransform>().rect.height>=48),size+": VIP navigation buttons meet 48-pixel touch target");
            var overflow=list.content.GetComponentsInChildren<Text>().Where(t=>t.preferredHeight>t.rectTransform.rect.height+2).Select(t=>t.text.Replace("\n"," "));
            Check(!overflow.Any(),size+": all VIP text fits: "+string.Join(" | ",overflow));
            Check(Find("×").GetComponent<RectTransform>().rect.height>=48,size+": VIP close action is reachable");
        }
        static void BubbleBounds(string size)
        {
            var bubble=GameObject.Find("VIP order").GetComponent<RectTransform>();var corners=new Vector3[4];bubble.GetWorldCorners(corners);
            Check(corners[0].x>=Screen.safeArea.xMin&&corners[2].x<=Screen.safeArea.xMax,size+": gold VIP order bubble fits horizontal safe area");
            Check(bubble.GetComponentsInChildren<Text>().Length==0&&bubble.GetComponentsInChildren<FoodIconGraphic>().Any(i=>i.Kind=="crown"),size+": VIP uses food icons and crown without small text");
            Check(bubble.GetComponent<Image>().color==RestaurantArt.Hex("FFE7A3"),size+": VIP has a gold order card");
        }
        static IEnumerator<float> Run()
        {
            BurgerEmpireMobileChecks.SetSize(2340,1080);yield return .7f;
            if(game.LayoutEditor.Active)game.Hud.FinishLayout(false);
            if(game.Hud.BlocksWorldInput)game.Hud.ClosePanel();
            SetSimulation(new Simulation(new Progress{version=10,coins=409,xp=2005,tutorialDone=true,served=66,popularity=49,influencerShares=4}));
            game.Hud.OpenPanel("Restoran");yield return .25f;Reveal("Open VIP");yield return .2f;
            var target=Center(Find("Open VIP").GetComponent<RectTransform>());
            Check(List.viewport.rect.Contains(List.viewport.InverseTransformPoint(target)),"VIP management entry is reachable from restaurant list");
            Touch(target,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;Touch(target,UnityEngine.InputSystem.TouchPhase.Ended);yield return .25f;
            Check(GameObject.Find("VIP summary")&&game.Hud.BlocksWorldInput&&game.Sim.Paused,"Actual touch opens VIP management and pauses the shift");
            Check(Texts.Contains("VIP ZİYARETLERİ KİLİTLİ")&&Texts.Contains("49 / 50"),"Locked VIP panel explains exact missing popularity");
            Check(game.Sim.P.version==BurgerEmpire.Core.Progress.CurrentVersion&&game.Sim.P.coins==409&&game.Sim.P.xp==2005&&game.Sim.P.popularity==49&&game.Sim.P.influencerShares==4&&game.Sim.P.vipArrived==0,"Unity version-ten migration preserves wallet and reputation without invented VIP visits");
            float time=game.Sim.Time;yield return .3f;Check(game.Sim.Time==time,"Reading VIP requirements freezes simulation time");
            var sw=Center(List.viewport);Touch(sw,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;
            Touch(sw+Vector2.up*220,UnityEngine.InputSystem.TouchPhase.Moved);yield return .12f;
            Touch(sw+Vector2.up*440,UnityEngine.InputSystem.TouchPhase.Moved);yield return .12f;
            Touch(sw+Vector2.up*440,UnityEngine.InputSystem.TouchPhase.Ended);yield return .25f;
            Check(List.content.anchoredPosition.y>80&&game.CameraControls.Zoom==1&&game.Sim.Actors[0].job=="","Finger scroll moves VIP details without moving player or camera");
            game.Hud.ClosePanel();SetSimulation(new Simulation(new Progress{coins=2500,xp=900,served=30,popularity=100,tutorialDone=true,decor=1,cheese=1,doubleBurger=1,blender=1,grill=2}));
            var guest=NaturalVip();Check(WaitOnly(()=>guest.phase=="queue"),"Actual eligible VIP arrives and walks to the restaurant queue");yield return .35f;
            Check(GameObject.Find("VIP gold tie")&&GameObject.Find("VIP sunglasses")&&GameObject.Find("VIP pin"),"Spawned VIP has distinct suit accessories in the live 3D scene");
            Check(GameObject.Find("VIP order").GetComponentsInChildren<FoodIconGraphic>().Any(i=>i.Kind=="crown"),"Live gold bubble identifies VIP with a crown illustration");
            BubbleBounds("2340x1080");game.CameraControls.ZoomStep(1.4f);yield return .3f;
            typeof(RestaurantHud).GetField("toastTime",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game.Hud,0f);
            ScreenCapture.CaptureScreenshot(Path.GetFullPath("BurgerEmpire-0.14-VIP-guest.png"));yield return .3f;game.CameraControls.Reset();
            BurgerEmpireMobileChecks.SetSize(1080,2340);yield return .6f;BubbleBounds("1080x2340");
            BurgerEmpireMobileChecks.SetSize(2340,1080);yield return .6f;
            game.Command("pause");yield return .1f;target=Center(Find("Sipariş al").GetComponent<RectTransform>());
            Touch(target,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;Touch(target,UnityEngine.InputSystem.TouchPhase.Ended);yield return .25f;
            Check(game.Sim.Actors[0].customer==guest.id&&game.Sim.Actors[0].job=="order","Actual order tap assigns player to the VIP guest");
            Check(Until(()=>guest.order=="ordered"),"VIP order reaches a real reserved dining table");
            int wallet=game.Sim.P.coins;Check(Until(()=>game.Sim.P.vipServed==1,2000),"Real cooking, serving and payment complete the VIP visit");yield return .3f;
            Check(game.Sim.P.coins-wallet==game.Sim.P.vipEarned&&game.Sim.P.vipEarned>guest.price&&game.Sim.P.vipLost==0,"VIP receipt reconciles quoted price, tip and common wallet without duplicate credit");
            Check(game.Sim.P.reviews.Last().kind==VipCatalog.Kind&&game.Sim.P.reviews.Last().paid==game.Sim.P.vipEarned&&!game.Sim.P.reviews.Last().influencerShare,"Completed VIP creates correct customer review with actual payment");
            game.Hud.OpenPanel("VIP misafirler");yield return .3f;
            Check(Texts.Contains("Servis edilen: 1")&&Texts.Contains("VIP ŞANSI  %8"),"VIP management shows earned service count and exact current chance");
            game.Save();var saved=JsonUtility.FromJson<Progress>(File.ReadAllText("BurgerEmpireVipValidationSave.json"));
            Check(saved.version==BurgerEmpire.Core.Progress.CurrentVersion&&saved.vipArrived==1&&saved.vipServed==1&&saved.vipEarned==game.Sim.P.vipEarned&&saved.reviews.Last().kind==6,"Isolated Unity disk save includes VIP results and review identity");
            SetSimulation(new Simulation(saved));game.Hud.RefreshPanel();yield return .25f;
            Check(game.Sim.P.vipServed==1&&game.Sim.P.vipArrived==1&&game.Sim.Customers.Count==0,"Reload retains VIP totals while clearing transient guests");
            int revenue=game.Sim.P.vipEarned;Check(game.Sim.OpenLondon(out _),"VIP fixture opens London");game.Hud.RefreshPanel();yield return .25f;
            Check(Texts.Contains("Londra · Özel misafirler")&&Texts.Contains("0 / 10")&&game.Sim.P.vipServed==0&&game.Sim.P.vipEarned==0,"London shows its own locked VIP progression and zero local totals");
            game.Sim.SwitchBranch(0,out _);game.Hud.RefreshPanel();yield return .25f;
            Check(game.Sim.P.vipServed==1&&game.Sim.P.vipEarned==revenue,"Returning to Istanbul restores exact VIP earnings");
            game.Sim.RefreshDay("2099-08-01");game.Hud.RefreshPanel();yield return .2f;
            Check(game.Sim.P.vipServed==1&&game.Sim.P.vipEarned==revenue,"Changing day does not reset VIP lifetime counters");
            Reveal("VIP reviews");yield return .2f;target=Center(Find("VIP reviews").GetComponent<RectTransform>());
            Touch(target,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;Touch(target,UnityEngine.InputSystem.TouchPhase.Ended);yield return .25f;
            Check(GameObject.Find("Review summary")&&Texts.Contains("VIP misafir"),"Actual navigation opens review history with VIP identity");
            game.Hud.OpenPanel("VIP misafirler");yield return .2f;Top();Bounds("2340x1080");
            ScreenCapture.CaptureScreenshot(Path.GetFullPath("BurgerEmpire-0.14-VIP.png"));yield return .3f;
            BurgerEmpireMobileChecks.SetSize(1280,720);yield return .6f;Bounds("1280x720");
            BurgerEmpireMobileChecks.SetSize(1080,2340);yield return .6f;Bounds("1080x2340");Top();yield return .2f;
            ScreenCapture.CaptureScreenshot(Path.GetFullPath("BurgerEmpire-0.14-Portrait.png"));yield return .3f;
            Reveal("VIP popularity");yield return .2f;target=Center(Find("VIP popularity").GetComponent<RectTransform>());
            Touch(target,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;Touch(target,UnityEngine.InputSystem.TouchPhase.Ended);yield return .25f;
            Check(GameObject.Find("Popularity summary")&&Find("Popularity VIP").GetComponentInChildren<Text>().text.Contains("%8"),"VIP links to popularity and exposes matching discovery chance");
            Reveal("Popularity VIP");yield return .2f;target=Center(Find("Popularity VIP").GetComponent<RectTransform>());
            Touch(target,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;Touch(target,UnityEngine.InputSystem.TouchPhase.Ended);yield return .25f;
            Check(GameObject.Find("VIP summary"),"Popularity action opens VIP management with actual touch");
            Reveal("VIP back");yield return .2f;target=Center(Find("VIP back").GetComponent<RectTransform>());
            Touch(target,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;Touch(target,UnityEngine.InputSystem.TouchPhase.Ended);yield return .25f;
            Check(Find("Open VIP")&&game.Sim.Paused,"Back action returns to restaurant management without resuming shift");
            game.Hud.ClosePanel();game.Sim.Paused=false;game.Hud.OpenPanel("VIP misafirler");yield return .2f;
            target=Center(Find("×").GetComponent<RectTransform>());Touch(target,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;Touch(target,UnityEngine.InputSystem.TouchPhase.Ended);yield return .25f;
            Check(!game.Hud.BlocksWorldInput&&!game.Sim.Paused,"Closing VIP panel restores the previous running state");game.Sim.Paused=true;
            BurgerEmpireMobileChecks.SetSize(2340,1080);yield return .5f;
            Check(File.ReadAllText("BurgerEmpireSave.json")==disk,"VIP validation sales and purchases never overwrite real player progress");
            File.AppendAllText(Report,"Completed. Unity touch, real 3D guest and isolated disk save verified; physical Android not tested.\n");
        }
    }
}
#endif
