#if UNITY_EDITOR && ENABLE_INPUT_SYSTEM
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using BurgerEmpire.Unity;
using UnityEditor;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.LowLevel;
using UnityEngine.UI;

namespace BurgerEmpire.Editor
{
    [InitializeOnLoad]
    public static class BurgerEmpireMobileChecks
    {
        const string Pending="BurgerEmpire.MobileChecks";
        static IEnumerator<float> steps;
        static double next;
        static int nextFrame;
        static Touchscreen touch;
        static BurgerEmpireGame game;
        static string progress;
        static BurgerEmpire.Core.Simulation original;
        static BurgerEmpire.Core.SessionMeasurements originalSession;
        static BurgerEmpire.Core.ProgressStore originalStore;
        static string originalSavePath,disk;
        static int lastEvent;
        static InputSettings.EditorInputBehaviorInPlayMode oldRouting;
        const BindingFlags Private=BindingFlags.Instance|BindingFlags.NonPublic;
        static InputSettings.BackgroundBehavior oldBackground;
        static readonly string Report="BurgerEmpireMobileChecks.txt";
        static BurgerEmpireMobileChecks(){EditorApplication.update+=Update;}
        static void Update()
        {
            if(EditorApplication.isCompiling||EditorApplication.isUpdating)return;
            if(File.Exists("BurgerEmpireMobileChecks.request")) {
                try {File.Delete("BurgerEmpireMobileChecks.request");} catch(IOException){return;}
                File.WriteAllText(Report,"");
                SessionState.SetBool(Pending,true);nextFrame=0;
                if(!EditorApplication.isPlaying){BurgerEmpireSetup.Play();return;}
            }
            if(!EditorApplication.isPlaying||!SessionState.GetBool(Pending,false))return;
            if(EditorApplication.timeSinceStartup<next||Time.frameCount<nextFrame)return;
            try {
                if(steps==null) {
                    game=UnityEngine.Object.FindFirstObjectByType<BurgerEmpireGame>();if(!game||!game.Hud)return;
                    progress=JsonUtility.ToJson(game.Sim.P);
                    original=game.Sim;originalSavePath=(string)typeof(BurgerEmpireGame).GetField("savePath",Private).GetValue(game);
                    originalSession=game.Session;originalStore=(BurgerEmpire.Core.ProgressStore)typeof(BurgerEmpireGame).GetField("progressStore",Private).GetValue(game);
                    typeof(BurgerEmpireGame).GetProperty("Session").SetValue(game,new BurgerEmpire.Core.SessionMeasurements());
                    disk=File.ReadAllText(originalSavePath);lastEvent=(int)typeof(BurgerEmpireGame).GetField("lastEvent",Private).GetValue(game);
                    typeof(BurgerEmpireGame).GetField("savePath",Private).SetValue(game,Path.GetFullPath("BurgerEmpireMobileValidationSave.json"));
                    if(game.LayoutEditor.Active)game.Hud.FinishLayout(false);
                    if(game.Hud.BlocksWorldInput)game.Hud.ClosePanel();
                    typeof(BurgerEmpireGame).GetProperty("Sim").SetValue(game,new BurgerEmpire.Core.Simulation(new BurgerEmpire.Core.Progress{tutorialDone=true,coins=2000,xp=900}));
                    typeof(BurgerEmpireGame).GetField("lastEvent",Private).SetValue(game,0);
                    game.Sim.Paused=false;game.Hud.OpenPanel("Yardım");
                    oldBackground=InputSystem.settings.backgroundBehavior;InputSystem.settings.backgroundBehavior=InputSettings.BackgroundBehavior.IgnoreFocus;
                    oldRouting=InputSystem.settings.editorInputBehaviorInPlayMode;InputSystem.settings.editorInputBehaviorInPlayMode=InputSettings.EditorInputBehaviorInPlayMode.AllDeviceInputAlwaysGoesToGameView;
                    touch=InputSystem.AddDevice<Touchscreen>();steps=Run();
                }
                if(steps.MoveNext()){next=EditorApplication.timeSinceStartup+steps.Current;nextFrame=Time.frameCount+3;}
                else Finish();
            } catch(Exception e){File.AppendAllText(Report,"FAIL: "+e+"\n");Finish();}
        }
        static void Finish()
        {
            if(touch!=null){InputSystem.RemoveDevice(touch);touch=null;}
            InputSystem.settings.backgroundBehavior=oldBackground;
            InputSystem.settings.editorInputBehaviorInPlayMode=oldRouting;
            if(game&&original!=null){
                if(game.Hud.BlocksWorldInput)game.Hud.ClosePanel();
                typeof(BurgerEmpireGame).GetField("savePath",Private).SetValue(game,originalSavePath);
                typeof(BurgerEmpireGame).GetField("progressStore",Private).SetValue(game,originalStore);
                typeof(BurgerEmpireGame).GetProperty("Session").SetValue(game,originalSession);
                typeof(BurgerEmpireGame).GetProperty("Sim").SetValue(game,original);game.Sim.Paused=true;game.Save();
                typeof(BurgerEmpireGame).GetField("lastEvent",Private).SetValue(game,lastEvent);
            }
            original=null;
            steps=null;nextFrame=0;SessionState.SetBool(Pending,false);
        }
        static void Check(bool passed,string message)
        {
            File.AppendAllText(Report,(passed?"PASS: ":"FAIL: ")+message+"\n");
            if(!passed)throw new Exception(message);
        }
        static void Touch(Vector2 p,UnityEngine.InputSystem.TouchPhase phase)
        { InputSystem.QueueStateEvent(touch,new TouchState{touchId=1,position=p,phase=phase}); }
        static Vector2 Center(RectTransform rt)
        { return RectTransformUtility.WorldToScreenPoint(null,rt.TransformPoint(rt.rect.center)); }
        static Button FindButton(string name)
        { return UnityEngine.Object.FindObjectsByType<Button>(FindObjectsSortMode.None).First(b=>b.name==name&&b.gameObject.activeInHierarchy); }
        static IEnumerator<float> Run()
        {
            SetSize(2340,1080);yield return 1;
            Check(Screen.width==2340&&Screen.height==1080,"Phone 19.5:9 resolution applied");
            Check(game.Hud.BlocksWorldInput&&game.Sim.Paused,"Welcome shields world and pauses time");
            game.Hud.ClosePanel();yield return .2f;
            Check(!game.Sim.Paused,"Welcome starts restaurant");
            ValidateButtons("2340x1080");
            var target=(Vector2)game.GameCamera.WorldToScreenPoint(new Vector3(7,.25f,7));
            Check(!game.PointerOnUI(target),"Restaurant floor is not blocked by UI");
            Touch(target,UnityEngine.InputSystem.TouchPhase.Began);yield return .15f;
            Touch(target,UnityEngine.InputSystem.TouchPhase.Ended);yield return .25f;
            Check(game.Sim.Actors[0].job=="move","Touch release creates walking job");
            var player=game.Sim.Actors[0];float x=player.x,z=player.z;yield return .4f;
            Check(Mathf.Abs(player.x-x)+Mathf.Abs(player.z-z)>.02f,"Player walks after touch");
            yield return 2;
            var pause=FindButton("II");var pausePoint=Center(pause.GetComponent<RectTransform>());
            Touch(pausePoint,UnityEngine.InputSystem.TouchPhase.Began);yield return .15f;
            Touch(pausePoint,UnityEngine.InputSystem.TouchPhase.Ended);yield return .25f;
            Check(game.Sim.Paused,"Touching pause button pauses simulation");
            Check(!game.TryMoveAt(pausePoint),"UI taps never move player");
            game.Sim.Paused=false;game.Hud.OpenPanel("Personel");yield return .2f;
            float before=game.Sim.Time;yield return .5f;
            Check(game.Sim.Paused&&Mathf.Abs(game.Sim.Time-before)<.001f,"Management freezes customer patience");
            var list=UnityEngine.Object.FindFirstObjectByType<ScrollRect>();
            Check(list.content.rect.height>list.viewport.rect.height,"Staff offers are scrollable");
            var swipe=Center(list.viewport);
            Touch(swipe,UnityEngine.InputSystem.TouchPhase.Began);yield return 1.1f;
            game.Save();yield return .15f;
            Touch(swipe+Vector2.up*220,UnityEngine.InputSystem.TouchPhase.Moved);yield return .15f;
            Touch(swipe+Vector2.up*360,UnityEngine.InputSystem.TouchPhase.Moved);yield return .15f;
            Touch(swipe+Vector2.up*360,UnityEngine.InputSystem.TouchPhase.Ended);yield return .25f;
            Check(list.content.anchoredPosition.y>20,"Touch swipe scrolls employee list");
            ScreenCapture.CaptureScreenshot(Path.GetFullPath("BurgerEmpire-Mobile-Personel.png"));yield return .3f;
            game.Hud.Back();yield return .2f;
            Check(!game.Hud.BlocksWorldInput&&!game.Sim.Paused,"Back closes panel and resumes prior running state");
            game.Hud.OpenPanel("Menü");game.Suspend();game.Hud.ClosePanel();yield return .2f;
            Check(game.Sim.Paused,"Returning from background requires explicit resume");
            var saved=JsonUtility.FromJson<BurgerEmpire.Core.Progress>(File.ReadAllText("BurgerEmpireMobileValidationSave.json"));
            Check(saved.coins==game.Sim.P.coins&&saved.tables==game.Sim.P.tables,"Background save preserves progression");
            game.Hud.OpenPanel("Menü");yield return .3f;
            var food=UnityEngine.Object.FindFirstObjectByType<RawImage>();
            Check(food&&food.texture&&food.texture.width>=512,"Generated meal artwork is loaded in the actual menu");
            ScreenCapture.CaptureScreenshot(Path.GetFullPath("BurgerEmpire-0.3-Menu.png"));yield return .3f;
            game.Hud.ClosePanel();game.Sim.Paused=false;
            for(int i=0;i<300&&!game.Sim.Customers.Any(c=>c.phase=="eating");i++){
                if(game.Sim.Actors[0].job=="")game.Command("next");yield return .2f;
            }
            game.Sim.Paused=true;
            Check(game.Sim.Customers.Any(c=>c.phase=="eating"),"Updated restaurant reaches a seated dining state");
            var dining=game.Sim.Customers.First(c=>c.phase=="eating");
            var world=GameObject.Find("Restaurant Environment").transform;
            Check(world.Find("Table_"+dining.table).Find("Meal").gameObject.activeSelf,"Served food appears on the customer's table");
            Check(world.Find("Street sign")&&world.Find("CookingSteam"),"Restaurant sign and cooking effect exist in rebuilt scene");
            ScreenCapture.CaptureScreenshot(Path.GetFullPath("BurgerEmpire-0.3-Restaurant.png"));yield return .3f;
            ScreenCapture.CaptureScreenshot(Path.GetFullPath("BurgerEmpire-Mobile-2340x1080.png"));yield return .3f;
            SetSize(1280,720);yield return .8f;ValidateButtons("1280x720");
            ScreenCapture.CaptureScreenshot(Path.GetFullPath("BurgerEmpire-Mobile-1280x720.png"));yield return .3f;
            SetSize(1080,2340);yield return .8f;ValidateButtons("1080x2340 portrait fallback");
            ScreenCapture.CaptureScreenshot(Path.GetFullPath("BurgerEmpire-Mobile-Portrait.png"));yield return .3f;
            SetSize(2340,1080);yield return .8f;
            Check(File.ReadAllText(originalSavePath)==disk,"Mobile scenarios preserve the player's save using an isolated test file");
            File.AppendAllText(Report,"Completed. Input injected through Unity Input System; physical Android device not tested.\n");
        }
        static void ValidateButtons(string label)
        {
            var safe=Screen.safeArea;var corners=new Vector3[4];
            foreach(var b in UnityEngine.Object.FindObjectsByType<Button>(FindObjectsSortMode.None)) {
                if(!b.gameObject.activeInHierarchy)continue;
                var rt=b.GetComponent<RectTransform>();rt.GetWorldCorners(corners);
                Check(corners[0].x>=safe.xMin-1&&corners[0].y>=safe.yMin-1&&corners[2].x<=safe.xMax+1&&corners[2].y<=safe.yMax+1,label+": "+b.name+" inside safe area");
                Check(rt.rect.height>=48,label+": "+b.name+" has touch height >=48 logical units");
            }
            Check(game.GameCamera.rect.width>0&&game.GameCamera.rect.height>0,label+": positive restaurant viewport");
        }
        // Editor-only preview helper. No reflection is used in the Android player.
        public static void SetSize(int width,int height)
        {
            var asm=typeof(UnityEditor.Editor).Assembly;
            var sizesType=asm.GetType("UnityEditor.GameViewSizes");
            var singleton=typeof(ScriptableSingleton<>).MakeGenericType(sizesType);
            var sizes=singleton.GetProperty("instance",BindingFlags.Public|BindingFlags.Static).GetValue(null);
            var groupType=asm.GetType("UnityEditor.GameViewSizeGroupType");
            var group=sizesType.GetMethod("GetGroup").Invoke(sizes,new[]{Enum.Parse(groupType,EditorUserBuildSettings.activeBuildTarget==BuildTarget.Android?"Android":"Standalone")});
            var sizeType=asm.GetType("UnityEditor.GameViewSize");var kind=asm.GetType("UnityEditor.GameViewSizeType");
            var newSize=Activator.CreateInstance(sizeType,new[]{Enum.Parse(kind,"FixedResolution"),(object)width,height,"Burger Empire "+width+"x"+height});
            group.GetType().GetMethod("AddCustomSize").Invoke(group,new[]{newSize});
            int count=(int)group.GetType().GetMethod("GetTotalCount").Invoke(group,null);
            var viewType=asm.GetType("UnityEditor.GameView");var view=EditorWindow.GetWindow(viewType);
            viewType.GetProperty("selectedSizeIndex",BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic).SetValue(view,count-1);
            view.maximized=true;view.Focus();view.Repaint();
        }
    }
}
#endif
