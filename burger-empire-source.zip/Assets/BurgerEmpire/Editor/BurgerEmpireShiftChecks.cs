#if UNITY_EDITOR && ENABLE_INPUT_SYSTEM
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using BurgerEmpire.Core;
using BurgerEmpire.Unity;
using UnityEditor;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.LowLevel;
using UnityEngine.UI;
using Progress=BurgerEmpire.Core.Progress;

namespace BurgerEmpire.Editor
{
    [InitializeOnLoad]
    public static class BurgerEmpireShiftChecks
    {
        const string Report="BurgerEmpireShiftChecks.txt",Pending="BurgerEmpire.ShiftChecks";
        const BindingFlags Private=BindingFlags.Instance|BindingFlags.NonPublic;
        static BurgerEmpireGame game;
        static Simulation original;
        static string disk,language,pref;
        static bool hadPref;
        static int lastEvent,nextFrame;
        static double next;
        static IEnumerator<float> steps;
        static Touchscreen touch;
        static InputSettings.BackgroundBehavior background;
        static InputSettings.EditorInputBehaviorInPlayMode routing;
        static BurgerEmpireShiftChecks(){EditorApplication.update+=Update;}
        static void Update()
        {
            if(EditorApplication.isCompiling||EditorApplication.isUpdating)return;
            if(File.Exists("BurgerEmpireShiftChecks.request")) {
                File.Delete("BurgerEmpireShiftChecks.request");File.WriteAllText(Report,"");SessionState.SetBool(Pending,true);
                if(!EditorApplication.isPlaying){BurgerEmpireSetup.Play();return;}
            }
            if(!EditorApplication.isPlaying||!SessionState.GetBool(Pending,false)||EditorApplication.timeSinceStartup<next||Time.frameCount<nextFrame)return;
            try {
                if(steps==null) {
                    game=UnityEngine.Object.FindFirstObjectByType<BurgerEmpireGame>();if(!game||game.Sim==null)return;
                    original=game.Sim;disk=File.ReadAllText("BurgerEmpireSave.json");language=Localization.Language;
                    hadPref=PlayerPrefs.HasKey("BurgerEmpire.Language");pref=PlayerPrefs.GetString("BurgerEmpire.Language");
                    lastEvent=(int)typeof(BurgerEmpireGame).GetField("lastEvent",Private).GetValue(game);
                    game.ValidationActive=true;
                    background=InputSystem.settings.backgroundBehavior;routing=InputSystem.settings.editorInputBehaviorInPlayMode;
                    InputSystem.settings.backgroundBehavior=InputSettings.BackgroundBehavior.IgnoreFocus;
                    InputSystem.settings.editorInputBehaviorInPlayMode=InputSettings.EditorInputBehaviorInPlayMode.AllDeviceInputAlwaysGoesToGameView;
                    touch=InputSystem.AddDevice<Touchscreen>();steps=Run();
                }
                if(steps.MoveNext()){next=EditorApplication.timeSinceStartup+steps.Current;nextFrame=Time.frameCount+3;}else Finish();
            }catch(Exception e){File.AppendAllText(Report,"FAIL: "+e+"\n");Finish();}
        }
        static void SetSimulation(Simulation s)
        {
            typeof(BurgerEmpireGame).GetProperty("Sim").SetValue(game,s);
            typeof(BurgerEmpireGame).GetField("lastEvent",Private).SetValue(game,s.Events.Count>0?s.Events.Last().id:0);
            typeof(RestaurantHud).GetField("toastTime",Private).SetValue(game.Hud,0f);
        }
        static void Check(bool pass,string message)
        {File.AppendAllText(Report,(pass?"PASS: ":"FAIL: ")+message+"\n");if(!pass)throw new Exception(message);}
        static Button Find(string name)=>UnityEngine.Object.FindObjectsByType<Button>(FindObjectsSortMode.None).First(b=>b.name==name&&b.gameObject.activeInHierarchy);
        static string Tab=>(string)typeof(RestaurantHud).GetField("tab",Private).GetValue(game.Hud);
        static Vector2 Center(RectTransform rt)=>RectTransformUtility.WorldToScreenPoint(null,rt.TransformPoint(rt.rect.center));
        static IEnumerator<float> Tap(string name)
        {
            var button=Find(name);var list=button.GetComponentInParent<ScrollRect>();
            if(list) {
                var rt=button.GetComponent<RectTransform>();float offset=-list.content.InverseTransformPoint(rt.TransformPoint(rt.rect.center)).y-list.viewport.rect.height*.5f;
                list.content.anchoredPosition=new Vector2(0,Mathf.Clamp(offset,0,Mathf.Max(0,list.content.rect.height-list.viewport.rect.height)));
                list.StopMovement();Canvas.ForceUpdateCanvases();yield return .12f;
            }
            var p=Center(button.GetComponent<RectTransform>());
            InputSystem.QueueStateEvent(touch,new TouchState{touchId=1,position=p,phase=UnityEngine.InputSystem.TouchPhase.Began});yield return .12f;
            InputSystem.QueueStateEvent(touch,new TouchState{touchId=1,position=p,phase=UnityEngine.InputSystem.TouchPhase.Ended});yield return .2f;
        }
        static IEnumerable<float> Wait(IEnumerator<float> steps){while(steps.MoveNext())yield return steps.Current;}
        static void Bounds(string context)
        {
            var safe=Screen.safeArea;var buttons=UnityEngine.Object.FindObjectsByType<Button>(FindObjectsSortMode.None).Where(b=>b.gameObject.activeInHierarchy).ToArray();
            var rects=new List<Rect>();var corners=new Vector3[4];
            foreach(var button in buttons) {
                var rt=button.GetComponent<RectTransform>();rt.GetWorldCorners(corners);
                var rect=new Rect(corners[0].x,corners[0].y,corners[2].x-corners[0].x,corners[2].y-corners[0].y);
                Check(rt.rect.width>=48&&rt.rect.height>=48&&rect.xMin>=safe.xMin-1&&rect.xMax<=safe.xMax+1&&rect.yMin>=safe.yMin-1&&rect.yMax<=safe.yMax+1,context+": "+button.name+" touch bounds");
                Check(rects.All(r=>!r.Overlaps(rect)),context+": "+button.name+" does not overlap another touch control");rects.Add(rect);
            }
            var overflow=UnityEngine.Object.FindObjectsByType<Text>(FindObjectsSortMode.None).Where(t=>t.gameObject.activeInHierarchy&&!t.resizeTextForBestFit&&t.preferredHeight>t.rectTransform.rect.height+2).Select(t=>t.text).ToArray();
            Check(overflow.Length==0,context+": readable text fits: "+string.Join(" | ",overflow));
            var view=game.GameCamera.pixelRect;
            if(safe.width>safe.height) {
                Check(view.width>=safe.width-1&&view.height/safe.height>=.70f,context+": restaurant spans full width and at least 70 percent of safe area");
                Check(buttons.All(b=>!view.Contains(Center(b.GetComponent<RectTransform>()))),context+": camera and service controls stay outside restaurant viewport");
            }
        }
        static IEnumerator<float> Run()
        {
            Directory.CreateDirectory("BurgerEmpireShifts-0.31");
            BurgerEmpireMobileChecks.SetSize(2340,1080);yield return .5f;
            if(game.Hud.BlocksWorldInput)game.Hud.ClosePanel();
            SetSimulation(new Simulation(new Progress{tutorialDone=true,coins=5000,xp=1400,tables=4,grill=3,fryer=2,cashier=2,cook=2,waiter=2,cleaner=1},39));
            game.SetLanguage("tr");game.Hud.StartGame();game.Sim.Paused=true;yield return .3f;
            foreach(var wait in Wait(Tap("Open management")))yield return wait;
            foreach(var wait in Wait(Tap("Management shift")))yield return wait;
            Check(Tab=="Hedef Vardiya"&&!game.Sim.P.shift.active,"Management opens target preview without starting automatically");
            ScreenCapture.CaptureScreenshot("BurgerEmpireShifts-0.31/Preview-tr.png");yield return .2f;
            int wallet=game.Sim.P.coins;
            foreach(var wait in Wait(Tap("Shift start")))yield return wait;
            Check(game.Sim.P.shift.active&&!game.Sim.Paused&&!game.Hud.BlocksWorldInput&&game.Sim.P.coins==wallet,"Real touch starts a target shift without an entry charge");
            float elapsed=game.Sim.P.shift.elapsed;yield return .35f;
            Check(game.Sim.P.shift.elapsed>elapsed,"Target timer advances during actual game frames");
            foreach(var wait in Wait(Tap("Open management")))yield return wait;
            elapsed=game.Sim.P.shift.elapsed;yield return .35f;
            Check(game.Sim.P.shift.elapsed==elapsed,"Management freezes target time");
            foreach(var wait in Wait(Tap("Management shift")))yield return wait;
            Check(!UnityEngine.Object.FindObjectsByType<Button>(FindObjectsSortMode.None).Any(b=>b.name=="Shift start"&&b.gameObject.activeInHierarchy),"Active target has resume instead of duplicate start");
            game.Suspend();game.Hud.ClosePanel();yield return .2f;
            Check(game.Sim.Paused&&game.Sim.P.shift.elapsed==elapsed,"Background and closing panel keep the target paused");
            var running=JsonUtility.FromJson<Progress>(JsonUtility.ToJson(game.Sim.P));SetSimulation(new Simulation(running));
            Check(game.Sim.P.shift.active&&game.Sim.P.shift.elapsed==elapsed,"Unity JSON round trip restores active target time");
            game.Sim.Paused=false;
            for(int i=0;i<1800;i++){if(game.Sim.Actors[0].job=="")game.Sim.Command("next");game.Sim.Tick(.1f);}
            yield return .3f;
            Check(Tab=="Hedef Vardiya"&&game.Sim.P.shift.pending&&game.Sim.Paused,"Completed target automatically opens paused result screen");
            Check(game.Sim.P.shift.served>0&&game.Sim.P.shift.earned>0&&game.Sim.P.shift.reviews>0,"Result reports actual simulated payments, income and customer reviews");
            wallet=game.Sim.P.coins;
            foreach(string lang in new[]{"tr","en"}) {
                game.SetLanguage(lang);
                foreach(var size in new[]{new Vector2Int(1920,1080),new Vector2Int(1080,2340)}) {
                    BurgerEmpireMobileChecks.SetSize(size.x,size.y);yield return .4f;
                    var labels=UnityEngine.Object.FindObjectsByType<Text>(FindObjectsSortMode.None).Where(t=>t.gameObject.activeInHierarchy&&!t.resizeTextForBestFit).ToArray();
                    Check(labels.All(t=>t.preferredHeight<=t.rectTransform.rect.height+2),lang+" "+size+": result text height fits");
                    if(lang=="en")Check(labels.All(t=>!System.Text.RegularExpressions.Regex.IsMatch(t.text,"[çğıöşüÇĞİÖŞÜ]")),"English result labels translated");
                    ScreenCapture.CaptureScreenshot("BurgerEmpireShifts-0.31/Result-"+lang+"-"+size.x+".png");yield return .2f;
                }
            }
            var completed=JsonUtility.FromJson<Progress>(JsonUtility.ToJson(game.Sim.P));SetSimulation(new Simulation(completed));game.Hud.OpenMainMenu();yield return .2f;
            game.Hud.StartGame();yield return .2f;
            Check(Tab=="Hedef Vardiya"&&game.Sim.P.shift.pending,"Continue after reload returns to unread result");
            foreach(var wait in Wait(Tap("Shift finish")))yield return wait;
            Check(!game.Sim.P.shift.pending&&!game.Hud.BlocksWorldInput&&!game.Sim.Paused&&game.Sim.P.coins==wallet,"Touch dismisses result and resumes without duplicate coins");
            game.Hud.OpenPanel("Hedef Vardiya");yield return .2f;
            Check(game.Sim.P.shift.finished&&Find("Shift start").interactable,"Last result remains reviewable and a new target can be started");
            game.Hud.Back();game.Sim.Paused=true;
            SetSimulation(new Simulation(new Progress()));game.Hud.OpenPanel("Hedef Vardiya");yield return .2f;
            Check(!UnityEngine.Object.FindObjectsByType<Button>(FindObjectsSortMode.None).Any(b=>b.name=="Shift start"&&b.gameObject.activeInHierarchy),"First-time player must finish teaching before target shifts");
            BurgerEmpireMobileChecks.SetSize(2340,1080);yield return .4f;
            Check(File.ReadAllText("BurgerEmpireSave.json")==disk,"Target UI checks never modify the real player save");
            File.AppendAllText(Report,"Completed. Actual touches, target timer, summary, TR/EN, restart and saved-progress isolation verified. Physical Android not tested.\n");
        }
        static void Finish()
        {
            if(touch!=null){InputSystem.RemoveDevice(touch);touch=null;}
            InputSystem.settings.backgroundBehavior=background;InputSystem.settings.editorInputBehaviorInPlayMode=routing;
            if(game&&original!=null) {
                SetSimulation(original);original.Paused=true;game.SetLanguage(language);
                if(hadPref)PlayerPrefs.SetString("BurgerEmpire.Language",pref);else PlayerPrefs.DeleteKey("BurgerEmpire.Language");PlayerPrefs.Save();
                game.ValidationActive=false;game.Hud.OpenMainMenu();
                typeof(BurgerEmpireGame).GetField("lastEvent",Private).SetValue(game,lastEvent);
            }
            original=null;steps=null;nextFrame=0;SessionState.SetBool(Pending,false);
        }
    }
}
#endif
