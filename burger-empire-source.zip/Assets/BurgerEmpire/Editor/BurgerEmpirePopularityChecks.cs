#if UNITY_EDITOR && ENABLE_INPUT_SYSTEM
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using BurgerEmpire.Core;
using BurgerEmpire.Unity;
using UnityEditor;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.LowLevel;
using UnityEngine.UI;
using Progress=BurgerEmpire.Core.Progress;

namespace BurgerEmpire.Editor
{
    [InitializeOnLoad]
    public static class BurgerEmpirePopularityChecks
    {
        const string Pending="BurgerEmpire.PopularityChecks",Report="BurgerEmpirePopularityChecks.txt";
        static IEnumerator<float> steps;
        static double next;
        static int nextFrame;
        static BurgerEmpireGame game;
        static Simulation original;
        static string disk;
        static string originalSavePath;
        static int lastEvent;
        static Touchscreen touch;
        static InputSettings.BackgroundBehavior background;
        static BurgerEmpirePopularityChecks(){EditorApplication.update+=Update;}
        static void Update()
        {
            if(EditorApplication.isCompiling||EditorApplication.isUpdating)return;
            if(File.Exists("BurgerEmpirePopularityChecks.request")) {
                try {File.Delete("BurgerEmpirePopularityChecks.request");} catch(IOException){return;}
                File.WriteAllText(Report,"");SessionState.SetBool(Pending,true);nextFrame=0;
                if(!EditorApplication.isPlaying){BurgerEmpireSetup.Play();return;}
            }
            if(!EditorApplication.isPlaying||!SessionState.GetBool(Pending,false)||EditorApplication.timeSinceStartup<next||Time.frameCount<nextFrame)return;
            try {
                if(steps==null) {
                    game=UnityEngine.Object.FindFirstObjectByType<BurgerEmpireGame>();if(!game||game.Sim==null)return;
                    original=game.Sim;disk=File.ReadAllText("BurgerEmpireSave.json");
                    originalSavePath=(string)typeof(BurgerEmpireGame).GetField("savePath",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).GetValue(game);
                    typeof(BurgerEmpireGame).GetField("savePath",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game,Path.GetFullPath("BurgerEmpirePopularityValidationSave.json"));
                    lastEvent=(int)typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).GetValue(game);
                    background=InputSystem.settings.backgroundBehavior;InputSystem.settings.backgroundBehavior=InputSettings.BackgroundBehavior.IgnoreFocus;
                    touch=InputSystem.AddDevice<Touchscreen>();steps=Run();
                }
                if(steps.MoveNext()){next=EditorApplication.timeSinceStartup+steps.Current;nextFrame=Time.frameCount+3;}else Finish();
            } catch(Exception e){File.AppendAllText(Report,"FAIL: "+e+"\n");Finish();}
        }
        static void SetSimulation(Simulation value)
        {
            typeof(BurgerEmpireGame).GetProperty("Sim").SetValue(game,value);
            typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game,0);
            typeof(RestaurantHud).GetField("toastTime",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game.Hud,0f);
        }
        static void Finish()
        {
            if(touch!=null){InputSystem.RemoveDevice(touch);touch=null;}InputSystem.settings.backgroundBehavior=background;
            if(game&&original!=null) {
                if(game.LayoutEditor.Active)game.Hud.FinishLayout(false);
                typeof(BurgerEmpireGame).GetField("savePath",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game,originalSavePath);
                SetSimulation(original);original.Paused=true;game.Save();game.Hud.OpenPanel("Popülerlik");
                typeof(BurgerEmpireGame).GetField("lastEvent",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(game,lastEvent);
            }
            steps=null;original=null;nextFrame=0;SessionState.SetBool(Pending,false);
        }
        static Progress Fixture()
        {
            return new Progress{coins=2000,xp=900,tables=2,grill=2,cook=1,tutorialDone=true};
        }
        static void Check(bool good,string message)
        {File.AppendAllText(Report,(good?"PASS: ":"FAIL: ")+message+"\n");if(!good)throw new Exception(message);}
        static Button Find(string name){return UnityEngine.Object.FindObjectsByType<Button>(FindObjectsSortMode.None).First(b=>b.name==name&&b.gameObject.activeInHierarchy);}
        static Vector2 Center(RectTransform rt){return RectTransformUtility.WorldToScreenPoint(null,rt.TransformPoint(rt.rect.center));}
        static void Touch(Vector2 p,UnityEngine.InputSystem.TouchPhase phase)
        {InputSystem.QueueStateEvent(touch,new TouchState{touchId=1,position=p,phase=phase});}
        static bool Until(Func<bool> condition,int limit=1000)
        {
            game.Sim.Paused=false;
            for(int i=0;i<limit&&!condition();i++){if(game.Sim.Actors[0].job=="")game.Sim.Command("next");game.Sim.Tick(.1f);}
            game.Sim.Paused=true;return condition();
        }
        static bool WaitOnly(Func<bool> condition,int limit=2000)
        {
            game.Sim.Paused=false;
            for(int i=0;i<limit&&!condition();i++)game.Sim.Tick(.1f);
            game.Sim.Paused=true;return condition();
        }


        static string Texts=>string.Join("\n",UnityEngine.Object.FindObjectsByType<Text>(FindObjectsSortMode.None).Where(t=>t.gameObject.activeInHierarchy).Select(t=>t.text));
        static ScrollRect List=>UnityEngine.Object.FindFirstObjectByType<ScrollRect>();
        static void Reveal(string name)
        {
            var target=Find(name).GetComponent<RectTransform>();
            List.StopMovement();List.content.anchoredPosition=new Vector2(0,Mathf.Max(0,-target.anchoredPosition.y-10));
        }
        static void Top(){List.StopMovement();List.verticalNormalizedPosition=1;}
        static void PayInfluencer()
        {
            int served=game.Sim.P.served;
            game.Sim.Customers.Add(new Customer{id=1001,kind=5,name="Can",phase="payment",order="served",table=0,price=32,maxPatience=100,patience=100});
            game.Sim.Tables[0].customer=1001;
            Check(Until(()=>game.Sim.P.served>served),"Real influencer payment completes through player collection and simulation ticks");
        }
        static void Bounds(string size)
        {
            var list=List;var points=new Vector3[4];list.viewport.GetWorldCorners(points);var safe=Screen.safeArea;
            Check(points[0].x>=safe.xMin&&points[2].x<=safe.xMax&&points[0].y>=safe.yMin&&points[2].y<=safe.yMax,size+": popularity viewport stays inside safe area");
            Check(list.content.rect.height>list.viewport.rect.height,size+": popularity explanations remain scrollable");
            Check(list.content.GetComponentsInChildren<Button>().All(b=>b.GetComponent<RectTransform>().rect.height>=48),size+": navigation actions have large touch targets");
            var overflow=list.content.GetComponentsInChildren<Text>().Where(t=>t.preferredHeight>t.rectTransform.rect.height+2).Select(t=>t.text.Replace("\n"," "));
            Check(!overflow.Any(),size+": popularity text fits its height: "+string.Join(" | ",overflow));
            Check(Find("×").GetComponent<RectTransform>().rect.height>=48,size+": close action remains reachable");
            var fill=GameObject.Find("Popularity fill").GetComponent<RectTransform>();
            Check(fill.rect.width>=0&&fill.rect.width<=list.content.rect.width-28+1,size+": popularity bar stays within track");
        }
        static IEnumerator<float> Run()
        {
            BurgerEmpireMobileChecks.SetSize(2340,1080);yield return .7f;
            if(game.LayoutEditor.Active)game.Hud.FinishLayout(false);
            if(game.Hud.BlocksWorldInput)game.Hud.ClosePanel();
            var old=JsonUtility.FromJson<Progress>(@"{""version"":9,""coins"":409,""xp"":2005,""served"":66,""tutorialDone"":true,""reviews"":[{""id"":67,""name"":""Can"",""kind"":5,""channel"":0,""completed"":true,""stars"":5}]}");
            SetSimulation(new Simulation(old));game.Hud.OpenPanel("Restoran");yield return .25f;
            Reveal("Open popularity");yield return .2f;
            var target=Center(Find("Open popularity").GetComponent<RectTransform>());
            Check(List.viewport.rect.Contains(List.viewport.InverseTransformPoint(target)),"Popularity entry can be reached in restaurant management scroll list");
            Touch(target,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;Touch(target,UnityEngine.InputSystem.TouchPhase.Ended);yield return .25f;
            Check(GameObject.Find("Popularity summary")&&game.Hud.BlocksWorldInput&&game.Sim.Paused,"Actual touch opens popularity screen and pauses the restaurant");
            Check(game.Sim.P.version==BurgerEmpire.Core.Progress.CurrentVersion&&game.Sim.P.coins==409&&game.Sim.P.xp==2005&&game.Sim.P.served==66,"Unity migration from missing popularity fields preserves player economy and sales");
            Check(game.Sim.P.popularity==0&&game.Sim.P.influencerShares==0&&!game.Sim.P.reviews[0].popularityRecorded,"Historic influencer reviews do not fabricate retroactive popularity");
            Check(Texts.Contains("0 / 100")&&Texts.Contains("Önceki yorumlar puana tekrar eklenmez"),"Empty popularity shows honest migration explanation");
            float time=game.Sim.Time;yield return .3f;Check(game.Sim.Time==time,"Reading popularity freezes customer time and patience");
            var sw=Center(List.viewport);Touch(sw,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;
            Touch(sw+Vector2.up*220,UnityEngine.InputSystem.TouchPhase.Moved);yield return .12f;
            Touch(sw+Vector2.up*440,UnityEngine.InputSystem.TouchPhase.Moved);yield return .12f;
            Touch(sw+Vector2.up*440,UnityEngine.InputSystem.TouchPhase.Ended);yield return .25f;
            Check(List.content.anchoredPosition.y>80,"Real finger swipe scrolls popularity explanations");
            Check(game.CameraControls.Zoom==1&&game.Sim.Actors[0].job=="","Popularity scrolling never zooms camera or moves the player");
            var fixture=new Progress{coins=2500,xp=900,served=30,popularity=72,influencerShares=3,tutorialDone=true};
            SetSimulation(new Simulation(fixture));PayInfluencer();game.Hud.RefreshPanel();Top();yield return .25f;
            Check(game.Sim.P.popularity==76&&game.Sim.P.influencerShares==4&&game.Sim.P.reviews.Last().popularityChange==4,"Actual satisfied influencer earns exactly four points and one share");
            Check(Texts.Contains("76 / 100")&&Texts.Contains("SALON TRAFİĞİ  +%19")&&Texts.Contains("INFLUENCER ŞANSI  %23"),"Panel presents score and the exact active traffic and customer probabilities");
            Check(Texts.Contains("Influencer paylaşımı +4"),"Last effect identifies actual influencer share");
            game.Save();var saved=JsonUtility.FromJson<Progress>(File.ReadAllText("BurgerEmpirePopularityValidationSave.json"));
            Check(saved.version==BurgerEmpire.Core.Progress.CurrentVersion&&saved.popularity==76&&saved.influencerShares==4&&saved.reviews.Last().popularityChange==4,"Isolated disk save includes local popularity and the review effect");
            SetSimulation(new Simulation(saved));game.Hud.RefreshPanel();yield return .2f;
            Check(game.Sim.P.popularity==76&&game.Sim.P.influencerShares==4,"Unity reload preserves reputation without reapplying the visit");
            Check(game.Sim.OpenLondon(out _),"Validated restaurant can open its London branch");game.Hud.RefreshPanel();Top();yield return .25f;
            Check(game.Sim.P.popularity==0&&Texts.Contains("Londra · Restoran popülerliği")&&Texts.Contains("0 / 10 ödeme"),"New London starts independently and explains introductory traffic protection");
            game.Sim.SwitchBranch(0,out _);game.Hud.RefreshPanel();Top();yield return .2f;
            Check(Texts.Contains("İstanbul · Restoran popülerliği")&&game.Sim.P.popularity==76&&game.Sim.P.influencerShares==4,"Returning to Istanbul restores its exact popularity and shares");
            game.Sim.RefreshDay("2099-05-01");game.Hud.RefreshPanel();yield return .2f;
            Check(game.Sim.P.popularity==76&&game.Sim.P.influencerShares==4,"A new day does not reset local popularity");
            Reveal("Popularity reviews");yield return .2f;target=Center(Find("Popularity reviews").GetComponent<RectTransform>());
            Touch(target,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;Touch(target,UnityEngine.InputSystem.TouchPhase.Ended);yield return .25f;
            Check(GameObject.Find("Review summary")&&Texts.Contains("Influencer paylaşımı +4"),"Touch navigation opens actual customer history with popularity effect");
            game.Hud.OpenPanel("Popülerlik");yield return .2f;Top();Bounds("2340x1080");
            ScreenCapture.CaptureScreenshot(Path.GetFullPath("BurgerEmpire-0.13-Popularity.png"));yield return .3f;
            BurgerEmpireMobileChecks.SetSize(1280,720);yield return .6f;Bounds("1280x720");
            BurgerEmpireMobileChecks.SetSize(1080,2340);yield return .6f;Bounds("1080x2340");Top();yield return .2f;
            ScreenCapture.CaptureScreenshot(Path.GetFullPath("BurgerEmpire-0.13-Portrait.png"));yield return .3f;
            Reveal("Popularity back");yield return .2f;target=Center(Find("Popularity back").GetComponent<RectTransform>());
            Touch(target,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;Touch(target,UnityEngine.InputSystem.TouchPhase.Ended);yield return .25f;
            Check(Find("Open popularity")&&game.Hud.BlocksWorldInput&&game.Sim.Paused,"Touch back returns to restaurant management without unpausing");
            SetSimulation(new Simulation(new Progress{tutorialDone=true,served=30,popularity=99}));PayInfluencer();game.Hud.OpenPanel("Popülerlik");yield return .2f;
            Check(Texts.Contains("100 / 100")&&Texts.Contains("Influencer paylaşımı +1"),"Capped score screen shows actual one-point gain instead of four");
            game.Hud.ClosePanel();game.Sim.Paused=false;game.Hud.OpenPanel("Popülerlik");yield return .2f;
            target=Center(Find("×").GetComponent<RectTransform>());Touch(target,UnityEngine.InputSystem.TouchPhase.Began);yield return .12f;Touch(target,UnityEngine.InputSystem.TouchPhase.Ended);yield return .25f;
            Check(!game.Hud.BlocksWorldInput&&!game.Sim.Paused,"Touch close restores a previously running shift");game.Sim.Paused=true;
            BurgerEmpireMobileChecks.SetSize(2340,1080);yield return .5f;
            Check(File.ReadAllText("BurgerEmpireSave.json")==disk,"Popularity fixture payments, purchases and saves never replace real player progress");
            File.AppendAllText(Report,"Completed. Unity touch, isolated disk save and JSON reload tested; physical Android not tested.\n");
        }
    }
}
#endif
