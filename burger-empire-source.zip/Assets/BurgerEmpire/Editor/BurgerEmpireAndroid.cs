#if UNITY_EDITOR
using System;
using System.IO;
using System.Text;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

namespace BurgerEmpire.Editor
{
    [InitializeOnLoad]
    public static class BurgerEmpireAndroid
    {
        const string Pending="BurgerEmpire.AndroidBuild";
        const string Request="BurgerEmpireAndroid.request";
        const string Status="BurgerEmpireAndroidBuild.txt";
        static bool building;
        static double nextCheck;
        static BurgerEmpireAndroid(){EditorApplication.update+=Check;}
        static void Check()
        {
            if(building||EditorApplication.isCompiling||EditorApplication.isUpdating||EditorApplication.isPlayingOrWillChangePlaymode||EditorApplication.timeSinceStartup<nextCheck)return;
            nextCheck=EditorApplication.timeSinceStartup+2;
            if(File.Exists(Request)) {
                string output=File.ReadAllText(Request).Trim();File.Delete(Request);
                try {output=AndroidReleasePlan.ValidateApkPath(output);Configure();}
                catch(Exception e){File.WriteAllText(Status,"FAILED: "+e.Message);SessionState.EraseString(Pending);return;}
                SessionState.SetString(Pending,output);
                File.WriteAllText(Status,"Switching to Android...\n"+DateTime.Now.ToString("O"));
            }
            if(SessionState.GetString(Pending,"")=="")return;
            if(EditorUserBuildSettings.activeBuildTarget!=BuildTarget.Android) {
                if(!EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTargetGroup.Android,BuildTarget.Android)) {
                    File.WriteAllText(Status,"FAILED: Android platform switch failed.");SessionState.EraseString(Pending);
                }
                return;
            }
            Build(SessionState.GetString(Pending,""));
        }
        [MenuItem("Burger Empire/Android/Yerel test APK oluştur")]
        public static void RequestBuild()
        {
            string path=EditorUtility.SaveFilePanel("Yerel test Android APK",Path.GetFullPath("Builds"),AndroidReleasePlan.ApkName,"apk");
            if(!string.IsNullOrEmpty(path))File.WriteAllText(Request,path);
        }
        public static void Configure()
        {
            AndroidReleasePlan.ValidateVersion(PlayerSettings.bundleVersion,PlayerSettings.Android.bundleVersionCode);
            PlayerSettings.companyName="Burger Empire";PlayerSettings.productName="Burger Empire";
            string package=PlayerSettings.GetApplicationIdentifier(NamedBuildTarget.Android);
            if(string.IsNullOrWhiteSpace(package))PlayerSettings.SetApplicationIdentifier(NamedBuildTarget.Android,AndroidReleasePlan.PackageOrDefault(package));
            PlayerSettings.bundleVersion=AndroidReleasePlan.Version;PlayerSettings.Android.bundleVersionCode=AndroidReleasePlan.VersionCode;
            PlayerSettings.Android.minSdkVersion=(AndroidSdkVersions)AndroidReleasePlan.MinApi;
            PlayerSettings.Android.targetSdkVersion=(AndroidSdkVersions)AndroidReleasePlan.TargetApi;
            PlayerSettings.Android.targetArchitectures=AndroidArchitecture.ARM64;
            PlayerSettings.SetScriptingBackend(NamedBuildTarget.Android,ScriptingImplementation.IL2CPP);
            PlayerSettings.SetManagedStrippingLevel(NamedBuildTarget.Android,ManagedStrippingLevel.Low);
            PlayerSettings.defaultInterfaceOrientation=UIOrientation.AutoRotation;
            PlayerSettings.allowedAutorotateToPortrait=false;PlayerSettings.allowedAutorotateToPortraitUpsideDown=false;
            PlayerSettings.allowedAutorotateToLandscapeLeft=true;PlayerSettings.allowedAutorotateToLandscapeRight=true;
            // Preserve the project's signing choice, aliases and credentials.
            PlayerSettings.Android.renderOutsideSafeArea=true;
            PlayerSettings.SetUseDefaultGraphicsAPIs(BuildTarget.Android,false);
            PlayerSettings.SetGraphicsAPIs(BuildTarget.Android,new[]{GraphicsDeviceType.OpenGLES3});
            EditorUserBuildSettings.buildAppBundle=false;EditorUserBuildSettings.exportAsGoogleAndroidProject=false;
            var mobile=AssetDatabase.LoadAssetAtPath<UniversalRenderPipelineAsset>("Assets/Settings/Mobile_RPAsset.asset");
            if(mobile){mobile.supportsHDR=false;mobile.msaaSampleCount=2;mobile.renderScale=1;mobile.shadowDistance=35;EditorUtility.SetDirty(mobile);}
            AssetDatabase.SaveAssets();
        }
        static void Build(string output)
        {
            building=true;SessionState.EraseString(Pending);
            try {
                // Platform switching can reload the previous PlayerSettings. Apply
                // the final values after the switch, immediately before the build.
                output=AndroidReleasePlan.ValidateApkPath(output);Configure();
                Directory.CreateDirectory(Path.GetDirectoryName(output));
                File.WriteAllText(Status,"Building ARM64 APK...\n"+DateTime.Now.ToString("O")+"\n"+PlayerSettings.productName+" "+PlayerSettings.bundleVersion+"\n"+PlayerSettings.GetApplicationIdentifier(NamedBuildTarget.Android));
                var report=BuildPipeline.BuildPlayer(new BuildPlayerOptions {
                    scenes=new[]{AndroidReleasePlan.Scene},locationPathName=output,
                    target=BuildTarget.Android,targetGroup=BuildTargetGroup.Android,options=BuildOptions.None
                });
                var text=new StringBuilder();
                text.AppendLine(report.summary.result.ToString());text.AppendLine("Output: "+report.summary.outputPath);
                text.AppendLine("Size: "+report.summary.totalSize);text.AppendLine("Time: "+report.summary.totalTime);
                text.AppendLine("Errors: "+report.summary.totalErrors+"; Warnings: "+report.summary.totalWarnings);
                text.AppendLine("Product: "+PlayerSettings.productName+" "+PlayerSettings.bundleVersion);
                text.AppendLine("Package: "+PlayerSettings.GetApplicationIdentifier(NamedBuildTarget.Android));
                foreach(var step in report.steps)foreach(var message in step.messages)
                    if(message.type==LogType.Error||message.type==LogType.Exception||message.type==LogType.Warning)text.AppendLine(message.content);
                File.WriteAllText(Status,text.ToString());
            } catch(Exception e){File.WriteAllText(Status,"FAILED\n"+e);Debug.LogException(e);}
            finally {building=false;}
        }
    }
}
#endif
