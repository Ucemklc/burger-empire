#if UNITY_EDITOR && ENABLE_INPUT_SYSTEM
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using BurgerEmpire.Core;
using BurgerEmpire.Unity;
using UnityEditor;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.LowLevel;
using UnityEngine.UI;
using Progress=BurgerEmpire.Core.Progress;

namespace BurgerEmpire.Editor
{
    [InitializeOnLoad]
    public static class BurgerEmpireCompactHudChecks
    {
        const string Report="BurgerEmpireCompactHudChecks.txt",Pending="BurgerEmpire.CompactHudChecks";
        const BindingFlags Private=BindingFlags.Instance|BindingFlags.NonPublic;
        static BurgerEmpireGame game;
        static Simulation original;
        static string disk,language,pref;
        static bool hadPref;
        static int lastEvent,nextFrame;
        static double next;
        static IEnumerator<float> steps;
        static Touchscreen touch;
        static InputSettings.BackgroundBehavior background;
        static InputSettings.EditorInputBehaviorInPlayMode routing;
        static BurgerEmpireCompactHudChecks(){EditorApplication.update+=Update;}
        static void Update()
        {
            if(EditorApplication.isCompiling||EditorApplication.isUpdating)return;
            if(File.Exists("BurgerEmpireCompactHudChecks.request")) {
                File.Delete("BurgerEmpireCompactHudChecks.request");File.WriteAllText(Report,"");SessionState.SetBool(Pending,true);
                if(!EditorApplication.isPlaying){BurgerEmpireSetup.Play();return;}
            }
            if(!EditorApplication.isPlaying||!SessionState.GetBool(Pending,false)||EditorApplication.timeSinceStartup<next||Time.frameCount<nextFrame)return;
            try {
                if(steps==null) {
                    game=UnityEngine.Object.FindFirstObjectByType<BurgerEmpireGame>();if(!game||game.Sim==null)return;
                    original=game.Sim;disk=File.ReadAllText("BurgerEmpireSave.json");language=Localization.Language;
                    hadPref=PlayerPrefs.HasKey("BurgerEmpire.Language");pref=PlayerPrefs.GetString("BurgerEmpire.Language");
                    lastEvent=(int)typeof(BurgerEmpireGame).GetField("lastEvent",Private).GetValue(game);
                    game.ValidationActive=true;
                    background=InputSystem.settings.backgroundBehavior;routing=InputSystem.settings.editorInputBehaviorInPlayMode;
                    InputSystem.settings.backgroundBehavior=InputSettings.BackgroundBehavior.IgnoreFocus;
                    InputSystem.settings.editorInputBehaviorInPlayMode=InputSettings.EditorInputBehaviorInPlayMode.AllDeviceInputAlwaysGoesToGameView;
                    touch=InputSystem.AddDevice<Touchscreen>();steps=Run();
                }
                if(steps.MoveNext()){next=EditorApplication.timeSinceStartup+steps.Current;nextFrame=Time.frameCount+3;}else Finish();
            }catch(Exception e){File.AppendAllText(Report,"FAIL: "+e+"\n");Finish();}
        }
        static void SetSimulation(Simulation s)
        {
            typeof(BurgerEmpireGame).GetProperty("Sim").SetValue(game,s);
            typeof(BurgerEmpireGame).GetField("lastEvent",Private).SetValue(game,s.Events.Count>0?s.Events.Last().id:0);
            typeof(RestaurantHud).GetField("toastTime",Private).SetValue(game.Hud,0f);
        }
        static void Check(bool pass,string message)
        {File.AppendAllText(Report,(pass?"PASS: ":"FAIL: ")+message+"\n");if(!pass)throw new Exception(message);}
        static Button Find(string name)=>UnityEngine.Object.FindObjectsByType<Button>(FindObjectsSortMode.None).First(b=>b.name==name&&b.gameObject.activeInHierarchy);
        static string Tab=>(string)typeof(RestaurantHud).GetField("tab",Private).GetValue(game.Hud);
        static Vector2 Center(RectTransform rt)=>RectTransformUtility.WorldToScreenPoint(null,rt.TransformPoint(rt.rect.center));
        static IEnumerator<float> Tap(string name)
        {
            var button=Find(name);var list=button.GetComponentInParent<ScrollRect>();
            if(list) {
                var rt=button.GetComponent<RectTransform>();float offset=-list.content.InverseTransformPoint(rt.TransformPoint(rt.rect.center)).y-list.viewport.rect.height*.5f;
                list.content.anchoredPosition=new Vector2(0,Mathf.Clamp(offset,0,Mathf.Max(0,list.content.rect.height-list.viewport.rect.height)));
                list.StopMovement();Canvas.ForceUpdateCanvases();yield return .12f;
            }
            var p=Center(button.GetComponent<RectTransform>());
            InputSystem.QueueStateEvent(touch,new TouchState{touchId=1,position=p,phase=UnityEngine.InputSystem.TouchPhase.Began});yield return .12f;
            InputSystem.QueueStateEvent(touch,new TouchState{touchId=1,position=p,phase=UnityEngine.InputSystem.TouchPhase.Ended});yield return .2f;
        }
        static IEnumerable<float> Wait(IEnumerator<float> steps){while(steps.MoveNext())yield return steps.Current;}
        static void Bounds(string context)
        {
            var safe=Screen.safeArea;var buttons=UnityEngine.Object.FindObjectsByType<Button>(FindObjectsSortMode.None).Where(b=>b.gameObject.activeInHierarchy).ToArray();
            var rects=new List<Rect>();var corners=new Vector3[4];
            foreach(var button in buttons) {
                var rt=button.GetComponent<RectTransform>();rt.GetWorldCorners(corners);
                var rect=new Rect(corners[0].x,corners[0].y,corners[2].x-corners[0].x,corners[2].y-corners[0].y);
                Check(rt.rect.width>=48&&rt.rect.height>=48&&rect.xMin>=safe.xMin-1&&rect.xMax<=safe.xMax+1&&rect.yMin>=safe.yMin-1&&rect.yMax<=safe.yMax+1,context+": "+button.name+" touch bounds");
                Check(rects.All(r=>!r.Overlaps(rect)),context+": "+button.name+" does not overlap another touch control");rects.Add(rect);
            }
            var overflow=UnityEngine.Object.FindObjectsByType<Text>(FindObjectsSortMode.None).Where(t=>t.gameObject.activeInHierarchy&&!t.resizeTextForBestFit&&t.preferredHeight>t.rectTransform.rect.height+2).Select(t=>t.text).ToArray();
            Check(overflow.Length==0,context+": readable text fits: "+string.Join(" | ",overflow));
            var view=game.GameCamera.pixelRect;
            if(safe.width>safe.height) {
                Check(view.width>=safe.width-1&&view.height/safe.height>=.70f,context+": restaurant spans full width and at least 70 percent of safe area");
                Check(buttons.All(b=>!view.Contains(Center(b.GetComponent<RectTransform>()))),context+": camera and service controls stay outside restaurant viewport");
            }
        }
        static IEnumerator<float> Run()
        {
            Directory.CreateDirectory("BurgerEmpireCompactHud-0.30");
            if(game.Hud.BlocksWorldInput)game.Hud.ClosePanel();
            var s=new Simulation(new Progress{coins=5000,xp=1400,tutorialDone=true,tables=4,grill=2,fryer=1,blender=1,cashier=1,cook=1,waiter=1,cleaner=1,decor=1,driveThru=1,delivery=1},39);
            s.Paused=false;for(int i=0;i<700;i++)s.Tick(.1f);s.Paused=true;SetSimulation(s);
            game.Hud.StartGame();s.Paused=true;
            foreach(string lang in new[]{"tr","en"}) {
                game.SetLanguage(lang);
                foreach(var size in new[]{new Vector2Int(2340,1080),new Vector2Int(1920,1080),new Vector2Int(1280,720),new Vector2Int(1024,768),new Vector2Int(1080,2340)}) {
                    BurgerEmpireMobileChecks.SetSize(size.x,size.y);yield return .4f;
                    Bounds(lang+" "+size.x+"x"+size.y);
                    Check(Find("Open management").GetComponentInChildren<Text>().text==Localization.Text("Yönetim"),lang+": management entry uses selected language");
                    ScreenCapture.CaptureScreenshot("BurgerEmpireCompactHud-0.30/"+lang+"-"+size.x+"x"+size.y+".png");yield return .15f;
                }
            }
            BurgerEmpireMobileChecks.SetSize(2340,1080);game.SetLanguage("tr");yield return .4f;
            s.Paused=false;
            foreach(var wait in Wait(Tap("Open management")))yield return wait;
            Check(Tab=="Yönetim"&&s.Paused&&game.Hud.BlocksWorldInput,"Touch opens management, pauses customer patience and shields restaurant");
            float time=s.Time;yield return .25f;Check(s.Time==time,"Management browsing does not advance the shift");
            ScreenCapture.CaptureScreenshot("BurgerEmpireCompactHud-0.30/Management.png");yield return .2f;
            foreach(string destination in new[]{"Restoran","Geliştir","Personel","Menü","Görevler","Ayarlar"}) {
                foreach(var wait in Wait(Tap("Management "+destination)))yield return wait;
                Check(Tab==destination&&s.Paused,"Touch reaches "+destination+" without resuming time");
                foreach(var wait in Wait(Tap("Management back")))yield return wait;
                Check(Tab=="Yönetim"&&s.Paused,"Back arrow returns from "+destination+" to management");
            }
            Check(!game.TryMoveAt(game.GameCamera.pixelRect.center),"Management shield prevents accidental walking");
            game.Hud.Back();yield return .2f;Check(!game.Hud.BlocksWorldInput&&!s.Paused,"Android Back closes management and restores running shift");
            s.Paused=true;
            foreach(var wait in Wait(Tap("Open management")))yield return wait;
            game.Hud.Back();yield return .2f;Check(s.Paused,"Opening and closing management keeps a previously paused shift paused");
            s.Paused=false;game.Hud.OpenPanel("Yönetim");game.Suspend();game.Hud.ClosePanel();yield return .2f;
            Check(s.Paused,"Backgrounding while browsing does not resume the shift on return");
            SetSimulation(new Simulation(new Progress()));game.Hud.StartGame();yield return .15f;game.Sim.Paused=true;yield return .15f;
            Bounds("first-shift tutorial");
            game.Hud.OpenPanel("Yönetim");BurgerEmpireMobileChecks.SetSize(1080,2340);yield return .4f;
            Check(Tab=="Yönetim"&&game.Sim.Paused,"Rotation keeps management open and paused");
            foreach(var wait in Wait(Tap("Management Personel")))yield return wait;
            Check(Tab=="Personel","Portrait management remains touch accessible");
            BurgerEmpireMobileChecks.SetSize(2340,1080);yield return .4f;
            Check(File.ReadAllText("BurgerEmpireSave.json")==disk,"Compact UI and navigation checks preserve the actual player save");
            File.AppendAllText(Report,"Completed. Compact HUD, actual Input System touches, TR/EN and five sizes verified. Physical Android not tested.\n");
        }
        static void Finish()
        {
            if(touch!=null){InputSystem.RemoveDevice(touch);touch=null;}
            InputSystem.settings.backgroundBehavior=background;InputSystem.settings.editorInputBehaviorInPlayMode=routing;
            if(game&&original!=null) {
                SetSimulation(original);original.Paused=true;game.SetLanguage(language);
                if(hadPref)PlayerPrefs.SetString("BurgerEmpire.Language",pref);else PlayerPrefs.DeleteKey("BurgerEmpire.Language");PlayerPrefs.Save();
                game.ValidationActive=false;game.Hud.OpenMainMenu();
                typeof(BurgerEmpireGame).GetField("lastEvent",Private).SetValue(game,lastEvent);
            }
            original=null;steps=null;nextFrame=0;SessionState.SetBool(Pending,false);
        }
    }
}
#endif
