using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using BurgerEmpire.Core;
using UnityEngine;
using UnityEngine.EventSystems;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.UI;
#endif

namespace BurgerEmpire.Unity
{
    public sealed class BurgerEmpireGame : MonoBehaviour
    {
        public Simulation Sim { get; private set; }
        public Camera GameCamera { get; private set; }
        public RestaurantHud Hud { get; private set; }
        public RestaurantLayoutEditor LayoutEditor { get; private set; }
        public RestaurantCamera CameraControls { get; private set; }
        LayoutAppearance layoutAppearance;
        MenuPresentation menuPresentation;
        BranchPresentation branchPresentation;
        DriveThruPresentation drivePresentation;
        DeliveryPresentation deliveryPresentation;
        RestaurantPolish restaurantPolish;
        RestaurantOperations operations;
        Simulation visualSimulation;
        int visualBranchRevision=-1;
        public bool SoundEnabled = true;
        public float MusicVolume {get;private set;}=.55f;
        public float EffectsVolume {get;private set;}=1;
#if UNITY_EDITOR
        public bool ValidationActive { get; set; }
        public RewardedAdsTest RewardTest {get;private set;}=new RewardedAdsTest();
#endif
        Transform environment, people;
        readonly Dictionary<string, RestaurantArt.Person> actors = new Dictionary<string, RestaurantArt.Person>();
        readonly Dictionary<int, RestaurantArt.Person> customers = new Dictionary<int, RestaurantArt.Person>();
        readonly Dictionary<int,Stack<RestaurantArt.Person>> pools = new Dictionary<int,Stack<RestaurantArt.Person>>();
        readonly List<RaycastResult> uiHits = new List<RaycastResult>();
        readonly List<int> expired = new List<int>();
        readonly Transform[] tableVisuals=new Transform[4], tablePads=new Transform[4], grillVisuals=new Transform[3];
        Transform extraDecor, cookingSteam;
        Vector2 touchStart;
        bool touchAllowed;
        float lastTouchTime=-10;
        RestaurantAudio restaurantAudio;
        int lastEvent;
        float saveIn=5;
        string savePath;
        ProgressStore progressStore;
        public SessionMeasurements Session {get;private set;}=new SessionMeasurements();
        public bool SaveBlocked {get{return progressStore!=null&&progressStore.Blocked;}}
        public string SaveState {get{return progressStore?.State??"new";}}
        public string SaveRecovery {get{return progressStore?.Recovery??"";}}
        public string LastSaveTime {get{return progressStore?.LastSaved?.ToString("HH:mm:ss")??"—";}}
        static string PreferenceKey(string key)
        {
#if UNITY_EDITOR
            return EditorPlaytestSession.PreferenceKey(key);
#else
            return key;
#endif
        }
        ProgressStore Store()
        {
            if(progressStore==null||progressStore.Path!=savePath){progressStore=new ProgressStore(savePath,JsonUtility.FromJson<Progress>,p=>JsonUtility.ToJson(p,true));progressStore.Load();}
            return progressStore;
        }
        void LoadProgress(){progressStore=new ProgressStore(savePath,JsonUtility.FromJson<Progress>,p=>JsonUtility.ToJson(p,true));Sim=new Simulation(progressStore.Load());Sim.Paused=true;}
        public void RetrySave()
        {
            if(SaveBlocked){LoadProgress();lastEvent=0;Session=new SessionMeasurements();}
            if(!SaveBlocked)Save();
            Hud.RefreshPanel();
        }

        void Awake()
        {
            Application.targetFrameRate=60;
            Application.runInBackground=false;
            QualitySettings.vSyncCount=0;
            SoundEnabled=PlayerPrefs.GetInt(PreferenceKey("BurgerEmpire.Sound"),1)!=0;
            Localization.SetLanguage(PlayerPrefs.GetString(PreferenceKey("BurgerEmpire.Language"),"tr"));
            MusicVolume=MusicDesign.Volume(PlayerPrefs.GetFloat(PreferenceKey("BurgerEmpire.MusicVolume"),.55f),.55f);
            EffectsVolume=MusicDesign.Volume(PlayerPrefs.GetFloat(PreferenceKey("BurgerEmpire.EffectsVolume"),1));
            savePath=Path.Combine(Application.isEditor?Path.GetFullPath(Path.Combine(Application.dataPath,"..")):Application.persistentDataPath,"BurgerEmpireSave.json");
#if UNITY_EDITOR
            savePath=EditorPlaytestSession.ResolveSavePath(savePath);
#endif
            LoadProgress();
            var existing=GameObject.Find("Restaurant Environment"); environment=existing?existing.transform:RestaurantArt.BuildWorld();
            for(int i=0;i<4;i++){tableVisuals[i]=environment.Find("Table_"+i);tablePads[i]=environment.Find("TablePad_"+i);}
            for(int i=0;i<3;i++)grillVisuals[i]=environment.Find("Grill_"+i);
            extraDecor=environment.Find("ExtraDecor");
            cookingSteam=environment.Find("CookingSteam");
            people=RestaurantArt.Group("Living Restaurant",transform,Vector3.zero);
            GameCamera=Camera.main;
            if(!GameCamera) { var go=new GameObject("Main Camera"); go.tag="MainCamera"; GameCamera=go.AddComponent<Camera>(); }
            ConfigureCamera(GameCamera);
            LayoutEditor=new RestaurantLayoutEditor(this);layoutAppearance=new LayoutAppearance(environment);
            CameraControls=new RestaurantCamera(this);
            menuPresentation=new MenuPresentation(environment);
            branchPresentation=new BranchPresentation(environment);
            drivePresentation=new DriveThruPresentation(environment);
            deliveryPresentation=new DeliveryPresentation(environment);
            if(!FindFirstObjectByType<Light>()) CreateLighting();
            restaurantPolish=new RestaurantPolish(environment);
            operations=new RestaurantOperations(environment);
            RestaurantFinishes.Apply(environment);
            RestaurantDressing.Apply(environment);
            foreach(var label in environment.GetComponentsInChildren<TextMesh>(true))if(!label.GetComponent<LocalizedWorldText>())label.gameObject.AddComponent<LocalizedWorldText>();
            if(!GameCamera.GetComponent<AudioListener>()) GameCamera.gameObject.AddComponent<AudioListener>();
            if(!FindFirstObjectByType<EventSystem>()) {
                var ev=new GameObject("Event System"); ev.AddComponent<EventSystem>();
#if ENABLE_INPUT_SYSTEM
                ev.AddComponent<InputSystemUIInputModule>();
#else
                ev.AddComponent<StandaloneInputModule>();
#endif
            }
            restaurantAudio=new RestaurantAudio(gameObject);restaurantAudio.SetEnabled(SoundEnabled);
            restaurantAudio.SetVolumes(MusicVolume,EffectsVolume);
            Hud=gameObject.AddComponent<RestaurantHud>(); Hud.Initialize(this);
            SyncVisuals();
            Debug.Log("BURGER_EMPIRE_READY: Unity sahnesi ve simülasyon başlatıldı.");
        }
        public static void ConfigureCamera(Camera cam)
        {
            cam.orthographic=true; cam.orthographicSize=8.3f;
            cam.transform.position=new Vector3(18,17,21);
            cam.transform.LookAt(new Vector3(4.8f,.3f,4.3f));
            cam.clearFlags=CameraClearFlags.SolidColor; cam.backgroundColor=RestaurantArt.Hex("A5B49A");
            cam.nearClipPlane=.1f; cam.farClipPlane=120; cam.allowHDR=false;
        }
        public static void CreateLighting()
        {
            RenderSettings.ambientMode=UnityEngine.Rendering.AmbientMode.Flat;
            RenderSettings.ambientLight=new Color(.55f,.60f,.64f);
            var go=new GameObject("Warm afternoon sun"); var sun=go.AddComponent<Light>(); sun.type=LightType.Directional;
            sun.color=new Color(1,.97f,.91f); sun.intensity=1.1f; sun.shadows=LightShadows.Soft;
            go.transform.rotation=Quaternion.Euler(50,-30,0); sun.shadowBias=.04f;
        }
        void Update()
        {
#if UNITY_EDITOR
            RewardTest.Flow.Tick(UnityEngine.Time.unscaledDeltaTime);
            if(RewardTest.Flow.Busy)Sim.Paused=true;
#endif
            if(SaveBlocked)Sim.Paused=true;
            var before=SessionMeasurements.Capture(Sim.P);float beforeTime=Sim.Time;
            Sim.Tick(UnityEngine.Time.deltaTime);
#if UNITY_EDITOR
            if(!ValidationActive)
#endif
            Session.Record(Sim.Time-beforeTime,before,SessionMeasurements.Capture(Sim.P));
            SyncVisuals();
            HandleInput();
            saveIn-=UnityEngine.Time.unscaledDeltaTime;
            if(saveIn<=0) { Sim.RefreshDay(DateTime.Now.ToString("yyyy-MM-dd")); Save(); saveIn=5; }
            restaurantAudio.Sync(Sim);PresentEvents();
        }
        void PresentEvents()
        {
            var e=FeedbackSignals.Consume(Sim.Events,ref lastEvent);
            if(e==null)return;
            Hud.Toast(e.text,e.kind);restaurantAudio.Play(e.kind);
        }
        void HandleInput()
        {
            bool cameraInput=CameraControls.HandleInput();
            if(cameraInput)touchAllowed=false;
            if(LayoutEditor.Active){LayoutEditor.HandleInput();return;}
            string command=null;
#if ENABLE_INPUT_SYSTEM
            var k=Keyboard.current;
            if(k!=null) {
                if(k.escapeKey.wasPressedThisFrame){Hud.Back();return;}
                if(Hud.BlocksWorldInput)return;
                if(k.digit1Key.wasPressedThisFrame) command="order";
                if(k.digit2Key.wasPressedThisFrame) command="cook";
                if(k.digit3Key.wasPressedThisFrame) command="serve";
                if(k.digit4Key.wasPressedThisFrame) command="collect";
                if(k.digit5Key.wasPressedThisFrame) command="clean";
                if(k.eKey.wasPressedThisFrame) command="next";
                if(k.spaceKey.wasPressedThisFrame) command="pause";
            }
            var screenTouch=Touchscreen.current;
            if(screenTouch!=null) {
                var touch=screenTouch.primaryTouch;
                if(touch.press.wasPressedThisFrame) {
                    lastTouchTime=Time.unscaledTime;touchStart=touch.position.ReadValue();
                    touchAllowed=!cameraInput&&!Hud.BlocksWorldInput&&!PointerOnUI(touchStart)&&GameCamera.pixelRect.Contains(touchStart);
                }
                if(touch.press.isPressed)lastTouchTime=Time.unscaledTime;
                if(touch.press.wasReleasedThisFrame) {
                    lastTouchTime=Time.unscaledTime;
                    Vector2 end=touch.position.ReadValue();
                    float tolerance=Mathf.Max(16,Mathf.Min(Screen.width,Screen.height)*.035f);
                    if(touchAllowed && touch.phase.ReadValue()!=UnityEngine.InputSystem.TouchPhase.Canceled && Vector2.Distance(touchStart,end)<tolerance)TryMoveAt(end);
                    touchAllowed=false;
                }
            }
            if(!cameraInput&&Mouse.current!=null&&Time.unscaledTime-lastTouchTime>.25f&&Mouse.current.leftButton.wasPressedThisFrame)TryMoveAt(Mouse.current.position.ReadValue());
#else
            if(Input.GetKeyDown(KeyCode.Alpha1)) command="order";
            if(Input.GetKeyDown(KeyCode.Alpha2)) command="cook";
            if(Input.GetKeyDown(KeyCode.Alpha3)) command="serve";
            if(Input.GetKeyDown(KeyCode.Alpha4)) command="collect";
            if(Input.GetKeyDown(KeyCode.Alpha5)) command="clean";
            if(Input.GetKeyDown(KeyCode.E)) command="next";
            if(Input.GetKeyDown(KeyCode.Space)) command="pause";
#endif
            if(command!=null) Command(command);
        }
        public void Command(string action,string id="",float x=0,float z=0)
        {
            if(SaveBlocked){Hud.OpenPanel("Kayıt ve Oturum");return;}
            if(LayoutEditor.Active)return;
            if(Hud.BlocksWorldInput && action!="buy" && action!="claim" && action!="achieve")return;
            string message=Sim.Command(action,id,x,z);
            if(message!="") Hud.Toast(message);
            if(Sim.Events.Any(e=>e.id>lastEvent))PresentEvents();else restaurantAudio.Play("click");
            if(action=="buy"||action=="claim"||action=="achieve")Save();
            Hud.RefreshPanel();
        }
        public void ChooseServicePriority(int mode)
        {
            if(LayoutEditor.Active||SaveBlocked)return;
            if(Sim.SetServicePriority(mode,out string message))Save();
            Hud.Toast(message);Hud.RefreshPanel();
        }
        public void VisitBranch(int id)
        {
            if(LayoutEditor.Active||SaveBlocked)return;
            bool changed=Sim.SwitchBranch(id,out string message);
            if(changed){touchAllowed=false;SyncVisuals();Save();Hud.OpenPanel("Şubeler");}
            Hud.Toast(message);
        }
        public void OpenLondon()
        {
            if(LayoutEditor.Active||SaveBlocked)return;
            bool opened=Sim.OpenLondon(out string message);
            if(opened){touchAllowed=false;SyncVisuals();Save();Hud.OpenPanel("Şubeler");}
            Hud.Toast(message);
        }
        public bool PointerOnUI(Vector2 screen)
        {
            if(EventSystem.current==null)return false;
            uiHits.Clear();EventSystem.current.RaycastAll(new PointerEventData(EventSystem.current){position=screen},uiHits);
            return uiHits.Count>0;
        }
        public bool TryMoveAt(Vector2 screen)
        {
            if(Sim.Paused||Hud.BlocksWorldInput||PointerOnUI(screen)||!GameCamera.pixelRect.Contains(screen))return false;
            var plane=new Plane(Vector3.up,new Vector3(0,.25f,0));var ray=GameCamera.ScreenPointToRay(screen);
            if(!plane.Raycast(ray,out float distance))return false;
            Vector3 p=ray.GetPoint(distance);
            if(!WorkZones.OnFloor(p.x,p.z))return false;
            Command("move","",p.x,p.z);return true;
        }
        public void SetSound(bool enabled)
        {
            SoundEnabled=enabled;restaurantAudio?.SetEnabled(enabled);PlayerPrefs.SetInt(PreferenceKey("BurgerEmpire.Sound"),enabled?1:0);PlayerPrefs.Save();
        }
        public void UiClick(){restaurantAudio?.Play("click");}
        public void SetLanguage(string code)
        {
            Localization.SetLanguage(code);PlayerPrefs.SetString(PreferenceKey("BurgerEmpire.Language"),Localization.Language);PlayerPrefs.Save();Hud?.LanguageChanged();
        }
        public void SetAudioLevels(float music,float effects)
        {
            MusicVolume=MusicDesign.Volume(music,.55f);EffectsVolume=MusicDesign.Volume(effects);
            restaurantAudio?.SetVolumes(MusicVolume,EffectsVolume);
            PlayerPrefs.SetFloat(PreferenceKey("BurgerEmpire.MusicVolume"),MusicVolume);PlayerPrefs.SetFloat(PreferenceKey("BurgerEmpire.EffectsVolume"),EffectsVolume);PlayerPrefs.Save();
            Hud?.RefreshPanel();
        }
        public void QuietKitchen(){restaurantAudio?.Sync(Sim);}
        public void Save()
        {
            if(Sim==null)return;
#if UNITY_EDITOR
            if(ValidationActive)return;
#endif
            var store=Store();if(store.Blocked)return;
            bool reported=store.State=="write-error";
            Sim.PrepareSave();
            if(!store.Save(Sim.P)&&!reported&&Hud)Hud.Toast("İlerleme kaydedilemedi. Kayıt ve Oturum ekranından tekrar dene.","bad");
        }
        void OnApplicationQuit() { Save(); }
        void OnApplicationPause(bool paused) { if(paused)Suspend(); }
        void OnApplicationFocus(bool focused) { if(!focused&&!Application.isEditor)Suspend(); }
        public void Suspend()
        {
#if UNITY_EDITOR
            RewardTest.Flow.Cancel();
#endif
            if(Sim==null)return;
            touchAllowed=false;CameraControls?.CancelGesture();Sim.Paused=true;restaurantAudio?.Stop();LayoutEditor?.Backgrounded();if(Hud)Hud.Backgrounded();Save();
        }
        void SyncVisuals()
        {
            if(visualSimulation!=Sim||visualBranchRevision!=Sim.BranchRevision) {
                restaurantAudio?.Reset();
                foreach(var visual in actors.Values)visual.motion.Reset();
                foreach(var visual in customers.Values){visual.root.gameObject.SetActive(false);pools[visual.variant].Push(visual);}
                customers.Clear();visualSimulation=Sim;visualBranchRevision=Sim.BranchRevision;
            }
            CameraControls.Sync();
            drivePresentation.Sync(Sim,LayoutEditor.Active);
            deliveryPresentation.Sync(Sim,LayoutEditor.Active);
            branchPresentation.Apply(Sim.P.activeBranch,GameCamera);
            menuPresentation.Sync(Sim);
            restaurantPolish.Sync(Sim);
            operations.Sync(Sim);
            for(int i=0;i<4;i++) {
                if(tableVisuals[i])tableVisuals[i].gameObject.SetActive(i<Sim.P.tables);
                if(tablePads[i])tablePads[i].gameObject.SetActive(i>=Sim.P.tables);
            }
            foreach(var pair in actors)pair.Value.root.gameObject.SetActive(Sim.Actors.Any(a=>a.role==pair.Key));
            layoutAppearance.Apply(LayoutEditor.Active?LayoutEditor.Preview:Sim.P.layout,LayoutEditor);
            people.gameObject.SetActive(!LayoutEditor.Active);
            foreach(var t in Sim.Tables) {
                var table=tableVisuals[t.id]; if(table) {
                    table.gameObject.SetActive(true);table.Find("Dirty").gameObject.SetActive(t.dirty);
                    var meal=table.Find("Meal");if(meal)meal.gameObject.SetActive(Sim.Customers.Any(c=>c.id==t.customer&&(c.phase=="eating"||c.phase=="payment")));
                }
                var pad=tablePads[t.id]; if(pad) pad.gameObject.SetActive(false);
            }
            for(int i=0;i<3;i++) { var grill=grillVisuals[i]; if(grill) grill.gameObject.SetActive(i<Sim.P.grill); }
            if(extraDecor)extraDecor.gameObject.SetActive(Sim.P.decor>0);
            if(cookingSteam) {
                cookingSteam.gameObject.SetActive(Sim.Customers.Any(c=>c.order=="cooking"&&c.station=="grill"));
                for(int i=0;i<cookingSteam.childCount;i++) {
                    float phase=Mathf.Repeat(Sim.Time*.6f+i*.25f,1);
                    var puff=cookingSteam.GetChild(i);puff.localPosition=new Vector3((i%2-.5f)*.23f,phase*.7f,0);puff.localScale=Vector3.one*(.08f+Mathf.Sin(phase*Mathf.PI)*.16f);
                }
            }
            foreach(var a in Sim.Actors) {
                if(!actors.TryGetValue(a.role,out var visual)) { visual=RestaurantArt.BuildPerson(a.role,actors.Count,people); actors[a.role]=visual; }
                visual.root.gameObject.SetActive(true);
                string activity=a.job=="serve"&&a.stage==2?"packing":a.path.Count==0?a.job:"";
                if(a.crowd.waiting)activity="waiting";
                else if(a.crowd.detour.Count>0)activity="";
                bool atDesk=a.role=="manager"&&a.job==""&&a.path.Count==0&&a.crowd.detour.Count==0&&a.crowd.returnTo==null&&WorkZones.InOffice(a.x,a.z);
                if(atDesk)activity="manage";
                if(activity=="sweep"||activity=="trash")activity="clean";
                if(activity=="cook"&&a.stage==2)activity="assembly";
                Vector3? facing=null;
                if(a.path.Count==0) {
                    if(a.job=="cook"||a.role=="cook"||atDesk)facing=Vector3.back;
                    if(a.job=="order"||a.role=="cashier"||a.role=="drive")facing=Vector3.forward;
                    if(a.job=="clean")facing=Vector3.left;
                    if(a.job=="serve"&&a.stage==2)facing=Vector3.right;
                }
                visual.UpdatePosition(a.x,a.z,Sim.Time,a.job=="serve"&&a.stage>=1,atDesk,activity,facing);
                var order=Sim.Customers.FirstOrDefault(c=>c.id==a.customer);
                bool carrying=a.job=="serve"&&a.stage==1;
                if(carrying)menuPresentation.Carry(visual,order?.product??"classic",order!=null&&CustomerProfiles.Portions(order)==2);
                drivePresentation.Carry(visual,carrying&&order!=null&&(order.drive||order.delivery));
            }
            foreach(var c in Sim.Customers.Where(c=>!c.drive&&!c.delivery)) {
                if(!customers.TryGetValue(c.id,out var visual)) {
                    if(!pools.TryGetValue(c.kind,out var pool)){pool=new Stack<RestaurantArt.Person>();pools[c.kind]=pool;}
                    visual=pool.Count>0?pool.Pop():RestaurantArt.BuildPerson("customer",c.kind,people);
                    visual.motion.Reset();
                    visual.root.gameObject.SetActive(true); customers[c.id]=visual;
                }
                visual.UpdatePosition(c.x,c.z,Sim.Time+c.id,false,c.phase=="waiting"||c.phase=="eating"||c.phase=="payment",CustomerProfiles.TakingPhoto(c,Sim.Time)?"photo":c.phase=="eating"?"eating":c.phase=="payment"?"payment":c.phase=="queue"||c.phase=="waiting"?c.patience<=20?"impatient":"waiting":c.crowd.waiting?"waiting":"");
            }
            expired.Clear();foreach(int id in customers.Keys)if(!Sim.Customers.Any(c=>c.id==id&&!c.drive&&!c.delivery))expired.Add(id);
            foreach(int id in expired) {
                var visual=customers[id]; visual.root.gameObject.SetActive(false); pools[visual.variant].Push(visual); customers.Remove(id);
            }
        }
        void OnDestroy(){
#if UNITY_EDITOR
            RewardTest?.Dispose();
#endif
            restaurantAudio?.Dispose();restaurantPolish?.Dispose();}
    }
}
