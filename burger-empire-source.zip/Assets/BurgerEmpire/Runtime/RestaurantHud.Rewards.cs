#if UNITY_EDITOR
using BurgerEmpire.Core;

namespace BurgerEmpire.Unity
{
    public sealed partial class RestaurantHud
    {
        float DrawRewardTest(float y)
        {
            var test=game.RewardTest;var flow=test.Flow;
            y=GuideText("EDİTÖR TESTİ · GERÇEK REKLAM DEĞİL",y,18,red,true);
            y=GuideText("Başarılı izleme: +100 deneme coin. Restoran bakiyen değişmez. Deneme bakiyesi Play yeniden başlatılınca sıfırlanır.",y,17,muted);
            y=GuideText("Deneme bakiyesi: "+test.Coins,y,22,ink,true);
            y=GuideText(RewardTestStatus(flow.State),y,17,green,true);
            if(flow.State==RewardedAdState.Showing) {
                y=RewardTestButton("BAŞARIYLA TAMAMLA","Reward complete",y,test.Complete);
                y=RewardTestButton("ERKEN KAPAT · ÖDÜL YOK","Reward cancel",y,test.CloseEarly);
                y=RewardTestButton("HATA OLUŞTUR · ÖDÜL YOK","Reward fail",y,test.Fail);
            } else if(!flow.Busy) {
                var button=Button("TESTİ BAŞLAT · +100 DENEME COIN",panel,10,y,panelWidth-20,58,red,()=>{flow.Begin();RefreshPanel();},16);
                button.name="Reward start";button.interactable=flow.CanBegin;y+=70;
                y=RewardTestButton(test.Available?"REKLAM YOK DURUMUNU DENE":"REKLAMI HAZIR DURUMA GETİR","Reward availability",y,test.ToggleAvailability);
            }
            y=GuideText("Test sadece seçtiğin düğmeyle başlar. İptal ve hata coin vermez. Menüden çıkmak testi sonlandırır.",y,16,muted);
            return HomeButton("AYARLARA DÖN","Reward back","Ayarlar",y+8);
        }
        float RewardTestButton(string text,string id,float y,System.Action action)
        {Button(text,panel,10,y,panelWidth-20,56,green,()=>{action();RefreshPanel();},16).name=id;return y+68;}
        string RewardTestStatus(RewardedAdState state)
        {
            switch(state) {
                case RewardedAdState.Unavailable:return "Reklam hazır değil. Test için tekrar hazır duruma getirebilirsin.";
                case RewardedAdState.Showing:return "Test açık. İzlemenin sonucunu aşağıdan seç.";
                case RewardedAdState.AwaitingReward:return "Kapandı. Tamamlama sonucu bekleniyor…";
                case RewardedAdState.Rewarded:return "Tamamlandı: +100 deneme coin eklendi.";
                case RewardedAdState.Canceled:return "Erken kapandı. Ödül verilmedi.";
                case RewardedAdState.Failed:return "Reklam hatası. Ödül verilmedi; tekrar deneyebilirsin.";
                case RewardedAdState.TimedOut:return "Test yanıt vermedi. Ödül verilmedi; tekrar deneyebilirsin.";
                case RewardedAdState.GrantFailed:return "Deneme ödülü eklenemedi. Bu izleme tekrar ödül vermez.";
                default:return "Hazır. Başlatmadan önce ödül miktarını görebilirsin.";
            }
        }
    }
}
#endif
