using BurgerEmpire.Core;
using UnityEngine;

namespace BurgerEmpire.Unity
{
    public sealed partial class RestaurantHud
    {
        float DrawBranches(float y)
        {
            var route=Card("Branch route",panel,0,y,panelWidth,110,RestaurantArt.Hex("DCE5DE"));
            Label("İSTANBUL    →    LONDRA",route.transform,14,6,panelWidth-28,40,23,green,FontStyle.Bold,TextAnchor.MiddleCenter);
            Label("Bir restoranla başladı. Şimdi büyüme zamanı.",route.transform,18,48,panelWidth-36,50,16,ink,FontStyle.Normal,TextAnchor.MiddleCenter);y+=122;
            for(int i=0;i<2;i++) {
                int id=i;bool owned=game.Sim.OwnsBranch(id),active=game.Sim.P.activeBranch==id;
                var progress=game.Sim.BranchProgress(id);
                var card=Card("Branch "+id,panel,0,y,panelWidth,owned?220:294,RestaurantArt.Hex(id==0?"ECECD8":"E0E9F1"));
                Label(BranchCatalog.Name(id)+(active?" · BURADASIN":owned?" · ŞUBEN":" · YENİ ŞUBE"),card.transform,14,8,panelWidth-28,40,24,ink,FontStyle.Bold);
                Label(BranchCatalog.Description(id),card.transform,14,50,panelWidth-28,48,16,muted);
                if(owned) {
                    Label(progress.tables+" masa · "+progress.served+" müşteri · "+(progress.reviewTotal/progress.reviewCount).ToString("0.0")+" ★\nEkip: "+(progress.cashier+progress.cook+progress.waiter+progress.cleaner+progress.manager)+" toplam seviye",card.transform,14,100,panelWidth-28,45,16,green);
                    var button=Button(active?"BU ŞUBEDESİN":"ŞUBEYE GİT",card.transform,12,152,panelWidth-24,56,green,()=>game.VisitBranch(id));
                    button.name="Visit branch "+id;button.interactable=!active;y+=232;
                } else {
                    int served=game.Sim.BranchProgress(0).served;
                    Label("Seviye "+game.Sim.Level+"/8 · İstanbul "+served+"/30 müşteri\nAçılış: 2 masa, 1 ızgara ve fritöz\nOfis müşterileri · %15 kısa geliş aralığı",card.transform,14,100,panelWidth-28,72,15,green);
                    Label(game.Sim.LondonLockReason(),card.transform,14,177,panelWidth-28,46,15,ink);
                    var button=Button("ŞUBEYİ AÇ · 1200 COIN",card.transform,12,226,panelWidth-24,56,red,game.OpenLondon);
                    button.name="Open London";button.interactable=game.Sim.CanOpenLondon;y+=306;
                }
            }
            Label("Kasa, XP ve günlük görevler ortak. Ekip, mutfak, menü ve düzen her şubeye özel. Yalnızca bulunduğun şube çalışır; bu oyun oturumunda diğer şubenin siparişleri bekler.",panel,12,y,panelWidth-24,112,16,muted);return y+124;
        }
    }
}
