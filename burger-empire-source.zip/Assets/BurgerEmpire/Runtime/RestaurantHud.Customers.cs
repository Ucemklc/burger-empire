using System.Linq;
using BurgerEmpire.Core;
using UnityEngine;

namespace BurgerEmpire.Unity
{
    public sealed partial class RestaurantHud
    {
        float DrawCustomers(float y)
        {
            y=GuideText("Her misafirin beklentisi farklı",y,23,ink,true);
            y=GuideText("Salon misafirlerinin tercihlerini tanı; mutfak ve servis düzenini buna göre geliştir.",y,17,muted);
            for(int kind=0;kind<=6;kind++) {
                y+=10;Card("Guest divider",panel,10,y,panelWidth-20,2,RestaurantArt.Gold,false);y+=12;
                y=GuideText(ReviewCatalog.Type(kind),y,21,green,true);
                y=GuideText(CustomerProfiles.Description(kind),y,17,ink);
            }
            Button("YORUMLARI GÖR",panel,10,y+12,panelWidth-20,56,green,()=>OpenPanel("Müşteri yorumları"),17).name="Guest reviews";return y+80;
        }
        float DrawRatingCategories(float y)
        {
            y=GuideText("SON ZİYARETLERİN PUANLARI",y,18,green,true);
            for(int i=0;i<5;i++) {
                float value=RatingSignals.Average(game.Sim.P.reviews,i);int count=RatingSignals.Count(game.Sim.P.reviews,i);
                string score=count==0?"Henüz ölçülmedi":value.ToString("0.0",Localization.Culture)+" / 5  ·  "+count+" yorum";
                y=GuideText(RatingSignals.Names[i]+"  ·  "+score,y,18,ink,true);
            }
            y=GuideText("Kategoriler son 12 ziyaretteki ölçümlere dayanır. Genel puan geçmiş ziyaretleri de içerir. Yemek almadan ayrılan ziyaretlerde lezzet ve fiyat ölçülmez.",y,15,muted);
            Button("MÜŞTERİLERİ TANI",panel,10,y+8,panelWidth-20,52,green,()=>OpenPanel("Müşteriler"),16).name="Show customer types";return y+72;
        }
        string ReviewScores(CustomerReview review)
        {
            if(!review.measured)return "Eski ziyaret · Kategori ölçümü yok";
            return string.Join("  ·  ",Enumerable.Range(0,5).Select(i=>RatingSignals.Names[i]+" "+(RatingSignals.Category(review,i)>0?RatingSignals.Category(review,i).ToString("0.0",Localization.Culture):"—")));
        }
    }
}
