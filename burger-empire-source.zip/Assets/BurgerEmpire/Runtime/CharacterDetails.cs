using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace BurgerEmpire.Unity
{
    public sealed class CharacterDetails
    {
        readonly Transform smile,teeth;
        readonly Transform[] brows,eyes;
        readonly Vector3[] eyeSizes;
        readonly int variant;
        public CharacterDetails(RestaurantArt.Person person,string role,Color skin)
        {
            var g=person.root;variant=person.variant;
            bool worker=role!="customer",vip=!worker&&variant==BurgerEmpire.Core.VipCatalog.Kind;
            Color hair=RestaurantArt.Hex(role=="manager"?"382C2A":!worker&&variant==4?"914563":!worker&&variant==1?"A95D35":"54342B");
            foreach(Transform t in g)if(t.name=="Hair"||t.name=="Ponytail"||t.name=="Eyebrow"||t.name=="Chef moustache")t.GetComponent<Renderer>().sharedMaterial=RestaurantArt.Mat(hair);
            // Swept locks have a different outline from the old smooth hair dome.
            var locks=RestaurantArt.Group("Swept hair",g,Vector3.zero);
            bool capped=worker&&role!="waiter"&&role!="manager";
            for(int i=0;i<3;i++) {
                var lockShape=RestaurantArt.Shape("Hair lock",PrimitiveType.Sphere,locks,new Vector3(-.17f+i*.14f,capped?1.44f:1.52f+(i==1?.045f:0),.14f),capped?new Vector3(.22f,.095f,.19f):new Vector3(.25f,.18f,.30f),hair);
                lockShape.transform.localEulerAngles=new Vector3(-12,0,25);
            }
            if(role=="cook")locks.gameObject.SetActive(false);
            if(role=="waiter")foreach(Transform t in g)if(t.name=="Cap"||t.name=="Cap brim")t.gameObject.SetActive(false);
            if(role=="cashier") {
                RestaurantArt.Shape("Staff ponytail",PrimitiveType.Sphere,g,new Vector3(0,1.30f,-.29f),new Vector3(.27f,.48f,.27f),hair);
                RestaurantArt.Shape("Staff hair tie",PrimitiveType.Sphere,g,new Vector3(0,1.47f,-.3f),new Vector3(.30f,.09f,.13f),RestaurantArt.Gold);
            }
            if(!worker&&variant==2)for(int i=0;i<4;i++)RestaurantArt.Shape("Curly hair",PrimitiveType.Sphere,locks,new Vector3(-.21f+i*.14f,1.60f,.03f),Vector3.one*.23f,hair);
            foreach(Transform eye in g.Cast<Transform>().Where(t=>t.name=="Pupil")) {
                eye.localPosition+=Vector3.forward*.025f;eye.localScale=new Vector3(.053f,.084f,.022f);
                RestaurantArt.Shape("Iris",PrimitiveType.Sphere,g,new Vector3(eye.localPosition.x,1.34f,.309f),new Vector3(.101f,.133f,.022f),RestaurantArt.Hex(role=="cleaner"?"3E8290":"7A5033"));
            }
            foreach(Transform t in g.Cast<Transform>().Where(t=>t.name=="Eye glint"))t.localPosition+=Vector3.forward*.03f;
            foreach(Transform t in g.Cast<Transform>().Where(t=>t.name=="Cheek"))t.GetComponent<Renderer>().sharedMaterial=RestaurantArt.Mat(Color.Lerp(skin,RestaurantArt.Hex("DC826D"),.38f));
            if(role=="manager"||!worker&&variant==3) {
                foreach(Transform t in g)if(t.name=="Glasses"||t.name=="Glasses bridge")t.gameObject.SetActive(false);
                var frames=RestaurantArt.Group("Open glasses",g,Vector3.zero);var black=RestaurantArt.Hex("303A3B");
                for(int side=-1;side<=1;side+=2) {
                    for(int edge=-1;edge<=1;edge+=2) {
                        RestaurantArt.Box("Frame rim",frames,side*.14f,1.34f+edge*.075f,.35f,.225f,.022f,.027f,black);
                        RestaurantArt.Box("Frame rim",frames,side*.14f+edge*.103f,1.34f,.35f,.022f,.15f,.027f,black);
                    }
                }
                RestaurantArt.Box("Frame bridge",frames,0,1.34f,.35f,.065f,.023f,.027f,RestaurantArt.Gold);
            }
            if(role=="waiter") {
                var apron=g.Find("Apron");apron.GetComponent<Renderer>().sharedMaterial=RestaurantArt.Mat(RestaurantArt.Hex("33453D"));
                RestaurantArt.Box("Bow tie",g,0,.91f,.205f,.17f,.075f,.065f,RestaurantArt.Red);
                for(int i=0;i<2;i++)RestaurantArt.Shape("Shirt button",PrimitiveType.Sphere,g,new Vector3(0,.85f-i*.06f,.208f),Vector3.one*.032f,RestaurantArt.Brown);
            }
            if(role=="cleaner")foreach(var hand in new[]{person.leftArm.Find("Hand"),person.rightArm.Find("Hand")})hand.GetComponent<Renderer>().sharedMaterial=RestaurantArt.Mat(RestaurantArt.Hex("E9B742"));
            if(worker&&role!="manager") {
                var badge=RestaurantArt.Group("Crown emblem",g,new Vector3(-.085f,.64f,.239f));
                RestaurantArt.Box("Emblem base",badge,0,0,0,.105f,.027f,.014f,RestaurantArt.Gold);
                for(int i=0;i<3;i++)RestaurantArt.Box("Crown point",badge,(i-1)*.037f,.028f+(i==1?.008f:0),0,.027f,.053f,.014f,RestaurantArt.Gold);
                for(int side=-1;side<=1;side+=2)RestaurantArt.Box("Apron strap",g,side*.13f,.85f,.183f,.043f,.22f,.025f,RestaurantArt.Brown);
            }
            foreach(var shoe in new[]{person.leftLeg.Find("Shoe"),person.rightLeg.Find("Shoe")}) {
                RestaurantArt.Box("Shoe sole",shoe,0,-.35f,.01f,.96f,.18f,.97f,RestaurantArt.Hex("F1DDBA"));
            }
            smile=g.Find("Smile");teeth=g.Find("Smile teeth");brows=g.Cast<Transform>().Where(t=>t.name=="Eyebrow").ToArray();
            eyes=g.Cast<Transform>().Where(t=>t.name=="Eye"||t.name=="Pupil"||t.name=="Iris"||t.name=="Eye glint").ToArray();eyeSizes=eyes.Select(t=>t.localScale).ToArray();
        }
        public void Pose(float time,string activity)
        {
            bool impatient=activity=="impatient";float phase=Mathf.Repeat(time+variant*.57f,4.6f);
            float open=phase<.16f?Mathf.Max(.09f,Mathf.Abs(phase-.08f)/.08f):1;
            for(int i=0;i<eyes.Length;i++){var scale=eyeSizes[i];scale.y*=open;eyes[i].localScale=scale;}
            foreach(var brow in brows)brow.localRotation=Quaternion.Euler(0,0,Mathf.Sign(brow.localPosition.x)*(impatient?18:-8));
            smile.localScale=impatient?new Vector3(.12f,.032f,.028f):new Vector3(.17f,activity=="eating"?.065f+Mathf.Sin(time*3)*.018f:.052f,.028f);
            teeth.gameObject.SetActive(!impatient);
        }
    }
}
