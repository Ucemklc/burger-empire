using BurgerEmpire.Core;
using UnityEngine;

namespace BurgerEmpire.Unity
{
    public sealed partial class RestaurantHud
    {
        string SaveStatusText()
        {
            switch(game.SaveState) {
                case "future":return "Bu kayıt daha yeni bir oyun sürümüne ait. Kaydın korunuyor; oyunun güncel sürümüyle aç.";
                case "unreadable":return "Kayıt dosyasına erişilemiyor. Dosyaların korunuyor; erişim düzeldikten sonra tekrar dene.";
                case "invalid":return "Kayıt ve yedekleri açılamadı. Dosyaların korunuyor; yeni oyunla üzerlerine yazılmadı.";
                case "write-error":return "İlerleme kaydedilemedi. Cihazındaki boş alanı kontrol et ve tekrar dene. Son sağlam kayıt korunuyor.";
            }
            if(game.SaveRecovery=="backup")return "İlerlemen son sağlam yedekten kurtarıldı. Son kayıttan sonraki işlemler eksik olabilir.";
            if(game.SaveRecovery=="pending")return "Yarım kalan kayıt tamamlanarak ilerlemen kurtarıldı.";
            return game.SaveState=="new"?"İlk kayıt, oyunu oynadığında bu cihazda oluşturulacak.":"İlerlemen bu cihazda saklanıyor. Önceki sağlam kayıt yedekte tutuluyor.";
        }
        float DrawSaveStatus(float y)
        {
            y=GuideText("KAYIT DURUMU",y,22,green,true);
            y=GuideText(SaveStatusText(),y,17,game.SaveBlocked?red:ink);
            y=GuideText("Bu oturumdaki son kayıt: "+game.LastSaveTime,y,16,muted);
            Button(game.SaveBlocked?"KAYDI TEKRAR OKU":"ŞİMDİ KAYDET",panel,10,y+10,panelWidth-20,56,green,game.RetrySave,17).name="Retry save";y+=80;
            y=GuideText("BU OTURUM",y,22,green,true);
            y=GuideText("Açık vardiya süresi: "+(game.Session.ActiveSeconds/60).ToString("0.0",Localization.Culture)+" dk",y,18,ink);
            y=GuideText("Servis edilen müşteri: "+game.Session.Served,y,18,ink);
            y=GuideText("Ayrılan müşteri: "+game.Session.Lost,y,18,ink);
            y=GuideText("Servisten kazanılan: "+game.Session.Earned+" coin",y,18,ink);
            y=GuideText("Oturum sayaçları oyun yeniden açılınca sıfırlanır. Menü ve duraklatma süresi sayılmaz. Bu bilgiler dışarı gönderilmez.",y,15,muted);
            y=GuideText("İlerlemen otomatik kaydedilir. Açık siparişler yeniden açılışta sıfırlanır; coin, ekip, görevler ve restoran düzeni korunur.",y,15,muted);
            return HomeButton("AYARLARA DÖN","Save settings","Ayarlar",y+10);
        }
    }
}
