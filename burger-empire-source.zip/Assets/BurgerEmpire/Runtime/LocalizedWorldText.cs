using BurgerEmpire.Core;
using UnityEngine;

namespace BurgerEmpire.Unity
{
    // Keeps the original wording for switching back, including dynamically updated signs.
    public sealed class LocalizedWorldText : MonoBehaviour
    {
        TextMesh label;
        string source,rendered;
        int revision=-1;
        void Awake(){label=GetComponent<TextMesh>();}
        void LateUpdate()
        {
            if(!label)return;
            if(label.text!=rendered){source=label.text;revision=-1;}
            if(revision==Localization.Revision)return;
            rendered=Localization.Text(source);label.text=rendered;revision=Localization.Revision;
        }
    }
}
