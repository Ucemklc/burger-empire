using System.Linq;
using BurgerEmpire.Core;
using UnityEngine;

namespace BurgerEmpire.Unity
{
    // Additive construction also upgrades existing saved Unity scenes without rebuilding them.
    public sealed class RestaurantOperations
    {
        readonly Transform root,door,pickupLight,trashPile;
        readonly Transform[] mess=new Transform[2];
        readonly Transform managerChair;
        static Color C(string hex)=>RestaurantArt.Hex(hex);
        static Transform G(string name,Transform p,float x=0,float y=0,float z=0)=>RestaurantArt.Group(name,p,new Vector3(x,y,z));
        static GameObject B(string name,Transform p,float x,float y,float z,float sx,float sy,float sz,Color c)=>RestaurantArt.Box(name,p,x,y,z,sx,sy,sz,c);
        public RestaurantOperations(Transform world)
        {
            root=G("Staff work zones",world);
            // Split the existing left wall around the doorway, keeping saved tables untouched.
            foreach(var name in new[]{"Side wall","Side trim","Left red stripe"}) {
                var old=world.Find(name);if(old)old.gameObject.SetActive(false);
            }
            foreach(Transform child in world) {
                if(child.name=="Window"&&child.localPosition.z<5)child.gameObject.SetActive(false);
                if(child.name=="Street tree"&&child.localPosition.x<0&&child.localPosition.z<5.5f)child.localPosition+=Vector3.left*3;
            }
            var office=G("Manager Office",root);
            B("Office foundation",office,-1.95f,-.03f,2.5f,3.9f,.42f,4.8f,C("826957"));
            for(int x=0;x<4;x++)for(int z=0;z<5;z++)B("Office wood floor",office,-3.4f+x*.92f,.225f,.55f+z*.9f,.90f,.04f,.88f,(x+z)%2==0?C("BBA388"):C("CAB697"));
            B("Office back wall",office,-1.9f,1.5f,.12f,3.9f,2.7f,.18f,RestaurantArt.Cream);
            B("Office outer wall",office,-3.86f,1.5f,2.48f,.18f,2.7f,4.9f,RestaurantArt.Cream);
            B("Office front cutaway",office,-1.95f,.72f,4.87f,3.9f,.94f,.18f,C("668F83"));
            B("Office partition",office,0,.9f,1.65f,.18f,1.3f,3.3f,C("668F83"));
            B("Dining side wall",office,-.07f,1.5f,7.42f,.2f,2.7f,5.25f,RestaurantArt.Cream);
            B("Dining side stripe",office,.055f,.65f,7.42f,.08f,.72f,5.25f,RestaurantArt.Red);
            B("Dining side trim",office,0,2.85f,7.42f,.3f,.15f,5.25f,RestaurantArt.Brown);
            for(int side=-1;side<=1;side+=2)B("Door frame",office,0,1.32f,WorkZones.DoorZ+side*.73f,.25f,2.14f,.12f,RestaurantArt.Brown);
            B("Door lintel",office,0,2.40f,WorkZones.DoorZ,.25f,.14f,1.58f,RestaurantArt.Brown);
            door=G("Push office door",office,0,.27f,WorkZones.DoorZ-.65f);
            RestaurantArt.Box("Door leaf",door,0,.99f,.65f,.10f,1.98f,1.30f,C("426C54"),true);
            B("Door threshold",office,0,.245f,WorkZones.DoorZ,.45f,.035f,1.4f,C("C79258"));
            B("Door frosted pane",door,.06f,1.32f,.65f,.025f,.68f,.88f,C("B8D8D0"));
            B("Door push bar",door,.10f,.82f,.82f,.06f,.075f,.68f,RestaurantArt.Gold);
            // Visible room contents, including a dedicated seated work position.
            var desk=G("Manager Desk",office,-2.05f,.25f,.92f);
            B("Desk oak top",desk,0,.77f,0,2.05f,.14f,.83f,C("C79258"));
            for(int side=-1;side<=1;side+=2)B("Desk leg",desk,side*.87f,.38f,0,.12f,.77f,.65f,RestaurantArt.Brown);
            B("Computer stand",desk,0,.91f,-.08f,.35f,.20f,.23f,C("334942"));
            B("Computer monitor",desk,0,1.21f,-.12f,.85f,.53f,.10f,C("334942"));
            B("Computer screen",desk,0,1.21f,-.059f,.73f,.41f,.018f,C("7CBBA3"));
            for(int i=0;i<3;i++)B("Dashboard bar",desk,-.24f+i*.21f,1.11f+i*.06f,-.042f,.11f,.1f+i*.12f,.009f,RestaurantArt.Gold);
            B("Keyboard",desk,0,.87f,.24f,.63f,.035f,.22f,C("425952"));
            for(int i=0;i<3;i++)B("Files",desk,.68f,.89f+i*.06f,0,.43f,.05f,.52f,i%2==0?RestaurantArt.Cream:RestaurantArt.Red);
            RestaurantArt.Cup(desk,new Vector3(-.73f,.84f,.12f));
            managerChair=G("Manager Chair",office,-2.05f,.25f,1.85f);
            B("Chair seat",managerChair,0,.42f,0,.65f,.13f,.62f,C("374F49"));
            B("Chair back",managerChair,0,.88f,.29f,.67f,.86f,.12f,C("374F49"));
            RestaurantArt.Shape("Chair stem",PrimitiveType.Cylinder,managerChair,new Vector3(0,.2f,0),new Vector3(.1f,.2f,.1f),RestaurantArt.Brown);
            B("Chair base",managerChair,0,.045f,0,.65f,.07f,.65f,RestaurantArt.Brown);
            B("Filing cabinet",office,-3.27f,.94f,3.45f,.69f,1.38f,1.15f,C("82988B"));
            for(int i=0;i<3;i++)B("Drawer handle",office,-2.91f,.53f+i*.38f,3.45f,.04f,.05f,.35f,RestaurantArt.Gold);
            B("Management board",office,-1.65f,2.06f,.25f,2.2f,1.05f,.07f,RestaurantArt.Brown);
            for(int i=0;i<3;i++)B("Office plan",office,-2.36f+i*.69f,2.05f,.30f,.49f,.71f,.018f,i==1?C("F3CD78"):RestaurantArt.Cream);
            RestaurantArt.Plant(office,new Vector3(-3.22f,.25f,.68f),.75f);
            RestaurantArt.Text("Office name","MÜDÜR",office,new Vector3(-1.75f,2.72f,.27f),.18f,RestaurantArt.Green);
            // Kitchen assembly surface and waiter pickup live on opposite sides of the counter.
            var prep=G("Preparation Table",root,6.05f,1.35f,1.1f);
            B("Assembly board",prep,0,0,0,1.15f,.06f,.88f,C("D4AA70"));
            RestaurantArt.Burger(prep,new Vector3(-.21f,.04f,0),.85f);
            B("Ingredient tray",prep,.35f,.08f,0,.28f,.12f,.53f,RestaurantArt.Green);
            var pickup=G("Kitchen Pickup Point",root,4.7f,1.43f,3.04f);
            B("Pickup tray",pickup,0,0,0,1.45f,.06f,.67f,C("CCD9BD"));
            pickupLight=B("Ready service light",pickup,.70f,.17f,.1f,.16f,.22f,.16f,C("65BF70")).transform;
            // Cleaning cart is against the outside edge, clear of the customer entrance.
            var cleaning=G("Cleaning Station",root,9.82f,.25f,7.35f);
            B("Cleaning cart",cleaning,0,.44f,0,.49f,.71f,.60f,C("548AA7"));
            B("Cart shelf",cleaning,0,.82f,0,.56f,.08f,.65f,RestaurantArt.Cream);
            for(int i=0;i<2;i++)RestaurantArt.Shape("Cleaner bottle",PrimitiveType.Capsule,cleaning,new Vector3(-.12f+i*.23f,1.0f,0),new Vector3(.15f,.20f,.15f),i==0?RestaurantArt.Gold:RestaurantArt.Green);
            B("Mop pole",cleaning,.2f,.93f,.37f,.055f,1.8f,.055f,RestaurantArt.Brown);
            B("Mop head",cleaning,.2f,.09f,.37f,.46f,.12f,.2f,C("B7D4D8"));
            var bin=G("Restaurant waste bin",root,9.78f,.25f,6.83f);
            B("Waste bin",bin,0,.35f,0,.51f,.70f,.48f,C("536B65"));
            trashPile=G("Waste pile",bin,0,.73f,0);
            for(int i=0;i<3;i++)B("Used wrapper",trashPile,-.12f+i*.12f,i*.04f,0,.22f,.08f,.26f,RestaurantArt.Cream);
            for(int i=0;i<2;i++) {
                mess[i]=G("Floor spill "+i,root);
                for(int k=0;k<5;k++)RestaurantArt.Shape("Crumb",PrimitiveType.Sphere,mess[i],new Vector3((k%3)*.14f-.17f,.015f,k/3*.19f-.08f),new Vector3(.11f,.025f,.09f),RestaurantArt.Gold);
            }
            foreach(string role in new[]{"cashier","cook","waiter","cleaner","drive","manager"}) {
                var p=WorkZones.Idle(role);G(role+" Idle Position",root,p.x,.25f,p.z);
                p=WorkZones.Interaction(role=="cook"?"grill":role=="waiter"?"pickup":role);G(role+" Interaction Position",root,p.x,.25f,p.z);
            }
        }
        public void Sync(Simulation sim)
        {
            door.localRotation=Quaternion.Euler(0,-sim.OfficeDoorAngle,0);
            pickupLight.gameObject.SetActive(sim.Customers.Any(c=>c.order=="ready"));
            trashPile.gameObject.SetActive(sim.Trash>=3);
            for(int i=0;i<mess.Length;i++) {
                mess[i].gameObject.SetActive(i<sim.FloorMess.Count);
                if(i<sim.FloorMess.Count)mess[i].localPosition=new Vector3(sim.FloorMess[i].x,.27f,sim.FloorMess[i].z);
            }
            // Chair remains part of the room even before hiring its manager.
        }
    }
}
