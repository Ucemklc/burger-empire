using System.Linq;
using BurgerEmpire.Core;
using UnityEngine;

namespace BurgerEmpire.Unity
{
    public sealed partial class RestaurantHud
    {
        float DrawDriveThru(float y)
        {
            var p=game.Sim.P;
            Label(BranchCatalog.Name(p.activeBranch)+" · Arabaya servis",panel,10,y,panelWidth-20,48,23,ink,FontStyle.Bold);y+=58;
            Label("Sipariş al → Hazırla → Servis et\nÖdeme paketi teslim ettiğinde alınır. Masa ve temizlik gerekmez; mutfak kapasitesi salonla ortaktır.",panel,10,y,panelWidth-20,108,17,muted);y+=120;
            if(p.driveThru>0) {
                var stats=Card("Drive stats",panel,0,y,panelWidth,100,RestaurantArt.Hex("DCE5DE"));
                Label(game.Sim.DriveQueue+"/"+game.Sim.DriveCapacity+" araç · "+p.driveServed+" paket teslim\n"+p.driveEarned+" coin gelir · "+p.driveLost+" ayrılan araç",stats.transform,14,8,panelWidth-28,84,19,green,FontStyle.Bold);y+=112;
                Label("Kasiyer siparişi alır, aşçı hazırlar, garson paketi teslim eder. Sürücüler fazla beklerse ayrılır. Kuyrukta yalnızca pencereye ulaşan ilk aracın siparişi alınır.",panel,10,y,panelWidth-20,112,16,muted);y+=124;
            }
            y=DrawOffer(game.Sim.Offers().First(o=>o.id=="drive"),y);
            Label("Paket fiyatları",panel,12,y,panelWidth-24,38,21,ink,FontStyle.Bold);y+=46;
            foreach(var recipe in MenuCatalog.All(p).Where(r=>r.available)){
                Label(recipe.name+" · "+Simulation.DrivePrice(recipe)+" coin",panel,12,y,panelWidth-24,34,17,green);y+=38;
            }
            Label("Paket fiyatı şehir menüsünün %20 üzerindedir; tam coine yuvarlanır. Bahşiş ve yoğunluk bonusları ayrıca eklenir. Geliştirme ve paket görevleri bu şubeye özeldir.",panel,12,y,panelWidth-24,106,16,muted);y+=118;
            var mission=game.Sim.Missions().FirstOrDefault(m=>m.id=="drive");if(mission!=null)y=DrawMission(mission,y);
            return y;
        }
    }
}
