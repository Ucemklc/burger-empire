using BurgerEmpire.Core;
using UnityEngine;

namespace BurgerEmpire.Unity
{
    // Small city landmarks are outside the playable floor and never affect service paths.
    public sealed class BranchPresentation
    {
        readonly Transform phoneBox;
        readonly TextMesh sign,menuBoard;
        readonly Renderer meadow;
        int current=-1;
        public BranchPresentation(Transform world)
        {
            var marker=RestaurantArt.Group("City marker",world,new Vector3(3.1f,0,10.8f));
            RestaurantArt.Box("Post",marker,0,1.1f,0,.10f,2.2f,.10f,RestaurantArt.Brown);
            RestaurantArt.Box("Board",marker,0,2.15f,0,1.7f,.53f,.12f,RestaurantArt.Green);
            sign=RestaurantArt.Text("City name","ISTANBUL",marker,new Vector3(0,2.15f,.08f),.17f,RestaurantArt.Cream);
            meadow=world.Find("Meadow")?.GetComponent<Renderer>();
            foreach(var text in world.GetComponentsInChildren<TextMesh>())if(text.name=="Menu"&&text.text.Contains("MENÜ")){menuBoard=text;break;}
            phoneBox=RestaurantArt.Group("London telephone box",world,new Vector3(11.3f,.2f,4.0f));
            RestaurantArt.Box("Cabin",phoneBox,0,.88f,0,.72f,1.76f,.72f,RestaurantArt.Red);
            RestaurantArt.Box("Roof",phoneBox,0,1.85f,0,.87f,.18f,.87f,RestaurantArt.Red);
            var glass=RestaurantArt.Hex("91BDD0");
            for(int row=0;row<3;row++)for(int col=0;col<2;col++) {
                RestaurantArt.Box("Front pane",phoneBox,-.17f+col*.34f,.52f+row*.39f,.37f,.25f,.31f,.025f,glass);
                RestaurantArt.Box("Side pane",phoneBox,.37f,.52f+row*.39f,-.17f+col*.34f,.025f,.31f,.25f,glass);
            }
            RestaurantArt.Text("Telephone label","PHONE",phoneBox,new Vector3(0,1.65f,.38f),.1f,RestaurantArt.Cream);
        }
        public void Apply(int id,Camera camera)
        {
            if(id==current)return;current=id;
            sign.text=id==1?"LONDRA":"ISTANBUL";phoneBox.gameObject.SetActive(id==1);
            var ground=RestaurantArt.Hex(id==1?"9DAFBB":"A5B49A");camera.backgroundColor=ground;
            if(meadow)meadow.sharedMaterial=RestaurantArt.Mat(ground);
            if(menuBoard)menuBoard.text="KLASİK MENÜ\n"+(id==1?35:32)+" COIN";
        }
    }
}
