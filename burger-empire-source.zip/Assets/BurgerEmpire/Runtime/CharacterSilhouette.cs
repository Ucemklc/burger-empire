using System.Collections.Generic;
using UnityEngine;

namespace BurgerEmpire.Unity
{
    // Visual proportions and secondary motion never move the navigation root in X/Z.
    public sealed class CharacterSilhouette
    {
        readonly Transform[] head;
        readonly Vector3[] positions;
        readonly Quaternion[] rotations;
        readonly Transform torso,food;
        readonly Vector3 trayPosition;
        readonly float lift,phase;
        static Mesh sculptedHead;
        public CharacterSilhouette(RestaurantArt.Person p,string role)
        {
            phase=p.variant*.63f;
            lift=role=="manager"?.08f:role=="waiter"?.045f:role=="customer"?(p.variant%3-1)*.025f:0;
            torso=p.root.Find("Torso");food=p.food;trayPosition=food.localPosition;
            float breadth=role=="cook"?1.20f:role=="cashier"?.91f:role=="manager"?.95f:role=="customer"?1+(p.variant%3-1)*.07f:1;
            torso.localScale=new Vector3(torso.localScale.x*breadth,torso.localScale.y,torso.localScale.z);
            var apron=p.root.Find("Apron");if(apron)apron.localScale=new Vector3(apron.localScale.x*breadth,apron.localScale.y,apron.localScale.z);
            var face=p.root.Find("Head").GetComponent<MeshFilter>();
            if(!sculptedHead) {
                sculptedHead=Object.Instantiate(face.sharedMesh);sculptedHead.name="BE_SharedSculptedHead";
                var vertices=sculptedHead.vertices;
                for(int i=0;i<vertices.Length;i++) {
                    var v=vertices[i];float jaw=Mathf.Lerp(.76f,1,Mathf.InverseLerp(-.5f,.03f,v.y));v.x*=jaw;vertices[i]=v;
                }
                sculptedHead.vertices=vertices;sculptedHead.RecalculateNormals();sculptedHead.RecalculateBounds();
            }
            face.sharedMesh=sculptedHead;
            var parts=new List<Transform>();
            foreach(Transform part in p.root) {
                if(part==p.leftLeg||part==p.rightLeg||part==food||part.name=="Player marker")continue;
                part.localPosition+=Vector3.up*lift;
                if(part.localPosition.y>1.04f+lift||part.name=="Swept hair"||part.name=="Open glasses")parts.Add(part);
            }
            head=parts.ToArray();positions=new Vector3[head.Length];rotations=new Quaternion[head.Length];
            for(int i=0;i<head.Length;i++){positions[i]=head[i].localPosition;rotations[i]=head[i].localRotation;}
            // The chef's double-breasted coat and contrasting cuffs read at restaurant scale.
            if(role=="cook")for(int side=-1;side<=1;side+=2)for(int row=0;row<2;row++)
                RestaurantArt.Shape("Chef coat button",PrimitiveType.Sphere,p.root,new Vector3(side*.18f,.88f-row*.09f,.19f),Vector3.one*.038f,RestaurantArt.Brown);
            if(role=="cashier") {
                var apronRenderer=apron.GetComponent<Renderer>();apronRenderer.sharedMaterial=RestaurantArt.Mat(RestaurantArt.Red);
                p.root.Find("Torso").GetComponent<Renderer>().sharedMaterial=RestaurantArt.Mat(RestaurantArt.Cream);
                foreach(var arm in new[]{p.leftArm,p.rightArm})arm.Find("Sleeve").GetComponent<Renderer>().sharedMaterial=RestaurantArt.Mat(RestaurantArt.Cream);
            }
        }
        public void Pose(float time,string activity,float stride,bool carrying,float bob,float rootScale)
        {
            float nod=activity=="eating"?8+Mathf.Sin(time*3)*5:activity=="cook"||activity=="assembly"||activity=="clean"?7:activity=="impatient"?-4:Mathf.Sin(time*1.4f+phase)*1.4f;
            float roll=activity=="waiting"?Mathf.Sin(time*1.1f+phase)*3:Mathf.Sin(time*2+phase)*stride*2;
            var turn=Quaternion.Euler(nod,0,roll);var pivot=new Vector3(0,1.03f+lift,0);
            for(int i=0;i<head.Length;i++){head[i].localPosition=pivot+turn*(positions[i]-pivot);head[i].localRotation=turn*(head[i].name=="Eyebrow"?head[i].localRotation:rotations[i]);}
            torso.localRotation=Quaternion.Euler(activity=="clean"?5:0,0,Mathf.Sin(time*2+phase)*stride*1.6f);
            // Cancel walking bounce for a loaded tray; its food stays level.
            food.localPosition=trayPosition-Vector3.up*(carrying?bob/rootScale:0);food.localRotation=Quaternion.identity;
        }
    }
}
