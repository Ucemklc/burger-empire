using BurgerEmpire.Core;
using UnityEngine;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

namespace BurgerEmpire.Unity
{
    public sealed class RestaurantLayoutEditor
    {
        readonly BurgerEmpireGame game;
        public bool Active { get; private set; }
        public RestaurantLayout Draft { get; private set; }
        public RestaurantLayout Preview { get; private set; }
        public int Selected { get; private set; }
        public string Message { get; private set; }
        public bool Valid { get; private set; }=true;
        public bool Dragging { get; private set; }
        bool resume,gesture;
        Vector2 offset;
        Vector2 lastCell;
        bool hasCell,lastAllowed;
        float touchTime=-10;
        public RestaurantLayoutEditor(BurgerEmpireGame owner){game=owner;}
        public void Begin(bool resumeAfter)
        {
            Draft=game.Sim.P.layout.Copy();Preview=Draft;Selected=0;resume=resumeAfter;
            Active=true;game.Sim.Paused=true;Message="Masayı veya bitkiyi sürükle. Değişiklikler Kaydet ile uygulanır.";
        }
        public bool Finish(bool save)
        {
            EndPointer(true);
            if(save&&!game.Sim.ApplyLayout(Draft,out string reason)){Message=reason;return false;}
            Active=false;game.Sim.Paused=!resume;
            if(save)game.Save();
            return true;
        }
        public void Backgrounded(){resume=false;EndPointer(true);}
        public void SelectNext()
        {
            EndPointer(true);
            do {Selected=(Selected+1)%7;} while(!Owned(Selected));
            Message="Seçili: "+SelectedName+". Sürükle veya zeminde bir konuma dokun.";
        }
        public bool Owned(int i){return i<4?i<game.Sim.P.tables:i==4||game.Sim.P.decor>0;}
        public string SelectedName {get{return Selected<4?"Masa "+(Selected+1):Selected==4?"Giriş bitkisi":"Bitki "+(Selected-4);}}
        public void CycleStyle(int category)
        {
            EndPointer(true);
            if(category==0)Draft.floor=(Draft.floor+1)%3;
            if(category==1)Draft.wall=(Draft.wall+1)%3;
            if(category==2)Draft.furniture=(Draft.furniture+1)%3;
            Preview=Draft;Message="Stil önizlemesi hazır. Uygulamak için Kaydet.";
        }
        public void Reset()
        {
            EndPointer(true);Draft=RestaurantLayout.Default();Preview=Draft;Message="İlk düzen önizleniyor. Kaydet veya Vazgeç.";
        }
        static Point Get(RestaurantLayout l,int id){return id<4?l.tables[id]:l.plants[id-4];}
        public Point SelectedPosition {get{return Get(Preview,Selected);}}
        bool Ground(Vector2 screen,out Vector3 p,float height=.25f)
        {
            var ray=game.GameCamera.ScreenPointToRay(screen);var plane=new Plane(Vector3.up,new Vector3(0,height,0));
            if(plane.Raycast(ray,out float d)){p=ray.GetPoint(d);return true;}p=default;return false;
        }
        int Pick(Vector2 screen)
        {
            int best=-1;float nearest=float.MaxValue;
            for(int i=0;i<7;i++)if(Owned(i)&&Ground(screen,out var p,i<4?1.15f:.9f)) {
                Point item=Get(Draft,i);float dx=Mathf.Abs(p.x-item.x),dz=Mathf.Abs(p.z-item.z);
                if(dx<(i<4?.95f:.7f)&&dz<(i<4?1.25f:.7f)) {
                    float d=Vector3.Distance(game.GameCamera.transform.position,p);if(d<nearest){best=i;nearest=d;}
                }
            }
            return best;
        }
        public void BeginPointer(Vector2 screen)
        {
            if(!Active||game.PointerOnUI(screen)||!game.GameCamera.pixelRect.Contains(screen)||!Ground(screen,out var p))return;
            int picked=Pick(screen);if(picked>=0)Selected=picked;
            Point original=Get(Draft,Selected);
            offset=picked>=0?new Vector2(original.x-p.x,original.z-p.z):Vector2.zero;
            gesture=true;Dragging=true;hasCell=false;MovePointer(screen);
        }
        public void MovePointer(Vector2 screen)
        {
            if(!gesture||!Ground(screen,out var p))return;
            Vector2 cell=new Vector2(LayoutRules.Snap(p.x+offset.x),LayoutRules.Snap(p.z+offset.y));
            bool allowed=game.GameCamera.pixelRect.Contains(screen)&&!game.PointerOnUI(screen);
            if(hasCell&&cell==lastCell&&allowed==lastAllowed)return;
            lastCell=cell;lastAllowed=allowed;hasCell=true;
            Preview=Draft.Copy();Point item=Get(Preview,Selected);
            item.x=cell.x;item.z=cell.y;Valid=allowed;
            string reason="Eşyayı restoranın içine bırak.";
            if(Valid)Valid=LayoutRules.Validate(Preview,out reason);
            Message=Valid?"Uygun konum · bırakınca yerleşir.":reason;
        }
        public void EndPointer(bool canceled=false)
        {
            if(!gesture)return;
            if(!canceled&&Valid){Draft=Preview;Message=SelectedName+" yerleştirildi. Kaydet ile kalıcı olur.";}
            else if(canceled)Message="Taşıma iptal edildi.";
            Preview=Draft;gesture=false;Dragging=false;Valid=true;
        }
        public void HandleInput()
        {
#if ENABLE_INPUT_SYSTEM
            if(Keyboard.current!=null&&Keyboard.current.escapeKey.wasPressedThisFrame){game.Hud.FinishLayout(false);return;}
            var touch=Touchscreen.current?.primaryTouch;
            if(touch!=null) {
                if(touch.press.wasPressedThisFrame){touchTime=Time.unscaledTime;BeginPointer(touch.position.ReadValue());}
                if(touch.press.isPressed){touchTime=Time.unscaledTime;MovePointer(touch.position.ReadValue());}
                if(touch.press.wasReleasedThisFrame){touchTime=Time.unscaledTime;EndPointer(touch.phase.ReadValue()==UnityEngine.InputSystem.TouchPhase.Canceled);}
            }
            var mouse=Mouse.current;
            if(mouse!=null&&Time.unscaledTime-touchTime>.2f) {
                if(mouse.leftButton.wasPressedThisFrame)BeginPointer(mouse.position.ReadValue());
                if(mouse.leftButton.isPressed)MovePointer(mouse.position.ReadValue());
                if(mouse.leftButton.wasReleasedThisFrame)EndPointer();
            }
#endif
        }
    }
}
