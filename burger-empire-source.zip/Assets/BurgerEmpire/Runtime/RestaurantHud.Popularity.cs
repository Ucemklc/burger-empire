using System.Linq;
using BurgerEmpire.Core;
using UnityEngine;

namespace BurgerEmpire.Unity
{
    public sealed partial class RestaurantHud
    {
        float DrawPopularity(float y)
        {
            var p=game.Sim.P;int score=PopularityCatalog.Score(p);
            Label(BranchCatalog.Name(p.activeBranch)+" · Restoran popülerliği",panel,10,y,panelWidth-20,60,23,ink,FontStyle.Bold);y+=68;
            var summary=Card("Popularity summary",panel,0,y,panelWidth,144,RestaurantArt.Hex("DCE5DE"));
            Label(score+" / 100",summary.transform,14,6,panelWidth-28,48,32,green,FontStyle.Bold);
            Label(PopularityCatalog.Tier(score),summary.transform,14,58,panelWidth-28,42,22,ink);
            Card("Popularity track",summary.transform,14,118,panelWidth-28,10,RestaurantArt.Hex("BECBBE"));
            Card("Popularity fill",summary.transform,14,118,(panelWidth-28)*score/100f,10,RestaurantArt.Gold);y+=156;
            string boost=PopularityCatalog.TrafficBonus(p).ToString("0.#");
            Label("SALON TRAFİĞİ  +%"+boost,panel,12,y,panelWidth-24,38,21,green,FontStyle.Bold);y+=44;
            Label(PopularityCatalog.TrafficUnlocked(p)?"Uygun yer olduğunda müşteriler daha sık gelir. 100 popülerlikte geliş sıklığı %25 artar.":"Trafik bonusu ilk vardiya ve 10 ödeme sonrası açılır. Şu an: "+Mathf.Min(p.served,10)+" / 10 ödeme.",panel,12,y,panelWidth-24,96,17,ink);y+=108;
            Label("INFLUENCER ŞANSI  %"+PopularityCatalog.InfluencerChance(p,p.activeBranch),panel,12,y,panelWidth-24,38,21,green,FontStyle.Bold);y+=44;
            Label("Salona gelen yeni müşteriler içindeki olasılık. Şubenin ilk müşterisi müdavimdir. Başarılı paylaşım: "+p.influencerShares,panel,12,y,panelWidth-24,96,17,ink);y+=108;
            Button("VIP MİSAFİR ŞANSI · %"+VipCatalog.Chance(p),panel,10,y,panelWidth-20,56,green,()=>OpenPanel("VIP misafirler"),16).name="Popularity VIP";y+=68;
            var last=p.reviews.LastOrDefault(r=>r.popularityRecorded);
            Label("SON ETKİ",panel,12,y,panelWidth-24,30,14,green,FontStyle.Bold);y+=34;
            Label(last==null?"Yeni ziyaretlerle tanınmaya başla. Önceki yorumlar puana tekrar eklenmez.":last.name+" · "+ReviewCatalog.Channel(last.channel)+"\n"+PopularityCatalog.Effect(last)+(last.popularityChange==0?" · Sınıra ulaşıldı":""),panel,12,y,panelWidth-24,90,18,ink).name="Popularity last effect";y+=102;
            Label("NASIL YÜKSELİR?",panel,12,y,panelWidth-24,30,14,green,FontStyle.Bold);y+=34;
            Label("4★ ve üzeri tamamlanan ziyaret: +1\nSalonda 4,5★ ve üzeri influencer: +4 toplam\n4★ altı tamamlanan ziyaret: −1\nSipariş tamamlanmadan ayrılma: −2",panel,12,y,panelWidth-24,144,17,ink);y+=156;
            Label("Hızlı servis, temiz masalar ve dekor iyi yorum getirir. Araç ve kurye yorumları da puanı etkiler; paylaşım bonusu salondaki influencer'a aittir.",panel,12,y,panelWidth-24,126,16,muted);y+=138;
            Label("Her şubenin popülerliği ayrıdır; gün değişiminde sıfırlanmaz. Bu bonus fiyatları ve paket geliş hızını değiştirmez. Dolu kuyruk yeni müşteriyi bekletir.",panel,12,y,panelWidth-24,126,16,muted);y+=138;
            Button("MÜŞTERİ YORUMLARINI GÖR",panel,10,y,panelWidth-20,56,green,()=>OpenPanel("Müşteri yorumları"),16).name="Popularity reviews";y+=68;
            Button("RESTORANA DÖN",panel,10,y,panelWidth-20,56,green,()=>OpenPanel("Restoran"),16).name="Popularity back";return y+68;
        }
    }
}
