using UnityEngine;

namespace BurgerEmpire.Unity
{
    public sealed partial class RestaurantHud
    {
        float DrawAudioSettings(float y)
        {
            y=GuideText("Restoranın ritmi",y,24,ink,true);
            y=GuideText("Hafif bir müzik eşliğinde restoranını işlet. Müzik ve oyun efektlerini ayrı ayarlayabilirsin.",y,17,muted);
            y=AudioLevel("Müzik",true,y+12);
            y=AudioLevel("Efektler ve mutfak",false,y+12);
            y=GuideText(game.SoundEnabled?"Ses açık. %0 seçtiğin kanal sessiz kalır.":"Tüm sesler kapalı. Ses açılınca seçtiğin düzeyler kullanılır.",y+8,16,green);
            Button(game.SoundEnabled?"TÜM SESLERİ KAPAT":"TÜM SESLERİ AÇ",panel,10,y,panelWidth-20,56,green,()=>{game.SetSound(!game.SoundEnabled);RefreshPanel();},16).name="Audio master";y+=68;
            y=GuideText("Müzik vardiya sırasında çalar. Menü açınca veya oyunu duraklatınca bekler; oyuna dönünce kaldığı yerden sürer. Telefon arka plana geçince bütün sesler durur.",y,16,muted);
            y=GuideText("Seçimlerin oyunu kapatıp açtığında korunur.",y+6,16,muted);
            Button(mainMenu?"AYARLARA DÖN":"RESTORANA DÖN",panel,10,y+8,panelWidth-20,56,green,()=>OpenPanel(mainMenu?"Ayarlar":"Restoran"),17);return y+76;
        }
        float AudioLevel(string title,bool music,float y)
        {
            float value=music?game.MusicVolume:game.EffectsVolume;
            y=GuideText(title,y,20,ink,true);
            string id=music?"music":"effects";
            var down=Button("−",panel,10,y,58,56,green,()=>AdjustAudio(music,-.1f),24);down.name="Audio down "+id;down.interactable=value>0;
            Label("%"+Mathf.RoundToInt(value*100),panel,76,y,panelWidth-152,56,24,ink,FontStyle.Bold,TextAnchor.MiddleCenter).name="Audio level "+id;
            var up=Button("+",panel,panelWidth-68,y,58,56,green,()=>AdjustAudio(music,.1f),24);up.name="Audio up "+id;up.interactable=value<1;
            return y+68;
        }
        void AdjustAudio(bool music,float delta)
        {
            float current=music?game.MusicVolume:game.EffectsVolume;
            float next=Mathf.Clamp01(Mathf.Round((current+delta)*100)/100);
            game.SetAudioLevels(music?next:game.MusicVolume,music?game.EffectsVolume:next);
        }
    }
}
