using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace BurgerEmpire.Unity
{
    public static class RestaurantArt
    {
        static readonly Dictionary<string, Material> palette = new Dictionary<string, Material>();
        public static readonly Color Red = Hex("D8442D"), Cream = Hex("FFF1D4"), Green = Hex("55884F"), Brown = Hex("624135"), Gold = Hex("F5B942");
        public static Color Hex(string hex) { ColorUtility.TryParseHtmlString("#" + hex, out Color c); return c; }
        public static Material Mat(Color color, bool metal = false)
        {
            string key = ColorUtility.ToHtmlStringRGBA(color) + (metal ? "metal" : "matte");
            if (palette.TryGetValue(key, out Material existing) && existing != null) return existing;
            var shader = Shader.Find("Universal Render Pipeline/Lit");
            var m = new Material(shader != null ? shader : Shader.Find("Standard")) { name = "BE_" + key };
            m.color = color;
            m.SetFloat("_Smoothness", metal ? .4f : .12f); m.SetFloat("_Metallic", metal ? .5f : 0);
            palette[key] = m; return m;
        }
        public static GameObject Shape(string name, PrimitiveType type, Transform parent, Vector3 position, Vector3 size, Color color, bool collider = false)
        {
            GameObject go = GameObject.CreatePrimitive(type); go.name = name; go.transform.SetParent(parent, false);
            go.transform.localPosition = position; go.transform.localScale = size;
            go.GetComponent<Renderer>().sharedMaterial = Mat(color);
            if(type==PrimitiveType.Cube&&StyleGeometry.Rounded(name))go.GetComponent<MeshFilter>().sharedMesh=StyleGeometry.SoftBox;
            else if(name=="Red cup"||name=="Shake cup")go.GetComponent<MeshFilter>().sharedMesh=StyleGeometry.Cup;
            if (!collider) { var c = go.GetComponent<Collider>(); if (Application.isPlaying) Object.Destroy(c); else Object.DestroyImmediate(c); }
            return go;
        }
        public static GameObject Box(string name, Transform parent, float x,float y,float z,float sx,float sy,float sz, Color c, bool collider=false)
        { return Shape(name, PrimitiveType.Cube, parent, new Vector3(x,y,z), new Vector3(sx,sy,sz),c,collider); }
        public static Transform Group(string name, Transform parent, Vector3 position)
        { var g = new GameObject(name).transform; g.SetParent(parent,false); g.localPosition=position; return g; }
        public static TextMesh Text(string name, string text, Transform parent, Vector3 pos, float size, Color color, bool flat=false)
        {
            var g=Group(name,parent,pos); var mesh=g.gameObject.AddComponent<TextMesh>();
            mesh.text=text; mesh.fontSize=64; mesh.characterSize=size*.24f; mesh.anchor=TextAnchor.MiddleCenter; mesh.alignment=TextAlignment.Center; mesh.color=color;
            g.gameObject.AddComponent<LocalizedWorldText>();
            mesh.font=Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            mesh.GetComponent<MeshRenderer>().sharedMaterial=mesh.font.material;
            g.localEulerAngles=flat?new Vector3(90,0,0):new Vector3(0,180,0);
            return mesh;
        }
        public static void Plant(Transform parent, Vector3 p, float scale=1)
        {
            Transform g=Group("Plant",parent,p); g.localScale=Vector3.one*scale;
            Shape("Terracotta",PrimitiveType.Cylinder,g,new Vector3(0,.22f,0),new Vector3(.45f,.22f,.45f),Hex("BC7355"));
            Shape("Soil",PrimitiveType.Cylinder,g,new Vector3(0,.45f,0),new Vector3(.37f,.02f,.37f),Brown);
            for(int i=0;i<5;i++) {
                float a=i*72*Mathf.Deg2Rad;
                var leaf=Shape("Leaf",PrimitiveType.Sphere,g,new Vector3(Mathf.Sin(a)*.2f,.76f,Mathf.Cos(a)*.2f),new Vector3(.27f,.75f,.23f),i%2==0?Green:Hex("6C9759"));
                leaf.transform.localEulerAngles=new Vector3(Mathf.Cos(a)*28,0,-Mathf.Sin(a)*28);
            }
        }
        public static void Burger(Transform parent, Vector3 p, float scale=1)
        {
            var g=Group("Burger",parent,p); g.localScale=Vector3.one*scale;
            Shape("Bottom bun",PrimitiveType.Cylinder,g,new Vector3(0,.06f,0),new Vector3(.42f,.055f,.42f),Gold);
            Shape("Patty",PrimitiveType.Cylinder,g,new Vector3(0,.16f,0),new Vector3(.44f,.04f,.44f),Brown);
            Box("Cheese",g,0,.21f,0,.43f,.025f,.43f,Hex("F6CE54"));
            Shape("Lettuce",PrimitiveType.Cylinder,g,new Vector3(0,.24f,0),new Vector3(.47f,.025f,.47f),Green);
            for(int i=0;i<5;i++)Shape("Lettuce edge",PrimitiveType.Sphere,g,new Vector3(Mathf.Sin(i*1.256f)*.20f,.245f,Mathf.Cos(i*1.256f)*.20f),new Vector3(.15f,.045f,.13f),Green);
            Shape("Tomato",PrimitiveType.Cylinder,g,new Vector3(0,.275f,0),new Vector3(.42f,.018f,.42f),Red);
            Shape("Top bun",PrimitiveType.Sphere,g,new Vector3(0,.32f,0),new Vector3(.45f,.2f,.45f),Hex("EBA655"));
            for(int i=0;i<5;i++) Shape("Sesame",PrimitiveType.Sphere,g,new Vector3(Mathf.Sin(i*2.4f)*.13f,.419f,Mathf.Cos(i*2.4f)*.1f),new Vector3(.02f,.008f,.05f),Cream);
        }
        public static void Cup(Transform parent, Vector3 p)
        {
            Shape("Red cup",PrimitiveType.Cylinder,parent,p+Vector3.up*.17f,new Vector3(.19f,.17f,.19f),Red);
            Shape("Lid",PrimitiveType.Cylinder,parent,p+Vector3.up*.35f,new Vector3(.21f,.025f,.21f),Cream);
            Box("Straw",parent,p.x+.03f,p.y+.49f,p.z,.025f,.27f,.025f,Gold);
        }
        public static Transform BuildWorld()
        {
            var root=new GameObject("Restaurant Environment").transform;
            Box("Meadow",root,5,-.52f,5,70,.45f,70,Hex("A5B49A"));
            Box("Sidewalk",root,5,-.23f,5,13,.35f,13,Hex("D9D5C5"));
            Box("Foundation",root,5,-.03f,5,10.4f,.42f,10.4f,Hex("826957"));
            for(int x=0;x<10;x++) for(int z=0;z<10;z++)
                Box("Floor tile",root,x+.5f,.205f,z+.5f,.98f,.045f,.98f,(x+z)%2==0?Hex("E9DECA"):Hex("D7C8AC"),true);
            Box("Back wall",root,5,1.5f,-.07f,10.4f,2.7f,.2f,Cream);
            Box("Side wall",root,-.07f,1.5f,5,.2f,2.7f,10.4f,Cream);
            Box("Back red stripe",root,5,.65f,.055f,10.25f,.72f,.08f,Red);
            Box("Left red stripe",root,.055f,.65f,5,.08f,.72f,10.25f,Red);
            Box("Wall trim",root,5,2.85f,0,10.4f,.15f,.3f,Brown);
            Box("Side trim",root,0,2.85f,5,.3f,.15f,10.4f,Brown);
            for(int i=0;i<3;i++) {
                var w=Group("Window",root,new Vector3(.08f,1.9f,4.1f+i*2.1f));
                Box("Wood frame",w,0,0,0,.13f,1.55f,1.65f,Brown);
                Box("Blue glass",w,.08f,0,0,.06f,1.32f,1.42f,Hex("A7CED0"));
                Box("Window bar",w,.14f,0,0,.08f,1.35f,.045f,Cream);
                Box("Window bar",w,.14f,0,0,.08f,.045f,1.4f,Cream);
                Box("Window sill",w,.15f,-.73f,0,.5f,.11f,1.8f,Cream);
                for(int stripe=0;stripe<7;stripe++)Box("Striped window valance",w,.25f,.67f,-.66f+stripe*.22f,.43f,.22f,.215f,stripe%2==0?Red:Cream);
            }
            Box("Brand plaque",root,5,2.06f,.14f,4.3f,1.1f,.12f,Red);
            Text("Brand", "BURGER EMPIRE",root,new Vector3(5,2.2f,.225f),.29f,Cream);
            Text("Motto", "İYİ BURGER, MUTLU İNSANLAR",root,new Vector3(5,1.81f,.23f),.09f,Gold);
            Box("Gold plaque border",root,5,2.59f,.22f,4.4f,.08f,.1f,Gold);
            for(int i=0;i<2;i++) {
                Box("Menu board",root,1.55f+i*6.85f,2.03f,.16f,1.8f,1.18f,.13f,Hex("35453D"));
                Text("Menu",i==0?"KLASİK MENÜ\n32 COIN":"ÇITIR PATATES\nBUZ GİBİ KOLA",root,new Vector3(1.55f+i*6.85f,2.05f,.245f),.105f,Cream);
            }
            Box("Kitchen base",root,4.7f,.73f,1.1f,8.2f,1.0f,1.45f,Hex("A6ADB0"));
            Box("Steel top",root,4.7f,1.28f,1.1f,8.4f,.12f,1.5f,Hex("CCD2CE"));
            for(int i=0;i<6;i++) {
                Box("Cabinet",root,1.1f+i*1.4f,.77f,1.85f,1.27f,.82f,.04f,Hex("BBC0B9"));
                Box("Handle",root,1.1f+i*1.4f,1.0f,1.9f,.35f,.04f,.035f,Brown);
            }
            for(int i=0;i<3;i++) {
                Transform grill=Group("Grill_"+i,root,new Vector3(1.6f+i*.9f,1.39f,1.1f));
                Box("Grill body",grill,0,0,0,.82f,.18f,1.0f,Hex("4B5250"));
                for(int k=0;k<6;k++) Box("Grill grate",grill,-.32f+k*.13f,.11f,0,.026f,.024f,.9f,Hex("8F9891"));
                Burger(grill,new Vector3(0,.13f,0),.65f);
                if(i>0) grill.gameObject.SetActive(false);
            }
            Box("Extractor hood",root,2.5f,2.56f,.85f,3.2f,.3f,1.2f,Hex("B3BCB8"));
            var steam=Group("CookingSteam",root,new Vector3(1.6f,1.7f,1.1f));
            for(int i=0;i<4;i++)Shape("Steam puff",PrimitiveType.Sphere,steam,new Vector3((i%2-.5f)*.23f,.2f+i*.13f,0),Vector3.one*.16f,Cream);
            steam.gameObject.SetActive(false);
            for(int i=0;i<2;i++) {
                Box("Fryer",root,4.5f+i*.73f,1.43f,1.05f,.6f,.23f,.9f,Hex("6D7670"));
                for(int k=0;k<7;k++) Box("Golden fries",root,4.29f+i*.73f+k*.065f,1.57f,1.03f,.045f,.14f,.32f,Gold);
                Box("Basket handle",root,4.5f+i*.73f,1.56f,1.8f,.1f,.08f,.55f,Brown);
            }
            Box("Soda machine",root,7.45f,1.94f,1.0f,1.05f,1.3f,.95f,Red);
            Box("Soda display",root,7.45f,2.13f,1.49f,.83f,.6f,.04f,Hex("343C3C"));
            Text("Soda brand","ICE COLD",root,new Vector3(7.45f,2.16f,1.525f),.075f,Cream);
            for(int i=0;i<3;i++) { Box("Tap",root,7.16f+i*.28f,1.67f,1.56f,.07f,.22f,.1f,Hex("C1C6B5")); Cup(root,new Vector3(7.16f+i*.28f,1.29f,1.77f)); }
            Box("Service counter",root,4.05f,.77f,3.02f,7.1f,1.05f,.8f,Red);
            Box("Counter top",root,4.05f,1.33f,3.02f,7.4f,.15f,1f,Hex("EDD3A3"));
            for(int i=0;i<8;i++) Box("Counter slat",root,.73f+i*.92f,.77f,3.46f,.025f,.85f,.03f,Hex("A5392D"));
            Text("Counter brand","HER ISIRIKTA MUTLULUK",root,new Vector3(3.8f,.85f,3.46f),.19f,Cream);
            Box("Counter gold rail",root,4.05f,1.18f,3.47f,7.1f,.055f,.06f,Gold);
            for(int i=0;i<3;i++) {
                float lx=2+i*2;
                Shape("Pendant cord",PrimitiveType.Cylinder,root,new Vector3(lx,3.45f,2.65f),new Vector3(.035f,.55f,.035f),Brown);
                Shape("Red pendant",PrimitiveType.Sphere,root,new Vector3(lx,2.94f,2.65f),new Vector3(.65f,.3f,.65f),Red);
                Shape("Warm bulb",PrimitiveType.Sphere,root,new Vector3(lx,2.82f,2.65f),new Vector3(.36f,.08f,.36f),Hex("FFE0A0"));
            }
            var register=Box("Cash register",root,7.05f,1.51f,2.98f,.5f,.26f,.5f,Hex("344C45"));
            Box("Register screen",root,7.05f,1.8f,3.03f,.54f,.37f,.1f,Hex("303C3A"));
            Box("Green screen",root,7.05f,1.8f,3.09f,.44f,.27f,.02f,Hex("91B8A1"));
            Cup(root,new Vector3(5.9f,1.41f,3.05f)); Burger(root,new Vector3(4.8f,1.41f,3.03f));
            for(int i=0;i<4;i++) BuildTable(root,i,i%2==0?2.3f:6,i<2?5.1f:7.8f,i<2);
            Plant(root,new Vector3(.55f,.25f,9.45f),1.4f); Plant(root,new Vector3(.6f,.25f,2.4f));
            Transform decorations=Group("ExtraDecor",root,Vector3.zero);
            Plant(decorations,new Vector3(4.15f,.25f,5.5f),1.1f); Plant(decorations,new Vector3(4.15f,.25f,8.6f),1.1f); decorations.gameObject.SetActive(false);
            Box("Entry mat",root,9.3f,.25f,8.5f,1.2f,.055f,1.6f,Green);
            Text("Welcome mat","HOŞ GELDİN",root,new Vector3(9.3f,.285f,8.5f),.10f,Cream,true);
            var sign=Group("Street sign",root,new Vector3(10.75f,.1f,6.5f));
            Shape("Sign pole",PrimitiveType.Cylinder,sign,new Vector3(0,1.05f,0),new Vector3(.12f,1.05f,.12f),Brown);
            Box("Sign board",sign,0,2.12f,0,1.5f,1.3f,.13f,Red);
            Text("Sign text","BURGER\nEMPIRE",sign,new Vector3(0,2.24f,.08f),.2f,Cream);
            Text("Open label","AÇIK",sign,new Vector3(0,1.8f,.08f),.16f,Gold);
            for(int i=0;i<5;i++) {
                var tree=Group("Street tree",root,new Vector3(i<3?-2f:12.4f,-.05f,i<3?i*5f:2+(i-3)*10));
                Shape("Trunk",PrimitiveType.Cylinder,tree,new Vector3(0,.7f,0),new Vector3(.25f,.8f,.25f),Brown);
                Shape("Canopy",PrimitiveType.Sphere,tree,new Vector3(0,1.85f,0),new Vector3(1.6f,2.0f,1.5f),i%2==0?Hex("769466"):Hex("628254"));
            }
            Box("Road",root,5,-.18f,14,40,.04f,3.5f,Hex("88968D"));
            for(int i=0;i<15;i++) Box("Road marking",root,-9+i*2,-.145f,14,.8f,.015f,.06f,Hex("DADED0"));
            return root;
        }
        static void BuildTable(Transform root,int id,float x,float z,bool active)
        {
            var g=Group("Table_"+id,root,new Vector3(x,.25f,z));
            Shape("Table leg",PrimitiveType.Cylinder,g,new Vector3(0,.43f,0),new Vector3(.15f,.4f,.15f),Brown);
            Box("Foot",g,0,.1f,0,.7f,.12f,.55f,Brown);
            Box("Oak top",g,0,.91f,0,1.55f,.18f,1.15f,Hex("DCA66C"));
            for(int i=0;i<4;i++) Box("Wood joint",g,-.53f+i*.35f,1.005f,0,.015f,.007f,1.14f,Hex("C9935E"));
            for(int side=-1;side<=1;side+=2) {
                Box("Seat cushion",g,0,.45f,side*.88f,.83f,.18f,.63f,Red);
                Box("Seat back",g,0,.8f,side*1.13f,.87f,.8f,.13f,Red);
                for(int k=-1;k<=1;k+=2) Box("Chair leg",g,k*.29f,.19f,side*.9f,.065f,.44f,.44f,Brown);
            }
            Cup(g,new Vector3(-.46f,1.02f,-.32f));
            var meal=Group("Meal",g,new Vector3(0,1.03f,.05f));
            Shape("Serving plate",PrimitiveType.Cylinder,meal,new Vector3(0,.015f,0),new Vector3(.85f,.018f,.65f),Cream);
            Burger(meal,new Vector3(-.12f,.04f,0),.8f);
            for(int i=0;i<4;i++)Box("Fries",meal,.2f+i*.055f,.07f,.04f,.04f,.045f,.24f,Gold);
            meal.gameObject.SetActive(false);
            Box("Napkin holder",g,.46f,1.12f,-.32f,.22f,.24f,.17f,Cream);
            Transform dirt=Group("Dirty",g,new Vector3(0,1.025f,0));
            Box("Tray",dirt,0,0,0,.69f,.025f,.48f,Hex("BCA274"));
            Box("Wrapper",dirt,.13f,.025f,0,.35f,.02f,.32f,Cream);
            for(int i=0;i<4;i++) Shape("Crumb",PrimitiveType.Sphere,dirt,new Vector3(-.2f+i*.13f,.035f,.05f),Vector3.one*.065f,Gold);
            dirt.gameObject.SetActive(false); g.gameObject.SetActive(active);
            if(!active) {
                var pad=Group("TablePad_"+id,root,new Vector3(x,.26f,z));
                Box("Expansion space",pad,0,0,0,1.7f,.012f,1.5f,Hex("C5C5AD"));
                Text("Build here","+",pad,new Vector3(0,.025f,0),.4f,Hex("8A957B"),true);
            }
        }
        public sealed class Person
        {
            public int variant;
            public Transform root,leftLeg,rightLeg,leftArm,rightArm,food;
            public Vector3 last;
            public CharacterMotion motion;
            public CharacterDetails details;
            public CharacterSilhouette silhouette;
            public void UpdatePosition(float x,float z,float time,bool carrying,bool seated=false,string activity="",Vector3? facing=null)
            {motion.Apply(x,z,time,carrying,seated,activity,facing);}
        }
        public static Person BuildPerson(string role, int variant, Transform parent)
        {
            Transform g=Group(role,parent,Vector3.zero);g.localScale=Vector3.one*1.08f;
            Color[] shirts={Hex("679D9B"),Hex("DC9B65"),Hex("807DB0"),Hex("475968"),Hex("D5849B"),Hex("AAB36B")};
            Color skin=variant%3==0?Hex("EFC199"):variant%3==1?Hex("D99B70"):Hex("AB775B");
            bool worker=role!="customer",vip=!worker&&variant==BurgerEmpire.Core.VipCatalog.Kind;
            Color shirt=worker?(role=="cook"||role=="waiter"?Cream:role=="cleaner"?Hex("5B8EB2"):role=="manager"?Hex("415057"):Red):vip?Hex("302D42"):shirts[variant%shirts.Length];
            var p=new Person {root=g,variant=variant};
            p.leftLeg=Group("Left leg",g,new Vector3(-.13f,.45f,0));
            p.rightLeg=Group("Right leg",g,new Vector3(.13f,.45f,0));
            foreach(Transform leg in new[]{p.leftLeg,p.rightLeg}) {
                Shape("Trousers",PrimitiveType.Capsule,leg,new Vector3(0,-.17f,0),new Vector3(.18f,.22f,.18f),Hex("3E4546"));
                Shape("Shoe",PrimitiveType.Cube,leg,new Vector3(0,-.35f,.065f),new Vector3(.22f,.12f,.34f),Brown);
            }
            Shape("Torso",PrimitiveType.Capsule,g,new Vector3(0,.7f,0),new Vector3(.48f,.33f,.36f),shirt);
            if(vip) {
                Box("VIP shirt",g,0,.79f,.19f,.19f,.28f,.035f,Cream);
                Box("VIP gold tie",g,0,.78f,.224f,.055f,.22f,.025f,Gold);
                for(int side=-1;side<=1;side+=2) {
                    var lapel=Box("VIP lapel",g,side*.115f,.82f,.204f,.06f,.27f,.035f,Hex("53465C"));
                    lapel.transform.localEulerAngles=new Vector3(0,0,side*18);
                }
                Shape("VIP pin",PrimitiveType.Sphere,g,new Vector3(.16f,.88f,.21f),new Vector3(.09f,.09f,.035f),Gold);
            }
            if(worker&&role!="manager") {
                Box("Apron",g,0,.63f,.2f,.36f,.44f,.055f,role=="cook"?Red:Brown);
                Box("Apron pocket",g,0,.55f,.232f,.23f,.12f,.018f,role=="cook"?Brown:Red);
                Box("Apron trim",g,0,.76f,.232f,.31f,.035f,.02f,Gold);
            }
            if(worker)Shape("Uniform badge",PrimitiveType.Sphere,g,new Vector3(.105f,.83f,.213f),new Vector3(.09f,.09f,.025f),Gold);
            if(role=="manager") {
                Box("Manager shirt",g,0,.8f,.18f,.2f,.3f,.04f,Cream);
                Box("Manager tie",g,0,.75f,.215f,.065f,.28f,.025f,Red);
            }
            p.leftArm=Group("Left arm",g,new Vector3(-.29f,.9f,0)); p.rightArm=Group("Right arm",g,new Vector3(.29f,.9f,0));
            foreach(Transform arm in new[]{p.leftArm,p.rightArm}) {
                Shape("Sleeve",PrimitiveType.Capsule,arm,new Vector3(0,-.14f,0),new Vector3(.19f,.15f,.2f),shirt);
                Shape("Hand",PrimitiveType.Sphere,arm,new Vector3(0,-.32f,0),new Vector3(.18f,.2f,.18f),skin);
            }
            Shape("Neck",PrimitiveType.Cylinder,g,new Vector3(0,1.01f,0),new Vector3(.17f,.1f,.17f),skin);
            Shape("Head",PrimitiveType.Sphere,g,new Vector3(0,1.28f,0),new Vector3(.63f,.66f,.56f),skin);
            Shape("Hair",PrimitiveType.Sphere,g,new Vector3(0,1.48f,-.04f),new Vector3(.63f,.30f,.56f),Brown);
            for(int i=-1;i<=1;i+=2) {
                Shape("Ear",PrimitiveType.Sphere,g,new Vector3(i*.275f,1.27f,0),new Vector3(.12f,.18f,.13f),skin);
                Shape("Eye",PrimitiveType.Sphere,g,new Vector3(i*.14f,1.34f,.265f),new Vector3(.14f,.17f,.055f),Cream);
                Shape("Pupil",PrimitiveType.Sphere,g,new Vector3(i*.14f,1.34f,.294f),new Vector3(.070f,.105f,.022f),Brown);
            }
            for(int side=-1;side<=1;side+=2) {
                var brow=Box("Eyebrow",g,side*.14f,1.465f,.267f,.16f,.035f,.03f,Brown);
                brow.transform.localRotation=Quaternion.Euler(0,0,side*-8);
                Shape("Eye glint",PrimitiveType.Sphere,g,new Vector3(side*.14f-.016f,1.37f,.312f),new Vector3(.026f,.030f,.012f),Cream);
                Shape("Cheek",PrimitiveType.Sphere,g,new Vector3(side*.21f,1.22f,.251f),new Vector3(.13f,.065f,.026f),Hex("E2A180"));
            }
            Shape("Nose",PrimitiveType.Sphere,g,new Vector3(0,1.25f,.30f),new Vector3(.1f,.1f,.09f),skin);
            if(vip) {
                for(int side=-1;side<=1;side+=2)Box("VIP sunglasses",g,side*.135f,1.34f,.323f,.23f,.13f,.034f,Hex("2A343D"));
                Box("VIP glasses bridge",g,0,1.34f,.33f,.07f,.026f,.024f,Gold);
            }
            Shape("Smile",PrimitiveType.Sphere,g,new Vector3(0,1.14f,.267f),new Vector3(.15f,.085f,.028f),Brown);
            Box("Smile teeth",g,0,1.162f,.285f,.11f,.025f,.012f,Cream);
            if(role=="cook") {
                for(int side=-1;side<=1;side+=2)Shape("Chef moustache",PrimitiveType.Sphere,g,new Vector3(side*.055f,1.195f,.27f),new Vector3(.13f,.055f,.035f),Brown);
                for(int i=0;i<3;i++)Shape("Chef hat puff",PrimitiveType.Sphere,g,new Vector3((i-1)*.18f,1.77f,0),new Vector3(.3f,.34f,.32f),Cream);
            }
            if(role=="manager"||(!worker&&variant==3)) {
                for(int side=-1;side<=1;side+=2)Box("Glasses",g,side*.13f,1.33f,.268f,.22f,.15f,.028f,Hex("263839"));
                Box("Glasses bridge",g,0,1.33f,.285f,.06f,.035f,.03f,Gold);
            }
            if(role=="drive") {
                Shape("Drive headset",PrimitiveType.Sphere,g,new Vector3(-.31f,1.34f,0),new Vector3(.16f,.25f,.20f),Hex("263839"));
                Box("Headset microphone",g,-.26f,1.17f,.22f,.045f,.045f,.35f,Hex("263839"));
            }
            if(!worker&&(variant==1||variant==4)) {
                Shape("Ponytail",PrimitiveType.Sphere,g,new Vector3(0,1.34f,-.3f),new Vector3(.32f,.48f,.33f),Brown);
                Shape("Hair ribbon",PrimitiveType.Sphere,g,new Vector3(0,1.53f,-.28f),new Vector3(.35f,.12f,.15f),Red);
            }
            if(worker && role!="manager") {
                Color cap=role=="cook"?Cream:shirt;
                Shape("Cap",PrimitiveType.Sphere,g,new Vector3(0,1.56f,0),new Vector3(.61f,role=="cook"?.43f:.21f,.57f),cap);
                if(role!="cook") Box("Cap brim",g,0,1.53f,.29f,.52f,.065f,.27f,cap);
            }
            p.food=Group("Carried tray",g,new Vector3(0,.85f,.55f));
            Box("Tray",p.food,0,0,0,.7f,.045f,.45f,Gold); Burger(p.food,new Vector3(-.14f,.03f,0),.55f); Cup(p.food,new Vector3(.21f,.03f,0)); p.food.gameObject.SetActive(false);
            if(role=="player") {
                Shape("Player marker",PrimitiveType.Cylinder,g,new Vector3(0,.005f,0),new Vector3(.9f,.012f,.9f),Hex("E6BB64"));
            }
            p.details=new CharacterDetails(p,role,skin);
            p.silhouette=new CharacterSilhouette(p,role);
            p.motion=new CharacterMotion(p,worker);
            return p;
        }
    }
}
