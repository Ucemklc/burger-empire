using System.Linq;
using BurgerEmpire.Core;
using UnityEngine;

namespace BurgerEmpire.Unity
{
    public sealed partial class RestaurantHud
    {
        float DrawAchievements(float y)
        {
            var items=game.Sim.Achievements();int collected=items.Count(a=>a.claimed),ready=items.Count(a=>a.unlocked&&!a.claimed);
            var summary=Card("Achievement summary",panel,0,y,panelWidth,112,RestaurantArt.Hex("DCE5DE"));
            Label(collected+" / "+items.Count+" ÖDÜL ALINDI",summary.transform,14,6,panelWidth-28,38,23,green,FontStyle.Bold);
            Label(ready>0?ready+" başarım ödülü seni bekliyor!":"Küçük restoranından büyük hedeflere.",summary.transform,14,48,panelWidth-28,50,17,ink);y+=124;
            Label("İki şubenin ortak hedefleri · Günlük sıfırlanmaz\nHer ödül bir kez alınır. Eski kayıtlı ilerlemen de sayılır.",panel,12,y,panelWidth-24,72,15,muted);y+=84;
            Button("‹ GÖREVLERE DÖN",panel,10,y,panelWidth-20,50,green,()=>OpenPanel("Görevler"),16).name="Achievements back";y+=62;
            // Ready rewards first; within each group keep the stable catalogue order.
            foreach(var a in items.OrderBy(a=>a.claimed?2:a.unlocked?0:1)) {
                var d=a.definition;
                var card=Card("Achievement "+d.id,panel,0,y,panelWidth,242,RestaurantArt.Hex(a.claimed?"E4E8D4":"ECECD8"));
                Card("Achievement accent",card.transform,0,0,5,242,a.unlocked?RestaurantArt.Gold:green,false);
                Label(d.title,card.transform,14,8,panelWidth-28,36,22,ink,FontStyle.Bold);
                Label(d.description,card.transform,14,48,panelWidth-28,54,16,muted);
                string amount=d.id=="rating"?(a.current/100f).ToString("0.00")+" / 4,50 puan":Mathf.Min(a.current,d.target).ToString("N0")+" / "+d.target.ToString("N0")+" "+d.unit;
                Label(a.claimed?"Ödül alındı · Kalıcı başarım":a.unlocked?"TAMAMLANDI · Ödülünü alabilirsin":amount,card.transform,14,107,panelWidth-28,26,14,green,FontStyle.Bold);
                Card("Progress track",card.transform,14,139,panelWidth-28,6,RestaurantArt.Hex("C2C9B9"));
                Card("Achievement progress",card.transform,14,139,(panelWidth-28)*(a.unlocked?1:Mathf.Clamp01(a.current/(float)d.target)),6,green);
                Label(d.reward+" coin + "+AchievementCatalog.RewardXP+" XP",card.transform,14,151,panelWidth-28,25,14,ink);
                var button=Button(a.claimed?"ALINDI":a.unlocked?"ÖDÜLÜ AL":"DEVAM EDİYOR",card.transform,12,181,panelWidth-24,50,a.unlocked&&!a.claimed?red:green,()=>game.Command("achieve",d.id),16);
                button.name="Claim achievement "+d.id;button.interactable=a.unlocked&&!a.claimed;y+=254;
            }
            Label("Burger hedefi: klasik, cheese ve çift katlı satışları. Milkshake dahil değildir. Gelir hedefi müşteri ödemelerini sayar; görev ve başarım ödülleri sayılmaz.",panel,12,y,panelWidth-24,126,15,muted);return y+138;
        }
    }
}
