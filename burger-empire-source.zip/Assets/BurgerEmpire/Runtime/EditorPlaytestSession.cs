#if UNITY_EDITOR
using System;
using System.IO;
using UnityEditor;
using UnityEngine;

namespace BurgerEmpire.Unity
{
    // This entire profile selector is excluded from Android builds.
    public static class EditorPlaytestSession
    {
        const string Key="BurgerEmpire.LocalPlaytest.Id";
        public static string Id=>SessionState.GetString(Key,"");
        public static bool Active=>Id!="";
        public static string Root=>Path.GetFullPath(Path.Combine(Application.dataPath,"..","BurgerEmpirePlaytests"));
        static string ValidId(string id)
        {
            if(!Guid.TryParseExact(id,"N",out _))throw new InvalidOperationException("Geçersiz deneme profili. Normal kayda geçilmedi.");
            return id;
        }
        public static string ProfilePath(string id)=>Path.Combine(Root,ValidId(id),"Progress.json");
        public static string ResolveSavePath(string normal)=>Active?ProfilePath(Id):normal;
        public static string PreferenceKey(string normal)=>Active?"BurgerEmpire.Playtest."+ValidId(Id)+"."+normal:normal;
        public static string NewProfile()
        {
            if(Application.isPlaying)throw new InvalidOperationException("Önce Play modunu durdur.");
            string id=Guid.NewGuid().ToString("N");Select(id);
            return id;
        }
        public static void Select(string id)
        {
            if(Application.isPlaying)throw new InvalidOperationException("Oynarken deneme profili değiştirilemez.");
            string path=ProfilePath(id);Directory.CreateDirectory(Path.GetDirectoryName(path));SessionState.SetString(Key,id);
        }
        public static void Clear()=>SessionState.EraseString(Key);
    }
}
#endif
