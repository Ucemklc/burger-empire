using System.Linq;
using BurgerEmpire.Core;
using UnityEngine;

namespace BurgerEmpire.Unity
{
    public sealed partial class RestaurantHud
    {
        float GuideText(string text,float y,int size,Color color,bool bold=false)
        {
            var label=Label(text,panel,14,y,panelWidth-28,32,size,color,bold?FontStyle.Bold:FontStyle.Normal);
            float h=Mathf.Max(28,label.preferredHeight+8);label.rectTransform.sizeDelta=new Vector2(panelWidth-28,h);return y+h;
        }
        float GuideLink(float y)
        {
            Button("GELİŞİM REHBERİ",panel,10,y,panelWidth-20,56,green,()=>OpenPanel("Gelişim Rehberi"),17).name="Open growth guide";return y+68;
        }
        float DrawGrowthGuide(float y)
        {
            var steps=GrowthGuide.Steps(game.Sim);var next=steps.FirstOrDefault(s=>!s.complete);
            y=GuideText(BranchCatalog.Name(game.Sim.P.activeBranch)+" · "+steps.Count(s=>s.complete)+"/"+steps.Count+" rehber adımı",y,22,ink,true);
            y=GuideText("İstediğin sırayla ilerleyebilirsin. Bu liste gelişim önerileridir; oyunun tamamlanma yüzdesi değildir.",y,16,muted);
            int rewards=game.Sim.Missions().Count(m=>!m.claimed&&m.current>=m.target);
            if(rewards>0||game.Sim.ReadyAchievements>0) {
                y=GuideText("Alınmayı bekleyen ödüllerin var.",y+6,17,green,true);
                string destination=rewards>0?"Görevler":"Başarımlar";
                Button("ÖDÜLLERE GİT",panel,10,y,panelWidth-20,52,red,()=>OpenPanel(destination),16).name="Guide rewards";y+=64;
            }
            if(next==null)y=GuideText("Bu rehberin bütün adımları tamam! Servis kaliteni, görevlerini ve şubelerindeki gelişmeleri takip etmeye devam edebilirsin.",y+8,17,green,true);
            foreach(var step in steps.OrderBy(s=>s.complete?1:0)) {
                y+=10;Card("Guide divider",panel,10,y,panelWidth-20,2,RestaurantArt.Gold,false);y+=10;
                y=GuideText((step.complete?"TAMAM · ":step==next?"SIRADAKİ · ":"")+step.title,y,20,step==next?red:ink,true);
                if(step.complete)continue;
                y=GuideText(step.description,y,16,muted);
                y=GuideText(step.detail,y,16,green);string target=step.target;
                string label=target=="play"?"VARDİYAYA DÖN":target=="Şubeler"?"ŞUBELERE GİT":"GEREKEN GELİŞTİRMEYİ GÖR";
                Button(label,panel,10,y,panelWidth-20,56,green,()=>{if(target=="play")ClosePanel();else OpenPanel(target);},15).name="Guide action "+step.id;y+=68;
            }
            Button("GÖREVLERE DÖN",panel,10,y+10,panelWidth-20,56,green,()=>OpenPanel("Görevler"),17);return y+78;
        }
        float DrawGuidedOffer(string id,float y)
        {
            var offer=game.Sim.Offers().FirstOrDefault(o=>o.id==id);
            if(offer!=null)y=DrawOffer(offer,y);
            y=GuideText("Satın alma sonrasında sıradaki öneri rehberde güncellenir.",y,16,muted);
            Button("REHBERE DÖN",panel,10,y,panelWidth-20,56,green,()=>OpenPanel("Gelişim Rehberi"),17).name="Back to growth guide";return y+68;
        }
    }
}
