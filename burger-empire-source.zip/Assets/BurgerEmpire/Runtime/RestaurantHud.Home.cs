using BurgerEmpire.Core;
using UnityEngine;

namespace BurgerEmpire.Unity
{
    public sealed partial class RestaurantHud
    {
        bool mainMenu=true;
        string toastSource="";
        public void LanguageChanged(){Rebuild();}
        public void OpenMainMenu()
        {
            if(game.LayoutEditor.Active)return;
            game.Save();game.Sim.Paused=true;mainMenu=true;resumeAfterModal=false;OpenPanel("Ana Menü");
        }
        public void StartGame(){if(game.SaveBlocked){OpenPanel("Kayıt ve Oturum");return;}mainMenu=false;if(game.Sim.P.shift.pending){OpenPanel("Hedef Vardiya");return;}resumeAfterModal=true;ClosePanel();}
        void CloseOrHome(){if(mainMenu){if(tab!="Ana Menü")OpenPanel("Ana Menü");}else if(ShowingShift&&game.Sim.P.shift.pending)LeaveShiftResult();else ClosePanel();}
        float HomeButton(string label,string id,string destination,float y)
        {Button(label,panel,10,y,panelWidth-20,56,green,()=>OpenPanel(destination),17).name=id;return y+68;}
        float DrawHome(float y)
        {
            if(brandArt){float w=Mathf.Min(270,panelWidth-24),h=w*brandArt.height/(float)brandArt.width;
                var mark=Box("Home brand",panel,(panelWidth-w)/2,y,w,h).gameObject.AddComponent<UnityEngine.UI.RawImage>();mark.texture=brandArt;mark.raycastTarget=false;y+=h+8;}
            y=GuideText("Küçük bir dükkândan büyük bir markaya.",y,20,ink,true);
            y=GuideText(BranchCatalog.Name(game.Sim.P.activeBranch)+" · Seviye "+game.Sim.Level+" · "+game.Sim.P.coins.ToString("N0",Localization.Culture)+" coin",y,16,muted);
            bool progress=game.Sim.P.tutorialDone||game.Sim.P.served>0||game.Sim.P.xp>0;
            if(game.SaveBlocked||game.SaveRecovery!=""||game.SaveState=="write-error")y=GuideText(SaveStatusText(),y,17,game.SaveBlocked?red:green,true);
            var play=Button(progress?"DEVAM ET":"OYUNA BAŞLA",panel,10,y+8,panelWidth-20,58,red,StartGame,18);play.name="Home play";play.interactable=!game.SaveBlocked;y+=78;
            if(game.SaveBlocked||game.SaveRecovery!=""||game.SaveState=="write-error")y=HomeButton("KAYIT VE OTURUM","Home save","Kayıt ve Oturum",y);
            y=HomeButton("AYARLAR","Home settings","Ayarlar",y);
            y=HomeButton("NASIL OYNANIR?","Home help","Yardım",y);
            return GuideText(game.SaveBlocked?"Kaydın açılana kadar vardiya başlatılmaz; mevcut dosyaların üzerine yazılmaz.":"Kaydın korunur. Kaldığın ilerlemeyle devam edersin.",y,15,muted)+10;
        }
        float DrawSettings(float y)
        {
            y=HomeButton("SES VE MÜZİK","Settings audio","Ses Ayarları",y);
            y=HomeButton("DİL SEÇİMİ","Settings language","Dil Seçimi",y);
            y=HomeButton("KAYIT VE OTURUM","Settings save","Kayıt ve Oturum",y);
#if UNITY_EDITOR
            y=HomeButton("REKLAM ÖDÜLÜ TESTİ","Settings rewards","Reklam Testi",y);
#endif
            return HomeButton(mainMenu?"ANA MENÜYE DÖN":"RESTORANA DÖN","Settings back",mainMenu?"Ana Menü":"Restoran",y);
        }
        float DrawLanguage(float y)
        {
            y=GuideText("Dil değişikliği ilerlemeni etkilemez. Seçimin bu cihazda saklanır.",y,17,muted);
            foreach(string code in new[]{"tr","en"}) {
                bool selected=Localization.Language==code;string current=code;
                var b=Button((code=="tr"?"Türkçe":"English")+(selected?" · SEÇİLİ":""),panel,10,y+12,panelWidth-20,58,selected?red:green,()=>game.SetLanguage(current),20);
                b.name="Language "+code;b.interactable=!selected;y+=82;
            }
            return HomeButton("AYARLARA DÖN","Language back","Ayarlar",y+12);
        }
    }
}
