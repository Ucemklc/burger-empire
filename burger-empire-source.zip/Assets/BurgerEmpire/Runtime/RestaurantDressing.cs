using System.Linq;
using UnityEngine;
using UnityEngine.Rendering;

namespace BurgerEmpire.Unity
{
    public static class RestaurantDressing
    {
        // Surface-only decoration: nothing is placed in a worker's path or table footprint.
        public static void Apply(Transform world)
        {
            if(world.Find("Restaurant dressing"))return;
            var root=RestaurantArt.Group("Restaurant dressing",world,Vector3.zero);
            foreach(Transform window in world.Cast<Transform>().Where(t=>t.name=="Window"&&t.gameObject.activeSelf)) {
                var scene=RestaurantArt.Group("Window scene",root,window.localPosition);
                for(int i=0;i<3;i++) {
                    float z=-.46f+i*.46f,h=.38f+i%2*.25f;
                    RestaurantArt.Box("Distant facade",scene,.118f,-.55f+h/2,z,.014f,h,.34f,RestaurantArt.Hex(i==1?"C6DBC9":"D9DEC8"));
                    for(int row=0;row<2;row++)for(int col=0;col<2;col++)
                        RestaurantArt.Box("Distant window",scene,.13f,-.46f+row*.12f,z-.075f+col*.15f,.012f,.058f,.07f,RestaurantArt.Cream);
                }
                var sheen=RestaurantArt.Box("Glass reflection",scene,.133f,.25f,-.30f,.013f,.53f,.07f,RestaurantArt.Hex("D1EEF0"));
                sheen.transform.localRotation=Quaternion.Euler(25,0,0);
                var sheen2=RestaurantArt.Box("Glass reflection",scene,.133f,.25f,.36f,.013f,.53f,.025f,RestaurantArt.Hex("D1EEF0"));
                sheen2.transform.localRotation=Quaternion.Euler(25,0,0);
            }
            // Recesses and metal trim make the service counter read as built furniture.
            for(int i=0;i<6;i++) {
                var panel=RestaurantArt.Group("Counter inset "+i,root,new Vector3(1.18f+i*1.05f,.49f,3.477f));
                RestaurantArt.Box("Inset enamel",panel,0,0,0,.88f,.22f,.012f,RestaurantArt.Hex("BB342B"));
                RestaurantArt.Box("Inset highlight",panel,0,.112f,.008f,.89f,.018f,.009f,RestaurantArt.Hex("F17C50"));
            }
            RestaurantArt.Box("Counter brass foot",root,4.05f,.30f,3.48f,7.1f,.08f,.025f,RestaurantArt.Gold);
            RestaurantArt.Box("Interior baseboard back",root,5,.30f,.052f,10.2f,.13f,.025f,RestaurantArt.Brown);
            RestaurantArt.Box("Interior baseboard side",root,.052f,.30f,5,.025f,.13f,10.2f,RestaurantArt.Brown);
            foreach(var renderer in root.GetComponentsInChildren<Renderer>())renderer.shadowCastingMode=ShadowCastingMode.Off;
        }
    }
}
