using System.Linq;
using BurgerEmpire.Core;
using UnityEngine;

namespace BurgerEmpire.Unity
{
    public sealed partial class RestaurantHud
    {
        float DrawDelivery(float y)
        {
            var p=game.Sim.P;
            Label(BranchCatalog.Name(p.activeBranch)+" · Kurye teslimatı",panel,10,y,panelWidth-20,48,23,ink,FontStyle.Bold);y+=58;
            Label("Sipariş al → Hazırla → Servis et\nServis sırasında menü tezgahta paketlenir. Kurye paketi aldığında ödeme gelir. Masa gerekmez.",panel,10,y,panelWidth-20,108,17,muted);y+=120;
            if(p.delivery>0) {
                var stats=Card("Delivery stats",panel,0,y,panelWidth,100,RestaurantArt.Hex("DCE5DE"));
                Label(game.Sim.DeliveryQueue+"/"+game.Sim.DeliveryCapacity+" kurye · "+p.deliveryServed+" teslimat\n"+p.deliveryEarned+" coin gelir · "+p.deliveryLost+" kaçan sipariş",stats.transform,14,8,panelWidth-28,84,19,green,FontStyle.Bold);y+=112;
                Label("Kasiyer siparişi alır, aşçı hazırlar, garson paketler ve teslim eder. Mutfak tüm siparişlere ortaktır. Tezgahta aynı anda 1 paket hazırlanır.",panel,10,y,panelWidth-20,112,16,muted);y+=124;
            }
            y=DrawOffer(game.Sim.Offers().First(o=>o.id=="delivery"),y);
            Label("Kurye menüleri",panel,12,y,panelWidth-24,38,21,ink,FontStyle.Bold);y+=46;
            foreach(var recipe in MenuCatalog.All(p).Where(r=>r.available)) {
                Label(recipe.name+" · "+Simulation.DeliveryPrice(recipe)+" coin",panel,12,y,panelWidth-24,34,17,green);y+=38;
            }
            Label("Kurye fiyatı şehir menüsünün %15 üzerindedir; tam coine yuvarlanır. Bahşiş ve yoğunluk bonusu ayrıca eklenir. Fazla bekleyen kurye ayrılır.",panel,12,y,panelWidth-24,106,16,muted);y+=118;
            Label("Seviye 1: 2 kurye alanı · paketleme 1,6 sn\nSeviye 2: 3 alan · paketleme 0,8 sn\nGeliştirmeler, gelir ve görevler bu şubeye özeldir.",panel,12,y,panelWidth-24,100,16,muted);y+=112;
            var mission=game.Sim.Missions().FirstOrDefault(m=>m.id=="delivery");if(mission!=null)y=DrawMission(mission,y);
            return y;
        }
    }
}
