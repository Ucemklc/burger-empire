using System.Collections.Generic;
using System.Linq;
using BurgerEmpire.Core;
using UnityEngine;

namespace BurgerEmpire.Unity
{
    public sealed class DeliveryPresentation
    {
        readonly Transform station,couriers,thirdBay,parcel,streetSign;
        readonly Vector3 signPosition;
        readonly TextMesh counterText;
        readonly Dictionary<int,RestaurantArt.Person> people=new Dictionary<int,RestaurantArt.Person>();
        readonly Stack<RestaurantArt.Person> pool=new Stack<RestaurantArt.Person>();
        Simulation previous;int revision=-1;
        public DeliveryPresentation(Transform world)
        {
            station=RestaurantArt.Group("Delivery station",world,Vector3.zero);
            couriers=RestaurantArt.Group("Delivery couriers",world,Vector3.zero);
            streetSign=world.Find("Street sign");if(streetSign)signPosition=streetSign.localPosition;
            var blue=RestaurantArt.Hex("397E91");
            RestaurantArt.Box("Delivery pavement",station,12,-.08f,6.1f,5.8f,.1f,5.4f,RestaurantArt.Hex("C6CCB8"));
            var counter=RestaurantArt.Group("Packaging counter",station,new Vector3(10.35f,.25f,Simulation.DeliveryCounterZ));
            RestaurantArt.Box("Cabinet",counter,0,.52f,0,1.12f,1.04f,1.65f,blue);
            RestaurantArt.Box("Worktop",counter,0,1.09f,0,1.3f,.13f,1.8f,RestaurantArt.Cream);
            RestaurantArt.Box("Shelf",counter,0,.28f,.84f,.94f,.1f,.05f,RestaurantArt.Gold);
            RestaurantArt.Text("Counter title","PAKETLEME",counter,new Vector3(0,.8f,.835f),.1f,RestaurantArt.Cream);
            counterText=RestaurantArt.Text("Packing status","",counter,new Vector3(0,.55f,.84f),.08f,RestaurantArt.Cream);
            for(int i=0;i<4;i++)RestaurantArt.Box("Flat bags",counter,-.1f,1.2f+i*.035f,-.50f,.65f,.03f,.45f,RestaurantArt.Hex("D6AC72"));
            RestaurantArt.Box("Order screen",counter,0,1.42f,-.72f,.70f,.45f,.10f,blue);
            RestaurantArt.Text("Courier title","KURYE",counter,new Vector3(0,1.45f,-.66f),.12f,RestaurantArt.Cream);
            parcel=RestaurantArt.Group("Packing parcel",counter,new Vector3(0,1.17f,.27f));
            RestaurantArt.Box("Bag",parcel,0,.22f,0,.43f,.44f,.3f,RestaurantArt.Hex("D6AC72"));
            RestaurantArt.Box("Seal",parcel,0,.29f,.16f,.16f,.19f,.02f,RestaurantArt.Red);
            for(int i=0;i<3;i++) {
                var bay=RestaurantArt.Group("Courier bay "+i,station,new Vector3(Simulation.DeliveryBayX,.005f,Simulation.DeliveryBayZ(i)));
                RestaurantArt.Box("Waiting pad",bay,0,0,0,1.15f,.02f,1.15f,blue);
                RestaurantArt.Text("Bay number",(i+1).ToString(),bay,new Vector3(0,.025f,.25f),.26f,RestaurantArt.Cream,true);
                if(i==2)thirdBay=bay;
            }
        }
        public void Sync(Simulation sim,bool editing)
        {
            if(previous!=sim||revision!=sim.BranchRevision) {
                foreach(var p in people.Values){p.root.gameObject.SetActive(false);pool.Push(p);}people.Clear();
                previous=sim;revision=sim.BranchRevision;
            }
            bool open=sim.P.delivery>0;
            station.gameObject.SetActive(open);couriers.gameObject.SetActive(open&&!editing);
            if(streetSign)streetSign.localPosition=signPosition+(open?new Vector3(-.1f,0,2.6f):Vector3.zero);
            thirdBay.gameObject.SetActive(sim.P.delivery==2);
            bool packing=sim.Customers.Any(c=>c.delivery&&c.order=="packing");
            parcel.gameObject.SetActive(packing&&!editing);counterText.text=packing?"PAKETLENİYOR":"TESLİM NOKTASI";
            foreach(var c in sim.Customers.Where(c=>c.delivery)) {
                if(!people.TryGetValue(c.id,out var p)){p=pool.Count>0?pool.Pop():BuildCourier(couriers);p.motion.Reset();people[c.id]=p;p.root.name="Courier "+c.id;}
                bool waiting=c.phase=="queue"||c.phase=="waiting"&&c.order!="packing";
                p.root.gameObject.SetActive(true);p.UpdatePosition(c.x,c.z,sim.Time+c.id,false,false,waiting||c.crowd.waiting?"waiting":"",waiting?(Vector3?)Vector3.left:null);
            }
            foreach(int id in people.Keys.Where(id=>!sim.Customers.Any(c=>c.delivery&&c.id==id)).ToArray()){
                var p=people[id];p.root.gameObject.SetActive(false);pool.Push(p);people.Remove(id);
            }
        }
        static RestaurantArt.Person BuildCourier(Transform parent)
        {
            var p=RestaurantArt.BuildPerson("customer",0,parent);
            var teal=RestaurantArt.Hex("397E91");
            RestaurantArt.Shape("Courier helmet",PrimitiveType.Sphere,p.root,new Vector3(0,1.51f,-.02f),new Vector3(.66f,.36f,.61f),teal);
            RestaurantArt.Box("Helmet visor",p.root,0,1.43f,.29f,.54f,.09f,.18f,RestaurantArt.Gold);
            RestaurantArt.Box("Delivery backpack",p.root,0,.87f,-.40f,.7f,.74f,.4f,teal);
            RestaurantArt.Box("Reflector",p.root,0,.91f,-.61f,.57f,.12f,.025f,RestaurantArt.Gold);
            RestaurantArt.Text("Bag label","BE",p.root,new Vector3(0,.7f,-.62f),.11f,RestaurantArt.Cream).transform.localRotation=Quaternion.Euler(0,180,0);
            return p;
        }
    }
}
