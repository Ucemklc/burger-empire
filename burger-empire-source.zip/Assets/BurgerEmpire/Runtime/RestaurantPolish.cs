using System.Linq;
using BurgerEmpire.Core;
using UnityEngine;
using UnityEngine.Rendering;

namespace BurgerEmpire.Unity
{
    // Additive dressing for both existing scenes and newly generated restaurants.
    public sealed class RestaurantPolish
    {
        readonly Transform root;
        readonly TextMesh menuPrice;
        readonly Transform[] grillGlows=new Transform[3];
        readonly Material glow;
        readonly Sprite logoSprite;
        public RestaurantPolish(Transform world)
        {
            root=RestaurantArt.Group("Restaurant polish",world,Vector3.zero);
            RenderSettings.ambientMode=AmbientMode.Trilight;
            RenderSettings.ambientSkyColor=RestaurantArt.Hex("DFE9F2");
            RenderSettings.ambientEquatorColor=RestaurantArt.Hex("94AAA9");
            RenderSettings.ambientGroundColor=RestaurantArt.Hex("88705B");
            var sun=Object.FindObjectsByType<Light>(FindObjectsSortMode.None).FirstOrDefault(l=>l.type==LightType.Directional);
            if(sun){sun.color=new Color(1,.94f,.81f);sun.intensity=1.12f;sun.shadowStrength=.72f;sun.shadows=LightShadows.Soft;sun.transform.rotation=Quaternion.Euler(48,-145,0);}
            foreach(var r in world.GetComponentsInChildren<Renderer>(true)) {
                string color=null;
                switch(r.name){
                    case "Service counter":case "Back red stripe":case "Left red stripe":case "Red pendant":color="EA4931";break;
                    case "Steel top":case "Extractor hood":case "Handle":
                        r.sharedMaterial=RestaurantArt.Mat(RestaurantArt.Hex("CCDDE0"),true);break;
                    case "Sidewalk":color="E4DEC9";break;
                    case "Road":color="72939A";break;
                    case "Road marking":color="FCF1D1";break;
                    case "Blue glass":color="87CFDF";break;
                }
                if(color!=null)r.sharedMaterial=RestaurantArt.Mat(RestaurantArt.Hex(color));
                if(r.GetComponent<TextMesh>()){r.shadowCastingMode=ShadowCastingMode.Off;r.receiveShadows=false;}
            }
            var oldBrand=world.Find("Brand");if(oldBrand)oldBrand.gameObject.SetActive(false);
            var oldMotto=world.Find("Motto");if(oldMotto)oldMotto.gameObject.SetActive(false);
            var oldPlaque=world.Find("Brand plaque");if(oldPlaque)oldPlaque.gameObject.SetActive(false);
            var oldBorder=world.Find("Gold plaque border");if(oldBorder)oldBorder.gameObject.SetActive(false);
            var sign=RestaurantArt.Group("Crowned brand",root,new Vector3(5,3.7f,.1f));
            RestaurantArt.Box("Gold frame",sign,0,0,0,5.1f,2.0f,.17f,RestaurantArt.Gold);
            RestaurantArt.Box("Red enamel",sign,0,0,.11f,4.96f,1.86f,.12f,RestaurantArt.Red);
            var logo=Resources.Load<Texture2D>("BurgerEmpireArt/BrandLogo-v09");
            if(logo) {
                logoSprite=Sprite.Create(logo,new Rect(0,0,logo.width,logo.height),new Vector2(.5f,.5f),100);
                var face=RestaurantArt.Group("Brand artwork",sign,new Vector3(0,.05f,.19f));
                face.localRotation=Quaternion.Euler(0,180,0);
                var renderer=face.gameObject.AddComponent<SpriteRenderer>();renderer.sprite=logoSprite;
                face.localScale=Vector3.one*(4.7f/logoSprite.bounds.size.x);
            } else RestaurantArt.Text("Brand fallback","BURGER EMPIRE",sign,new Vector3(0,0,.19f),.34f,RestaurantArt.Cream);
            RestaurantArt.Text("Fresh motto","TAZE PİŞER, MUTLU EDER",root,new Vector3(5,2.65f,.38f),.12f,RestaurantArt.Gold);
            foreach(var text in world.GetComponentsInChildren<TextMesh>().Where(t=>t.name=="Menu"))text.gameObject.SetActive(false);
            foreach(Transform t in world)if(t.name=="Menu board")t.gameObject.SetActive(false);
            for(int i=0;i<2;i++) {
                var menu=RestaurantArt.Group("Illustrated menu "+i,root,new Vector3(i==0?1.3f:8.65f,3.5f,.18f));
                RestaurantArt.Box("Menu frame",menu,0,0,0,1.9f,1.95f,.13f,RestaurantArt.Gold);
                RestaurantArt.Box("Menu face",menu,0,0,.08f,1.76f,1.81f,.08f,RestaurantArt.Hex("294B42"));
                if(i==0) {
                    var meal=RestaurantArt.Group("Menu burger",menu,new Vector3(0,.1f,.2f));meal.localRotation=Quaternion.Euler(65,0,0);
                    RestaurantArt.Burger(meal,Vector3.zero,2.2f);
                    menuPrice=RestaurantArt.Text("Menu price","",menu,new Vector3(0,-.60f,.17f),.13f,RestaurantArt.Cream);
                } else {
                    var drink=RestaurantArt.Group("Menu drink",menu,new Vector3(.38f,-.25f,.18f));RestaurantArt.Cup(drink,Vector3.zero);drink.localScale=Vector3.one*1.75f;
                    RestaurantArt.Box("Fries carton",menu,-.35f,-.15f,.28f,.53f,.5f,.20f,RestaurantArt.Red);
                    for(int k=0;k<5;k++)RestaurantArt.Box("Menu fries",menu,-.57f+k*.11f,.21f+(k%2)*.1f,.27f,.085f,.52f,.14f,RestaurantArt.Gold);
                    RestaurantArt.Text("Menu sides","ÇITIR + BUZ GİBİ",menu,new Vector3(0,-.60f,.17f),.10f,RestaurantArt.Cream);
                }
            }
            for(int i=0;i<3;i++) {
                var grill=world.Find("Grill_"+i);if(!grill)continue;
                grillGlows[i]=RestaurantArt.Box("Grill heat",grill,0,.097f,0,.70f,.01f,.88f,RestaurantArt.Hex("ED8035")).transform;
            }
            glow=new Material(RestaurantArt.Mat(RestaurantArt.Hex("FF9A3E"))){name="BE_GrillGlow"};
            glow.EnableKeyword("_EMISSION");glow.SetColor("_EmissionColor",new Color(.65f,.18f,.025f));
            foreach(var heat in grillGlows)if(heat)heat.GetComponent<Renderer>().sharedMaterial=glow;
            for(int i=0;i<4;i++) {
                var table=world.Find("Table_"+i);if(!table)continue;
                var sauces=RestaurantArt.Group("Table sauces",table,new Vector3(.51f,1.025f,.22f));
                RestaurantArt.Shape("Ketchup",PrimitiveType.Capsule,sauces,new Vector3(0,.13f,0),new Vector3(.10f,.15f,.10f),RestaurantArt.Red);
                RestaurantArt.Shape("Mustard",PrimitiveType.Capsule,sauces,new Vector3(.14f,.13f,0),new Vector3(.10f,.15f,.10f),RestaurantArt.Gold);
                RestaurantArt.Text("Table number",(i+1).ToString(),table,new Vector3(-.46f,1.08f,.28f),.08f,RestaurantArt.Brown,true);
            }
            // Extra leaf clusters soften the existing simple street tree silhouettes.
            foreach(Transform tree in world)if(tree.name=="Street tree") {
                for(int i=0;i<3;i++)RestaurantArt.Shape("Leaf cluster",PrimitiveType.Sphere,tree,new Vector3((i-1)*.45f,1.9f+(i%2)*.4f,.28f),new Vector3(1.2f,1.3f,1.1f),RestaurantArt.Hex(i%2==0?"79B75A":"96C666"));
            }
        }
        public void Sync(Simulation sim)
        {
            if(menuPrice)menuPrice.text="KLASİK  "+MenuCatalog.Get("classic",sim.P).price+" COIN";
            int working=sim.Customers.Count(c=>c.station=="grill"&&c.order=="cooking");
            for(int i=0;i<grillGlows.Length;i++)if(grillGlows[i])grillGlows[i].gameObject.SetActive(i<working);
        }
        public void Dispose(){if(glow)Object.Destroy(glow);if(logoSprite)Object.Destroy(logoSprite);}
    }
}
