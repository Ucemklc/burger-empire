using System.Linq;
using UnityEngine;
using UnityEngine.Rendering;

namespace BurgerEmpire.Unity
{
    // Surface details stay inside existing furniture and wall footprints.
    public static class RestaurantFinishes
    {
        static Color C(string hex){return RestaurantArt.Hex(hex);}
        static GameObject B(string name,Transform p,float x,float y,float z,float w,float h,float d,Color c)
        {return RestaurantArt.Box(name,p,x,y,z,w,h,d,c);}
        public static void Apply(Transform world)
        {
            if(world.Find("Restaurant finishes"))return;
            StyleGeometry.Apply(world);
            var details=RestaurantArt.Group("Restaurant finishes",world,Vector3.zero);
            // Thin tile relief and brass accents sit on the kitchen wall, above the worktop.
            var splash=RestaurantArt.Group("Kitchen backsplash",details,Vector3.zero);
            for(int row=0;row<3;row++)for(int column=0;column<16;column++) {
                float x=.47f+column*.60f+(row%2)*.16f;
                B("Ceramic tile",splash,x,1.56f+row*.28f,.074f,.565f,.255f,.02f,C((row+column)%5==0?"B5C8B4":"F6EAD5"));
            }
            for(int i=0;i<4;i++) {
                var table=world.Find("Table_"+i);if(!table)continue;
                var tailoring=RestaurantArt.Group("Furniture finish",table,Vector3.zero);
                foreach(Transform seat in table.Cast<Transform>().Where(t=>t.name=="Seat back")) {
                    float side=Mathf.Sign(seat.localPosition.z);
                    // The seam and buttons never extend outside the original chair envelope.
                    for(int line=-1;line<=1;line++)B("Upholstery seam",tailoring,line*.22f,.80f,side*1.061f,.008f,.58f,.007f,C("F1B99B"));
                    for(int stud=-1;stud<=1;stud++)RestaurantArt.Shape("Upholstery button",PrimitiveType.Sphere,tailoring,new Vector3(stud*.22f,.85f,side*1.055f),new Vector3(.043f,.043f,.014f),RestaurantArt.Gold);
                }
                B("Table edge inlay",tailoring,0,.918f,.574f,1.35f,.031f,.012f,C("F6D19D"));
                // One folded napkin and printed coaster make each place setting distinct.
                B("Folded napkin",tailoring,-.38f,1.014f,.24f,.29f,.012f,.24f,RestaurantArt.Cream);
                var fold=B("Napkin fold",tailoring,-.38f,1.023f,.24f,.22f,.007f,.024f,C("DBBBA0"));fold.transform.localEulerAngles=new Vector3(0,32,0);
                RestaurantArt.Shape("Cup coaster",PrimitiveType.Cylinder,tailoring,new Vector3(-.46f,1.014f,-.32f),new Vector3(.30f,.006f,.30f),C("BF7753"));
            }
            // Existing machine fronts gain controls and vents; no new floor obstacles.
            for(int bank=0;bank<3;bank++) {
                var controls=RestaurantArt.Group("Cooktop controls "+bank,details,new Vector3(1.1f+bank*2.75f,1.12f,1.875f));
                for(int dial=0;dial<3;dial++) {
                    var knob=RestaurantArt.Shape("Control dial",PrimitiveType.Cylinder,controls,new Vector3(-.28f+dial*.28f,0,0),new Vector3(.085f,.022f,.085f),C("374A49"));knob.transform.localEulerAngles=new Vector3(90,0,0);
                    B("Dial marker",controls,-.28f+dial*.28f,.023f,.025f,.008f,.025f,.012f,RestaurantArt.Cream);
                }
            }
            var hood=world.Find("Extractor hood");if(hood) {
                var vents=RestaurantArt.Group("Hood vents",hood,Vector3.zero);
                for(int i=0;i<12;i++)B("Vent slot",vents,-.43f+i*.078f,-.03f,.505f,.027f,.38f,.012f,C("526562"));
            }
            var soda=world.Find("Soda machine");if(soda) {
                var emblem=RestaurantArt.Group("Soda enamel badge",soda,new Vector3(0,.3f,.51f));
                RestaurantArt.Shape("Gold seal",PrimitiveType.Sphere,emblem,Vector3.zero,new Vector3(.25f,.22f,.02f),RestaurantArt.Gold);
            }
            foreach(var renderer in world.GetComponentsInChildren<Renderer>(true)) {
                if(renderer.name=="Terracotta")renderer.sharedMaterial=RestaurantArt.Mat(C("B86543"));
                if(renderer.name=="Floor tile")renderer.shadowCastingMode=ShadowCastingMode.Off;
                if(renderer.name=="Seat cushion"||renderer.name=="Seat back"||renderer.name=="Oak top")renderer.receiveShadows=true;
            }
            // Small fixed decorations do not need shadow maps of their own.
            foreach(var r in details.GetComponentsInChildren<Renderer>())r.shadowCastingMode=ShadowCastingMode.Off;
        }
    }
}
