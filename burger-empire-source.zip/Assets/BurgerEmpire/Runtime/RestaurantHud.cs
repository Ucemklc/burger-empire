using System.Collections.Generic;
using System.Linq;
using BurgerEmpire.Core;
using UnityEngine;
using UnityEngine.UI;

namespace BurgerEmpire.Unity
{
    // Logical dimensions are based on the safe area, including display cutouts.
    public sealed partial class RestaurantHud : MonoBehaviour
    {
        BurgerEmpireGame game;
        RectTransform canvasRoot, root, panel, modal, bubbles;
        ScrollRect scroll;
        Font font; Sprite round;
        readonly Color ink=RestaurantArt.Hex("34392F"), muted=RestaurantArt.Hex("737965"), cream=RestaurantArt.Hex("FFF9E8"), green=RestaurantArt.Hex("426C54"), red=RestaurantArt.Red;
        readonly string[] commands={"order","cook","serve","collect","clean"};
        readonly List<Button> actions=new List<Button>();
        readonly Dictionary<string,Button> navigation=new Dictionary<string,Button>();
        readonly Dictionary<int,RectTransform> customerBubbles=new Dictionary<int,RectTransform>();
        readonly List<int> expired=new List<int>();
        Text coins,level,hint,status,toast,pauseLabel,soundLabel;
        Image toastBackground,lessonProgress;
        FoodIconGraphic toastIcon;
        string toastKind="info";
        float importantToastUntil;
        Text cameraZoom;
        Button zoomIn,zoomOut;
        Button management;
        Texture2D mealArt,brandArt;
        string tab="",panelKey="";
        float width,height,scaleFactor,lastWidth,lastHeight,toastTime,refreshIn,panelWidth;
        Rect safeArea;
        bool started,resumeAfterModal,portrait;
        public bool BlocksWorldInput { get { return modal!=null||game.LayoutEditor.Active; } }
        public void Initialize(BurgerEmpireGame owner)
        {
            game=owner;font=Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");round=RoundedSprite();mealArt=Resources.Load<Texture2D>("BurgerEmpireArt/MenuCombo");brandArt=Resources.Load<Texture2D>("BurgerEmpireArt/BrandLogo-v09");Rebuild();
        }
        Sprite RoundedSprite()
        {
            var texture=new Texture2D(40,40,TextureFormat.RGBA32,false);texture.filterMode=FilterMode.Bilinear;
            var pixels=new Color[1600];
            for(int y=0;y<40;y++)for(int x=0;x<40;x++) {
                float dx=Mathf.Max(8-x,0,x-31),dy=Mathf.Max(8-y,0,y-31);
                pixels[y*40+x]=new Color(1,1,1,Mathf.Clamp01(9-Mathf.Sqrt(dx*dx+dy*dy)));
            }
            texture.SetPixels(pixels);texture.Apply();
            return Sprite.Create(texture,new Rect(0,0,40,40),new Vector2(.5f,.5f),100,0,SpriteMeshType.FullRect,new Vector4(10,10,10,10));
        }
        RectTransform Box(string name,Transform parent,float x,float y,float w,float h)
        {
            var rt=new GameObject(name,typeof(RectTransform)).GetComponent<RectTransform>();rt.SetParent(parent,false);
            rt.anchorMin=rt.anchorMax=new Vector2(0,1);rt.pivot=new Vector2(0,1);rt.anchoredPosition=new Vector2(x,-y);rt.sizeDelta=new Vector2(w,h);return rt;
        }
        Image Card(string name,Transform parent,float x,float y,float w,float h,Color c,bool rounded=true)
        {
            var im=Box(name,parent,x,y,w,h).gameObject.AddComponent<Image>();im.color=c;im.raycastTarget=false;
            if(rounded){im.sprite=round;im.type=Image.Type.Sliced;}return im;
        }
        Text Label(string value,Transform parent,float x,float y,float w,float h,int size,Color c,FontStyle style=FontStyle.Normal,TextAnchor align=TextAnchor.MiddleLeft)
        {
            var t=Box("Text",parent,x,y,w,h).gameObject.AddComponent<Text>();t.font=font;t.fontSize=size;t.color=c;t.text=Localization.Text(value);
            t.fontStyle=style;t.alignment=align;t.raycastTarget=false;t.horizontalOverflow=HorizontalWrapMode.Wrap;return t;
        }
        Button Button(string name,Transform parent,float x,float y,float w,float h,Color c,System.Action click,int size=17)
        {
            Card(name+" shadow",parent,x,y+3,w,h,RestaurantArt.Hex("C2B592"));
            var im=Card(name,parent,x,y,w,h,c);im.raycastTarget=true;var b=im.gameObject.AddComponent<Button>();b.targetGraphic=im;
            var colors=b.colors;colors.highlightedColor=Color.white;colors.pressedColor=new Color(.78f,.85f,.75f);colors.disabledColor=new Color(.65f,.68f,.60f);b.colors=colors;
            b.onClick.AddListener(()=>{click();game.UiClick();});Label(name,im.transform,5,0,w-10,h,size,c==green||c==red?cream:ink,FontStyle.Bold,TextAnchor.MiddleCenter);return b;
        }
        void Rebuild()
        {
            string pendingToast=toast&&toastTime>0?toastSource:"";
            if(canvasRoot){canvasRoot.gameObject.SetActive(false);Destroy(canvasRoot.gameObject);}
            actions.Clear();navigation.Clear();customerBubbles.Clear();iconBubbles.Clear();modal=null;panel=null;
            lastWidth=Screen.width;lastHeight=Screen.height;safeArea=Screen.safeArea;
            portrait=safeArea.height>safeArea.width;
            scaleFactor=Mathf.Max(.1f,portrait?safeArea.width/420f:safeArea.height/480f);
            width=safeArea.width/scaleFactor;height=safeArea.height/scaleFactor;
            var go=new GameObject("Burger Empire Mobile Interface",typeof(RectTransform),typeof(Canvas),typeof(CanvasScaler),typeof(GraphicRaycaster));
            var canvas=go.GetComponent<Canvas>();canvas.renderMode=RenderMode.ScreenSpaceOverlay;canvas.sortingOrder=20;
            var scaler=go.GetComponent<CanvasScaler>();scaler.uiScaleMode=CanvasScaler.ScaleMode.ConstantPixelSize;scaler.scaleFactor=scaleFactor;
            canvasRoot=go.GetComponent<RectTransform>();root=Box("Safe area",canvasRoot,safeArea.x/scaleFactor,(Screen.height-safeArea.yMax)/scaleFactor,width,height);
            if(game.LayoutEditor.Active){BuildLayoutHud();return;}
            float header=portrait?112:56,bottom=portrait?172:84,left=0;
            game.GameCamera.rect=new Rect((safeArea.x+left*scaleFactor)/Screen.width,(safeArea.y+bottom*scaleFactor)/Screen.height,
                (safeArea.width-left*scaleFactor)/Screen.width,(safeArea.height-(header+bottom)*scaleFactor)/Screen.height);
            bubbles=Box("Order bubbles",root,0,0,width,height);
            Card("Header",root,0,0,width,header,cream,false).raycastTarget=true;
            bool showBrand=portrait||width>=800;
            if(showBrand&&brandArt) {
                float bw=94,bh=bw*brandArt.height/(float)brandArt.width;
                var mark=Box("Burger Empire brand",root,10,(56-bh)/2,bw,bh).gameObject.AddComponent<RawImage>();mark.texture=brandArt;mark.raycastTarget=false;
            } else if(showBrand)Label("BURGER\nEMPIRE",root,10,4,94,48,16,red,FontStyle.Bold);
            Card("Header gold line",root,0,header-2,width,2,RestaurantArt.Gold,false);
            float menuX=portrait?10:showBrand?114:10;
            management=Button("Yönetim",root,menuX,portrait?60:4,104,48,green,()=>OpenPanel("Yönetim"),14);management.name="Open management";
            float moneyX=portrait?114:menuX+116,moneyW=portrait?width-242:width-332-moneyX;
            coins=Label("",root,moneyX,2,moneyW,28,20,ink,FontStyle.Bold);coins.resizeTextForBestFit=true;coins.resizeTextMinSize=12;coins.resizeTextMaxSize=20;
            level=Label("",root,moneyX,30,moneyW,22,11,green,FontStyle.Bold);level.resizeTextForBestFit=true;level.resizeTextMinSize=9;level.resizeTextMaxSize=11;
            BuildCameraControls(header);
            soundLabel=Button(game.SoundEnabled?"SES":"SESSİZ",root,width-124,4,54,48,RestaurantArt.Hex("E4E8D4"),()=>{
                game.SetSound(!game.SoundEnabled);soundLabel.text=Localization.Text(game.SoundEnabled?"SES":"SESSİZ");
            },12).GetComponentInChildren<Text>();
            pauseLabel=Button("II",root,width-64,4,54,48,green,()=>game.Command("pause"),21).GetComponentInChildren<Text>();
            Card("Action area",root,left,height-bottom,width-left,bottom,cream,false).raycastTarget=true;
            float areaW=width-left;
            float statusW=portrait?width-24:Mathf.Min(300,width*.36f);
            status=Label("",root,12,height-bottom, statusW,portrait?22:30,10,green,FontStyle.Bold);
            lessonProgress=Card("Lesson progress",root,12,height-bottom+(portrait?59:30),0,2,red,false);
            hint=Label("",root,portrait?12:statusW+24,height-bottom+(portrait?22:0),portrait?width-24:width-statusW-36,portrait?36:30,12,ink);
            string[] labels={"Sipariş al","Hazırla","Servis et","Ödeme al","Temizle"};
            for(int i=0;i<5;i++) {
                string cmd=commands[i];float aw=portrait?(areaW-32)/3:(areaW-48)/5;
                float x=portrait?12+(i<3?i:i-3)*(aw+4):left+12+i*(aw+6);
                float y=height-bottom+(portrait?64:32)+(portrait&&i>=3?54:0);
                actions.Add(Button(labels[i],root,x,y,aw,48,green,()=>game.Command(cmd),14));
            }
            if(portrait)Button("?",root,width-12-(areaW-32)/3,height-bottom+118,(areaW-32)/3,48,RestaurantArt.Hex("E4E8D4"),()=>OpenPanel("Yardım"),20);
            float tw=Mathf.Min(width-left-24,500);
            toastBackground=Card("Toast",root,left+(areaW-tw)/2,height-bottom-49,tw,42,green);
            toastIcon=Box("Toast icon",toastBackground.transform,10,11,20,20).gameObject.AddComponent<FoodIconGraphic>();toastIcon.raycastTarget=false;
            toast=Label(pendingToast,toastBackground.transform,37,0,tw-45,42,14,cream,FontStyle.Bold,TextAnchor.MiddleCenter);StyleToast();
            toastBackground.gameObject.SetActive(toastTime>0&&!string.IsNullOrEmpty(pendingToast));
            if(!started&&tab==""){tab="Ana Menü";resumeAfterModal=false;game.Sim.Paused=true;BuildModal();}
            else if(tab!="")BuildModal();
            refreshIn=0;
        }
        void Update()
        {
            if(game==null||game.Sim==null)return;
            if(Screen.width!=lastWidth||Screen.height!=lastHeight||Screen.safeArea!=safeArea){Rebuild();return;}
            if(game.LayoutEditor.Active){UpdateLayoutHud();return;}
            UpdateShiftHud();
            toastTime-=Time.unscaledDeltaTime;toastBackground.gameObject.SetActive(toastTime>0&&!string.IsNullOrEmpty(toast.text));
            refreshIn-=Time.unscaledDeltaTime;if(refreshIn>0)return;refreshIn=.1f;
            var s=game.Sim.View();coins.text=Localization.Text(s.progress.coins.ToString("N0",Localization.Culture)+" coin");level.text=Localization.Text("Seviye "+s.level+"  ·  "+s.progress.xp%100+"/100 XP");
            pauseLabel.text=s.paused?"▶":"II";soundLabel.text=Localization.Text(game.SoundEnabled?"SES":"SESSİZ");hint.text=Localization.Text(s.hint);
            UpdateCameraControls();
            status.text=s.paused?"DURAKLATILDI  ·  ▶ İLE DEVAM ET":s.rush?"ÖĞLE YOĞUNLUĞU  ·  GELİR ×1,5":"AÇIK  ·  YERE DOKUNARAK YÜRÜ";
            if(s.tutorialStep>0&&!s.paused)status.text="İLK VARDİYA  ·  "+s.tutorialStep+"/5  ·  "+s.tutorialTitle.ToUpperInvariant();
            status.text=BranchCatalog.Name(s.progress.activeBranch).ToUpperInvariant()+"  ·  "+status.text;
            if(s.progress.driveThru>0)status.text+="  ·  ARAÇ "+game.Sim.DriveQueue+"/"+game.Sim.DriveCapacity;
            if(s.progress.shift.active)status.text=BranchCatalog.Name(s.progress.activeBranch)+" · "+ShiftClock()+" · "+s.progress.shift.served+"/"+s.progress.shift.target+" ödeme";
            status.text=Localization.Text(status.text);
            lessonProgress.rectTransform.sizeDelta=new Vector2(s.tutorialStep>0?(width-24)*s.tutorialStep/5f:0,2);
            bool rewardReady=s.missions.Any(m=>!m.claimed&&m.current>=m.target)||game.Sim.ReadyAchievements>0;
            management.GetComponent<Image>().color=rewardReady?RestaurantArt.Gold:green;
            management.GetComponentInChildren<Text>().color=rewardReady?ink:cream;
            if(navigation.TryGetValue("Görevler",out var goals)&&goals)goals.GetComponent<Image>().color=rewardReady?RestaurantArt.Gold:RestaurantArt.Hex("E4E8D4");
            for(int i=0;i<actions.Count;i++) {
                actions[i].interactable=game.Sim.CanPerform(commands[i])&&!BlocksWorldInput;
                actions[i].GetComponent<Image>().color=commands[i]==s.suggestedAction?red:green;
            }
            string key=JsonUtility.ToJson(s.progress);
            if(tab=="Ana Menü"||tab=="Kayıt ve Oturum")key+="|"+game.SaveState+"|"+game.LastSaveTime;
#if UNITY_EDITOR
            if(tab=="Reklam Testi")key+="|"+game.RewardTest.Flow.State+"|"+game.RewardTest.Coins+"|"+game.RewardTest.Available;
#endif
            if(panel&&key!=panelKey){RefreshPanel();panelKey=key;}
            UpdateBubbles(s);
        }
        public void Toast(string message,string kind="info")
        {
            if(!toast)return;
            if(kind!="info"&&toastTime>0&&Time.unscaledTime<importantToastUntil&&FeedbackSignals.Priority(kind)<FeedbackSignals.Priority(toastKind))return;
            toastSource=message;toast.text=Localization.Text(message);toastKind=kind;toastTime=kind=="order"||kind=="happy"||kind=="clean"?1.8f:3.8f;
            importantToastUntil=FeedbackSignals.Priority(kind)>=5?Time.unscaledTime+1.5f:0;StyleToast();
        }
        void StyleToast()
        {
            bool gold=toastKind=="upgrade"||toastKind=="vip";
            toastBackground.color=gold?RestaurantArt.Gold:toastKind=="bad"?RestaurantArt.Hex("8C4033"):green;
            toast.color=gold?ink:cream;toastIcon.Set(FeedbackSignals.Icon(toastKind),toastKind=="bad"?2:0);
        }
        public void OpenPanel(string selected)
        {
            if(game.LayoutEditor.Active)return;
#if UNITY_EDITOR
            if(selected!="Reklam Testi")game.RewardTest.Flow.Cancel();
#endif
            game.CameraControls.CancelGesture();
            if(!BlocksWorldInput)resumeAfterModal=!game.Sim.Paused;
            game.Sim.Paused=true;game.QuietKitchen();tab=selected;BuildModal();
        }
        public void Backgrounded(){resumeAfterModal=false;}
        public void Back(){if(game.LayoutEditor.Active)FinishLayout(false);else if(BlocksWorldInput)CloseOrHome();else game.Command("pause");}
        public void ClosePanel()
        {
#if UNITY_EDITOR
            game.RewardTest.Flow.Cancel();
#endif
            if(modal){modal.gameObject.SetActive(false);Destroy(modal.gameObject);}modal=null;panel=null;scroll=null;tab="";
            started=true;mainMenu=false;game.Sim.Paused=game.SaveBlocked||!resumeAfterModal;refreshIn=0;
        }
        void BuildModal()
        {
            if(modal){modal.gameObject.SetActive(false);Destroy(modal.gameObject);}
            // Shield covers the complete display so a panel tap cannot move the player.
            modal=Box("Modal shield",canvasRoot,0,0,Screen.width/scaleFactor,Screen.height/scaleFactor);
            modal.gameObject.AddComponent<Image>().color=new Color(.10f,.17f,.12f,.76f);
            float mw=Mathf.Min(620,width-20),mh=Mathf.Min(height-20,650);
            float sx=safeArea.x/scaleFactor+(width-mw)/2,sy=(Screen.height-safeArea.yMax)/scaleFactor+(height-mh)/2;
            var paper=Card("Management",modal,sx,sy,mw,mh,cream);paper.raycastTarget=true;
            string title=tab=="Yardım"?"Hoş geldin, patron!":tab.StartsWith("Ürün:")?"Menüyü genişlet":tab.StartsWith("Geliştirme:")?"Geliştirmeyi incele":tab;
            bool canReturn=!mainMenu&&tab!="Yönetim"&&!game.Sim.P.shift.pending;
            if(canReturn)Button("‹",paper.transform,12,8,48,56,green,()=>OpenPanel("Yönetim"),28).name="Management back";
            Label(title,paper.transform,canReturn?72:20,8,mw-(canReturn?156:110),56,23,red,FontStyle.Bold);
            if(!mainMenu||tab!="Ana Menü")Button(mainMenu?"‹":"×",paper.transform,mw-68,8,56,56,green,CloseOrHome,28);
            var viewport=Box("Scrollable content",paper.transform,14,76,mw-28,mh-90);
            viewport.gameObject.AddComponent<Image>().color=new Color(1,1,1,.01f);viewport.gameObject.AddComponent<RectMask2D>();
            panelWidth=mw-28;panel=Box("Content",viewport,0,0,panelWidth,600);
            scroll=viewport.gameObject.AddComponent<ScrollRect>();scroll.viewport=viewport;scroll.content=panel;scroll.horizontal=false;
            scroll.movementType=ScrollRect.MovementType.Clamped;scroll.scrollSensitivity=28;scroll.decelerationRate=.08f;
            RefreshPanel();scroll.verticalNormalizedPosition=1;
        }
        public void RefreshPanel()
        {
            if(!panel||game.Sim==null)return;
            float position=scroll?scroll.verticalNormalizedPosition:1;
            foreach(Transform child in panel){child.gameObject.SetActive(false);Destroy(child.gameObject);}
            var s=game.Sim.View();float y=0;
            if(tab=="Hedef Vardiya") {
                y=DrawShift(y);
            } else if(tab=="Yönetim") {
                y=DrawManagement(y);
            } else if(tab=="Ana Menü") {
                y=DrawHome(y);
            } else if(tab=="Ayarlar") {
                y=DrawSettings(y);
            } else if(tab=="Dil Seçimi") {
                y=DrawLanguage(y);
            } else if(tab=="Kayıt ve Oturum") {
                y=DrawSaveStatus(y);
#if UNITY_EDITOR
            } else if(tab=="Reklam Testi") {
                y=DrawRewardTest(y);
#endif
            } else if(tab=="Yardım") {
                if(brandArt){float bw=Mathf.Min(300,panelWidth-20),bh=bw*brandArt.height/(float)brandArt.width;
                    var mark=Box("Welcome brand",panel,(panelWidth-bw)/2,y,bw,bh).gameObject.AddComponent<RawImage>();mark.texture=brandArt;mark.raycastTarget=false;y+=bh+12;}
                Label("İlk burger. İlk adım.",panel,10,y,panelWidth-20,54,28,ink,FontStyle.Bold);y+=60;
                Label("1. Sipariş al, menüyü hazırla ve servis et.\n2. Ödemeyi al, boşalan masayı temizle.\n3. Ödüllerini topla ve kendi ekibini kur.\n\nKırmızı düğme sıradaki işi önerir. Yere dokunarak yürüyebilirsin. Menüler açıkken vardiya durur.",panel,10,y,panelWidth-20,190,17,muted);y+=202;
                Label("İki parmağını açarak yakınlaş, birlikte kaydırarak etrafa bak. + / − düğmeleri de yakınlığı değiştirir. MERKEZ ilk görünüme döndürür. Düzenleme ekranında eşyalara tek parmakla dokun. Bilgisayarda: tekerlek ve sağ tuşla sürükleme.",panel,10,y,panelWidth-20,125,15,muted);y+=137;
                Button(mainMenu?"OYUNA BAŞLA":"OYUNA DÖN",panel,10,y,panelWidth-20,58,red,()=>{if(mainMenu)StartGame();else ClosePanel();},18);y+=70;
            } else if(tab=="Restoran") {
                Label(BranchCatalog.Name(s.progress.activeBranch)+" şubesi",panel,10,y,panelWidth-20,40,25,ink,FontStyle.Bold);y+=48;
                Button("ANA MENÜ",panel,10,y,panelWidth-20,56,green,OpenMainMenu,17).name="Open main menu";y+=68;
                y=HomeButton("AYARLAR","Open settings","Ayarlar",y);
                y=GuideLink(y);
                Button("SES AYARLARI",panel,10,y,panelWidth-20,56,green,()=>OpenPanel("Ses Ayarları"),17).name="Open audio settings";y+=68;
                Button("ŞUBELER · DÜNYAYA AÇIL",panel,10,y,panelWidth-20,56,green,()=>OpenPanel("Şubeler"),17);y+=68;
                Button("ARABAYA SERVİS",panel,10,y,panelWidth-20,56,green,()=>OpenPanel("Arabaya servis"),17);y+=68;
                Button("KURYE TESLİMATI",panel,10,y,panelWidth-20,56,green,()=>OpenPanel("Kurye teslimatı"),17);y+=68;
                Label(s.rating.ToString("0.0")+" ★  ·  Temizlik %"+(int)s.cleanliness,panel,10,y,panelWidth-20,48,24,green,FontStyle.Bold);y+=58;
                Label(s.progress.served+" müşteri ağırladın  ·  "+s.progress.earned+" coin kazandın",panel,10,y,panelWidth-20,52,16,ink);y+=64;
                Button("MÜŞTERİ YORUMLARI",panel,10,y,panelWidth-20,56,green,()=>OpenPanel("Müşteri yorumları"),17);y+=68;
                Button("POPÜLERLİK · "+s.progress.popularity+" / 100",panel,10,y,panelWidth-20,56,green,()=>OpenPanel("Popülerlik"),17).name="Open popularity";y+=68;
                Button("MÜŞTERİLERİ TANI",panel,10,y,panelWidth-20,56,green,()=>OpenPanel("Müşteriler"),17).name="Open customer types";y+=68;
                Button("VIP MİSAFİRLER",panel,10,y,panelWidth-20,56,green,()=>OpenPanel("VIP misafirler"),17).name="Open VIP";y+=68;
                Button("RESTORANI DÜZENLE",panel,10,y,panelWidth-20,56,red,BeginLayout,17);y+=68;
                var main=s.missions.FirstOrDefault(m=>m.id=="main");if(main!=null)y=DrawMission(main,y);
                Button("NASIL OYNANIR?",panel,10,y,panelWidth-20,56,green,()=>OpenPanel("Yardım"),17);y+=68;
            } else if(tab=="Müşteriler") {
                y=DrawCustomers(y);
            } else if(tab=="Müşteri yorumları") {
                y=DrawReviews(y);
            } else if(tab=="Popülerlik") {
                y=DrawPopularity(y);
            } else if(tab=="VIP misafirler") {
                y=DrawVip(y);
            } else if(tab=="Servis önceliği") {
                y=DrawServicePriority(y);
            } else if(tab=="Arabaya servis") {
                y=DrawDriveThru(y);
            } else if(tab=="Kurye teslimatı") {
                y=DrawDelivery(y);
            } else if(tab=="Şubeler") {
                y=DrawBranches(y);
            } else if(tab.StartsWith("Ürün:")) {
                var recipe=MenuCatalog.Get(tab.Substring(5),s.progress);
                y=DrawOffer(s.offers.First(o=>o.id==recipe.unlock),y);
                Button("MENÜYE DÖN",panel,10,y,panelWidth-20,56,green,()=>OpenPanel("Menü"),17);y+=68;
            } else if(tab=="Ses Ayarları") {
                y=DrawAudioSettings(y);
            } else if(tab=="Gelişim Rehberi") {
                y=DrawGrowthGuide(y);
            } else if(tab.StartsWith("Geliştirme:")) {
                y=DrawGuidedOffer(tab.Substring("Geliştirme:".Length),y);
            } else if(tab=="Görevler") {
                y=GuideLink(y);
                int ready=game.Sim.ReadyAchievements;
                Button(ready>0?"BAŞARIMLAR · "+ready+" ÖDÜL HAZIR":"BAŞARIMLAR · UZUN VADELİ HEDEFLER",panel,10,y,panelWidth-20,56,ready>0?red:green,()=>OpenPanel("Başarımlar"),16).name="Open achievements";y+=68;
                foreach(var m in s.missions)y=DrawMission(m,y);
            } else if(tab=="Başarımlar") {
                y=DrawAchievements(y);
            } else if(tab=="Menü") {
                if(mealArt){
                    float w=Mathf.Min(panelWidth-20,330),h=w*mealArt.height/(float)mealArt.width;
                    var art=Box("Burger meal artwork",panel,(panelWidth-w)/2,y,w,h).gameObject.AddComponent<RawImage>();art.texture=mealArt;art.raycastTarget=false;y+=h+12;
                }
                foreach(var recipe in MenuCatalog.All(s.progress))y=DrawRecipe(recipe,y,s.offers);
                Label("Aileler büyük porsiyon sipariş eder.\nHızlı servis daha çok bahşiş getirir. Ürün satışları ödeme alındığında sayılır.",panel,12,y,panelWidth-24,85,16,muted);y+=95;
            } else {
                if(tab=="Personel") {
                    Button("SERVİS ÖNCELİĞİ",panel,10,y,panelWidth-20,56,green,()=>OpenPanel("Servis önceliği"),17).name="Open service priority";y+=64;
                    Label("Seçili: "+ServicePriorityCatalog.Name(s.progress.servicePriority),panel,12,y,panelWidth-24,40,16,green,FontStyle.Bold);y+=52;
                }
                foreach(var o in s.offers.Where(o=>tab=="Personel"?new[]{"cashier","cook","waiter","cleaner","manager"}.Contains(o.id):new[]{"table","grill","blender","fryer","decor","drive","delivery"}.Contains(o.id)))y=DrawOffer(o,y);
            }
            panel.sizeDelta=new Vector2(panelWidth,Mathf.Max(y,scroll.viewport.rect.height));
            Canvas.ForceUpdateCanvases();scroll.verticalNormalizedPosition=position;
        }
        float DrawMission(Mission m,float y)
        {
            var card=Card("Mission",panel,0,y,panelWidth,162,RestaurantArt.Hex("ECECD8"));
            Label(m.title,card.transform,14,8,panelWidth-28,49,20,ink,FontStyle.Bold);
            Label(Mathf.Min(m.current,m.target)+"/"+m.target+"  ·  Ödül "+m.reward+" coin",card.transform,14,59,panelWidth-28,27,16,muted);
            var b=Button(m.claimed?"ALINDI":"ÖDÜLÜ AL",card.transform,12,94,panelWidth-24,56,green,()=>game.Command("claim",m.id));
            b.interactable=!m.claimed&&m.current>=m.target;return y+174;
        }
        float DrawRecipe(Recipe recipe,float y,List<Offer> offers)
        {
            var card=Card("Recipe "+recipe.id,panel,0,y,panelWidth,recipe.available?142:168,RestaurantArt.Hex(recipe.station=="blender"?"F2E0D9":"ECECD8"));
            Label(recipe.name+" · "+recipe.price+" coin",card.transform,14,5,panelWidth-28,44,21,ink,FontStyle.Bold);
            Label(recipe.description,card.transform,14,49,panelWidth-28,35,15,muted);
            if(recipe.available) {
                string station=recipe.station=="blender"?"Milkshake makinesi":"Izgara + fritöz";
                Label(station+" · "+MenuCatalog.PrepSeconds(recipe,game.Sim.P).ToString("0.0")+" sn\n"+MenuCatalog.Sales(game.Sim.P,recipe.id)+" satış · Menüde açık",card.transform,14,86,panelWidth-28,46,14,green);
                return y+154;
            }
            var offer=offers.First(o=>o.id==recipe.unlock);
            string info=string.IsNullOrEmpty(offer.lockedReason)?offer.cost+" coin ile açılır":offer.lockedReason;
            Label(info,card.transform,14,82,panelWidth-28,23,13,green);
            var button=Button(recipe.unlock=="blender"?"MAKİNEYİ GÖR":"TARİFİ GÖR",card.transform,12,108,panelWidth-24,50,green,()=>OpenPanel("Ürün:"+recipe.id),15);
            return y+180;
        }
        float DrawOffer(Offer o,float y)
        {
            var card=Card("Offer",panel,0,y,panelWidth,202,RestaurantArt.Hex("ECECD8"));
            Label(o.name,card.transform,14,7,panelWidth-28,35,22,ink,FontStyle.Bold);
            Label(o.description,card.transform,14,44,panelWidth-28,57,16,muted);
            int shortage=Mathf.Max(0,o.cost-game.Sim.P.coins);
            string detail=o.level>=o.max?"En yüksek seviye":!string.IsNullOrEmpty(o.lockedReason)?o.lockedReason:shortage>0?shortage+" coin eksik · yaklaşık "+Mathf.CeilToInt(shortage/32f)+" klasik menü":"Bütçen yeterli · Seviye "+o.level+" → "+(o.level+1);
            Label(detail,card.transform,14,102,panelWidth-28,26,13,green);
            string label=o.level>=o.max?"TAMAMLANDI":!string.IsNullOrEmpty(o.lockedReason)?"KİLİTLİ":(o.level>0?"GELİŞTİR":"SATIN AL")+"  ·  "+o.cost+" COIN";
            var b=Button(label,card.transform,12,134,panelWidth-24,56,green,()=>game.Command("buy",o.id));
            b.name="Buy "+o.id;b.interactable=o.level<o.max&&game.Sim.P.coins>=o.cost&&string.IsNullOrEmpty(o.lockedReason);return y+214;
        }
        void OnDestroy(){if(canvasRoot)Destroy(canvasRoot.gameObject);if(round){Destroy(round.texture);Destroy(round);}}
    }
}
