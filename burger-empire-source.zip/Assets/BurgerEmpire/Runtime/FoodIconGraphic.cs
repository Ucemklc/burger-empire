using UnityEngine;
using UnityEngine.UI;

namespace BurgerEmpire.Unity
{
    // Small vector illustrations rendered as UI geometry: no emoji/font dependency on Android.
    [RequireComponent(typeof(CanvasRenderer))]
    public sealed class FoodIconGraphic : MaskableGraphic
    {
        public string Kind {get;private set;}="burger";
        public int Mood {get;private set;}
        public int DrawnVertices {get;private set;}
        static Color C(string hex)=>RestaurantArt.Hex(hex);
        VertexHelper mesh;
        public void Set(string kind,int mood=0){if(Kind==kind&&Mood==mood)return;Kind=kind;Mood=mood;SetVerticesDirty();}
        Vector2 P(float x,float y){var r=rectTransform.rect;return new Vector2(r.xMin+x*r.width,r.yMin+y*r.height);}
        void Quad(float x,float y,float w,float h,Color c)
        {Poly(c,new Vector2(x,y),new Vector2(x+w,y),new Vector2(x+w,y+h),new Vector2(x,y+h));}
        void Poly(Color c,params Vector2[] points)
        {
            int start=mesh.currentVertCount;
            foreach(var p in points)mesh.AddVert(P(p.x,p.y),c*color,Vector2.zero);
            for(int i=1;i<points.Length-1;i++)mesh.AddTriangle(start,start+i,start+i+1);
        }
        void Ellipse(float x,float y,float rx,float ry,Color c)
        {
            int start=mesh.currentVertCount;mesh.AddVert(P(x,y),c*color,Vector2.zero);
            for(int i=0;i<=24;i++){float a=i*Mathf.PI/12;mesh.AddVert(P(x+Mathf.Cos(a)*rx,y+Mathf.Sin(a)*ry),c*color,Vector2.zero);}
            for(int i=0;i<24;i++)mesh.AddTriangle(start,start+i+1,start+i+2);
        }
        void Line(float x1,float y1,float x2,float y2,float thickness,Color c)
        {
            var a=new Vector2(x1,y1);var b=new Vector2(x2,y2);var n=new Vector2(-(b-a).y,(b-a).x).normalized*thickness*.5f;
            Poly(c,a-n,b-n,b+n,a+n);
        }
        protected override void OnPopulateMesh(VertexHelper vh)
        {
            mesh=vh;mesh.Clear();Color bun=C("F6B448"),gold=C("FFD16A"),red=C("E64B35"),green=C("68A447"),dark=C("52362B"),cream=C("FFF6DD");
            if(Kind=="burger"||Kind=="cheese"||Kind=="double"||Kind=="chicken"||Kind=="bbq") {
                if(Kind=="bbq")bun=C("D78B3E");
                Ellipse(.5f,.19f,.43f,.12f,bun);Quad(.08f,.20f,.84f,.09f,bun);
                Ellipse(.5f,.33f,.43f,.10f,Kind=="chicken"?C("D89F52"):dark);Quad(.06f,.40f,.88f,.07f,Kind=="bbq"?C("773721"):red);
                if(Kind=="double"){Ellipse(.5f,.47f,.43f,.08f,dark);Quad(.06f,.53f,.88f,.055f,red);}
                if(Kind!="burger")Poly(Kind=="chicken"?cream:gold,new Vector2(.06f,.43f),new Vector2(.94f,.43f),new Vector2(.7f,.33f),new Vector2(.47f,.42f),new Vector2(.28f,.34f));
                for(int i=0;i<5;i++)Ellipse(.16f+i*.17f,.54f,.12f,.055f,green);
                Ellipse(.5f,.65f,.43f,.22f,bun);Quad(.07f,.54f,.86f,.10f,bun);
                for(int i=0;i<5;i++)Line(.24f+i*.12f,.73f+(i%2)*.065f,.28f+i*.12f,.75f+(i%2)*.065f,.025f,cream);
            } else if(Kind=="fries") {
                for(int i=0;i<6;i++){float x=.19f+i*.10f;Quad(x,.4f,.07f,.42f+(i%3)*.05f,gold);Quad(x,.43f,.02f,.35f+(i%3)*.05f,cream);}
                Poly(red,new Vector2(.16f,.56f),new Vector2(.84f,.56f),new Vector2(.73f,.13f),new Vector2(.27f,.13f));
                Ellipse(.5f,.33f,.115f,.09f,gold);
            } else if(Kind=="cola"||Kind=="shake"||Kind=="chocolate") {
                bool shake=Kind=="shake"||Kind=="chocolate",chocolate=Kind=="chocolate";
                Poly(chocolate?C("986747"):shake?C("F5BCD0"):red,new Vector2(.22f,.71f),new Vector2(.78f,.71f),new Vector2(.69f,.13f),new Vector2(.31f,.13f));
                Quad(.38f,.22f,.14f,.35f,shake?cream:gold);Ellipse(.5f,.72f,.31f,.06f,cream);
                if(shake){for(int i=0;i<3;i++)Ellipse(.5f,.77f+i*.05f,.24f-i*.06f,.065f,i%2==0?cream:chocolate?dark:C("ED91B0"));if(chocolate)Line(.65f,.81f,.75f,.98f,.06f,gold);else Ellipse(.54f,.93f,.04f,.04f,red);}
                else {Line(.59f,.73f,.66f,.96f,.045f,red);Line(.66f,.96f,.79f,.96f,.045f,red);}
            } else if(Kind=="face") {
                Ellipse(.5f,.5f,.45f,.45f,Mood==2?C("F2946E"):gold);
                Ellipse(.33f,.60f,.043f,.066f,dark);Ellipse(.67f,.60f,.043f,.066f,dark);
                if(Mood==2){Line(.23f,.75f,.40f,.68f,.04f,dark);Line(.60f,.68f,.77f,.75f,.04f,dark);}
                for(int i=0;i<8;i++){float x=.27f+i*.0575f,nx=x+.0575f;float y=.28f+(x-.5f)*(x-.5f)*2,ny=.28f+(nx-.5f)*(nx-.5f)*2;if(Mood==1)y=ny=.31f;if(Mood==2){y=.41f-(x-.5f)*(x-.5f)*1.7f;ny=.41f-(nx-.5f)*(nx-.5f)*1.7f;}Line(x,y,nx,ny,.038f,dark);}
            } else if(Kind=="check") {
                Ellipse(.5f,.5f,.47f,.47f,C("418C53"));Line(.23f,.48f,.43f,.28f,.10f,cream);Line(.43f,.28f,.80f,.74f,.10f,cream);
            } else if(Kind=="spinner") {
                for(int i=0;i<8;i++){float a=i*Mathf.PI/4;var c=C("D9992A");c.a=.25f+i*.10f;Ellipse(.5f+Mathf.Cos(a)*.33f,.5f+Mathf.Sin(a)*.33f,.07f,.07f,c);}
            } else if(Kind=="clock") {
                Ellipse(.5f,.5f,.46f,.46f,C("7D9F92"));Ellipse(.5f,.5f,.35f,.35f,cream);Line(.5f,.5f,.5f,.77f,.065f,dark);Line(.5f,.5f,.72f,.39f,.065f,dark);
            } else if(Kind=="coin") {
                Ellipse(.5f,.5f,.47f,.47f,C("C58B27"));Ellipse(.5f,.5f,.37f,.37f,gold);Quad(.45f,.24f,.10f,.52f,cream);Quad(.32f,.44f,.36f,.1f,cream);
            } else if(Kind=="crown") {
                Poly(gold,new Vector2(.13f,.25f),new Vector2(.03f,.79f),new Vector2(.29f,.59f),new Vector2(.5f,.96f),new Vector2(.71f,.59f),new Vector2(.97f,.79f),new Vector2(.87f,.25f));Quad(.13f,.13f,.74f,.10f,C("C58B27"));
            } else if(Kind=="car") {
                Quad(.08f,.24f,.84f,.30f,C("548AA7"));Poly(C("548AA7"),new Vector2(.21f,.54f),new Vector2(.31f,.78f),new Vector2(.69f,.78f),new Vector2(.8f,.54f));Quad(.34f,.56f,.32f,.16f,cream);Ellipse(.25f,.24f,.11f,.11f,dark);Ellipse(.75f,.24f,.11f,.11f,dark);
            } else if(Kind=="bag") {
                Quad(.20f,.13f,.60f,.65f,bun);Line(.34f,.78f,.4f,.93f,.05f,dark);Line(.4f,.93f,.65f,.93f,.05f,dark);Line(.65f,.93f,.7f,.78f,.05f,dark);Quad(.37f,.30f,.26f,.27f,red);
            }
            DrawnVertices=mesh.currentVertCount;
        }
    }
}
