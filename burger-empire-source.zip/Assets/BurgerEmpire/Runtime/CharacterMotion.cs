using UnityEngine;

namespace BurgerEmpire.Unity
{
    // Uses simulation time, so animations stop exactly with the restaurant or an open panel.
    public sealed class CharacterMotion
    {
        readonly RestaurantArt.Person person;
        readonly Transform spatula,cloth,notepad,phone;
        Vector3 position;
        readonly Vector3 leftFoot,rightFoot;
        float lastTime=float.NaN,walkPhase,stride;
        string lastActivity="";
        bool lastCarrying,lastSeated;
        public float Stride {get{return stride;}}
        public string State {get;private set;}="idle";
        public void Reset(){lastTime=float.NaN;walkPhase=stride=0;State="idle";}
        public CharacterMotion(RestaurantArt.Person p,bool worker)
        {
            person=p;
            leftFoot=p.leftLeg.localPosition;rightFoot=p.rightLeg.localPosition;
            if(!worker&&p.variant==5) {
                phone=RestaurantArt.Group("Selfie phone",p.rightArm,new Vector3(0,-.36f,.045f));
                phone.localRotation=Quaternion.Euler(105,0,0);
                RestaurantArt.Box("Phone case",phone,0,0,0,.14f,.23f,.04f,RestaurantArt.Hex("433E61"));
                RestaurantArt.Box("Phone screen",phone,0,0,-.024f,.115f,.19f,.008f,RestaurantArt.Hex("A9DCD9"));
                phone.gameObject.SetActive(false);
            }
            if(!worker)return;
            spatula=RestaurantArt.Group("Spatula",p.rightArm,new Vector3(0,-.33f,.025f));
            RestaurantArt.Box("Handle",spatula,0,-.09f,0,.055f,.23f,.055f,RestaurantArt.Brown);
            RestaurantArt.Box("Blade",spatula,0,-.28f,0,.18f,.22f,.025f,RestaurantArt.Hex("B9D1D4"));
            cloth=RestaurantArt.Group("Cleaning cloth",p.rightArm,new Vector3(0,-.36f,.045f));
            RestaurantArt.Box("Folded cloth",cloth,0,0,0,.30f,.06f,.23f,RestaurantArt.Hex("79C9DF"));
            notepad=RestaurantArt.Group("Order pad",p.leftArm,new Vector3(0,-.36f,.04f));
            RestaurantArt.Box("Pad",notepad,0,0,0,.23f,.055f,.29f,RestaurantArt.Cream);
            RestaurantArt.Box("Clip",notepad,0,.035f,-.1f,.11f,.02f,.025f,RestaurantArt.Gold);
            spatula.gameObject.SetActive(false);cloth.gameObject.SetActive(false);notepad.gameObject.SetActive(false);
        }
        public void Apply(float x,float z,float time,bool carrying,bool seated,string activity,Vector3? facing)
        {
            var target=new Vector3(x,.28f,z);
            bool first=float.IsNaN(lastTime)||time<lastTime||time-lastTime>1||!person.root.gameObject.activeInHierarchy;
            Vector3 delta=target-position;delta.y=0;
            float dt=first?0:Mathf.Clamp(time-lastTime,0,.25f);
            if(!first&&time==lastTime&&delta.sqrMagnitude<.000001f&&activity==lastActivity&&carrying==lastCarrying&&seated==lastSeated)return;
            float distance=delta.magnitude;
            bool moving=!first&&dt>0&&distance>.0001f&&distance<2;
            float blend=first||dt==0?1:1-Mathf.Exp(-12*dt);
            stride=Mathf.Lerp(stride,moving?1:0,blend);
            walkPhase+=moving?distance*(carrying?4.6f:4.0f):dt*3*stride;
            State=moving?"walk":activity!=""?activity:seated?"seated":carrying?"carry":"idle";
            Quaternion rotation=person.root.rotation;
            if(moving)rotation=Quaternion.LookRotation(delta);
            else if(facing.HasValue&&facing.Value.sqrMagnitude>.001f)rotation=Quaternion.LookRotation(facing.Value);
            else if(seated)rotation=Quaternion.LookRotation(Vector3.back);
            person.root.rotation=first?rotation:Quaternion.RotateTowards(person.root.rotation,rotation,480*dt);
            float gait=Mathf.Sin(walkPhase)*(carrying?20:29)*stride;
            float left=carrying?-66:seated?-42:-gait*.65f,right=carrying?-66:seated?-42:gait*.65f;
            float rightSide=7,leftSide=-7;
            float pulse=Mathf.Sin(time*8),gentle=Mathf.Sin(time*2.3f);
            bool working=!moving&&!carrying;
            if(working&&activity=="cook"){left=-38;right=-55+pulse*24;rightSide=14;}
            if(working&&activity=="clean"){left=-35;right=-77+pulse*12;rightSide=10+Mathf.Sin(time*7)*24;}
            if(working&&activity=="order"){left=-65;right=-52+pulse*8;}
            if(!moving&&activity=="packing"){left=-62+pulse*9;right=-62-pulse*9;}
            if(working&&activity=="assembly"){left=-65+pulse*12;right=-65-pulse*12;}
            if(working&&activity=="manage"){left=-56+pulse*5;right=-56-pulse*5;}
            if(working&&activity=="inspect"){left=-65;right=-40+gentle*8;}
            if(working&&activity=="waiting"){left=-12;right=-16+gentle*5;}
            if(working&&activity=="impatient"){left=-32;right=-42+Mathf.Sin(time*4)*8;rightSide=18;}
            if(working&&activity=="photo"){left=-35;right=-116;rightSide=18;}
            if(working&&activity=="eating"){left=-48;right=-70+Mathf.Sin(time*3)*35;}
            if(working&&activity=="payment"){left=-45;right=-110+gentle*14;rightSide=20;}
            if(working&&activity=="collect"){left=-65;right=-75+pulse*9;}
            person.leftLeg.localRotation=Quaternion.Euler(seated?-78:gait,0,0);
            person.rightLeg.localRotation=Quaternion.Euler(seated?-78:-gait,0,0);
            person.leftArm.localRotation=Quaternion.Slerp(person.leftArm.localRotation,Quaternion.Euler(left,0,leftSide),blend);
            person.rightArm.localRotation=Quaternion.Slerp(person.rightArm.localRotation,Quaternion.Euler(right,0,rightSide),blend);
            person.leftLeg.localPosition=leftFoot+Vector3.up*(seated?0:Mathf.Max(0,Mathf.Sin(walkPhase))*.045f*stride);
            person.rightLeg.localPosition=rightFoot+Vector3.up*(seated?0:Mathf.Max(0,-Mathf.Sin(walkPhase))*.045f*stride);
            float bob=seated?0:Mathf.Lerp(gentle*.009f,Mathf.Abs(Mathf.Sin(walkPhase))*(carrying?.012f:.027f),stride);
            person.root.position=target+Vector3.up*bob;
            person.food.gameObject.SetActive(carrying&&activity!="packing");
            if(spatula)spatula.gameObject.SetActive(working&&activity=="cook");
            if(cloth)cloth.gameObject.SetActive(working&&activity=="clean");
            if(notepad)notepad.gameObject.SetActive(working&&(activity=="order"||activity=="inspect"));
            if(phone)phone.gameObject.SetActive(working&&activity=="photo");
            person.details.Pose(time,activity);
            person.silhouette.Pose(time,activity,stride,carrying,bob,person.root.localScale.y);
            position=target;lastTime=time;person.last=target;lastActivity=activity;lastCarrying=carrying;lastSeated=seated;
        }
    }
}
