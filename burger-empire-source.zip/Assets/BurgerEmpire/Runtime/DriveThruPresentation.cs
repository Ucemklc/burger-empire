using System.Collections.Generic;
using System.Linq;
using BurgerEmpire.Core;
using UnityEngine;

namespace BurgerEmpire.Unity
{
    public sealed class DriveThruPresentation
    {
        readonly Transform structure,traffic,exitTree;
        readonly Vector3 originalTreePosition;
        readonly Dictionary<int,Transform> cars=new Dictionary<int,Transform>();
        readonly Stack<Transform> pool=new Stack<Transform>();
        readonly Dictionary<Transform,Transform> bags=new Dictionary<Transform,Transform>();
        readonly TextMesh levelSign;
        readonly Transform fourthMarker;
        Simulation previous;
        int revision=-1;
        public DriveThruPresentation(Transform world)
        {
            structure=RestaurantArt.Group("DriveThru",world,Vector3.zero);
            traffic=RestaurantArt.Group("Drive vehicles",world,Vector3.zero);
            exitTree=world.Cast<Transform>().FirstOrDefault(t=>t.name=="Street tree"&&t.localPosition.x>10&&Mathf.Abs(t.localPosition.z-Simulation.DriveLaneZ)<1);
            if(exitTree)originalTreePosition=exitTree.localPosition;
            RestaurantArt.Box("Lane",structure,5,-.13f,12,27,.08f,2.25f,RestaurantArt.Hex("627C7D"));
            for(int side=-1;side<=1;side+=2)RestaurantArt.Box("Lane edge",structure,5,-.075f,12+side*1.05f,27,.025f,.065f,RestaurantArt.Gold);
            for(int i=0;i<4;i++) {
                var marker=RestaurantArt.Group("Queue slot "+i,structure,new Vector3(Simulation.DriveWindowX-i*3.3f,-.06f,12));
                RestaurantArt.Box("Stop line",marker,1.35f,0,0,.065f,.025f,1.7f,RestaurantArt.Cream);
                if(i==3)fourthMarker=marker;
            }
            var window=RestaurantArt.Group("Pickup window",structure,new Vector3(Simulation.DriveWindowX,.25f,10.1f));
            RestaurantArt.Box("Counter",window,0,.52f,0,1.65f,1.04f,.70f,RestaurantArt.Red);
            RestaurantArt.Box("Worktop",window,0,1.08f,0,1.83f,.13f,.88f,RestaurantArt.Cream);
            for(int side=-1;side<=1;side+=2)RestaurantArt.Box("Canopy post",window,side*.8f,1.65f,0,.09f,1.4f,.09f,RestaurantArt.Brown);
            for(int i=0;i<8;i++)RestaurantArt.Box("Awning stripe",window,-.875f+i*.25f,2.38f,0,.25f,.15f,1.25f,i%2==0?RestaurantArt.Red:RestaurantArt.Cream);
            RestaurantArt.Box("Pickup sign",window,0,2.15f,.12f,1.75f,.36f,.10f,RestaurantArt.Green);
            RestaurantArt.Text("Pickup title","ARABAYA SERVİS",window,new Vector3(0,2.15f,.18f),.11f,RestaurantArt.Cream);
            levelSign=RestaurantArt.Text("Drive level","",window,new Vector3(0,.69f,.36f),.12f,RestaurantArt.Cream);
            RestaurantArt.Text("Drive markup","PAKET +%20",window,new Vector3(0,.36f,.36f),.11f,RestaurantArt.Gold);
            RestaurantArt.Box("Intercom",structure,6.6f,.65f,10.85f,.3f,1.35f,.25f,RestaurantArt.Brown);
            RestaurantArt.Box("Speaker",structure,6.6f,1.42f,10.85f,.46f,.42f,.32f,RestaurantArt.Green);
        }
        public void Sync(Simulation sim,bool editing)
        {
            if(previous!=sim||revision!=sim.BranchRevision) {
                foreach(var car in cars.Values){car.gameObject.SetActive(false);pool.Push(car);}cars.Clear();
                previous=sim;revision=sim.BranchRevision;
            }
            if(exitTree)exitTree.localPosition=originalTreePosition+(sim.P.driveThru>0?Vector3.back*1.8f:Vector3.zero);
            structure.gameObject.SetActive(sim.P.driveThru>0);traffic.gameObject.SetActive(sim.P.driveThru>0&&!editing);
            fourthMarker.gameObject.SetActive(sim.P.driveThru==2);levelSign.text=sim.DriveCapacity+" ARAÇLIK HAT";
            foreach(var c in sim.Customers.Where(c=>c.drive)) {
                if(!cars.TryGetValue(c.id,out var car)){car=pool.Count>0?pool.Pop():BuildCar(traffic);cars[c.id]=car;car.name="Vehicle "+c.id;}
                car.gameObject.SetActive(true);car.position=new Vector3(c.x,.08f,c.z);
                car.Find("Paint").GetComponent<Renderer>().sharedMaterial=RestaurantArt.Mat(RestaurantArt.Hex(new[]{"DE6248","E8B646","4D92A1","9B79AB","537E67","E0DDD0"}[c.kind%6]));
                car.Find("Brake lights").gameObject.SetActive(c.phase!="arriving"&&c.phase!="leaving");
            }
            foreach(int id in cars.Keys.Where(id=>!sim.Customers.Any(c=>c.drive&&c.id==id)).ToArray()){
                var car=cars[id];car.gameObject.SetActive(false);pool.Push(car);cars.Remove(id);
            }
        }
        public void Carry(RestaurantArt.Person person,bool carryingPackage)
        {
            if(!bags.TryGetValue(person.root,out var bag)) {
                if(!carryingPackage)return;
                bag=RestaurantArt.Group("Takeaway bag",person.root,person.food.localPosition);bags[person.root]=bag;
                RestaurantArt.Box("Paper",bag,0,.19f,0,.40f,.42f,.28f,RestaurantArt.Hex("D6AC72"));
                RestaurantArt.Box("Fold",bag,0,.42f,0,.42f,.07f,.30f,RestaurantArt.Hex("BA8954"));
                RestaurantArt.Box("Brand seal",bag,0,.2f,.145f,.20f,.18f,.015f,RestaurantArt.Red);
            }
            bag.gameObject.SetActive(carryingPackage);if(carryingPackage)person.food.gameObject.SetActive(false);
        }
        static Transform BuildCar(Transform parent)
        {
            var root=RestaurantArt.Group("Vehicle",parent,Vector3.zero);
            RestaurantArt.Box("Chassis",root,0,.3f,0,2.55f,.34f,1.25f,RestaurantArt.Brown);
            RestaurantArt.Box("Paint",root,0,.55f,0,2.6f,.5f,1.35f,RestaurantArt.Red);
            RestaurantArt.Box("Cabin",root,-.22f,.99f,0,1.30f,.55f,1.08f,RestaurantArt.Cream);
            RestaurantArt.Box("Front glass",root,.44f,1f,0,.025f,.36f,.89f,RestaurantArt.Hex("8CB6C3"));
            for(int side=-1;side<=1;side+=2) {
                RestaurantArt.Box("Side glass",root,-.23f,1f,side*.55f,1.07f,.32f,.025f,RestaurantArt.Hex("8CB6C3"));
                for(int axle=-1;axle<=1;axle+=2) {
                    var wheel=RestaurantArt.Shape("Wheel",PrimitiveType.Cylinder,root,new Vector3(axle*.83f,.30f,side*.68f),new Vector3(.57f,.13f,.57f),RestaurantArt.Hex("343D3F"));
                    wheel.transform.localRotation=Quaternion.Euler(90,0,0);
                }
                RestaurantArt.Box("Headlight",root,1.31f,.57f,side*.43f,.025f,.19f,.24f,RestaurantArt.Gold);
            }
            var brakes=RestaurantArt.Group("Brake lights",root,Vector3.zero);
            for(int side=-1;side<=1;side+=2)RestaurantArt.Box("Light",brakes,-1.31f,.57f,side*.43f,.025f,.19f,.24f,RestaurantArt.Red);
            return root;
        }
    }
}
