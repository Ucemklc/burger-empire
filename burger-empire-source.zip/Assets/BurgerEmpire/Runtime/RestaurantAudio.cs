using System.Collections.Generic;
using System.Linq;
using BurgerEmpire.Core;
using UnityEngine;

namespace BurgerEmpire.Unity
{
    public sealed class RestaurantAudio
    {
        readonly Dictionary<string,AudioClip> clips=new Dictionary<string,AudioClip>();
        readonly Dictionary<string,float> playedAt=new Dictionary<string,float>();
        readonly AudioSource effects,grill,blender,music;
        readonly AudioClip musicClip;
        float effectsVolume=1,musicVolume=.55f;
        bool musicStarted;
        bool enabled=true;
        float nextEffect;
        public string LastCue {get;private set;}
        public int PlayedCues {get;private set;}
        public RestaurantAudio(GameObject owner)
        {
            effects=Source(owner,"Restaurant effects",.20f,false);
            grill=Source(owner,"Grill ambience",.075f,true);blender=Source(owner,"Blender ambience",.035f,true);
            foreach(var kind in SoundDesign.Kinds) {
                var data=SoundDesign.Samples(kind);var clip=AudioClip.Create("BE_"+kind,data.Length,1,SoundDesign.SampleRate,false);
                clip.SetData(data,0);clips[kind]=clip;
            }
            grill.clip=clips["grill"];blender.clip=clips["blender"];
            music=Source(owner,"Restaurant music",.16f*musicVolume,true);
            var tune=MusicDesign.Samples();musicClip=AudioClip.Create("BE_RestaurantTheme",tune.Length,1,MusicDesign.SampleRate,false);
            musicClip.SetData(tune,0);music.clip=musicClip;
        }
        static AudioSource Source(GameObject owner,string name,float volume,bool loop)
        {
            var child=new GameObject(name);child.transform.SetParent(owner.transform,false);
            var source=child.AddComponent<AudioSource>();source.playOnAwake=false;source.loop=loop;source.volume=volume;source.spatialBlend=0;return source;
        }
        public void SetEnabled(bool value){enabled=value;if(!value)Stop();}
        public void SetVolumes(float musicLevel,float effectLevel)
        {
            musicVolume=MusicDesign.Volume(musicLevel,.55f);effectsVolume=MusicDesign.Volume(effectLevel);
            music.volume=.16f*musicVolume;effects.volume=.20f*effectsVolume;
            grill.volume=.075f*effectsVolume;blender.volume=.035f*effectsVolume;
            if(musicVolume==0&&music.isPlaying)music.Pause();
            if(effectsVolume==0){effects.Stop();grill.Stop();blender.Stop();}
        }
        public bool Play(string kind)
        {
            if(!enabled||effectsVolume==0||!clips.TryGetValue(kind,out var clip)||kind=="grill"||kind=="blender")return false;
            float now=Time.unscaledTime;
            float gap=kind=="click"?.075f:kind=="upgrade"||kind=="vip"?.6f:.4f;
            if(playedAt.TryGetValue(kind,out var previous)&&now-previous<gap)return false;
            bool important=FeedbackSignals.Priority(kind)>=5;
            if(now<nextEffect&&!important)return false;
            // One effect voice: a warning or purchase can replace a minor cue, never pile up.
            effects.Stop();effects.clip=clip;effects.Play();playedAt[kind]=now;nextEffect=now+(important?.35f:.12f);
            LastCue=kind;PlayedCues++;return true;
        }
        public void Sync(Simulation sim)
        {
            bool running=enabled&&!sim.Paused;
            if(running&&musicVolume>0) {
                if(!musicStarted){music.Play();musicStarted=true;}
                else if(!music.isPlaying)music.UnPause();
            } else if(music.isPlaying)music.Pause();
            running&=effectsVolume>0;
            Loop(grill,running&&sim.Customers.Any(c=>c.station=="grill"&&c.order=="cooking"));
            Loop(blender,running&&sim.Customers.Any(c=>c.station=="blender"&&c.order=="cooking"));
        }
        static void Loop(AudioSource source,bool run){if(run&&!source.isPlaying)source.Play();else if(!run&&source.isPlaying)source.Stop();}
        public void Stop(){effects.Stop();grill.Stop();blender.Stop();music.Stop();musicStarted=false;}
        public void Reset(){Stop();playedAt.Clear();nextEffect=0;LastCue=null;}
        public void Dispose(){Stop();foreach(var clip in clips.Values)Object.Destroy(clip);clips.Clear();Object.Destroy(musicClip);}
    }
}
