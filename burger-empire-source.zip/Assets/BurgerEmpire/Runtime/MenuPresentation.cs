using System.Collections.Generic;
using System.Linq;
using BurgerEmpire.Core;
using UnityEngine;

namespace BurgerEmpire.Unity
{
    // Native geometry shares the restaurant's palette and needs no texture downloads.
    public sealed class MenuPresentation
    {
        readonly Transform station,secondMixer;
        readonly Transform[] whisks=new Transform[2];
        readonly TextMesh fryerLabel;
        readonly MealVisual[] meals=new MealVisual[4];
        readonly Dictionary<Transform,MealVisual> trays=new Dictionary<Transform,MealVisual>();
        public MenuPresentation(Transform world)
        {
            for(int i=0;i<4;i++)meals[i]=new MealVisual(world.Find("Table_"+i).Find("Meal"));
            station=RestaurantArt.Group("Milkshake station",world,new Vector3(9.25f,.25f,1.05f));
            RestaurantArt.Box("Milkshake cabinet",station,0,.48f,0,1.12f,.96f,1.1f,RestaurantArt.Hex("C9868F"));
            RestaurantArt.Box("Milkshake worktop",station,0,1.01f,0,1.2f,.10f,1.2f,RestaurantArt.Cream);
            RestaurantArt.Text("Milkshake sign","SHAKE",station,new Vector3(0,.65f,.565f),.13f,RestaurantArt.Cream);
            for(int i=0;i<2;i++) {
                var mixer=RestaurantArt.Group("Mixer "+i,station,new Vector3(i==0?-.29f:.29f,1.08f,0));if(i==1)secondMixer=mixer;
                RestaurantArt.Box("Mixer base",mixer,0,.09f,0,.46f,.18f,.55f,RestaurantArt.Hex("496F7A"));
                RestaurantArt.Shape("Pink jar",PrimitiveType.Cylinder,mixer,new Vector3(0,.41f,0),new Vector3(.32f,.23f,.32f),RestaurantArt.Hex("EBADB7"));
                RestaurantArt.Shape("Jar lid",PrimitiveType.Cylinder,mixer,new Vector3(0,.66f,0),new Vector3(.36f,.035f,.36f),RestaurantArt.Cream);
                whisks[i]=RestaurantArt.Box("Mixing indicator",mixer,0,.705f,0,.25f,.035f,.04f,RestaurantArt.Red).transform;
            }
            fryerLabel=RestaurantArt.Text("Fryer upgrade label","",world,new Vector3(5.2f,1.78f,1.7f),.075f,RestaurantArt.Gold);
            station.gameObject.SetActive(false);
        }
        public void Sync(Simulation sim)
        {
            station.gameObject.SetActive(sim.P.blender>0);secondMixer.gameObject.SetActive(sim.P.blender>1);
            bool mixing=sim.Customers.Any(c=>c.station=="blender"&&c.order=="cooking");
            foreach(var whisk in whisks)whisk.localRotation=Quaternion.Euler(0,mixing?sim.Time*420:0,0);
            fryerLabel.text=sim.P.fryer>1?"FRİTÖZ  "+sim.P.fryer:"";
            foreach(var table in sim.Tables) {
                var customer=sim.Customers.FirstOrDefault(c=>c.id==table.customer);
                meals[table.id].Set(customer?.product??"classic",customer!=null&&CustomerProfiles.Portions(customer)==2);
            }
        }
        public void Carry(RestaurantArt.Person person,string product,bool family=false)
        {
            if(!trays.TryGetValue(person.food,out var visual)){visual=new MealVisual(person.food);trays[person.food]=visual;}
            visual.Set(product,family);
        }
        sealed class MealVisual
        {
            readonly Transform[] original;
            readonly Transform burger,shake,doubleBurger;
            readonly Transform parent;
            // Build extra variants only when ordered, then reuse them on this table/tray.
            readonly Dictionary<string,Transform> variants=new Dictionary<string,Transform>();
            readonly Dictionary<string,Transform> familyServings=new Dictionary<string,Transform>();
            bool lastFamily;
            string last;
            public MealVisual(Transform parent)
            {
                this.parent=parent;
                original=parent.Cast<Transform>().Where(t=>t.name!="Tray"&&t.name!="Serving plate").ToArray();burger=parent.Find("Burger");
                doubleBurger=RestaurantArt.Group("Double burger",parent,Vector3.zero);
                RestaurantArt.Burger(doubleBurger,burger.localPosition,burger.localScale.x);
                var body=doubleBurger.Find("Burger");
                foreach(Transform part in body)if(part.name!="Bottom bun"&&part.name!="Patty")part.localPosition+=Vector3.up*.10f;
                RestaurantArt.Shape("Second patty",PrimitiveType.Cylinder,body,new Vector3(0,.245f,0),new Vector3(.44f,.04f,.44f),RestaurantArt.Brown);
                shake=RestaurantArt.Group("Strawberry milkshake",parent,new Vector3(0,.04f,0));
                RestaurantArt.Shape("Shake cup",PrimitiveType.Cylinder,shake,new Vector3(0,.22f,0),new Vector3(.29f,.22f,.29f),RestaurantArt.Hex("DF8F9F"));
                RestaurantArt.Shape("Cream swirl",PrimitiveType.Sphere,shake,new Vector3(0,.46f,0),new Vector3(.35f,.2f,.35f),RestaurantArt.Cream);
                RestaurantArt.Shape("Cherry",PrimitiveType.Sphere,shake,new Vector3(.05f,.575f,0),Vector3.one*.09f,RestaurantArt.Red);
                RestaurantArt.Box("Pink straw",shake,-.085f,.63f,.03f,.025f,.33f,.025f,RestaurantArt.Hex("AC435F"));
                Set("classic");
            }
            public void Set(string product,bool family=false)
            {
                if(last==product&&lastFamily==family)return;last=product;lastFamily=family;
                bool drink=product=="shake"||product=="chocolate";
                bool extra=product=="chicken"||product=="bbq"||product=="chocolate";
                if(extra&&!variants.ContainsKey(product))variants[product]=BuildVariant(product);
                foreach(var t in original)t.gameObject.SetActive(!drink);
                burger.gameObject.SetActive(!drink&&product!="double"&&!extra);
                shake.gameObject.SetActive(product=="shake");doubleBurger.gameObject.SetActive(product=="double");
                foreach(var entry in variants)entry.Value.gameObject.SetActive(entry.Key==product);
                if(family&&!drink&&!familyServings.ContainsKey(product)) {
                    var template=product=="double"?doubleBurger:extra?variants[product]:burger;
                    var second=Object.Instantiate(template.gameObject,parent).transform;second.name="Family serving "+product;
                    second.localPosition=template.localPosition+new Vector3(.21f,.01f,.17f);second.localScale=template.localScale*.65f;familyServings[product]=second;
                }
                foreach(var entry in familyServings)entry.Value.gameObject.SetActive(family&&!drink&&entry.Key==product);
            }
            Transform BuildVariant(string product)
            {
                if(product=="chocolate") {
                    var g=RestaurantArt.Group("Chocolate milkshake",parent,new Vector3(0,.04f,0));
                    RestaurantArt.Shape("Shake cup",PrimitiveType.Cylinder,g,new Vector3(0,.22f,0),new Vector3(.29f,.22f,.29f),RestaurantArt.Hex("986747"));
                    RestaurantArt.Shape("Cream swirl",PrimitiveType.Sphere,g,new Vector3(0,.46f,0),new Vector3(.35f,.2f,.35f),RestaurantArt.Cream);
                    for(int i=0;i<3;i++)RestaurantArt.Box("Chocolate drizzle",g,(i-1)*.08f,.545f,0,.03f,.02f,.22f,RestaurantArt.Brown);
                    var wafer=RestaurantArt.Box("Wafer",g,-.09f,.65f,.03f,.065f,.33f,.065f,RestaurantArt.Gold);wafer.transform.localEulerAngles=new Vector3(0,0,12);
                    RestaurantArt.Box("Chocolate straw",g,.09f,.63f,.02f,.025f,.33f,.025f,RestaurantArt.Brown);
                    return g;
                }
                var group=RestaurantArt.Group(product=="chicken"?"Chicken burger":"BBQ burger",parent,Vector3.zero);
                RestaurantArt.Burger(group,burger.localPosition,burger.localScale.x);
                var body=group.Find("Burger");
                if(product=="chicken") {
                    body.Find("Patty").GetComponent<Renderer>().sharedMaterial=RestaurantArt.Mat(RestaurantArt.Hex("D89F52"));
                    body.Find("Cheese").GetComponent<Renderer>().sharedMaterial=RestaurantArt.Mat(RestaurantArt.Cream);
                    for(int i=0;i<3;i++)RestaurantArt.Box("Grill mark",body,(i-1)*.10f,.203f,0,.025f,.009f,.32f,RestaurantArt.Brown);
                } else {
                    body.Find("Tomato").GetComponent<Renderer>().sharedMaterial=RestaurantArt.Mat(RestaurantArt.Hex("773721"));
                    body.Find("Top bun").GetComponent<Renderer>().sharedMaterial=RestaurantArt.Mat(RestaurantArt.Hex("CA7F34"));
                    for(int i=0;i<3;i++)RestaurantArt.Shape("Onion",PrimitiveType.Sphere,body,new Vector3((i-1)*.12f,.28f,.13f),new Vector3(.14f,.045f,.14f),RestaurantArt.Hex("E8CFB0"));
                }
                return group;
            }
        }
    }
}
