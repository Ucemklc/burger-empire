using BurgerEmpire.Core;
using UnityEngine;

namespace BurgerEmpire.Unity
{
    public sealed partial class RestaurantHud
    {
        float DrawServicePriority(float y)
        {
            var sim=game.Sim;
            Label(BranchCatalog.Name(sim.P.activeBranch)+" · Ekibin çalışma sırası",panel,12,y,panelWidth-24,62,22,ink,FontStyle.Bold);y+=72;
            Label("Aşçı hangi siparişi hazırlasın, garson hangisini önce götürsün? Bu şube için bir öncelik seç.",panel,12,y,panelWidth-24,86,17,muted);y+=98;
            for(int mode=0;mode<=2;mode++) {
                int selectedMode=mode;bool selected=sim.P.servicePriority==mode;
                var card=Card("Priority card "+mode,panel,0,y,panelWidth,232,RestaurantArt.Hex(selected?"DCE5DE":"ECECD8"));
                Label(ServicePriorityCatalog.Name(mode),card.transform,14,8,panelWidth-28,40,22,selected?green:ink,FontStyle.Bold);
                Label(ServicePriorityCatalog.Description(mode),card.transform,14,54,panelWidth-28,100,16,ink);
                var choose=Button(selected?"SEÇİLİ":"BU ÖNCELİĞİ SEÇ",card.transform,12,164,panelWidth-24,56,green,()=>game.ChooseServicePriority(selectedMode),16);
                choose.name="Choose priority "+mode;choose.interactable=!selected;y+=244;
            }
            Label("Ekip elindeki işi bitirir; yeni işte seçtiğin sırayı kullanır. Kasadaki ve araç penceresindeki müşteri sırası değişmez. Oyuncunun Hazırla ve Servis et düğmeleri de bu önceliği kullanır.",panel,12,y,panelWidth-24,154,16,muted);y+=166;
            Label("ŞİMDİKİ UYGUN SİPARİŞLER",panel,12,y,panelWidth-24,46,18,green,FontStyle.Bold);y+=54;
            Label(PriorityPreview("Hazırlık",sim.UpcomingPreparation)+"\n"+PriorityPreview("Servis",sim.UpcomingService),panel,12,y,panelWidth-24,100,16,ink);y+=112;
            Label("Ücretsizdir. Seçimin bu şubeye kaydedilir; diğer şubenin ayarı değişmez.",panel,12,y,panelWidth-24,70,16,muted);y+=82;
            Button("PERSONELE DÖN",panel,10,y,panelWidth-20,56,green,()=>OpenPanel("Personel"),16).name="Priority back";
            return y+68;
        }
        static string PriorityPreview(string action,Customer customer)
        {
            if(customer==null)return action+": Uygun sipariş yok";
            string channel=customer.drive?"Araç":customer.delivery?"Kurye":VipCatalog.IsVip(customer)?"VIP":customer.name;
            return action+": "+channel+" · "+customer.meal;
        }
    }
}
