using UnityEngine;

namespace BurgerEmpire.Unity
{
    public sealed partial class RestaurantHud
    {
        void BuildCameraControls(float header)
        {
            // Safe-area coordinates; every touch target is at least 48 logical pixels tall.
            float x=portrait?width-196:width-320,y=portrait?60:4;
            zoomOut=Button("−",root,x,y,48,48,cream,()=>game.CameraControls.ZoomStep(.8f),26);zoomOut.name="Camera zoom out";
            zoomIn=Button("+",root,x+54,y,48,48,cream,()=>game.CameraControls.ZoomStep(1.25f),26);zoomIn.name="Camera zoom in";
            var reset=Button("MERKEZ",root,x+108,y,76,48,green,()=>game.CameraControls.Reset(),12);reset.name="Camera reset";
            var title=reset.GetComponentInChildren<UnityEngine.UI.Text>();title.rectTransform.sizeDelta=new Vector2(66,27);
            cameraZoom=Label("1,0×",reset.transform,0,27,76,18,11,cream,FontStyle.Bold,TextAnchor.MiddleCenter);
        }
        void UpdateCameraControls()
        {
            cameraZoom.text=game.CameraControls.Zoom.ToString("0.0")+"×";
            zoomIn.interactable=!BlocksWorldInput&&game.CameraControls.Zoom<RestaurantCamera.MaxZoom-.001f;
            zoomOut.interactable=!BlocksWorldInput&&game.CameraControls.Zoom>RestaurantCamera.MinZoom+.001f;
        }
    }
}
