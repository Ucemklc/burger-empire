using System.Linq;
using BurgerEmpire.Core;
using UnityEngine;

namespace BurgerEmpire.Unity
{
    public sealed partial class RestaurantHud
    {
        bool ShowingShift=>tab=="Hedef Vardiya";
        string ShiftClock()
        {
            int seconds=Mathf.CeilToInt(ShiftProgress.Duration-game.Sim.P.shift.elapsed);
            return (seconds/60)+":"+(seconds%60).ToString("00");
        }
        void UpdateShiftHud()
        {
            var shift=game.Sim.P.shift;
            if(shift.pending&&!mainMenu&&!ShowingShift){game.Save();OpenPanel("Hedef Vardiya");}
        }
        void BeginTargetShift()
        {
            if(game.SaveBlocked)return;
            if(!game.Sim.StartShift(out string reason)){Toast(reason);RefreshPanel();return;}
            game.Save();resumeAfterModal=true;ClosePanel();Toast(reason,"upgrade");
        }
        void LeaveShiftResult()
        {
            game.Sim.AcknowledgeShift();game.Save();resumeAfterModal=true;ClosePanel();
        }
        float DrawShift(float y)
        {
            var shift=game.Sim.P.shift;
            y=GuideText(BranchCatalog.Name(game.Sim.P.activeBranch)+" · "+(shift.number>0?"Vardiya "+shift.number:"Hedef Vardiya"),y,22,green,true);
            if(shift.active) {
                y=GuideText("Kalan süre: "+ShiftClock(),y,22,ink,true);
                y=GuideText("Tamamlanan ödeme: "+shift.served+" / "+shift.target,y,20,ink);
                y=GuideText("Hedef süre içinde müşteri ödemelerini tamamla. Salon, araç ve kurye satışları sayılır.",y,16,muted);
                y=GuideText("Menülerde ve diğer şubedeyken süre bekler. Oyunu yeniden açınca kalan süre ve sonuçların korunur; açık siparişler sıfırlanır.",y,16,muted);
                Button("VARDİYAYA DÖN",panel,10,y+8,panelWidth-20,56,green,ClosePanel,17).name="Shift resume";return y+76;
            }
            if(shift.finished) {
                y=GuideText(shift.Success?"HEDEF TAMAMLANDI!":"BİR SONRAKİ VARDİYADA TEKRAR DENE",y,22,shift.Success?green:red,true);
                y=GuideText("Tamamlanan ödeme: "+shift.served+" / "+shift.target,y,19,ink);
                y=GuideText("Ayrılan müşteri: "+shift.lost,y,18,ink);
                y=GuideText("Servisten kazanılan: "+shift.earned+" coin",y,20,green,true);
                y=GuideText(shift.reviews>0?"Vardiya puanı: "+shift.Rating.ToString("0.0",Localization.Culture)+" / 5":"Bu vardiyada henüz değerlendirme yok.",y,18,ink);
                y=GuideText("Bu gelir servis sırasında bakiyene eklendi. Sonuç ekranı tekrar coin vermez.",y,15,muted);
                var step=GrowthGuide.Steps(game.Sim).FirstOrDefault(s=>!s.complete);
                if(step!=null)y=GuideText("Sıradaki öneri: "+step.title,y+8,17,green,true);
                if(shift.pending) {
                    Button("SONUCU KAPAT VE DEVAM ET",panel,10,y+10,panelWidth-20,56,green,LeaveShiftResult,16).name="Shift finish";return y+78;
                }
            }
            if(game.Sim.TutorialActive)return GuideText("Önce ilk vardiya rehberini tamamla.",y+8,17,muted);
            y=GuideText("3 dakikalık hedef: "+game.Sim.NextShiftTarget+" müşteri ödemesini tamamla.",y+12,20,ink,true);
            y=GuideText("Hedef vardiya isteğe bağlıdır. Süre yalnız restoranı oynarken ilerler; bittiğinde sonuç ekranı açılır. Ek ceza veya giriş ücreti yoktur.",y,16,muted);
            Button("HEDEF VARDİYAYI BAŞLAT",panel,10,y+8,panelWidth-20,56,red,BeginTargetShift,17).name="Shift start";
            return y+76;
        }
    }
}
