using System.Collections.Generic;
using UnityEngine;

namespace BurgerEmpire.Unity
{
    // Shared geometry: rounded silhouettes without a unique mesh per chair or character.
    public static class StyleGeometry
    {
        static Mesh softBox,cup;
        static readonly HashSet<string> rounded=new HashSet<string>{
            "Oak top","Seat cushion","Seat back","Chair seat","Chair back","Desk oak top",
            "Counter top","Steel top","Tray","Pickup tray","Assembly board","Ingredient tray",
            "Cash register","Register screen","Computer monitor","Order screen","Milkshake cabinet",
            "Mixer base","Cap brim","Shoe","Apron","Apron pocket","Delivery backpack","Helmet visor",
            "Napkin holder","Bag","Fries carton","Fries","Menu fries","Golden fries"};
        public static bool Rounded(string name){return rounded.Contains(name);}
        public static Mesh SoftBox
        {
            get {
                if(softBox)return softBox;
                var vertices=new List<Vector3>();var normals=new List<Vector3>();var triangles=new List<int>();
                var directions=new[]{Vector3.right,Vector3.left,Vector3.up,Vector3.down,Vector3.forward,Vector3.back};
                float[] grid={-.5f,-.39f,.39f,.5f};
                foreach(var normal in directions) {
                    var up=Mathf.Abs(normal.y)>.5f?Vector3.forward:Vector3.up;var right=Vector3.Cross(up,normal);int start=vertices.Count;
                    for(int y=0;y<4;y++)for(int x=0;x<4;x++) {
                        var p=normal*.5f+right*grid[x]+up*grid[y];
                        var core=new Vector3(Mathf.Clamp(p.x,-.39f,.39f),Mathf.Clamp(p.y,-.39f,.39f),Mathf.Clamp(p.z,-.39f,.39f));
                        var n=(p-core).normalized;vertices.Add(core+n*.11f);normals.Add(n);
                    }
                    for(int y=0;y<3;y++)for(int x=0;x<3;x++) {
                        int a=start+y*4+x;triangles.AddRange(new[]{a,a+1,a+4,a+1,a+5,a+4});
                    }
                }
                softBox=new Mesh{name="BE_SharedSoftBox"};softBox.SetVertices(vertices);softBox.SetNormals(normals);softBox.SetTriangles(triangles,0);softBox.RecalculateBounds();
                return softBox;
            }
        }
        public static Mesh Cup
        {
            get {
                if(cup)return cup;
                var vertices=new List<Vector3>();var normals=new List<Vector3>();var triangles=new List<int>();const int count=20;
                for(int ring=0;ring<2;ring++)for(int i=0;i<=count;i++) {
                    float a=i*Mathf.PI*2/count;var direction=new Vector3(Mathf.Cos(a),0,Mathf.Sin(a));
                    vertices.Add(direction*(ring==0?.36f:.5f)+Vector3.up*(ring==0?-1:1));normals.Add((direction-Vector3.up*.07f).normalized);
                }
                for(int i=0;i<count;i++) {int t=i+count+1;triangles.AddRange(new[]{i,t,i+1,i+1,t,t+1});}
                for(int side=0;side<2;side++) {
                    int center=vertices.Count;var n=side==0?Vector3.down:Vector3.up;
                    vertices.Add(n);normals.Add(n);
                    for(int i=0;i<count;i++){float a=i*Mathf.PI*2/count;vertices.Add(new Vector3(Mathf.Cos(a)*(side==0?.36f:.5f),side==0?-1:1,Mathf.Sin(a)*(side==0?.36f:.5f)));normals.Add(n);}
                    for(int i=0;i<count;i++){int a=center+1+i,b=center+1+(i+1)%count;triangles.AddRange(side==0?new[]{center,a,b}:new[]{center,b,a});}
                }
                cup=new Mesh{name="BE_SharedTaperedCup"};cup.SetVertices(vertices);cup.SetNormals(normals);cup.SetTriangles(triangles,0);cup.RecalculateBounds();return cup;
            }
        }
        public static void Apply(Transform root)
        {
            foreach(var filter in root.GetComponentsInChildren<MeshFilter>(true)) {
                if(Rounded(filter.name))filter.sharedMesh=SoftBox;
                else if(filter.name=="Red cup"||filter.name=="Shake cup")filter.sharedMesh=Cup;
            }
        }
    }
}
