using UnityEngine;

namespace BurgerEmpire.Unity
{
    public sealed partial class RestaurantHud
    {
        float DrawManagement(float y)
        {
            navigation.Clear();
            y=HomeButton("HEDEF VARDİYA","Management shift","Hedef Vardiya",y);
            string[] destinations={"Restoran","Geliştir","Personel","Menü","Görevler","Ayarlar"};
            float cell=(panelWidth-32)/2;
            for(int i=0;i<destinations.Length;i++) {
                string destination=destinations[i];
                var button=Button(destination,panel,10+(i%2)*(cell+12),y+(i/2)*76,cell,64,
                    RestaurantArt.Hex("E4E8D4"),()=>OpenPanel(destination),18);
                button.name="Management "+destination;navigation[destination]=button;
            }
            y+=228;
            y=HomeButton("GELİŞİM REHBERİ","Management guide","Gelişim Rehberi",y);
            y=HomeButton("NASIL OYNANIR?","Management help","Yardım",y);
            Button("ANA MENÜ",panel,10,y,panelWidth-20,56,green,OpenMainMenu,17).name="Management home";
            return y+68;
        }
    }
}
