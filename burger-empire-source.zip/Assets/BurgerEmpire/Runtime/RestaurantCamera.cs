using BurgerEmpire.Core;
using UnityEngine;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

namespace BurgerEmpire.Unity
{
    // Presentation only: viewing the restaurant never changes saved progress or game time.
    public sealed class RestaurantCamera
    {
        public const float MinZoom=1,MaxZoom=2.5f;
        public float Zoom { get; private set; }=1;
        public Vector3 Pan { get; private set; }
        readonly BurgerEmpireGame game;
        readonly int[] touchIds=new int[10];
        readonly bool[] eligible=new bool[10];
        Simulation simulation;
        int branch=-1;
        bool layout,drive,delivery,framed,suppressTouch,cancelUntilRelease,pinching,mouseDragging;
        Rect viewport;
        Vector3 offset;
        float baseSize=8.3f,previousDistance,lastTouch=-10;
        Vector2 previousCenter,mousePosition;
        int firstId,secondId;
        Camera Camera=>game.GameCamera;
        public RestaurantCamera(BurgerEmpireGame owner){game=owner;}

        public void Sync()
        {
            bool nextLayout=game.LayoutEditor.Active;
            bool nextDrive=game.Sim.P.driveThru>0&&!nextLayout,nextDelivery=game.Sim.P.delivery>0&&!nextLayout;
            bool changed=!framed||simulation!=game.Sim||branch!=game.Sim.BranchRevision||layout!=nextLayout||drive!=nextDrive||delivery!=nextDelivery||viewport!=Camera.pixelRect;
            simulation=game.Sim;branch=game.Sim.BranchRevision;layout=nextLayout;drive=nextDrive;delivery=nextDelivery;viewport=Camera.pixelRect;framed=true;
            offset=(drive?new Vector3(0,0,1.5f):Vector3.zero)+(delivery?new Vector3(.9f,0,0):Vector3.zero)+new Vector3(-.7f,.7f,-.15f);
            baseSize=drive||delivery?Mathf.Max(8.4f,11.0f/Camera.aspect):Mathf.Max(7.7f,10.0f/Camera.aspect);
            if(changed)Reset();else Apply();
        }
        void Apply()
        {
            Camera.transform.position=new Vector3(18,17,21)+offset+Pan;
            Camera.transform.LookAt(new Vector3(4.8f,.3f,4.3f)+offset+Pan);
            Camera.orthographicSize=baseSize/Zoom;
        }
        public void CancelGesture(){suppressTouch=true;cancelUntilRelease=true;pinching=false;mouseDragging=false;}
        public void Reset(){Zoom=1;Pan=Vector3.zero;CancelGesture();Apply();}
        public void ZoomStep(float factor)
        {
            if(game.Hud.BlocksWorldInput)return;
            TransformView(Camera.pixelRect.center,Camera.pixelRect.center,factor);
        }
        bool WorldPoint(Vector2 screen,out Vector3 point)
        {
            var ray=Camera.ScreenPointToRay(screen);
            if(new Plane(Vector3.up,new Vector3(0,.25f,0)).Raycast(ray,out float distance)){point=ray.GetPoint(distance);return true;}
            point=Vector3.zero;return false;
        }
        void TransformView(Vector2 from,Vector2 to,float factor)
        {
            if(!WorldPoint(from,out var anchor))return;
            Zoom=Mathf.Clamp(Zoom*factor,MinZoom,MaxZoom);Apply();
            if(WorldPoint(to,out var after)) {
                var pan=Pan+anchor-after;float limit=1.5f+3*(1-1/Zoom);
                Pan=new Vector3(Mathf.Clamp(pan.x,-limit,limit),0,Mathf.Clamp(pan.z,-limit,limit));
            }
            Apply();
        }
        bool CanStart(Vector2 p)=>Camera.pixelRect.Contains(p)&&!game.PointerOnUI(p);

        // Keep ownership until ALL fingers lift, including the primary-touch release frame.
        public bool HandleInput()
        {
            bool blocked=game.Hud.BlocksWorldInput;
            if(blocked)CancelGesture();
            bool consumed=suppressTouch;
#if ENABLE_INPUT_SYSTEM
            int count=0,a=-1,b=-1;
            var screen=Touchscreen.current;
            if(screen!=null)for(int i=0;i<screen.touches.Count&&i<touchIds.Length;i++) {
                var t=screen.touches[i];
                if(!t.press.isPressed){touchIds[i]=0;eligible[i]=false;continue;}
                int id=t.touchId.ReadValue();
                if(touchIds[i]!=id||t.phase.ReadValue()==UnityEngine.InputSystem.TouchPhase.Began) {
                    touchIds[i]=id;eligible[i]=!blocked&&CanStart(t.position.ReadValue());
                }
                if(count==0)a=i;else if(count==1)b=i;count++;
            }
            if(count>0)lastTouch=Time.unscaledTime;
            if(count>=2){suppressTouch=true;consumed=true;}
            if(!blocked&&!cancelUntilRelease&&count==2&&eligible[a]&&eligible[b]) {
                Vector2 p=screen.touches[a].position.ReadValue(),q=screen.touches[b].position.ReadValue();
                Vector2 center=(p+q)*.5f;float distance=Vector2.Distance(p,q);
                if(pinching&&firstId==touchIds[a]&&secondId==touchIds[b]&&previousDistance>10&&distance>10)
                    TransformView(previousCenter,center,distance/previousDistance);
                previousCenter=center;previousDistance=distance;firstId=touchIds[a];secondId=touchIds[b];pinching=true;
            } else pinching=false;
            if(count==0){suppressTouch=false;cancelUntilRelease=false;}
            var mouse=Mouse.current;
            if(blocked||count>0||Time.unscaledTime-lastTouch<.25f)mouseDragging=false;
            else if(mouse!=null) {
                Vector2 position=mouse.position.ReadValue();
                float wheel=mouse.scroll.ReadValue().y;
                if(wheel!=0&&CanStart(position))TransformView(position,position,Mathf.Exp(Mathf.Clamp(wheel*.0015f,-.5f,.5f)));
                if(mouse.rightButton.wasPressedThisFrame||mouse.middleButton.wasPressedThisFrame) {
                    mouseDragging=CanStart(position);mousePosition=position;
                }
                if(mouseDragging) {
                    consumed=true;
                    if(mouse.rightButton.isPressed||mouse.middleButton.isPressed){TransformView(mousePosition,position,1);mousePosition=position;}
                    else mouseDragging=false;
                }
            }
#else
            suppressTouch=false;
#endif
            return consumed||blocked;
        }
    }
}
