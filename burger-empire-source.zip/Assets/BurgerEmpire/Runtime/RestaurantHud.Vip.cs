using System.Linq;
using BurgerEmpire.Core;
using UnityEngine;

namespace BurgerEmpire.Unity
{
    public sealed partial class RestaurantHud
    {
        float DrawVip(float y)
        {
            var p=game.Sim.P;int chance=VipCatalog.Chance(p);
            Label(BranchCatalog.Name(p.activeBranch)+" · Özel misafirler",panel,10,y,panelWidth-20,60,23,ink,FontStyle.Bold);y+=68;
            var summary=Card("VIP summary",panel,0,y,panelWidth,174,RestaurantArt.Hex("F4E4BA"));
            Label(chance>0?"VIP ŞANSI  %"+chance:"VIP ZİYARETLERİ KİLİTLİ",summary.transform,14,8,panelWidth-28,45,24,ink,FontStyle.Bold);
            Label(VipCatalog.LockReason(p),summary.transform,14,60,panelWidth-28,65,17,ink);
            Label("Popülerlik "+p.popularity+" / 100",summary.transform,14,130,panelWidth-28,28,15,green,FontStyle.Bold);y+=186;
            Label("YÜKSEK HESAP, HIZLI SERVİS",panel,12,y,panelWidth-24,40,20,green,FontStyle.Bold);y+=48;
            Label("VIP misafirler aynı menüye %50 fazla öder. Bahşiş, yoğunluk ve müdür bonusu ayrıca eklenir. Ücret yalnızca ödeme alındığında kasaya girer.",panel,12,y,panelWidth-24,120,17,ink);y+=132;
            Label("Bekleme sabrı: "+VipCatalog.Patience(p)+" saniye"+(p.decor>0?" · Dekor dahil":" · Dekor +25 saniye sağlar"),panel,12,y,panelWidth-24,64,18,green,FontStyle.Bold);y+=76;
            Label("Süre, sipariş kuyruğunda, masaya yürürken ve yemek beklerken azalır. Temiz masa, hazır mutfak ve hızlı servis ekibi önemlidir.",panel,12,y,panelWidth-24,112,16,muted);y+=124;
            int present=game.Sim.Customers.Count(c=>VipCatalog.IsVip(c)&&c.phase!="leaving");
            var stats=Card("VIP stats",panel,0,y,panelWidth,166,RestaurantArt.Hex("DCE5DE"));
            Label("BU ŞUBENİN VIP ZİYARETLERİ",stats.transform,14,8,panelWidth-28,36,19,green,FontStyle.Bold);
            Label("Şimdi içeride: "+present+"  ·  Toplam gelen: "+p.vipArrived+"\nServis edilen: "+p.vipServed+"  ·  Ayrılan: "+p.vipLost+"\nVIP geliri: "+p.vipEarned.ToString("N0")+" coin",stats.transform,14,54,panelWidth-28,98,17,ink);y+=178;
            Label("VIP MENÜ FİYATLARI",panel,12,y,panelWidth-24,35,19,green,FontStyle.Bold);y+=43;
            foreach(var r in MenuCatalog.All(p).Where(r=>r.available)) {
                Label(r.name+"\n"+r.price+" coin → VIP "+VipCatalog.Price(r.price)+" coin",panel,14,y,panelWidth-28,65,17,ink);y+=77;
            }
            Label("Popülerlik 50'de olasılık %2, 100'de %8 olur. İlk müşteri daima müdavimdir. Puan 50'nin altına düşerse yeni VIP gelişi durur; içerideki misafirin fiyatı ve sabrı değişmez.",panel,12,y,panelWidth-24,144,16,muted);y+=156;
            Label("VIP'ler salonda normal masa kullanır; altın sipariş balonu, koyu takım ve altın kravatla ayırt edilir. Yorumları ve popülerlik etkileri diğer salon müşterileri gibi hesaplanır. Her şubenin sayacı ayrıdır.",panel,12,y,panelWidth-24,144,16,muted);y+=156;
            Button("POPÜLERLİĞİ GÖR",panel,10,y,panelWidth-20,56,green,()=>OpenPanel("Popülerlik"),16).name="VIP popularity";y+=68;
            Button("MÜŞTERİ YORUMLARINI GÖR",panel,10,y,panelWidth-20,56,green,()=>OpenPanel("Müşteri yorumları"),16).name="VIP reviews";y+=68;
            Button("RESTORANA DÖN",panel,10,y,panelWidth-20,56,green,()=>OpenPanel("Restoran"),16).name="VIP back";return y+68;
        }
    }
}
