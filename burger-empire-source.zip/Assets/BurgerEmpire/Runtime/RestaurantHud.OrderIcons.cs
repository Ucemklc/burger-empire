using System.Collections.Generic;
using System.Linq;
using BurgerEmpire.Core;
using UnityEngine;
using UnityEngine.UI;

namespace BurgerEmpire.Unity
{
    public sealed partial class RestaurantHud
    {
        sealed class OrderBubbleView
        {
            public RectTransform root;
            public Image fill,track,connector;
            public FoodIconGraphic[] food;
            public FoodIconGraphic status,emotion,badge,coin;
        }
        readonly Dictionary<int,OrderBubbleView> iconBubbles=new Dictionary<int,OrderBubbleView>();
        readonly List<Rect> placedBubbles=new List<Rect>();
        FoodIconGraphic Icon(string name,Transform parent,float x,float y,float w,float h,string kind)
        {
            var icon=Box(name,parent,x,y,w,h).gameObject.AddComponent<FoodIconGraphic>();icon.raycastTarget=false;icon.Set(kind);return icon;
        }
        OrderBubbleView BuildOrderBubble(Customer c)
        {
            bool vip=VipCatalog.IsVip(c);
            var connector=Card("Order connector",bubbles,0,0,1,2,vip?RestaurantArt.Gold:green,false);
            connector.rectTransform.pivot=new Vector2(.5f,.5f);
            var bg=Card(vip?"VIP order":"Order",bubbles,0,0,64,29,vip?RestaurantArt.Hex("FFE7A3"):cream);
            var b=new OrderBubbleView{root=bg.rectTransform,food=new FoodIconGraphic[3],connector=connector};
            for(int i=0;i<3;i++)b.food[i]=Icon("Food item "+i,b.root,3+i*15,2,14,15,"burger");
            b.status=Icon("Order status",b.root,50,3,12,12,"clock");
            b.track=Card("Patience track",b.root,3,23,45,2,RestaurantArt.Hex("D5D4BE"));
            b.fill=Card("Patience",b.root,3,23,45,2,green);
            b.emotion=Icon("Emotion",b.root,52,18,10,10,"face");
            b.badge=Icon("Guest badge",b.root,-2,-5,10,10,vip?"crown":c.drive?"car":"bag");
            b.badge.gameObject.SetActive(vip||c.drive||c.delivery);
            b.coin=Icon("Payment coin",b.root,3,3,14,14,"coin");b.coin.gameObject.SetActive(false);
            customerBubbles[c.id]=b.root;iconBubbles[c.id]=b;return b;
        }
        void UpdateBubbles(Snapshot s)
        {
            placedBubbles.Clear();
            foreach(var c in s.customers.OrderByDescending(c=>c.z)) {
                if(!iconBubbles.TryGetValue(c.id,out var b))b=BuildOrderBubble(c);
                bool payment=c.phase=="payment";
                Vector3 screen=game.GameCamera.WorldToScreenPoint(new Vector3(c.x,c.drive?1.6f:2.05f,c.z));
                bool visible=!BlocksWorldInput&&(OrderSignals.ShowOrder(c)||payment)&&game.GameCamera.pixelRect.Contains(screen);
                b.root.gameObject.SetActive(visible);b.connector.gameObject.SetActive(visible);if(!visible)continue;
                var items=OrderSignals.Items(c.product);
                // These are passive indicators, not touch targets: keep the restaurant visible.
                float w=payment?20:19+items.Length*15,h=payment?20:29;
                b.root.sizeDelta=new Vector2(w,h);
                for(int i=0;i<3;i++) {
                    b.food[i].gameObject.SetActive(!payment&&i<items.Length);
                    if(i<items.Length){b.food[i].Set(items[i]);b.food[i].rectTransform.anchoredPosition=new Vector2(3+i*15,-2);}
                }
                b.coin.gameObject.SetActive(payment);b.fill.gameObject.SetActive(!payment);b.track.gameObject.SetActive(!payment);
                b.status.gameObject.SetActive(!payment);b.emotion.gameObject.SetActive(!payment);b.badge.gameObject.SetActive(!payment&&(VipCatalog.IsVip(c)||c.drive||c.delivery));
                if(!payment) {
                    b.status.rectTransform.anchoredPosition=new Vector2(w-14,-3);
                    b.emotion.rectTransform.anchoredPosition=new Vector2(w-12,-18);
                    b.track.rectTransform.sizeDelta=new Vector2(w-19,2);
                    string state=OrderSignals.Status(c);b.status.Set(state);b.status.rectTransform.localRotation=Quaternion.Euler(0,0,state=="spinner"?-s.time*170:0);
                    float amount=OrderSignals.Patience(c);b.fill.rectTransform.sizeDelta=new Vector2((w-19)*amount,2);b.fill.color=amount<.25f?red:amount<.55f?RestaurantArt.Gold:green;
                    b.emotion.Set("face",OrderSignals.Emotion(c));
                }
                var view=game.GameCamera.pixelRect;
                float minX=(view.xMin-safeArea.x)/scaleFactor+5,maxX=(view.xMax-safeArea.x)/scaleFactor-w-5;
                float minY=(safeArea.yMax-view.yMax)/scaleFactor+6,maxY=(safeArea.yMax-view.yMin)/scaleFactor-h-2;
                float x=Mathf.Clamp((screen.x-safeArea.x)/scaleFactor-w/2,minX,Mathf.Max(minX,maxX));
                float y=Mathf.Clamp((safeArea.yMax-screen.y)/scaleFactor-h-2,minY,Mathf.Max(minY,maxY));
                var area=new Rect(x,y,w,h);
                // Search nearby rows and columns; a leader keeps displaced cards tied to their guest.
                if(placedBubbles.Any(p=>p.Overlaps(area))) {
                    float best=float.PositiveInfinity;
                    for(int row=-3;row<=3;row++)for(int col=-3;col<=3;col++) {
                        var candidate=new Rect(Mathf.Clamp(x+col*(w+3),minX,Mathf.Max(minX,maxX)),Mathf.Clamp(y+row*(h+3),minY,Mathf.Max(minY,maxY)),w,h);
                        if(placedBubbles.Any(p=>p.Overlaps(candidate)))continue;
                        float distance=(candidate.position-new Vector2(x,y)).sqrMagnitude;
                        if(distance<best){best=distance;area=candidate;}
                    }
                }
                b.root.anchoredPosition=new Vector2(area.x,-area.y);placedBubbles.Add(area);
                var head=new Vector2((screen.x-safeArea.x)/scaleFactor,(safeArea.yMax-screen.y)/scaleFactor);
                var edge=new Vector2(Mathf.Clamp(head.x,area.xMin+5,area.xMax-5),Mathf.Clamp(head.y,area.yMin+5,area.yMax-5));
                var delta=head-edge;var line=b.connector.rectTransform;
                line.anchoredPosition=new Vector2((edge.x+head.x)/2,-(edge.y+head.y)/2);line.sizeDelta=new Vector2(delta.magnitude,.7f);
                line.localRotation=Quaternion.Euler(0,0,Mathf.Atan2(-delta.y,delta.x)*Mathf.Rad2Deg);
            }
            expired.Clear();foreach(int id in customerBubbles.Keys)if(!s.customers.Any(c=>c.id==id))expired.Add(id);
            foreach(int id in expired){Destroy(iconBubbles[id].connector.gameObject);Destroy(customerBubbles[id].gameObject);customerBubbles.Remove(id);iconBubbles.Remove(id);}
        }
    }
}
