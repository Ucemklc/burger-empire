#if UNITY_EDITOR
using System;
using BurgerEmpire.Core;

namespace BurgerEmpire.Unity
{
    // Entire provider and test wallet are excluded from Android/player assemblies.
    public sealed class RewardedAdsTest : IDisposable
    {
        sealed class ManualProvider : IRewardedAdProvider
        {
            public bool Ready=true;
            Action<RewardedAdSignal> callback;
            public bool IsReady=>Ready;
            public void Show(Action<RewardedAdSignal> value){callback=value;}
            public void Dismiss(){callback=null;}
            public void Send(RewardedAdSignal signal){callback?.Invoke(signal);}
        }
        readonly ManualProvider provider=new ManualProvider();
        public RewardedAdFlow Flow {get;}
        public int Coins {get;private set;}
        public bool Available=>provider.Ready;
        public RewardedAdsTest(){Flow=new RewardedAdFlow(provider,(id,amount)=>Coins=checked(Coins+amount));}
        public void ToggleAvailability(){if(!Flow.Busy){provider.Ready=!provider.Ready;Flow.RefreshAvailability();}}
        public void Complete(){provider.Send(RewardedAdSignal.Earned);provider.Send(RewardedAdSignal.Closed);}
        public void CloseEarly(){provider.Send(RewardedAdSignal.Closed);}
        public void Fail(){provider.Send(RewardedAdSignal.Failed);}
        public void Dispose(){Flow.Dispose();}
    }
}
#endif
