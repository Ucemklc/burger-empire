using System.Linq;
using BurgerEmpire.Core;
using UnityEngine;

namespace BurgerEmpire.Unity
{
    public sealed partial class RestaurantHud
    {
        float DrawReviews(float y)
        {
            var p=game.Sim.P;
            Label(BranchCatalog.Name(p.activeBranch)+" · Müşteri yorumları",panel,10,y,panelWidth-20,60,23,ink,FontStyle.Bold);y+=68;
            var summary=Card("Review summary",panel,0,y,panelWidth,116,RestaurantArt.Hex("DCE5DE"));
            Label(game.Sim.Rating.ToString("0.0")+" ★",summary.transform,14,5,100,52,32,green,FontStyle.Bold);
            Label("GENEL PUAN\nGeçmiş ziyaretler dahil",summary.transform,120,8,panelWidth-134,48,14,green,FontStyle.Bold);
            Label("Yeni yorumlar: "+p.reviews.Count+" / "+ReviewCatalog.Capacity+"  ·  En yeni yorum üstte",summary.transform,14,65,panelWidth-28,44,15,ink);y+=128;
            var daily=game.Sim.Missions().First(m=>m.id=="dailyReview");y=DrawMission(daily,y);
            y=DrawRatingCategories(y);
            if(p.reviews.Count==0) {
                Label("İlk yorumunu bekliyorsun",panel,12,y,panelWidth-24,42,22,ink,FontStyle.Bold);y+=50;
                Label("Müşteriler ödeme sonrası veya beklemekten vazgeçtiğinde yorum bırakır. Eski ziyaretlerin puanı korunur; yorum geçmişi bu güncellemeyle başlar.",panel,12,y,panelWidth-24,126,17,muted);y+=138;
            } else {
                var latest=p.reviews[p.reviews.Count-1];
                Label("SON YORUMUN ÖNERİSİ",panel,12,y,panelWidth-24,30,14,green,FontStyle.Bold);y+=34;
                Label(ReviewCatalog.Advice(latest),panel,12,y,panelWidth-24,88,17,ink);y+=96;
                foreach(var review in p.reviews.AsEnumerable().Reverse()) {
                    var card=Card("Review "+review.id,panel,0,y,panelWidth,350,cream);
                    Card("Review accent",card.transform,0,0,5,350,review.stars>=4?green:red,false);
                    Label(review.stars.ToString("0.0")+" ★",card.transform,14,8,82,38,23,review.stars>=4?green:red,FontStyle.Bold);
                    Label(review.name+" · "+ReviewCatalog.Type(review.kind),card.transform,100,8,panelWidth-114,40,15,ink,FontStyle.Bold);
                    Label(ReviewCatalog.Channel(review.channel)+" · "+MenuCatalog.Get(review.product,p).name,card.transform,14,52,panelWidth-28,40,14,muted);
                    Label(ReviewCatalog.Comment(review),card.transform,14,98,panelWidth-28,84,18,ink);
                    Label("Kalan sabır %"+review.patience+"  ·  Temizlik %"+review.cleanliness+"\n"+(review.completed?review.paid+" coin ödeme · Tamamlandı":"Sipariş tamamlanmadı")+"\n"+PopularityCatalog.Effect(review),card.transform,14,188,panelWidth-28,88,14,green);
                    Label(ReviewScores(review),card.transform,14,280,panelWidth-28,64,14,ink);y+=362;
                }
            }
            Label("Yeni genel puan lezzet, hız, temizlik, fiyat ve hizmetten oluşur. Lezzet hazır yemeğin beklemesini, hizmet ödeme bekleyişini ölçer. Her şubenin yorumları ayrıdır.",panel,12,y,panelWidth-24,126,15,muted);return y+138;
        }
    }
}
