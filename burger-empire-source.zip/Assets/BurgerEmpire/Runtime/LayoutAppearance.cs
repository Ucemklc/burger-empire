using System.Collections.Generic;
using BurgerEmpire.Core;
using UnityEngine;

namespace BurgerEmpire.Unity
{
    public sealed class LayoutAppearance
    {
        readonly Transform[] tables=new Transform[4],plants=new Transform[3],pads=new Transform[4];
        readonly List<Renderer> floor=new List<Renderer>(),walls=new List<Renderer>(),seats=new List<Renderer>(),tops=new List<Renderer>(),joints=new List<Renderer>();
        readonly Transform outline;
        readonly Transform[] edges=new Transform[4];
        readonly Transform[] decorPads=new Transform[2];
        int lastFloor=-1,lastWall=-1,lastFurniture=-1;
        public LayoutAppearance(Transform world)
        {
            for(int i=0;i<4;i++){tables[i]=world.Find("Table_"+i);pads[i]=world.Find("TablePad_"+i);}
            foreach(Transform t in world)if(t.name=="Plant"&&t.localPosition.z>4)plants[0]=t;
            var extra=world.Find("ExtraDecor");if(extra)for(int i=0;i<2;i++)plants[i+1]=extra.GetChild(i);
            foreach(var r in world.GetComponentsInChildren<Renderer>(true)) {
                if(r.name=="Floor tile")floor.Add(r);
                if(r.name=="Back wall"||r.name=="Side wall")walls.Add(r);
                if(r.name=="Seat cushion"||r.name=="Seat back")seats.Add(r);
                if(r.name=="Oak top")tops.Add(r);
                if(r.name=="Wood joint")joints.Add(r);
            }
            outline=RestaurantArt.Group("Layout selection",world,Vector3.zero);
            for(int i=0;i<4;i++)edges[i]=RestaurantArt.Box("Outline",outline,0,0,0,1,.04f,.04f,RestaurantArt.Green).transform;
            outline.gameObject.SetActive(false);
            for(int i=0;i<2;i++) {
                var pad=RestaurantArt.Group("Reserved decor "+i,world,Vector3.zero);decorPads[i]=pad;
                RestaurantArt.Box("Plant space",pad,0,0,0,.78f,.018f,.78f,RestaurantArt.Hex("ACC4AB"));
                RestaurantArt.Text("Plant label","DEKOR",pad,new Vector3(0,.018f,0),.10f,RestaurantArt.Hex("426C54"),true);
                pad.gameObject.SetActive(false);
            }
        }
        public void Apply(RestaurantLayout layout,RestaurantLayoutEditor editor)
        {
            for(int i=0;i<4;i++) {
                Point p=layout.tables[i];if(tables[i])tables[i].localPosition=new Vector3(p.x,.25f,p.z);
                if(pads[i])pads[i].localPosition=new Vector3(p.x,.26f,p.z);
            }
            for(int i=0;i<3;i++){Point p=layout.plants[i];if(plants[i])plants[i].localPosition=new Vector3(p.x,.25f,p.z);}
            for(int i=0;i<2;i++) {
                Point p=layout.plants[i+1];decorPads[i].localPosition=new Vector3(p.x,.275f,p.z);
                decorPads[i].gameObject.SetActive(editor.Active&&!editor.Owned(i+5));
            }
            if(lastFloor!=layout.floor) {
                string[] light={"E9DECA","D7E6DA","CBD1D5"},dark={"D7C8AC","A8C9BB","8D9DA7"};
                foreach(var r in floor){var p=r.transform.localPosition;bool even=((int)p.x+(int)p.z)%2==0;r.sharedMaterial=RestaurantArt.Mat(RestaurantArt.Hex(even?light[layout.floor]:dark[layout.floor]));}
                lastFloor=layout.floor;
            }
            if(lastWall!=layout.wall){Paint(walls,new[]{"FFF1D4","BBD4C8","EDC5B5"}[layout.wall]);lastWall=layout.wall;}
            if(lastFurniture!=layout.furniture) {
                Paint(seats,new[]{"D8442D","496F7A","547457"}[layout.furniture]);
                Paint(tops,new[]{"DCA66C","75523D","E6E1D4"}[layout.furniture]);
                Paint(joints,new[]{"C9935E","604535","C9C7BC"}[layout.furniture]);lastFurniture=layout.furniture;
            }
            outline.gameObject.SetActive(editor.Active);
            if(editor.Active) {
                Point p=editor.SelectedPosition;bool table=editor.Selected<4;float w=table?1.96f:1.1f,d=table?2.54f:1.1f;
                outline.localPosition=new Vector3(p.x,.3f,p.z);
                for(int i=0;i<4;i++) {
                    bool horizontal=i<2;edges[i].localPosition=horizontal?new Vector3(0,0,(i==0?-1:1)*d/2):new Vector3((i==2?-1:1)*w/2,0,0);
                    edges[i].localScale=horizontal?new Vector3(w,.025f,.04f):new Vector3(.04f,.025f,d);
                    edges[i].GetComponent<Renderer>().sharedMaterial=RestaurantArt.Mat(editor.Valid?RestaurantArt.Hex("47BA6D"):RestaurantArt.Red);
                }
            }
        }
        static void Paint(List<Renderer> renderers,string hex){var material=RestaurantArt.Mat(RestaurantArt.Hex(hex));foreach(var r in renderers)r.sharedMaterial=material;}
    }
}
