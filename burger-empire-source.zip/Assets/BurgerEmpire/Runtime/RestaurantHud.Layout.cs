using UnityEngine;
using UnityEngine.UI;

namespace BurgerEmpire.Unity
{
    public sealed partial class RestaurantHud
    {
        Text layoutMessage,layoutSelection;
        readonly Text[] styleLabels=new Text[3];
        public void BeginLayout()
        {
            if(game.LayoutEditor.Active)return;
            bool resume=modal?resumeAfterModal:!game.Sim.Paused;
            if(modal)ClosePanel();
            started=true;tab="";game.LayoutEditor.Begin(resume);Rebuild();
        }
        public void FinishLayout(bool save)
        {
            if(!game.LayoutEditor.Active||!game.LayoutEditor.Finish(save))return;
            Rebuild();Toast(save?"Restoran düzenin kaydedildi.":"Önceki düzen korundu.");
        }
        void BuildLayoutHud()
        {
            float header=portrait?132:68,bottom=portrait?230:142;
            game.GameCamera.rect=new Rect(safeArea.x/Screen.width,(safeArea.y+bottom*scaleFactor)/Screen.height,
                safeArea.width/Screen.width,(safeArea.height-(header+bottom)*scaleFactor)/Screen.height);
            game.GameCamera.orthographicSize=Mathf.Max(7.1f,8.3f/game.GameCamera.aspect);
            Card("Layout header",root,0,0,width,header,cream,false).raycastTarget=true;
            Label("RESTORANINI DÜZENLE",root,14,5,portrait?width-28:width-370,33,portrait?23:24,red,FontStyle.Bold);
            Label("Vardiya durdu · Renk seçenekleri ücretsiz",root,14,37,portrait?width-28:width-370,24,13,green);
            float by=portrait?72:10;
            Button("VAZGEÇ",root,portrait?12:width-336,by,100,50,RestaurantArt.Hex("E4E8D4"),()=>FinishLayout(false),14);
            Button("İLK DÜZEN",root,portrait?122:width-228,by,100,50,RestaurantArt.Hex("E4E8D4"),()=>game.LayoutEditor.Reset(),13);
            Button("KAYDET",root,portrait?width-122:width-120,by,108,50,red,()=>FinishLayout(true),16);
            float y=height-bottom;
            Card("Layout tools",root,0,y,width,bottom,cream,false).raycastTarget=true;
            layoutSelection=Button("",root,12,y+9,portrait?width-24:260,50,green,()=>game.LayoutEditor.SelectNext(),15).GetComponentInChildren<Text>();
            layoutSelection.transform.parent.name="Sonraki eşya";
            layoutMessage=Label("",root,portrait?12:285,y+(portrait?65:6),portrait?width-24:width-299,portrait?46:56,14,ink);
            float sy=y+(portrait?117:68),sw=(width-36)/3;
            for(int i=0;i<3;i++) {
                int category=i;var b=Button("",root,12+i*(sw+6),sy,sw,54,RestaurantArt.Hex("E4E8D4"),()=>game.LayoutEditor.CycleStyle(category),portrait?12:15);
                b.name=new[]{"Zemin stili","Duvar stili","Mobilya stili"}[i];styleLabels[i]=b.GetComponentInChildren<Text>();
            }
            Label("Yeşil: uygun · Kırmızı: engelli · + / DEKOR alanları yeni eşyalar için ayrıldı",root,12,y+(portrait?179:124),width-24,portrait?42:17,portrait?11:10,muted);
            UpdateLayoutHud();
        }
        void UpdateLayoutHud()
        {
            var editor=game.LayoutEditor;layoutMessage.text=BurgerEmpire.Core.Localization.Text(editor.Message);layoutMessage.color=editor.Valid?ink:red;
            layoutSelection.text=BurgerEmpire.Core.Localization.Text(editor.SelectedName+"  →");
            styleLabels[0].text=BurgerEmpire.Core.Localization.Text("Zemin\n"+new[]{"Klasik karo","Nane karo","Gri taş"}[editor.Draft.floor]);
            styleLabels[1].text=BurgerEmpire.Core.Localization.Text("Duvar\n"+new[]{"Krem","Adaçayı","Somon"}[editor.Draft.wall]);
            styleLabels[2].text=BurgerEmpire.Core.Localization.Text("Mobilya\n"+new[]{"Meşe / Kırmızı","Ceviz / Mavi","Açık / Yeşil"}[editor.Draft.furniture]);
        }
    }
}
