using System;
using System.Collections.Generic;

namespace BurgerEmpire.Core
{
    // Session-only movement state: no progression or save schema change.
    [Serializable] public sealed class CrowdMotion
    {
        public bool waiting;
        public float retryAt,holdUntil,resumeAt;
        public List<Point> detour=new List<Point>();
        public Point returnTo;
        public Point requestFrom;
        public bool backingFor;
        public string requestJob;
        public object yieldingTo;
        public void Reset(){waiting=backingFor=false;retryAt=holdUntil=resumeAt=0;detour.Clear();returnTo=requestFrom=null;yieldingTo=null;requestJob=null;}
    }

    public partial class Simulation
    {
        public const float PersonalSpace=.48f;
        readonly List<Point> crowdPoints=new List<Point>();
        struct Pedestrian
        {
            public object owner;public float x,z;
            public Pedestrian(object owner,float x,float z){this.owner=owner;this.x=x;this.z=z;}
        }
        IEnumerable<Pedestrian> Pedestrians()
        {
            foreach(var a in Actors)yield return new Pedestrian(a,a.x,a.z);
            foreach(var c in Customers)if(!c.drive)yield return new Pedestrian(c,c.x,c.z);
        }
        static float DistanceToSegment(float x,float z,Point a,Point b)
        {
            float dx=b.x-a.x,dz=b.z-a.z,length=dx*dx+dz*dz;
            float t=length<.000001f?0:Math.Max(0,Math.Min(1,((x-a.x)*dx+(z-a.z)*dz)/length));
            dx=x-a.x-t*dx;dz=z-a.z-t*dz;return (float)Math.Sqrt(dx*dx+dz*dz);
        }
        object BlockingPerson(object mover,Point from,Point to)
        {
            foreach(var other in Pedestrians()) {
                if(other.owner==mover)continue;
                float before=WorkZones.Distance(from,new Point(other.x,other.z));
                float after=WorkZones.Distance(to,new Point(other.x,other.z));
                // Layout edits or an old session can begin overlapping; only outward motion is legal.
                if(before<PersonalSpace-.001f&&after>before+.00001f)continue;
                if(DistanceToSegment(other.x,other.z,from,to)<PersonalSpace-.001f)return other.owner;
            }
            return null;
        }
        List<Point> OtherPositions(object mover)
        {
            crowdPoints.Clear();
            foreach(var person in Pedestrians())if(person.owner!=mover)crowdPoints.Add(new Point(person.x,person.z));
            return crowdPoints;
        }
        static Point PositionOf(object person)
        {
            if(person is Actor a)return new Point(a.x,a.z);
            var c=(Customer)person;return new Point(c.x,c.z);
        }
        static CrowdMotion MotionOf(object person){return person is Actor a?a.crowd:((Customer)person).crowd;}
        static List<Point> PathOf(object person){return person is Actor a?a.path:((Customer)person).path;}
        int PassagePriority(object person){return person is Actor a?Actors.IndexOf(a):100+((Customer)person).id;}
        static string JobOf(object person){return person is Actor a?a.job:((Customer)person).phase;}
        static bool BlocksRoute(Point pocket,object requester)
        {
            var previous=PositionOf(requester);
            foreach(var next in PathOf(requester)) {
                if(DistanceToSegment(pocket.x,pocket.z,previous,next)<PersonalSpace+.08f)return true;
                previous=next;
            }
            return false;
        }
        List<Point> ReplanCrowdPath(object mover,Point from,List<Point> path,Point fallback,bool avoidPeople=true)
        {
            int goalIndex=path.Count-1;
            // Seated guests have one final chair-entry segment inside the furniture envelope.
            // Plan to the aisle approach and retain that explicitly authorized final segment.
            while(goalIndex>0&&!LayoutRules.Walkable(P.layout,path[goalIndex]))goalIndex--;
            var goal=goalIndex>=0?path[goalIndex]:fallback;
            var route=avoidPeople?LayoutRules.PathAroundPeople(P.layout,from,goal,OtherPositions(mover),PersonalSpace):LayoutRules.Path(P.layout,from,goal);
            if(route!=null)for(int i=goalIndex+1;i<path.Count;i++)route.Add(path[i]);
            return route;
        }
        bool CrowdStep(object mover,CrowdMotion motion,ref float x,ref float z,Point target,float amount,bool seatAccess=false)
        {
            var from=new Point(x,z);float nx=x,nz=z;bool reached=Move(ref nx,ref nz,target.x,target.z,amount);
            var to=new Point(nx,nz);
            if(!LayoutRules.ClearStructure(from,to))return false;
            if(!seatAccess&&!LayoutRules.ClearWalkSegment(P.layout,from,to))return false;
            if(mover is Actor actor&&DoorBlocks(actor,to,amount)){motion.waiting=true;return false;}
            var blocker=BlockingPerson(mover,from,to);
            if(blocker==null){x=nx;z=nz;motion.waiting=false;return reached;}
            motion.waiting=true;
            if(Time<motion.retryAt)return false;
            motion.retryAt=Time+.5f;
            // A short detour uses the same walls and furniture as the main navigation graph.
            if(!seatAccess) {
                var path=motion.detour.Count>0?motion.detour:PathOf(mover);
                var route=ReplanCrowdPath(mover,from,path,target);
                if(route!=null){path.Clear();path.AddRange(route);return false;}
            }
            if(MotionOf(blocker).returnTo==null) {
                bool idle=blocker is Actor other&&other.job==""&&other.path.Count==0;
                bool movable=blocker is Actor b?b.path.Count>0:((Customer)blocker).phase=="arriving"||((Customer)blocker).phase=="queue"||((Customer)blocker).phase=="walking"||((Customer)blocker).phase=="leaving";
                if(idle||movable&&PassagePriority(mover)<PassagePriority(blocker)) {
                    if(!AskToYield(blocker,mover)&&motion.returnTo==null&&!AskToYield(mover,blocker,true))
                        ClearQueuedPassage(mover,blocker);
                }
            }
            return false;
        }
        void ClearQueuedPassage(object mover,object blocker)
        {
            // Three people can trap the middle worker in a one-person aisle: neither
            // of the first pair can reach a pocket until the worker behind them yields.
            var middle=PositionOf(mover);var front=PositionOf(blocker);
            float dx=middle.x-front.x,dz=middle.z-front.z;
            foreach(var tail in Actors) {
                if(tail==mover||tail==blocker||tail.crowd.returnTo!=null||tail.job!=""&&tail.path.Count==0)continue;
                float tx=tail.x-middle.x,tz=tail.z-middle.z;
                if(tx*dx+tz*dz<=0||tx*tx+tz*tz>4)continue;
                if(AskToYield(tail,blocker))return;
            }
        }
        bool AskToYield(object actor,object requester,bool backing=false)
        {
            var motion=MotionOf(actor);var start=PositionOf(actor);var requesterPoint=PositionOf(requester);
            if(Time<motion.holdUntil)return false;
            motion.holdUntil=Time+1;
            var people=OtherPositions(actor);
            List<Point> best=null;float bestLength=float.PositiveInfinity;
            // Small side steps first; long pockets are needed in the one-person kitchen aisle.
            foreach(float radius in new[]{.85f,1.4f,2.2f,3.4f,5.2f,7f}) {
                for(int direction=0;direction<12;direction++) {
                    double angle=direction*Math.PI/6;
                    var goal=new Point(start.x+(float)Math.Cos(angle)*radius,start.z+(float)Math.Sin(angle)*radius);
                    if(actor is Actor&&!WorkZones.OnFloor(goal.x,goal.z))continue;
                    if(!LayoutRules.Walkable(P.layout,goal)||WorkZones.Distance(goal,requesterPoint)<PersonalSpace*2)continue;
                    if(!backing&&BlocksRoute(goal,requester))continue;
                    // The pocket must lie outside the requester's approach line, not further along the aisle.
                    float dx=start.x-requesterPoint.x,dz=start.z-requesterPoint.z,length=(float)Math.Sqrt(dx*dx+dz*dz);
                    if(length>.01f&&Math.Abs((goal.x-start.x)*dz-(goal.z-start.z)*dx)/length<PersonalSpace+.12f)continue;
                    var route=LayoutRules.PathAroundPeople(P.layout,start,goal,people,PersonalSpace);
                    if(route==null)continue;
                    float cost=0;var previous=start;
                    foreach(var point in route){cost+=WorkZones.Distance(previous,point);previous=point;}
                    if(cost<bestLength){bestLength=cost;best=route;}
                }
                if(best!=null)break;
            }
            if(best==null)return false;
            motion.detour.Clear();motion.detour.AddRange(best);motion.returnTo=start;motion.yieldingTo=requester;
            motion.requestFrom=requesterPoint;motion.requestJob=JobOf(requester);motion.backingFor=backing;
            motion.resumeAt=Time+8;
            motion.waiting=false;return true;
        }
        bool TickCrowdDetour(object owner,CrowdMotion motion,ref float x,ref float z,float amount)
        {
            if(motion.detour.Count>0) {
                if(CrowdStep(owner,motion,ref x,ref z,motion.detour[0],amount))motion.detour.RemoveAt(0);
                return true;
            }
            if(motion.returnTo==null)return false;
            if(owner is Actor parked&&parked.role=="player"&&parked.job==""&&parked.path.Count==0){motion.Reset();return false;}
            var blocker=motion.yieldingTo;
            // In a dead-end aisle the approaching worker first backs into a pocket,
            // then lets the idle occupant leave the aisle before resuming the original job.
            if(motion.backingFor&&blocker is Actor occupant&&occupant.job==""&&occupant.path.Count==0&&occupant.crowd.returnTo==null) {
                if(Time<occupant.crowd.holdUntil){motion.waiting=true;return true;}
                if(AskToYield(occupant,owner)){motion.waiting=true;return true;}
            }
            if(motion.backingFor&&blocker!=null&&MotionOf(blocker).detour.Count>0){motion.waiting=true;return true;}
            bool active=blocker is Actor a?Actors.Contains(a):blocker is Customer c&&Customers.Contains(c);
            if(active&&!motion.backingFor&&Time<motion.resumeAt&&JobOf(blocker)==motion.requestJob) {
                var now=PositionOf(blocker);float dx=motion.returnTo.x-motion.requestFrom.x,dz=motion.returnTo.z-motion.requestFrom.z;
                float length=(float)Math.Sqrt(dx*dx+dz*dz);
                bool passed=length>.001f&&((now.x-motion.returnTo.x)*dx+(now.z-motion.returnTo.z)*dz)/length>PersonalSpace+.1f;
                bool stoppedClear=PathOf(blocker).Count==0&&WorkZones.Distance(now,motion.returnTo)>1.2f;
                if(!passed&&!stoppedClear){motion.waiting=true;return true;}
            }
            if(owner is Actor idle&&idle.job==""&&idle.path.Count==0){motion.Reset();ReturnHome(idle);return false;}
            var originalPath=PathOf(owner);
            var returnPoint=originalPath.Count>0?originalPath[originalPath.Count-1]:motion.returnTo;
            var path=ReplanCrowdPath(owner,new Point(x,z),originalPath,returnPoint,false);
            if(path==null){motion.waiting=true;return true;}
            originalPath.Clear();originalPath.AddRange(path);motion.returnTo=null;motion.yieldingTo=null;motion.waiting=false;
            return true;
        }
    }
}
