using System;
using System.Linq;

namespace BurgerEmpire.Core
{
    public static class CustomerProfiles
    {
        public static string Description(int kind)
        {
            switch(kind) {
                case 1:return "Bekleme toleransı düşük. Siparişi ve servisi geciktirme.";
                case 2:return "İki kişilik burger menüsü seçer; hazırlık ve yemek süresi daha uzundur.";
                case 3:return "Öğle yoğunluğunda daha sık gelir; hızlı hazırlanan burgerleri tercih eder.";
                case 4:return "Bütçesine uyan ürünlerden seçer; yüksek hesap fiyat puanını düşürür.";
                case 5:return "Beklerken fotoğraf çeker. İyi yorumuyla popülerliğini artırabilir.";
                case 6:return "Daha fazla öder; yüksek beklentisi ve sınırlı sabrı vardır.";
                default:return "Açık menüden farklı lezzetler dener; dengeli servis bekler.";
            }
        }
        public static int Portions(Customer c)=>!c.drive&&!c.delivery&&c.kind==2?2:1;
        public static int Budget(int kind,int branch)
        {int amount=kind==4?40:kind==2?100:kind==6?160:80;return (int)Math.Round(amount*(branch==1?1.1f:1));}
        public static Recipe Select(Progress p,int kind,int roll)
        {
            var choices=MenuCatalog.All(p).Where(r=>r.available).ToArray();
            if(kind==4) {
                var affordable=choices.Where(r=>r.price<=Budget(kind,p.activeBranch)).ToArray();
                choices=affordable.Length>0?affordable:new[]{choices.OrderBy(r=>r.price).First()};
            } else if(kind==2)choices=choices.Where(r=>r.station=="grill").ToArray();
            else if(kind==3)choices=choices.Where(r=>r.station=="grill"&&r.seconds<=7).ToArray();
            return choices[(roll&int.MaxValue)%choices.Length];
        }
        public static bool TakingPhoto(Customer c,float time)
        {return c.kind==5&&!c.drive&&!c.delivery&&c.patience>20&&(c.phase=="waiting"||c.phase=="eating")&&(time+c.id)%8<2.5f;}
    }
}
