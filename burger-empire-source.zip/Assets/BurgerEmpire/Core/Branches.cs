using System;
using System.Collections.Generic;

namespace BurgerEmpire.Core
{
    // These fields belong to one restaurant. Wallet, XP and daily rewards stay on Progress.
    [Serializable] public class RestaurantProgress
    {
        public int tables=2,grill=1;
        public RestaurantLayout layout;
        public bool tutorialDone;
        public int cashier,cook,waiter,cleaner,manager,decor,cheese;
        public int fryer=1,blender,doubleBurger;
        public int classicSold,cheeseSold,doubleSold,shakeSold;
        public int chickenBurger,bbqBurger,chocolateShake;
        public int chickenSold,bbqSold,chocolateSold;
        public int served,cooked,cleaned,earned,lost,mission;
        public int driveThru,driveServed,driveEarned,driveLost,driveMission;
        public int delivery,deliveryServed,deliveryEarned,deliveryLost,deliveryMission;
        public float reviewTotal=4.2f;
        public int reviewCount=1;
        public List<CustomerReview> reviews=new List<CustomerReview>();
        public int popularity,influencerShares;
        public int vipArrived,vipServed,vipEarned,vipLost;
        public int servicePriority;
        public ShiftProgress shift=new ShiftProgress();

        public RestaurantProgress Copy(){var copy=new RestaurantProgress();CopyInto(copy);return copy;}
        public void CopyInto(RestaurantProgress target)
        {
            target.tables=tables;target.grill=grill;target.layout=layout?.Copy();target.tutorialDone=tutorialDone;
            target.cashier=cashier;target.cook=cook;target.waiter=waiter;target.cleaner=cleaner;target.manager=manager;
            target.decor=decor;target.cheese=cheese;target.fryer=fryer;target.blender=blender;target.doubleBurger=doubleBurger;
            target.classicSold=classicSold;target.cheeseSold=cheeseSold;target.doubleSold=doubleSold;target.shakeSold=shakeSold;
            target.chickenBurger=chickenBurger;target.bbqBurger=bbqBurger;target.chocolateShake=chocolateShake;
            target.chickenSold=chickenSold;target.bbqSold=bbqSold;target.chocolateSold=chocolateSold;
            target.served=served;target.cooked=cooked;target.cleaned=cleaned;target.earned=earned;target.lost=lost;target.mission=mission;
            target.driveThru=driveThru;target.driveServed=driveServed;target.driveEarned=driveEarned;target.driveLost=driveLost;target.driveMission=driveMission;
            target.delivery=delivery;target.deliveryServed=deliveryServed;target.deliveryEarned=deliveryEarned;target.deliveryLost=deliveryLost;target.deliveryMission=deliveryMission;
            target.reviewTotal=reviewTotal;target.reviewCount=reviewCount;
            target.popularity=popularity;target.influencerShares=influencerShares;
            target.vipArrived=vipArrived;target.vipServed=vipServed;target.vipEarned=vipEarned;target.vipLost=vipLost;
            target.servicePriority=servicePriority;
            target.shift=shift?.Copy()??new ShiftProgress();
            target.reviews=new List<CustomerReview>();
            if(reviews!=null)foreach(var review in reviews)if(review!=null)target.reviews.Add(review.Copy());
        }
    }
    public static class BranchCatalog
    {
        public const int LondonCost=1200,RequiredLevel=8,RequiredServed=30;
        public static string Name(int id){return id==1?"Londra":"İstanbul";}
        public static string Description(int id){return id==1?"Ofis bölgesi · Menü fiyatları %10 yüksek":"İlk restoranın · Klasik mahalle lezzetleri";}
    }

    public partial class Simulation
    {
        // Runtime sessions are frozen while away. As before, only permanent progress is saved to disk.
        sealed class BranchSession
        {
            public List<Customer> customers;
            public List<Actor> actors;
            public List<Table> tables;
            public float time,spawnIn,autoIn,driveSpawnIn,deliverySpawnIn;
            public float doorAngle,doorHold,inspectionIn;
            public int trash;
            public List<Point> floorMess;
            public int nextCustomer;
        }
        readonly Dictionary<int,BranchSession> branchSessions=new Dictionary<int,BranchSession>();
        public int BranchRevision {get;private set;}
        public bool OwnsBranch(int id){return id==0||id==1&&P.londonOpen;}
        public RestaurantProgress BranchProgress(int id)
        {
            if(!OwnsBranch(id))return null;
            return (id==P.activeBranch?P:id==0?P.istanbul:P.london)?.Copy();
        }
        public string LondonLockReason()
        {
            if(P.londonOpen)return "";
            if(Level<BranchCatalog.RequiredLevel)return "Seviye 8 gerekiyor. Şu an: "+Level;
            int served=BranchProgress(0)?.served??0;
            if(served<BranchCatalog.RequiredServed)return "İstanbul'da 30 müşteriye servis yap: "+served+"/30";
            if(P.coins<BranchCatalog.LondonCost)return "1200 coin gerekiyor. Eksik: "+(BranchCatalog.LondonCost-P.coins);
            return "Açılışa hazır! 2 masa, 1 ızgara ve fritöz dahil.";
        }
        public bool CanOpenLondon {get{return !P.londonOpen&&Level>=8&&(BranchProgress(0)?.served??0)>=30&&P.coins>=1200;}}
        public bool OpenLondon(out string message)
        {
            if(!Paused){message="Şube açmak için vardiyayı duraklat.";return false;}
            if(P.londonOpen){message="Londra şuben zaten açık.";return false;}
            if(!CanOpenLondon){message=LondonLockReason();return false;}
            var layout=RestaurantLayout.Default();layout.floor=2;layout.wall=1;layout.furniture=1;
            P.london=new RestaurantProgress{tutorialDone=true,layout=layout};
            P.londonOpen=true;P.coins-=BranchCatalog.LondonCost;
            SwitchBranch(1,out _);message="Londra şuben açıldı! Yeni vardiyanın ilk müşterisini bekliyor.";
            Emit(message,"upgrade");return true;
        }
        public bool SwitchBranch(int id,out string message)
        {
            if(!OwnsBranch(id)){message="Bu şube henüz açık değil.";return false;}
            if(id==P.activeBranch){message="Zaten bu şubedesin.";return false;}
            if(!Paused){message="Şube değiştirmek için vardiyayı duraklat.";return false;}
            PrepareSave();
            branchSessions[P.activeBranch]=new BranchSession{
                customers=new List<Customer>(Customers),actors=new List<Actor>(Actors),tables=new List<Table>(Tables),
                time=Time,spawnIn=spawnIn,autoIn=autoIn,driveSpawnIn=driveSpawnIn,deliverySpawnIn=deliverySpawnIn,nextCustomer=nextCustomer,
                doorAngle=OfficeDoorAngle,doorHold=doorHold,inspectionIn=inspectionIn,trash=Trash,floorMess=new List<Point>(FloorMess)};
            (id==0?P.istanbul:P.london).CopyInto(P);P.activeBranch=id;
            Customers.Clear();Actors.Clear();Tables.Clear();Events.Clear();
            FloorMess.Clear();OfficeDoorAngle=0;doorHold=0;inspectionIn=35;Trash=0;
            if(branchSessions.TryGetValue(id,out var session)) {
                Customers.AddRange(session.customers);Actors.AddRange(session.actors);Tables.AddRange(session.tables);
                Time=session.time;spawnIn=session.spawnIn;autoIn=session.autoIn;driveSpawnIn=session.driveSpawnIn;deliverySpawnIn=session.deliverySpawnIn;nextCustomer=session.nextCustomer;
                OfficeDoorAngle=session.doorAngle;doorHold=session.doorHold;inspectionIn=session.inspectionIn;Trash=session.trash;FloorMess.AddRange(session.floorMess);
            } else {
                Time=0;spawnIn=1;autoIn=0;driveSpawnIn=4;deliverySpawnIn=6;nextCustomer=1;
                SyncTables();Actors.Add(new Actor{role="player",label="Sen",x=8.1f,z=4});SyncStaff();
            }
            BranchRevision++;message=BranchCatalog.Name(id)+" şubesine hoş geldin.";Emit(message);return true;
        }
        public void PrepareSave()
        {
            RefreshAchievements();
            // Flat inherited fields are authoritative for the active branch, preserving v1-v4 saves.
            if(P.activeBranch==0)P.istanbul=P.Copy();else P.london=P.Copy();
        }
    }
}
