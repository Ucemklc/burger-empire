using System;
using System.Collections.Generic;
using System.Linq;

namespace BurgerEmpire.Core
{
    public sealed class AchievementDefinition
    {
        public readonly string id,title,description,unit;
        public readonly int target,reward;
        public AchievementDefinition(string id,string title,string description,int target,int reward,string unit)
        {this.id=id;this.title=title;this.description=description;this.target=target;this.reward=reward;this.unit=unit;}
    }
    public sealed class Achievement
    {
        public AchievementDefinition definition;
        public int current;
        public bool unlocked,claimed;
    }
    public static class AchievementCatalog
    {
        public const int RewardXP=25;
        public static readonly IReadOnlyList<AchievementDefinition> All=Array.AsReadOnly(new[]{
            new AchievementDefinition("firstBurger","İlk burger","Herhangi bir şubede ilk burger menünü sat.",1,40,"burger"),
            new AchievementDefinition("hundredBurgers","Yüz burgerlik lezzet","İstanbul ve Londra'da toplam 100 burger menüsü sat.",100,120,"burger"),
            new AchievementDefinition("burgerMaster","Burger ustası","İki şubede toplam 1.000 burger menüsü sat.",1000,400,"burger"),
            new AchievementDefinition("cleanTables","Pırıl pırıl","Toplam 50 masayı temizle; ekibinin yaptıkları da sayılır.",50,120,"masa"),
            new AchievementDefinition("income","Büyüyen işletme","Müşteri ödemelerinden toplam 10.000 coin kazan.",10000,200,"coin"),
            new AchievementDefinition("millionaire","Burger milyoneri","Müşteri ödemelerinden toplam 1.000.000 coin kazan.",1000000,1000,"coin"),
            new AchievementDefinition("crew","İşi ekibe bırak","Aynı şubede kasiyer, aşçı, garson ve temizlikçi çalıştır.",4,150,"rol"),
            new AchievementDefinition("menu","Menü koleksiyonu","Aynı şubede klasik, cheese, çift katlı ve milkshake aç.",4,150,"ürün"),
            new AchievementDefinition("drive","Yol üstü lezzet","Toplam 25 araca paket teslim et.",25,150,"araç"),
            new AchievementDefinition("delivery","Kapıya kadar","Toplam 25 kurye siparişini tamamla.",25,150,"teslimat"),
            new AchievementDefinition("branches","İki şehir, bir marka","İstanbul ve Londra şubelerini aç.",2,200,"şube"),
            new AchievementDefinition("rating","Mahallenin gözdesi","Bir şubede 20 ödeme ve en az 4,5 genel puana ulaş.",450,150,"puan")
        });
    }
    public partial class Simulation
    {
        struct AchievementStats
        {
            public long burgers,cleaned,earned,drive,delivery;
            public int crew,menu,rating,branches;
            public void Add(RestaurantProgress p)
            {
                if(p==null)return;
                burgers+=(long)p.classicSold+p.cheeseSold+p.doubleSold+p.chickenSold+p.bbqSold;
                cleaned+=p.cleaned;earned+=p.earned;drive+=p.driveServed;delivery+=p.deliveryServed;
                crew=Math.Max(crew,(p.cashier>0?1:0)+(p.cook>0?1:0)+(p.waiter>0?1:0)+(p.cleaner>0?1:0));
                menu=Math.Max(menu,1+(p.cheese>0?1:0)+(p.doubleBurger>0?1:0)+(p.blender>0?1:0));
                if(p.served>=20)rating=Math.Max(rating,(int)Math.Floor(p.reviewTotal/p.reviewCount*100+.001f));
                branches++;
            }
            public int Value(string id)
            {
                long value=0;
                switch(id) {
                    case "firstBurger":case "hundredBurgers":case "burgerMaster":value=burgers;break;
                    case "cleanTables":value=cleaned;break;
                    case "income":case "millionaire":value=earned;break;
                    case "crew":value=crew;break;case "menu":value=menu;break;
                    case "drive":value=drive;break;case "delivery":value=delivery;break;
                    case "branches":value=branches;break;case "rating":value=rating;break;
                }
                return (int)Math.Min(int.MaxValue,Math.Max(0,value));
            }
        }
        AchievementStats AchievementTotals()
        {
            var stats=new AchievementStats();
            // The active flat fields are authoritative. Its saved snapshot must never count twice.
            stats.Add(P);
            if(P.londonOpen)stats.Add(P.activeBranch==0?P.london:P.istanbul);
            return stats;
        }
        void NormalizeAchievements()
        {
            var ids=new HashSet<string>(AchievementCatalog.All.Select(a=>a.id));
            P.achievementsUnlocked=(P.achievementsUnlocked??new List<string>()).Where(ids.Contains).Distinct().ToList();
            P.achievementsClaimed=(P.achievementsClaimed??new List<string>()).Where(ids.Contains).Distinct().ToList();
            foreach(string id in P.achievementsClaimed)if(!P.achievementsUnlocked.Contains(id))P.achievementsUnlocked.Add(id);
        }
        void RefreshAchievements()
        {
            var stats=AchievementTotals();
            foreach(var a in AchievementCatalog.All)
                if(stats.Value(a.id)>=a.target&&!P.achievementsUnlocked.Contains(a.id))P.achievementsUnlocked.Add(a.id);
        }
        public List<Achievement> Achievements()
        {
            var stats=AchievementTotals();
            return AchievementCatalog.All.Select(a=>new Achievement{definition=a,current=stats.Value(a.id),
                unlocked=P.achievementsUnlocked.Contains(a.id),claimed=P.achievementsClaimed.Contains(a.id)}).ToList();
        }
        public int ReadyAchievements=>P.achievementsUnlocked.Count(id=>!P.achievementsClaimed.Contains(id));
        string ClaimAchievement(string id)
        {
            var definition=AchievementCatalog.All.FirstOrDefault(a=>a.id==id);
            if(definition==null)return "Bilinmeyen başarım.";
            RefreshAchievements();
            if(!P.achievementsUnlocked.Contains(id))return "Bu başarım henüz tamamlanmadı.";
            if(P.achievementsClaimed.Contains(id))return "Bu başarımın ödülü zaten alındı.";
            if(P.coins>int.MaxValue-definition.reward||P.xp>int.MaxValue-AchievementCatalog.RewardXP)return "Kayıt değerleri ödül eklemek için çok yüksek.";
            P.achievementsClaimed.Add(id);P.coins+=definition.reward;P.xp+=AchievementCatalog.RewardXP;
            string message=definition.title+" · +"+definition.reward+" coin, +"+AchievementCatalog.RewardXP+" XP";
            Emit(message,"upgrade");return message;
        }
    }
}
