using System;
using System.Linq;

namespace BurgerEmpire.Core
{
    public partial class Simulation
    {
        public const float DeliveryCounterX=9.4f,DeliveryCounterZ=6f,DeliveryPickupX=11.5f,DeliveryBayX=12.7f;
        float deliverySpawnIn=6;
        public int DeliveryCapacity {get{return P.delivery==0?0:P.delivery+1;}}
        public int DeliveryQueue {get{return Customers.Count(c=>c.delivery&&c.phase!="leaving");}}
        public float DeliveryPackingSeconds {get{return P.delivery>=2?.8f:1.6f;}}
        public static int DeliveryPrice(Recipe recipe){return (int)Math.Round(recipe.price*1.15f);}
        public static float DeliveryBayZ(int bay){return 4.5f+bay*1.6f;}
        static bool AtDeliveryPickup(Customer c){return Math.Abs(c.x-DeliveryPickupX)<.02f&&Math.Abs(c.z-DeliveryCounterZ)<.02f;}

        Customer NextServingOrder(Actor actor=null)
        {
            // Reserve the single packaging counter from pickup through handoff; other service can continue.
            bool packing=Actors.Any(a=>a.job=="serve"&&Customers.Any(c=>c.id==a.customer&&c.delivery));
            return PrioritizedCustomer(c=>c.order=="ready"&&c.phase=="waiting"&&!c.reserved&&HandlesChannel(actor,c)&&(!c.delivery||!packing));
        }
        void TickDelivery(float dt)
        {
            if(P.delivery==0||TutorialActive)return;
            deliverySpawnIn-=dt;if(deliverySpawnIn>0)return;
            deliverySpawnIn=(P.delivery==1?40:30)+random.Next(4);
            // Keep a bay occupied until the departing courier has cleared it.
            int bay=Enumerable.Range(0,DeliveryCapacity).Where(i=>!Customers.Any(c=>c.delivery&&c.deliveryBay==i)).DefaultIfEmpty(-1).First();
            if(bay<0)return;
            var recipes=MenuCatalog.All(P).Where(r=>r.available).ToList();var recipe=recipes[random.Next(recipes.Count)];
            float patience=P.delivery==1?110:140;
            var courier=new Customer{id=nextCustomer++,kind=random.Next(6),delivery=true,deliveryBay=bay,name="Kurye",
                x=15,z=DeliveryBayZ(bay),patience=patience,maxPatience=patience,price=DeliveryPrice(recipe),
                product=recipe.id,station=recipe.station,meal=recipe.name};
            Customers.Add(courier);
        }
        void UpdateDelivery(Customer c,float dt)
        {
            if(c.phase=="leaving"){if(Follow(c,dt*3))Customers.Remove(c);return;}
            if(c.phase=="arriving"&&WalkCustomer(c,new Point(DeliveryBayX,DeliveryBayZ(c.deliveryBay)),dt*2.6f))c.phase="queue";
            if(c.order=="packing")WalkCustomer(c,new Point(DeliveryPickupX,DeliveryCounterZ),dt*2.6f);
            c.patience-=dt;if(c.patience<=0){Lose(c);return;}
            UpdateCooking(c,dt);
        }
        void DeliveryExit(Customer c)
        {
            CustomerRoute(c,new Point(15.5f,c.z));
        }
    }
}
