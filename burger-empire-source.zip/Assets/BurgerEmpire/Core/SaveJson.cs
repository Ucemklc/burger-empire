using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace BurgerEmpire.Core
{
    public sealed class FutureSaveException : Exception {}

    // JsonUtility accepts missing fields. Check the entire document and its identity before using it.
    public static class SaveJson
    {
        public const int MaxLength=4*1024*1024;
        public static int Validate(string json)
        {
            var reader=new Reader(json);var fields=reader.Document();
            int version=Number(fields,"version");
            if(version>Progress.CurrentVersion)throw new FutureSaveException();
            if(version<1)throw new FormatException("Unsupported save version");
            foreach(string name in new[]{"coins","xp","tables","grill"})Number(fields,name);
            return version;
        }
        static int Number(Dictionary<string,string> fields,string key)
        {
            if(!fields.TryGetValue(key,out var value)||!int.TryParse(value,NumberStyles.AllowLeadingSign,CultureInfo.InvariantCulture,out int result))throw new FormatException("Missing or invalid "+key);
            return result;
        }
        sealed class Reader
        {
            readonly string text;int pos;
            public Reader(string text){if(string.IsNullOrWhiteSpace(text)||text.Length>MaxLength)throw new FormatException("Invalid save length");this.text=text;}
            void Space(){while(pos<text.Length&&(text[pos]==' '||text[pos]=='\r'||text[pos]=='\n'||text[pos]=='\t'))pos++;}
            bool Take(char c){Space();if(pos<text.Length&&text[pos]==c){pos++;return true;}return false;}
            void Need(char c){if(!Take(c))throw new FormatException("Invalid JSON at "+pos);}
            public Dictionary<string,string> Document(){var result=Object(0);Space();if(pos!=text.Length)throw new FormatException("Trailing JSON data");return result;}
            Dictionary<string,string> Object(int depth)
            {
                Need('{');var fields=new Dictionary<string,string>();if(Take('}'))return fields;
                do {Space();string key=String();Need(':');Space();int start=pos;Value(depth+1);
                    if(fields.ContainsKey(key))throw new FormatException("Duplicate field");fields.Add(key,text.Substring(start,pos-start));
                    if(Take('}'))return fields;Need(',');
                }while(true);
            }
            void Value(int depth)
            {
                if(depth>64)throw new FormatException("JSON nesting limit");Space();if(pos>=text.Length)throw new FormatException("Truncated JSON");
                char c=text[pos];if(c=='{'){Object(depth);return;}if(c=='"'){String();return;}
                if(c=='['){pos++;if(Take(']'))return;do{Value(depth+1);if(Take(']'))return;Need(',');}while(true);}
                foreach(string literal in new[]{"true","false","null"})if(c==literal[0]){if(pos+literal.Length>text.Length||text.Substring(pos,literal.Length)!=literal)throw new FormatException("Invalid literal");pos+=literal.Length;return;}
                if(c=='-')pos++;if(pos>=text.Length)throw new FormatException("Missing number");
                if(text[pos]=='0')pos++;else {if(text[pos]<'1'||text[pos]>'9')throw new FormatException("Invalid number");Digits();}
                if(pos<text.Length&&text[pos]=='.'){pos++;RequiredDigits();}
                if(pos<text.Length&&(text[pos]=='e'||text[pos]=='E')){pos++;if(pos<text.Length&&(text[pos]=='+'||text[pos]=='-'))pos++;RequiredDigits();}
            }
            void Digits(){while(pos<text.Length&&text[pos]>='0'&&text[pos]<='9')pos++;}
            void RequiredDigits(){int start=pos;Digits();if(pos==start)throw new FormatException("Missing digits");}
            string String()
            {
                Need('"');var b=new StringBuilder();while(pos<text.Length){char c=text[pos++];if(c=='"')return b.ToString();
                    if(c<' ')throw new FormatException("Control character");if(c!='\\'){b.Append(c);continue;}
                    if(pos>=text.Length)break;c=text[pos++];switch(c){case '"':case '\\':case '/':b.Append(c);break;
                        case 'b':b.Append('\b');break;case 'f':b.Append('\f');break;case 'n':b.Append('\n');break;case 'r':b.Append('\r');break;case 't':b.Append('\t');break;
                        case 'u':if(pos+4>text.Length||!ushort.TryParse(text.Substring(pos,4),NumberStyles.AllowHexSpecifier,CultureInfo.InvariantCulture,out ushort code))throw new FormatException("Invalid unicode");b.Append((char)code);pos+=4;break;
                        default:throw new FormatException("Invalid escape");}
                }throw new FormatException("Unclosed string");
            }
        }
    }
}
