using System;

namespace BurgerEmpire.Core
{
    public static class OrderSignals
    {
        static readonly string[] classic={"burger","fries","cola"},cheese={"cheese","fries","cola"},doubleBurger={"double","fries","cola"},shake={"shake"};
        static readonly string[] chicken={"chicken","fries","cola"},bbq={"bbq","fries","cola"},chocolate={"chocolate"};
        public static string[] Items(string product)
        {return product=="chicken"?chicken:product=="bbq"?bbq:product=="chocolate"?chocolate:product=="shake"?shake:product=="double"?doubleBurger:product=="cheese"?cheese:classic;}
        public static bool ShowOrder(Customer c)
        {return c.phase!="arriving"&&c.phase!="leaving"&&c.phase!="eating"&&c.phase!="payment"&&c.order!="served";}
        public static float Patience(Customer c){return c.maxPatience<=0?0:Math.Max(0,Math.Min(1,c.patience/c.maxPatience));}
        public static int Emotion(Customer c){float p=Patience(c);return p<.25f?2:p<.55f?1:0;}
        public static string Status(Customer c)
        {return c.order=="ready"?"check":c.order=="cooking"||c.order=="packing"?"spinner":"clock";}
    }
}
