using System;

namespace BurgerEmpire.Core
{
    // Original eight-bar, 104 BPM instrumental loop. Generated once, reused by one voice.
    public static class MusicDesign
    {
        public const int SampleRate=22050;
        public const double Beat=60.0/104,Duration=32*Beat;
        public static float Volume(float value,float fallback=1)
        {return float.IsNaN(value)||float.IsInfinity(value)?fallback:Math.Max(0,Math.Min(1,value));}
        static double Frequency(int midi){return 440*Math.Pow(2,(midi-69)/12.0);}
        static void Note(float[] data,double start,double duration,int midi,double gain,bool bass=false)
        {
            int from=(int)(start*SampleRate),length=(int)(duration*SampleRate);double frequency=Frequency(midi);
            for(int n=0;n<length&&from+n<data.Length;n++) {
                double t=n/(double)SampleRate,u=n/(double)length;
                double envelope=Math.Min(1,t/.012)*Math.Pow(1-u,1.8)*Math.Exp(-t*(bass?2:4));
                double wave=Math.Sin(2*Math.PI*frequency*t)+.20*Math.Sin(4*Math.PI*frequency*t)+.06*Math.Sin(6*Math.PI*frequency*t);
                data[from+n]+=(float)(gain*envelope*wave);
            }
        }
        public static float[] Samples()
        {
            var data=new float[(int)(Duration*SampleRate)];
            int[][] chords={new[]{48,52,55},new[]{45,48,52},new[]{53,57,60},new[]{43,47,50}};
            int[][] melody={new[]{72,-1,76,79,-1,76,74,-1},new[]{72,69,-1,72,76,-1,74,72},new[]{69,-1,72,77,-1,76,72,-1},new[]{71,74,-1,79,77,74,-1,-1},
                new[]{76,-1,79,84,-1,79,76,-1},new[]{76,72,-1,69,72,76,74,-1},new[]{77,-1,76,72,-1,69,72,74},new[]{71,-1,74,79,74,-1,72,-1}};
            var random=new Random(22022);
            for(int bar=0;bar<8;bar++) {
                var chord=chords[bar%4];double start=bar*4*Beat;
                for(int beat=0;beat<4;beat++) {
                    Note(data,start+beat*Beat,Beat*.8,chord[beat%2==0?0:2]-12,.16,true);
                    if(beat%2==1)foreach(int tone in chord)Note(data,start+beat*Beat,Beat*.75,tone+12,.035);
                }
                for(int eighth=0;eighth<8;eighth++) {
                    double t=start+eighth*Beat*.5;
                    if(melody[bar][eighth]>=0)Note(data,t,Beat*.65,melody[bar][eighth],.14);
                    int from=(int)(t*SampleRate),length=(int)(.045*SampleRate);
                    for(int n=0;n<length&&from+n<data.Length;n++) {
                        double u=n/(double)length;
                        data[from+n]+=(float)((random.NextDouble()*2-1)*.018*Math.Sin(Math.PI*u)*Math.Pow(1-u,3));
                    }
                }
            }
            for(int i=0;i<data.Length;i++)data[i]*=(float)Math.Min(1,Math.Min(i,data.Length-1-i)/(SampleRate*.008));
            return data;
        }
    }
}
