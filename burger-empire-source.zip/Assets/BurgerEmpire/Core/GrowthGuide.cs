using System.Collections.Generic;
using System.Linq;

namespace BurgerEmpire.Core
{
    public sealed class GrowthStep
    {
        public string id,title,description,target,detail;
        public bool complete;
    }

    // Read-only suggestions. Offers remain the authority for price and purchase conditions.
    public static class GrowthGuide
    {
        public static List<GrowthStep> Steps(Simulation sim)
        {
            var p=sim.P;var offers=sim.Offers();var result=new List<GrowthStep>();
            result.Add(new GrowthStep{id="shift",title="İlk vardiyanı tamamla",description="Sipariş al, hazırla, servis et, ödemeyi al ve masayı temizle.",complete=p.tutorialDone,target="play",detail="Alt düğmeler sıradaki işi gösterir. İlk müşterinin sabrı tükenmez."});
            Add(result,offers,p,"crew","Ekibini kur","Kasiyer sipariş ve ödeme alır; aşçı hazırlar, garson servis eder, temizlik görevlisi masaları temizler.",
                p.cashier==0?"cashier":p.cook==0?"cook":p.waiter==0?"waiter":p.cleaner==0?"cleaner":"");
            Add(result,offers,p,"menu","Temel menünü genişlet","Cheeseburger, çilekli milkshake ve çift katlı burgeri bu şubede aç.",
                p.cheese==0?"cheese":p.blender==0?"blender":p.doubleBurger==0?"double":"");
            Add(result,offers,p,"flavors","Yeni lezzetler ekle","Tavuk burger, BBQ burger ve çikolatalı milkshake ile seçenekleri artır.",
                p.chickenBurger==0?"chicken":p.bbqBurger==0?"bbq":p.chocolateShake==0?"chocolate":"");
            Add(result,offers,p,"drive","Arabaya servisi aç","Araç siparişleri için yeni bir servis kanalı kur. Ekip ve mutfak kapasiteni de takip et.",p.driveThru==0?"drive":"");
            Add(result,offers,p,"delivery","Kurye teslimatını aç","Paket siparişleriyle restoran dışındaki müşterilere de ulaş.",p.delivery==0?"delivery":"");
            result.Add(new GrowthStep{id="london",title="Londra şubesini aç",description="Ortak bütçe ve seviye kullanılır. Yeni şubenin ekipmanı ve personeli ayrı gelişir.",complete=p.londonOpen,target="Şubeler",
                detail="Seviye "+BranchCatalog.RequiredLevel+" · İstanbul'da "+BranchCatalog.RequiredServed+" servis · "+BranchCatalog.LondonCost+" coin\n"+sim.LondonLockReason()});
            return result;
        }
        static void Add(List<GrowthStep> steps,List<Offer> offers,Progress p,string id,string title,string description,string wanted)
        {
            var step=new GrowthStep{id=id,title=title,description=description,complete=wanted=="",target="Menü",detail="Bu şubede tamamlandı."};
            if(!step.complete) {
                string next=Prerequisite(p,wanted);var offer=offers.First(o=>o.id==next);
                step.target="Geliştirme:"+next;
                step.detail=(next!=wanted?"Önce ":"Sıradaki: ")+offer.name+" · "+offer.cost+" coin\n";
                if(!string.IsNullOrEmpty(offer.lockedReason))step.detail+=offer.lockedReason+"\n";
                step.detail+=p.coins<offer.cost?(offer.cost-p.coins)+" coin eksik. Servis ve görev ödülleriyle biriktirebilirsin.":"Bütçen yeterli.";
            }
            steps.Add(step);
        }
        static string Prerequisite(Progress p,string wanted)
        {
            if(wanted=="bbq"&&p.doubleBurger==0)return Prerequisite(p,"double");
            if((wanted=="double"||wanted=="chicken")&&p.cheese==0)return "cheese";
            if((wanted=="double"||wanted=="bbq"||wanted=="drive"||wanted=="delivery")&&p.grill<2)return "grill";
            if(wanted=="chocolate"&&p.blender==0)return "blender";
            if(wanted=="delivery"&&p.cook==0)return "cook";
            return wanted;
        }
    }
}
