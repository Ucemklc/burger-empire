using System.Collections.Generic;

namespace BurgerEmpire.Core
{
    // Presentation only: every event is consumed once, even when a busier frame is coalesced.
    public static class FeedbackSignals
    {
        public static int Priority(string kind)
        {
            switch(kind){case "upgrade":return 7;case "bad":return 6;case "vip":return 5;case "coin":return 4;case "ready":return 3;case "order":return 2;default:return 1;}
        }
        public static Event Consume(IList<Event> events,ref int lastSeen)
        {
            Event selected=null;int newest=lastSeen;
            foreach(var e in events) {
                if(e==null||e.id<=lastSeen)continue;
                if(e.id>newest)newest=e.id;
                if(selected==null||Priority(e.kind)>Priority(selected.kind)||Priority(e.kind)==Priority(selected.kind)&&e.id>selected.id)selected=e;
            }
            lastSeen=newest;return selected;
        }
        public static string Icon(string kind)
        {switch(kind){case "coin":return "coin";case "upgrade":case "vip":return "crown";case "bad":return "face";case "ready":case "happy":case "clean":return "check";default:return "clock";}}
    }
}
