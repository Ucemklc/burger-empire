using System;

namespace BurgerEmpire.Core
{
    // Current process only. No identifiers, network requests or external analytics.
    public sealed class SessionMeasurements
    {
        public double ActiveSeconds {get;private set;}
        public long Served {get;private set;}
        public long Lost {get;private set;}
        public long Earned {get;private set;}
        public struct Totals {public long served,lost,earned;}
        public static Totals Capture(Progress p)
        {
            var result=new Totals();Add(ref result,p);
            var other=p.activeBranch==1?p.istanbul:p.londonOpen?p.london:null;if(other!=null)Add(ref result,other);return result;
        }
        static void Add(ref Totals t,RestaurantProgress p){t.served+=p.served;t.lost+=p.lost;t.earned+=p.earned;}
        public void Record(float elapsed,Totals before,Totals after)
        {
            if(float.IsNaN(elapsed)||float.IsInfinity(elapsed)||elapsed<0)return;
            ActiveSeconds+=elapsed;Served+=Math.Max(0,after.served-before.served);Lost+=Math.Max(0,after.lost-before.lost);Earned+=Math.Max(0,after.earned-before.earned);
        }
    }
}
