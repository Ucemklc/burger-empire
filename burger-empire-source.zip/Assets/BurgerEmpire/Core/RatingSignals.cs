using System;
using System.Collections.Generic;
using System.Linq;

namespace BurgerEmpire.Core
{
    public static class RatingSignals
    {
        public static readonly string[] Names={"Lezzet","Hız","Temizlik","Fiyat","Hizmet"};
        public static float Clamp(float value,float fallback=1)
        {return float.IsNaN(value)||float.IsInfinity(value)?fallback:Math.Max(1,Math.Min(5,value));}
        public static float Category(CustomerReview r,int category)
        {
            if(!r.measured)return 0;
            switch(category){case 0:return r.completed?r.food:0;case 1:return r.speed;case 2:return r.clean;case 3:return r.completed?r.value:0;default:return r.service;}
        }
        public static float Average(IEnumerable<CustomerReview> reviews,int category)
        {var scores=reviews.Select(r=>Category(r,category)).Where(v=>v>0).ToArray();return scores.Length==0?0:scores.Average();}
        public static int Count(IEnumerable<CustomerReview> reviews,int category)=>reviews.Count(r=>Category(r,category)>0);
        public static void Measure(CustomerReview review,Customer c,Progress p,int bill)
        {
            review.measured=true;
            review.readySeconds=Seconds(c.readySeconds);review.paymentSeconds=Seconds(c.paymentSeconds);review.bill=Math.Max(0,bill);
            review.clean=Clamp(3+review.cleanliness*.02f);
            review.speed=review.completed?Clamp(1+review.patience*.04f-(c.kind==1||c.kind==3?.12f:0)):1;
            review.service=review.completed?Clamp(4.8f+p.decor*.1f-review.paymentSeconds*.04f):1;
            if(!review.completed){review.food=review.value=0;return;}
            review.food=Clamp(5-Math.Max(0,review.readySeconds-4)*.04f);
            float ratio=bill/(float)Math.Max(1,CustomerProfiles.Budget(c.kind,p.activeBranch));
            review.value=Clamp(5-Math.Max(0,ratio-.75f)*(c.kind==4?3.2f:2));
        }
        public static float Overall(CustomerReview r)=>r.completed?Clamp(r.food*.20f+r.speed*.35f+r.clean*.15f+r.value*.1f+r.service*.20f):2;
        public static float Seconds(float value)=>float.IsNaN(value)||float.IsInfinity(value)?0:Math.Max(0,Math.Min(3600,value));
        public static void Normalize(CustomerReview r)
        {
            if(!r.measured){r.food=r.speed=r.clean=r.value=r.service=r.readySeconds=r.paymentSeconds=0;r.bill=0;return;}
            r.speed=Clamp(r.speed);r.clean=Clamp(r.clean);r.service=Clamp(r.service);
            r.food=r.completed?Clamp(r.food):0;r.value=r.completed?Clamp(r.value):0;
            r.readySeconds=Seconds(r.readySeconds);r.paymentSeconds=Seconds(r.paymentSeconds);r.bill=Math.Max(0,r.bill);
        }
    }
}
