using System;
using System.Collections.Generic;

namespace BurgerEmpire.Core
{
    public static class ServicePriorityCatalog
    {
        public const int Arrival=0,Patience=1,Vip=2;
        public const float UrgentSeconds=20;
        public static bool Valid(int mode){return mode>=Arrival&&mode<=Vip;}
        public static string Name(int mode)
        {
            switch(mode){case Patience:return "Sabır öncelikli";case Vip:return "VIP öncelikli";default:return "Sırayla";}
        }
        public static string Description(int mode)
        {
            switch(mode) {
                case Patience:return "Uygun siparişler arasında sabrı en az kalan müşteriye önce hazırlanır ve servis edilir.";
                case Vip:return "VIP misafirler öne alınır. Sabrı 20 saniye ve altına düşen diğer siparişler VIP'den de önce gelir.";
                default:return "Uygun siparişler müşterilerin geliş sırasına göre hazırlanır ve servis edilir.";
            }
        }
    }

    public partial class Simulation
    {
        public bool SetServicePriority(int mode,out string message)
        {
            if(!ServicePriorityCatalog.Valid(mode)){message="Geçersiz servis önceliği.";return false;}
            if(!Paused){message="Önceliği değiştirmek için personel ekranını aç.";return false;}
            if(P.servicePriority==mode){message="Bu öncelik zaten seçili.";return false;}
            P.servicePriority=mode;
            message=BranchCatalog.Name(P.activeBranch)+": "+ServicePriorityCatalog.Name(mode)+" seçildi.";
            return true;
        }
        // Filter role, station and reservation eligibility before comparing priority.
        // Equal priority retains the existing list's arrival order. Assigned work is never preempted.
        Customer PrioritizedCustomer(Func<Customer,bool> eligible)
        {
            Customer best=null;
            foreach(var candidate in Customers) {
                if(!eligible(candidate))continue;
                if(best==null||Before(candidate,best))best=candidate;
            }
            return best;
        }
        bool Before(Customer candidate,Customer current)
        {
            if(P.servicePriority==ServicePriorityCatalog.Patience)return candidate.patience<current.patience;
            if(P.servicePriority!=ServicePriorityCatalog.Vip)return false;
            bool urgent=candidate.patience<=ServicePriorityCatalog.UrgentSeconds;
            bool currentUrgent=current.patience<=ServicePriorityCatalog.UrgentSeconds;
            if(urgent!=currentUrgent)return urgent;
            if(urgent)return candidate.patience<current.patience;
            return VipCatalog.IsVip(candidate)&&!VipCatalog.IsVip(current);
        }
        public Customer UpcomingPreparation {get{return NextCookingOrder();}}
        public Customer UpcomingService {get{return NextServingOrder();}}
    }
}
