using System;

namespace BurgerEmpire.Core
{
    // World-space footprints of fixed scene geometry, including clearance for a person.
    // Door leaves are handled by the simulation; the two jambs always remain solid.
    public struct NavigationSolid
    {
        public readonly string name;
        public readonly float x,z,width,depth,clearance;
        public NavigationSolid(string name,float x,float z,float width,float depth,float clearance)
        {this.name=name;this.x=x;this.z=z;this.width=width;this.depth=depth;this.clearance=clearance;}
    }
    public static class NavigationGeometry
    {
        public static readonly NavigationSolid[] Solids={
            new NavigationSolid("Back wall",5,-.07f,10.4f,.2f,.4f),
            new NavigationSolid("Office back wall",-1.9f,.12f,3.9f,.18f,.4f),
            new NavigationSolid("Office outer wall",-3.86f,2.48f,.18f,4.9f,.4f),
            new NavigationSolid("Office front cutaway",-1.95f,4.87f,3.9f,.18f,.4f),
            new NavigationSolid("Office partition",0,1.65f,.18f,3.3f,.4f),
            new NavigationSolid("Dining side wall",-.07f,7.42f,.2f,5.25f,.4f),
            new NavigationSolid("Door frame lower",0,WorkZones.DoorZ-.73f,.25f,.12f,.4f),
            new NavigationSolid("Door frame upper",0,WorkZones.DoorZ+.73f,.25f,.12f,.4f),
            // Walk around the inward-open leaf; never take a shortcut through its swing.
            new NavigationSolid("Open door clearance",-.65f,WorkZones.DoorZ-.65f,1.4f,.1f,.4f),
            new NavigationSolid("Counter top",4.05f,3.02f,7.4f,1f,.28f),
            new NavigationSolid("Steel top",4.7f,1.1f,8.4f,1.5f,.28f),
            new NavigationSolid("Milkshake worktop",9.25f,1.05f,1.2f,1.2f,.28f),
            new NavigationSolid("Desk oak top",-2.05f,.92f,2.05f,.83f,.28f),
            new NavigationSolid("Filing cabinet",-3.27f,3.45f,.69f,1.15f,.28f),
            new NavigationSolid("Kitchen plant",.6f,2.4f,.45f,.45f,.28f),
            new NavigationSolid("Cleaning cart",9.9f,7.42f,.72f,.80f,.28f),
            new NavigationSolid("Waste bin",9.78f,6.83f,.51f,.48f,.28f),
            new NavigationSolid("Drive worktop",Simulation.DriveWindowX,10.1f,1.83f,.88f,.28f),
            new NavigationSolid("Packaging worktop",10.35f,Simulation.DeliveryCounterZ,1.3f,1.8f,.28f)
        };
        public static bool OnFloor(Point p)
        {
            return p.x>=.3f&&p.x<=15.6f&&p.z>=1.95f&&p.z<=9.7f||
                p.x>=-3.6f&&p.x<=.3f&&p.z>=.55f&&p.z<=4.6f;
        }
        public static bool FloorSegment(Point a,Point b)
        {
            if(!OnFloor(a)||!OnFloor(b))return false;
            if((a.x<.3f)==(b.x<.3f))return true;
            float t=(.3f-a.x)/(b.x-a.x),z=a.z+(b.z-a.z)*t;
            return z>=1.95f&&z<=4.6f;
        }
    }
}
