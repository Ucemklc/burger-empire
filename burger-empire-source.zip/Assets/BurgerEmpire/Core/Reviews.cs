using System;
using System.Collections.Generic;
using System.Linq;

namespace BurgerEmpire.Core
{
    [Serializable] public sealed class CustomerReview
    {
        public int id,kind,channel,patience,cleanliness,paid;
        public string name,product;
        public float stars;
        public bool measured;
        public float food,speed,clean,value,service,readySeconds,paymentSeconds;
        public int bill;
        public bool completed;
        public bool popularityRecorded,influencerShare;
        public int popularityChange;
        public CustomerReview Copy(){return (CustomerReview)MemberwiseClone();}
    }

    public static class ReviewCatalog
    {
        public const int Capacity=12,DailyTarget=5,DailyReward=100;
        public static string Channel(int channel)=>channel==1?"Arabaya servis":channel==2?"Kurye":"Salon";
        public static string Type(int kind)=>new[]{"Müdavim","Acelesi olan","Aile","Ofis çalışanı","Öğrenci","Influencer","VIP misafir"}[Math.Max(0,Math.Min(6,kind))];
        public static string Reason(CustomerReview review)
        {
            if(!review.completed)return "timeout";
            if(review.measured&&review.completed) {
                if(review.value<3.5f)return "price";
                if(review.food<3.8f)return "cold";
                if(review.service<3.8f)return "payment";
            }
            if(review.patience<35)return "slow";
            if(review.cleanliness<75)return "dirty";
            return review.patience>=65?"fast":"good";
        }
        public static string Comment(CustomerReview review)
        {
            switch(Reason(review)) {
                case "price":return "Hesap bütçeme göre yüksekti.";
                case "cold":return "Yemeğim hazırlandıktan sonra uzun süre bekledi.";
                case "payment":return "Yemek sonrası ödeme için fazla bekledim.";
                case "timeout":return review.channel==2?"Paket gelmeyince ayrılmak zorunda kaldım.":"Çok bekledim, siparişimi tamamlayamadan ayrıldım.";
                case "slow":return review.channel==2?"Paketimi aldım ama hazırlanması uzun sürdü.":"Siparişim geldi ama servis biraz yavaştı.";
                case "dirty":return "Siparişim tamamlandı; kirli masalar daha hızlı toplanabilir.";
                case "fast":return review.channel==2?"Paketim hızlıca hazırlandı, yola çıkabildim!":review.channel==1?"Paketimi hızlıca aldım. Tekrar gelirim!":"Hızlı servis ve temiz bir restoran. Tekrar gelirim!";
                default:return review.channel==2?"Paket teslimatı sorunsuz tamamlandı.":"Siparişim sorunsuz tamamlandı. Teşekkürler!";
            }
        }
        public static string Advice(CustomerReview review)
        {
            switch(Reason(review)) {
                case "price":return "Öğrenciler uygun fiyatlı ürünleri seçer; yoğunluk zammı hesabı artırır.";
                case "cold":return "Hazır yemekleri bekletme; garsonu ve servis önceliğini kontrol et.";
                case "payment":return "Yemeği biten müşterilerin ödemesini al; garson desteği beklemeyi azaltır.";
                case "timeout":case "slow":return "Beklemeyi azalt: siparişleri al, mutfağı ve servis ekibini geliştir.";
                case "dirty":return "Masaları temizle veya temizlikçi işe alarak salonu hazır tut.";
                default:return "Bu düzeni koru: hızlı servis ve temiz masalar iyi yorum getirir.";
            }
        }
    }

    public partial class Simulation
    {
        static void NormalizeReviews(RestaurantProgress p)
        {
            var list=(p.reviews??new List<CustomerReview>()).Where(r=>r!=null&&r.id>0&&!float.IsNaN(r.stars)&&!float.IsInfinity(r.stars))
                .GroupBy(r=>r.id).Select(g=>g.Last().Copy()).OrderBy(r=>r.id).ToList();
            if(list.Count>ReviewCatalog.Capacity)list.RemoveRange(0,list.Count-ReviewCatalog.Capacity);
            foreach(var r in list) {
                r.stars=Math.Max(1,Math.Min(5,r.stars));r.kind=Clamp(r.kind,0,6);r.channel=Clamp(r.channel,0,2);
                r.patience=Clamp(r.patience,0,100);r.cleanliness=Clamp(r.cleanliness,0,100);r.paid=Math.Max(0,r.paid);
                r.popularityChange=r.popularityRecorded?Clamp(r.popularityChange,-2,4):0;
                r.influencerShare=r.popularityRecorded&&r.influencerShare&&r.completed&&r.channel==0&&r.kind==5&&r.stars>=4.5f;
                r.name=string.IsNullOrEmpty(r.name)?"Misafir":r.name.Substring(0,Math.Min(24,r.name.Length)).Replace("<","").Replace(">","");
                RatingSignals.Normalize(r);
                if(!MenuCatalog.Known(r.product))r.product="classic";
            }
            p.reviews=list;
        }
        void RecordReview(Customer c,bool completed,float cleanliness,int paid=0,int bill=0)
        {
            float remaining=c.maxPatience>0?c.patience/c.maxPatience:0;
            if(float.IsNaN(remaining)||float.IsInfinity(remaining))remaining=0;
            int id=P.reviews.Count==0?P.reviewCount+1:Math.Max(P.reviewCount+1,P.reviews[P.reviews.Count-1].id+1);
            var review=new CustomerReview{id=id,kind=c.kind,channel=c.delivery?2:c.drive?1:0,
                name=c.name??"Misafir",product=c.product,completed=completed,paid=paid,
                patience=Clamp((int)Math.Round(remaining*100),0,100),cleanliness=Clamp((int)Math.Round(cleanliness),0,100)};
            RatingSignals.Measure(review,c,P,bill);review.stars=RatingSignals.Overall(review);
            P.reviewTotal+=review.stars;P.reviewCount++;
            ApplyPopularity(review);
            P.reviews.Add(review);
            if(P.reviews.Count>ReviewCatalog.Capacity)P.reviews.RemoveAt(0);
            // Only successful visits with at least four stars count; abandoned orders never reward neglect.
            if(completed&&review.stars>=4)P.dailyReviews=Math.Min(ReviewCatalog.DailyTarget,P.dailyReviews+1);
        }
    }
}
