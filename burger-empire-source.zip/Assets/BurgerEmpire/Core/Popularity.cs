using System;

namespace BurgerEmpire.Core
{
    public static class PopularityCatalog
    {
        public static int Score(RestaurantProgress p)=>Math.Max(0,Math.Min(100,p.popularity));
        public static bool TrafficUnlocked(RestaurantProgress p)=>p.tutorialDone&&p.served>=10;
        public static float TrafficBonus(RestaurantProgress p)=>TrafficUnlocked(p)?Score(p)*.25f:0;
        public static float ArrivalMultiplier(RestaurantProgress p)=>1f/(1+TrafficBonus(p)/100f);
        public static int InfluencerChance(RestaurantProgress p,int branch)
        {
            int score=TrafficUnlocked(p)?Score(p):0;
            return branch==1?8+score*12/100:17+score*8/100;
        }
        public static int CustomerKind(RestaurantProgress p,int branch,int roll,int regular,bool lunch=false)
        {
            int chance=InfluencerChance(p,branch);
            if(roll<chance)return 5;
            int vip=VipCatalog.Chance(p);
            if(roll<chance+vip)return VipCatalog.Kind;
            if(branch==1&&roll<chance+vip+(100-chance)*3/5)return 3;
            if(lunch&&roll<chance+vip+(100-chance-vip)*.45f)return 3;
            return Math.Max(0,Math.Min(4,regular));
        }
        public static string Tier(int score)=>score>=75?"Şehrin gözdesi":score>=50?"Adından söz ettiren":score>=25?"Mahallede tanınan":"Yeni keşif";
        public static string Effect(CustomerReview r)
        {
            if(!r.popularityRecorded)return "Önceki ziyaret · Popülerlik ölçülmedi";
            string amount=(r.popularityChange>0?"+":"")+r.popularityChange;
            return (r.influencerShare?"Influencer paylaşımı":"Popülerlik")+" "+amount;
        }
    }
    public partial class Simulation
    {
        void ApplyPopularity(CustomerReview review)
        {
            // One recorded visit has one effect. Old reviews are never replayed on load.
            int before=PopularityCatalog.Score(P);
            review.influencerShare=review.completed&&review.channel==0&&review.kind==5&&review.stars>=4.5f;
            int change=!review.completed?-2:review.influencerShare?4:review.stars>=4?1:-1;
            P.popularity=Clamp(before+change,0,100);
            review.popularityRecorded=true;review.popularityChange=P.popularity-before;
            if(review.influencerShare&&P.influencerShares<int.MaxValue)P.influencerShares++;
        }
    }
}
