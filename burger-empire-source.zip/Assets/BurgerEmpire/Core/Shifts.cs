using System;

namespace BurgerEmpire.Core
{
    [Serializable] public sealed class ShiftProgress
    {
        public bool active,pending,finished;
        public int number,target,served,lost,earned,reviews;
        public float elapsed,reviewTotal;
        public const float Duration=180;
        public bool Success=>finished&&served>=target;
        public float Rating=>reviews>0?reviewTotal/reviews:0;
        public ShiftProgress Copy()=>(ShiftProgress)MemberwiseClone();
        public void Normalize()
        {
            number=Math.Max(0,number);target=Math.Max(1,Math.Min(50,target));
            served=Math.Max(0,served);lost=Math.Max(0,lost);earned=Math.Max(0,earned);reviews=Math.Max(0,reviews);
            elapsed=float.IsNaN(elapsed)||float.IsInfinity(elapsed)?0:Math.Max(0,Math.Min(Duration,elapsed));
            reviewTotal=float.IsNaN(reviewTotal)||float.IsInfinity(reviewTotal)?0:Math.Max(0,Math.Min(reviews*5f,reviewTotal));
            if(active&&elapsed>=Duration){active=false;finished=true;pending=true;}
            if(active){finished=false;pending=false;}else if(!finished)pending=false;
        }
    }

    public partial class Simulation
    {
        public int NextShiftTarget=>P.cashier>0&&P.cook>0&&P.waiter>0?8:4;
        public bool StartShift(out string message)
        {
            if(TutorialActive){message="Önce ilk vardiya rehberini tamamla.";return false;}
            if(P.shift.active){message="Hedef vardiyan zaten sürüyor.";return false;}
            if(P.shift.pending){message="Önce vardiya sonucunu incele.";return false;}
            P.shift=new ShiftProgress{active=true,number=P.shift.number==int.MaxValue?int.MaxValue:P.shift.number+1,target=NextShiftTarget};
            message="Hedef vardiya başladı!";return true;
        }
        public void AcknowledgeShift(){P.shift.pending=false;}
        void RecordShift(float dt,int served,int lost,int earned,int reviews,float rating)
        {
            var s=P.shift;if(!s.active)return;
            s.elapsed=Math.Min(ShiftProgress.Duration,s.elapsed+dt);
            s.served+=Math.Max(0,P.served-served);s.lost+=Math.Max(0,P.lost-lost);s.earned+=Math.Max(0,P.earned-earned);
            int count=Math.Max(0,P.reviewCount-reviews);s.reviews+=count;
            if(count>0)s.reviewTotal+=Math.Max(0,Math.Min(count*5f,P.reviewTotal-rating));
            if(s.elapsed>=ShiftProgress.Duration-.001f) {
                s.elapsed=ShiftProgress.Duration;s.active=false;s.finished=true;s.pending=true;Paused=true;
                Emit("Vardiya tamamlandı. Sonuçlarını incele.","upgrade");
            }
        }
    }
}
