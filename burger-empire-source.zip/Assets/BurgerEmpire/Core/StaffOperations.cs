using System;
using System.Collections.Generic;
using System.Linq;

namespace BurgerEmpire.Core
{
    // Shared coordinates keep the visible workstations and authoritative navigation aligned.
    public static class WorkZones
    {
        public const float DoorZ=3.95f,DoorHalfWidth=.65f;
        public static Point Idle(string role)
        {
            switch(role) {
                case "cashier":return new Point(6.8f,2.16f);
                case "cook":return new Point(3.4f,2.16f);
                case "waiter":return new Point(8.15f,4.05f);
                case "cleaner":return new Point(8.55f,7.35f);
                case "drive":return new Point(8.25f,9.25f);
                case "manager":return new Point(-2.05f,1.85f);
                default:return new Point(8.1f,4);
            }
        }
        public static Point Interaction(string station)
        {
            switch(station) {
                case "cashier":return new Point(7.45f,2.16f);
                case "grill":return new Point(2.35f,2.16f);
                case "fryer":return new Point(4.85f,2.16f);
                case "prep":return new Point(6.05f,2.16f);
                case "blender":return new Point(9.25f,2.16f);
                case "pickup":return new Point(4.7f,3.88f);
                case "cleaner":return new Point(9.25f,7.3f);
                case "drive":return new Point(Simulation.DriveWindowX,Simulation.DriveWindowZ);
                case "manager":return Idle("manager");
                default:return Idle(station);
            }
        }
        public static bool InOffice(float x,float z){return x<.1f&&x>=-3.65f&&z>=.5f&&z<=4.65f;}
        public static bool OnFloor(float x,float z)
        {return InOffice(x,z)||x>=0&&x<=10&&z>=1.95f&&z<=9.7f;}
        public static float Distance(Point a,Point b){float x=a.x-b.x,z=a.z-b.z;return (float)Math.Sqrt(x*x+z*z);}
    }

    public partial class Simulation
    {
        public readonly List<Point> FloorMess=new List<Point>();
        public int Trash {get;private set;}
        public float OfficeDoorAngle {get;private set;}
        float doorHold,inspectionIn=35;
        bool CanTidy {get{return FloorMess.Count>0&&!Actors.Any(a=>a.job=="sweep")||Trash>=3&&!Actors.Any(a=>a.job=="trash");}}

        public Point StaffHome(string role)
        {
            var p=LayoutRules.NearestFree(P.layout,WorkZones.Idle(role));
            // A player's custom table arrangement can move a service aisle.
            return ClearWorkPoint(null,p,role);
        }
        Point ClearWorkPoint(Actor actor,Point desired,string ownRole="")
        {
            var p=LayoutRules.NearestFree(P.layout,desired);
            foreach(float offset in new[]{0f,.65f,-.65f,1.3f,-1.3f}) {
                var candidate=LayoutRules.NearestFree(P.layout,new Point(p.x+offset,p.z));
                if(Actors.All(other=>other==actor||other.role==ownRole||
                    WorkZones.Distance(other.path.Count>0?other.path[other.path.Count-1]:new Point(other.x,other.z),candidate)>=.55f))return candidate;
            }
            return p;
        }
        bool StationRoute(Actor actor,string station)
        {
            var p=ClearWorkPoint(actor,WorkZones.Interaction(station));return Route(actor,p.x,p.z);
        }
        void ReturnHome(Actor actor)
        {
            if(actor.role=="player")return;
            var p=StaffHome(actor.role);if(WorkZones.Distance(p,new Point(actor.x,actor.z))>.06f)Route(actor,p.x,p.z);
        }
        bool HandlesChannel(Actor actor,Customer c)
        {
            if(actor==null||actor.role=="player")return true;
            if(actor.role=="drive")return c.drive;
            return !c.drive; // The dedicated window attendant owns vehicle orders.
        }
        void TickOperations(float dt)
        {
            bool approach=Actors.Any(a=>a.path.Count>0&&Math.Abs(a.x)<2.25f&&Math.Abs(a.z-WorkZones.DoorZ)<1.7f||
                Math.Abs(a.x)<1.75f&&Math.Abs(a.z-WorkZones.DoorZ)<1.0f);
            if(approach)doorHold=1.25f;else doorHold=Math.Max(0,doorHold-dt);
            float goal=doorHold>0?88:0;
            OfficeDoorAngle+=Math.Max(-105*dt,Math.Min(160*dt,goal-OfficeDoorAngle));
            inspectionIn-=dt;
            var manager=Actors.FirstOrDefault(a=>a.role=="manager");
            if(manager!=null&&manager.job==""&&manager.path.Count==0&&inspectionIn<=0) {
                inspectionIn=40;
                if(Customers.Count(c=>c.phase=="queue")>=3||Tables.Count(t=>t.dirty)>=2) {
                    var p=ClearWorkPoint(manager,new Point(8.15f,6.75f));
                    if(Route(manager,p.x,p.z)){manager.job="inspect";manager.timer=0;}
                }
            }
        }
        bool DoorBlocks(Actor a,Point next,float distance)
        {
            if(OfficeDoorAngle>=85)return false;
            float length=WorkZones.Distance(new Point(a.x,a.z),next);
            float fraction=length<=distance||length<.0001f?1:distance/length;
            float x=a.x+(next.x-a.x)*fraction,z=a.z+(next.z-a.z)*fraction;
            // Wait outside the whole moving leaf, from either side, while it opens.
            return x> -1.75f&&x<.55f&&z>WorkZones.DoorZ-1.1f&&z<WorkZones.DoorZ+1.1f;
        }
        bool AssignTidying(Actor a)
        {
            if(FloorMess.Count>0&&!Actors.Any(v=>v.job=="sweep")) {
                if(!Route(a,FloorMess[0].x,FloorMess[0].z))return false;
                a.job="sweep";a.timer=0;a.customer=0;a.table=-1;
                return true;
            }
            if(Trash>=3&&!Actors.Any(v=>v.job=="trash")) {
                if(!StationRoute(a,"cleaner"))return false;
                a.job="trash";a.timer=0;a.customer=0;a.table=-1;return true;
            }
            return false;
        }
        void RecordOperationWaste(Customer c)
        {
            Trash=Math.Min(5,Trash+1);
            if(!c.drive&&!c.delivery&&P.served%3==0&&FloorMess.Count<2&&c.table>=0) {
                var t=Tables[c.table];var p=LayoutRules.NearestFree(P.layout,new Point(t.x+1.25f,t.z+.3f));
                if(FloorMess.All(f=>WorkZones.Distance(f,p)>.5f))FloorMess.Add(p);
            }
        }
    }
}
