using System;

namespace BurgerEmpire.Core
{
    // Original, deterministic mono sounds; no downloads or platform-specific audio codecs.
    public static class SoundDesign
    {
        public const int SampleRate=22050;
        public static readonly string[] Kinds={"click","order","ready","happy","coin","clean","upgrade","bad","vip","grill","blender"};
        public static float Duration(string kind)
        {
            switch(kind){case "click":return .055f;case "order":return .12f;case "ready":return .30f;case "happy":return .16f;
                case "coin":return .24f;case "clean":return .24f;case "upgrade":return .60f;case "bad":return .24f;case "vip":return .48f;
                case "grill":case "blender":return 2;default:return 0;}
        }
        static double Sin(double frequency,double time){return Math.Sin(2*Math.PI*frequency*time);}
        public static float[] Samples(string kind)
        {
            int count=(int)(SampleRate*Duration(kind));var samples=new float[count];var random=new Random(819);
            double filtered=0;bool loop=kind=="grill"||kind=="blender";
            for(int i=0;i<count;i++) {
                double t=i/(double)SampleRate,u=i/(double)(count-1),value;
                double noise=random.NextDouble()*2-1;filtered=filtered*.80+noise*.20;
                if(kind=="grill")value=(filtered*.75+noise*.12)*(.7+.3*Sin(3,t)*Sin(7,t));
                else if(kind=="blender")value=(Sin(90,t)*.48+Sin(180,t)*.18+filtered*.12)*(.8+.2*Sin(4,t));
                else if(kind=="clean")value=filtered*(.6+.4*Sin(18,t));
                else {
                    double frequency=kind=="click"?520:kind=="order"?680:kind=="happy"?440:kind=="bad"?185:kind=="ready"?880:kind=="coin"?1175:660;
                    int notes=kind=="upgrade"?3:kind=="vip"||kind=="ready"||kind=="coin"?2:1;
                    int note=Math.Min(notes-1,(int)(u*notes));double local=(u*notes)-note;
                    frequency*=Math.Pow(kind=="bad"?.8:1.259921,note);
                    double noteEnvelope=Math.Min(1,local/.045)*Math.Pow(1-local,1.6);
                    value=(Sin(frequency,t)*.68+Sin(frequency*2,t)*.16+Sin(frequency*3,t)*.04)*noteEnvelope;
                }
                double edge=Math.Min(1,Math.Min(i,count-1-i)/(SampleRate*.008));
                double envelope=loop?edge:edge*Math.Pow(1-u,.6);
                samples[i]=(float)(value*envelope);
            }
            return samples;
        }
    }
}
