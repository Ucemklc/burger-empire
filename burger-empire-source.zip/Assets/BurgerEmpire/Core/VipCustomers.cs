using System;

namespace BurgerEmpire.Core
{
    public static class VipCatalog
    {
        public const int Kind=6,RequiredPopularity=50;
        public static bool IsVip(Customer c)=>c.kind==Kind&&!c.drive&&!c.delivery;
        public static int Chance(RestaurantProgress p)=>PopularityCatalog.TrafficUnlocked(p)&&PopularityCatalog.Score(p)>=RequiredPopularity?2+(PopularityCatalog.Score(p)-50)*6/50:0;
        public static int Price(int basePrice)=>(int)Math.Min(int.MaxValue,(Math.Max(0,(long)basePrice)*3+1)/2);
        public static float Patience(RestaurantProgress p)=>70+p.decor*25;
        public static string LockReason(RestaurantProgress p)
        {
            if(!p.tutorialDone)return "Önce ilk vardiyanı tamamla.";
            if(p.served<10)return "Şubede 10 ödeme al: "+p.served+" / 10";
            if(p.popularity<RequiredPopularity)return "Popülerliği 50'ye çıkar: "+p.popularity+" / 50";
            return "VIP misafirler bu şubeyi keşfedebilir.";
        }
        public static int Add(int count,int amount)=> (int)Math.Min(int.MaxValue,Math.Max(0,(long)count)+Math.Max(0,amount));
    }
}
