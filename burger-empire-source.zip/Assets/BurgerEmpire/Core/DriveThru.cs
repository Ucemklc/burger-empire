using System;
using System.Linq;

namespace BurgerEmpire.Core
{
    public partial class Simulation
    {
        public const float DriveWindowX=8.8f,DriveWindowZ=9.25f,DriveLaneZ=12f;
        float driveSpawnIn=4;
        public int DriveCapacity {get{return P.driveThru==0?0:P.driveThru+2;}}
        public int DriveQueue {get{return Customers.Count(c=>c.drive&&c.phase!="leaving");}}
        public Customer DriveFront {get{return Customers.FirstOrDefault(c=>c.drive&&c.phase!="leaving");}}
        public static int DrivePrice(Recipe recipe){return (int)Math.Round(recipe.price*1.2f);}

        Customer NextOrder(Actor actor=null)
        {
            bool free=Tables.Any(t=>t.customer==0&&!t.dirty&&!t.reserved);
            var front=DriveFront;
            // Preserve arrival order across channels, skipping diners who cannot get a table yet.
            return Customers.FirstOrDefault(c=>c.phase=="queue"&&!c.reserved&&HandlesChannel(actor,c)&&
                (c.delivery?P.delivery>0:c.drive?P.driveThru>0&&c==front&&Math.Abs(c.x-DriveWindowX)<.02f:free));
        }
        void TickDrive(float dt)
        {
            if(P.driveThru==0||TutorialActive)return;
            driveSpawnIn-=dt;
            if(driveSpawnIn>0)return;
            driveSpawnIn=(P.driveThru==1?32:24)+random.Next(4);
            if(Customers.Count(c=>c.drive)>=DriveCapacity)return;
            var recipes=MenuCatalog.All(P).Where(r=>r.available).ToList();
            var recipe=recipes[random.Next(recipes.Count)];
            float patience=P.driveThru==1?100:120;
            // Enter behind the tail, including any vehicle still approaching from outside view.
            float start=Math.Min(-4,Customers.Where(c=>c.drive&&c.phase!="leaving").Select(c=>c.x-3.3f).DefaultIfEmpty(-4).Min());
            Customers.Add(new Customer{id=nextCustomer++,kind=random.Next(6),drive=true,name="Sürücü",x=start,z=DriveLaneZ,
                patience=patience,maxPatience=patience,price=DrivePrice(recipe),product=recipe.id,station=recipe.station,meal=recipe.name});
        }
        void UpdateDrive(Customer c,float dt)
        {
            if(c.phase=="leaving"){if(Follow(c,dt*4.5f))Customers.Remove(c);return;}
            if(c.phase=="arriving"||c.phase=="queue") {
                int position=Customers.Where(v=>v.drive&&v.phase!="leaving").ToList().IndexOf(c);
                float target=DriveWindowX-position*3.3f;
                if(Move(ref c.x,ref c.z,target,DriveLaneZ,dt*3.1f))c.phase="queue";
            }
            c.patience-=dt;
            if(c.patience<=0){Lose(c);return;}
            UpdateCooking(c,dt);
        }
        void DriveExit(Customer c,bool abandoned=false)
        {
            c.path.Clear();
            // A lost order leaves via the outer lane instead of driving through the queue.
            if(abandoned)c.path.Add(new Point(c.x,14.3f));
            c.path.Add(new Point(19,abandoned?14.3f:DriveLaneZ));
        }
        void UpdateCooking(Customer c,float dt)
        {
            if(c.order!="cooking")return;
            c.cookTime-=dt;
            if(c.cookTime<=0&&!Actors.Any(a=>a.job=="cook"&&a.customer==c.id)){c.order="ready";P.cooked++;Emit(c.delivery?"Kurye menüsü hazır!":c.drive?"Araç paketi hazır!":"Sipariş hazır!","ready",4.7f,2.4f);}
        }
        void TakePayment(Customer c)
        {
            if(c.phase=="leaving")return;
            int tip=(int)(c.price*Math.Max(.03f,c.patience/c.maxPatience*.25f));
            int total=(int)((c.price+tip)*(Rush?1.5f:1f)*(1+P.manager*.1f));
            P.coins+=total;P.earned+=total;P.dailyEarned+=total;P.served++;P.dailyServed++;P.xp+=20;
            if(VipCatalog.IsVip(c)){P.vipServed=VipCatalog.Add(P.vipServed,1);P.vipEarned=VipCatalog.Add(P.vipEarned,total);}
            MenuCatalog.RecordSale(P,c.product);
            int bill=(int)(c.price*(Rush?1.5f:1f)*(1+P.manager*.1f));
            RecordReview(c,true,Cleanliness,total,bill);
            c.phase="leaving";
            RecordOperationWaste(c);
            if(c.delivery){P.deliveryServed++;P.deliveryEarned+=total;DeliveryExit(c);}
            else if(c.drive){P.driveServed++;P.driveEarned+=total;DriveExit(c);}
            else {var t=Tables[c.table];t.customer=0;t.dirty=true;LeaveRoute(c);}
            RefreshAchievements();
            Emit((c.delivery?"Kuryeye teslim! ":c.drive?"Paket teslim! ":VipCatalog.IsVip(c)?"VIP servis! ":"")+"+"+total+" coin · "+tip+" bahşiş","coin",c.x,c.z);
        }
    }
}
