using System;
using System.Collections.Generic;

namespace BurgerEmpire.Core
{
    [Serializable] public sealed class Recipe
    {
        public string id,name,description,station,unlock;
        public int price,familyExtra;
        public float seconds;
        public bool available;
    }
    public static class MenuCatalog
    {
        public static List<Recipe> All(Progress p)
        {
            var recipes=new List<Recipe> {
                new Recipe{id="classic",name="Klasik Menü",description="Burger + patates + kola",station="grill",price=32,familyExtra=24,seconds=6,available=true,unlock=""},
                new Recipe{id="cheese",name="Cheeseburger Menü",description="Peynirli burger + patates + kola",station="grill",price=48,familyExtra=24,seconds=6.5f,available=p.cheese>0,unlock="cheese"},
                new Recipe{id="double",name="Çift Katlı Menü",description="İki köfteli burger + patates + kola",station="grill",price=68,familyExtra=24,seconds=9,available=p.doubleBurger>0,unlock="double"},
                new Recipe{id="shake",name="Çilekli Milkshake",description="Soğuk çilekli içecek · tek ürün",station="blender",price=24,familyExtra=12,seconds=5,available=p.blender>0,unlock="blender"},
                new Recipe{id="chicken",name="Tavuk Burger Menü",description="Izgara tavuk + patates + kola",station="grill",price=44,familyExtra=24,seconds=7,available=p.chickenBurger>0,unlock="chicken"},
                new Recipe{id="bbq",name="Barbekü Menü",description="Barbekü soslu burger + patates + kola",station="grill",price=62,familyExtra=24,seconds=8.5f,available=p.bbqBurger>0,unlock="bbq"},
                new Recipe{id="chocolate",name="Çikolatalı Milkshake",description="Çikolata soslu içecek · tek ürün",station="blender",price=30,familyExtra=12,seconds=6.5f,available=p.chocolateShake>0&&p.blender>0,unlock="chocolate"}
            };
            if(p.activeBranch==1)foreach(var recipe in recipes){recipe.price=(int)Math.Round(recipe.price*1.1f);recipe.familyExtra=(int)Math.Round(recipe.familyExtra*1.1f);}
            return recipes;
        }
        public static Recipe Get(string id,Progress p){return All(p).Find(r=>r.id==id)??All(p)[0];}
        public static float PrepSeconds(Recipe recipe,Progress p)
        {
            if(recipe.station=="blender")return recipe.seconds/(1+Math.Max(0,p.blender-1)*.3f+p.cook*.1f);
            return recipe.seconds/(1+(p.grill-1)*.3f+p.cook*.1f+Math.Max(0,p.fryer-1)*.15f);
        }
        public static bool Known(string id)
        {return id=="classic"||id=="cheese"||id=="double"||id=="shake"||id=="chicken"||id=="bbq"||id=="chocolate";}
        public static int Sales(Progress p,string id)
        {switch(id){case "chicken":return p.chickenSold;case "bbq":return p.bbqSold;case "chocolate":return p.chocolateSold;case "shake":return p.shakeSold;case "double":return p.doubleSold;case "cheese":return p.cheeseSold;default:return p.classicSold;}}
        public static void RecordSale(Progress p,string id)
        {
            int bit=1;
            switch(id){case "chicken":p.chickenSold++;bit=16;break;case "bbq":p.bbqSold++;bit=32;break;case "chocolate":p.chocolateSold++;bit=64;break;case "shake":p.shakeSold++;bit=8;break;case "double":p.doubleSold++;bit=4;break;case "cheese":p.cheeseSold++;bit=2;break;default:p.classicSold++;break;}
            p.dailyMenuMask|=bit;
        }
        public static int Variety(int mask){int count=0;for(int i=0;i<7;i++)if((mask&(1<<i))!=0)count++;return count;}
    }
}
